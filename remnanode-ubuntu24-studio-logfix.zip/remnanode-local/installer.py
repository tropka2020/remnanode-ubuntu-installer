#!/usr/bin/env python3
"""Interactive fresh-server installation for Ubuntu 24.04."""
import argparse
import base64
import getpass
import ipaddress
import json
import os
from pathlib import Path
import re
import secrets
import signal
import shlex
import socket
import sys
import tempfile
import time
from types import SimpleNamespace

import manage as m

NODE_IMAGE = 'remnawave/node:latest'
CADDY_IMAGE = 'caddy:2.11.4'
BACKEND_PORT = 9443
XRAY = '/usr/local/bin/xray'


def read_os():
    data = {}
    for line in Path('/etc/os-release').read_text().splitlines():
        if '=' in line:
            key, value = line.split('=', 1)
            data[key] = value.strip('"')
    return data


def preflight():
    if sys.platform != 'linux' or os.geteuid() != 0:
        raise m.Failure('Мастер запускается от root на Ubuntu 24.04.')
    info = read_os()
    if info.get('ID') != 'ubuntu' or info.get('VERSION_ID') != '24.04':
        raise m.Failure('Этот мастер рассчитан только на Ubuntu 24.04.')
    m.secure_path(m.BASE, directory=True)
    for name in ('installer.py', 'bootstrap.py', 'manage.py', 'site.py', 'themed_site.py',
                 'studio_site.py', 'design_catalog.py', 'design_state.py', 'registry_client.py',
                 'selfsteal.py', 'install-remnanode.sh'):
        m.secure_path(m.BASE / name, directory=False)
        if not (m.BASE / name).is_file():
            raise m.Failure('Нужен полный локальный комплект: отсутствует ' + name)
    if not Path('/run/systemd/system').is_dir():
        raise m.Failure('Для firewall rollback и Docker нужен systemd.')
    for directory in (m.NODE, m.WEB, Path('/opt/nginx-selfsteal')):
        if directory.exists() or directory.is_symlink():
            raise m.Failure('Найдена существующая/частичная установка: ' + str(directory) +
                            '. Мастер ничего не перезаписывает.')
    for port in (80, 443, 2222, BACKEND_PORT):
        m.assert_free(port)
    m.run(['systemctl', 'is-system-running'], check=False)


def prompt_value(label, validator):
    while True:
        value = input(label).strip()
        try:
            return validator(value)
        except (argparse.ArgumentTypeError, ValueError):
            print('Некорректное значение, попробуйте ещё раз.')


def valid_secret(value):
    if not value or len(value.encode('utf-8')) > 16384 or any(
            c.isspace() or ord(c) < 32 or ord(c) == 127 for c in value):
        raise ValueError('Invalid secret')
    return value


def dns_addresses(domain):
    addresses = sorted({record[4][0] for record in socket.getaddrinfo(domain, 443, type=socket.SOCK_STREAM)})
    if not addresses or any(ipaddress.ip_address(a).is_unspecified or
                            ipaddress.ip_address(a).is_loopback or
                            ipaddress.ip_address(a).is_multicast for a in addresses):
        raise m.Failure('Домен не имеет подходящих A/AAAA записей.')
    return addresses


def collect_settings(ssh_ports):
    print('\nRemnawave Node + собственный сайт — новая установка Ubuntu 24.04')
    domain = prompt_value('Домен сайта: ', m.check_domain)
    panel = prompt_value('IPv4 панели Remnawave: ', m.check_ip)
    while True:
        try:
            secret = valid_secret(getpass.getpass('SECRET_KEY из окна создания ноды (ввод скрыт): '))
            break
        except ValueError:
            print('Секрет пустой, слишком длинный или содержит пробелы/управляющие символы.')
    addresses = dns_addresses(domain)
    if any(ipaddress.ip_address(address).version != 4 for address in addresses):
        raise m.Failure('Мастер создаёт IPv4 inbound. Уберите AAAA этого домена до настройки и проверки IPv6.')
    print('DNS домена:', ', '.join(addresses))
    print('Эти адреса должны вести на этот сервер, без HTTP-прокси/CDN.')
    print('Обнаруженные SSH-порты:', ', '.join(map(str, ssh_ports)))
    print('Темы: 1 — растения; 2 — кофе; 3 — фотография; 4 — свой каталог сайта.')
    choice = prompt_value('Тема [1–4]: ', lambda v: v if v in ('1', '2', '3', '4') else int('invalid'))
    source, title, theme = None, '', None
    if choice == '4':
        source = input('Абсолютный путь к подготовленному сайту: ').strip()
        if not Path(source).is_absolute():
            raise m.Failure('Ожидается абсолютный путь.')
        m.site_tool('validate', '--source', source)
    else:
        theme = {'1': 'plants', '2': 'coffee', '3': 'photo'}[choice]
        title = input('Название сайта [Enter — название по теме]: ').strip()
        if len(title) > 120 or any(ord(c) < 32 for c in title):
            raise m.Failure('Некорректное название сайта.')
    print('\nБудут установлены Docker (если отсутствует), нода и Caddy.')
    print('TCP: публичные 80/443, API 2222 только панели, backend 9443 только localhost.')
    print('Будут настроены UFW и logrotate. SSH-порты сохраняются; нужен доступ к консоли провайдера.')
    print('Домен:', domain, '| Панель:', panel, '| Тема:', theme or 'ваш каталог')
    print('Новые образы:', NODE_IMAGE, CADDY_IMAGE, '; после загрузки закрепляются по digest.')
    print('Установка пакетов Docker не откатывается автоматически. Существующие установки не удаляются.')
    if input('DNS верен, snapshot сделан, начать установку? Введите УСТАНОВИТЬ: ').strip() != 'УСТАНОВИТЬ':
        return None
    return SimpleNamespace(domain=domain, panel_ip=panel, secret=secret,
                           source=source, theme=theme, title=title, ssh_ports=ssh_ports)


def resolve_image(reference):
    m.run(['docker', 'pull', reference], timeout=600)
    text = m.run(['docker', 'image', 'inspect', reference], capture=True)
    try:
        obj = json.loads(text)
        digests = obj[0]['RepoDigests']
        if not isinstance(digests, list) or not digests or not all(isinstance(d, str) for d in digests):
            raise ValueError('No valid digest list')
        repository = reference.rsplit(':', 1)[0]
        for digest in digests:
            if digest.split('@', 1)[0] == repository:
                return m.check_image(digest)
        raise ValueError('Unknown repository digest')
    except (ValueError, KeyError, IndexError, TypeError, argparse.ArgumentTypeError) as exc:
        raise m.Failure('Не удалось закрепить доверенный образ по digest: ' + reference) from exc


def parse_keypair(text):
    fields = {}
    for line in text.splitlines():
        if ':' in line:
            key, value = line.split(':', 1)
            fields[re.sub(r'\s+', '', key).lower()] = value.strip()
    private = fields.get('privatekey')
    public = fields.get('publickey') or fields.get('password') or fields.get('password(publickey)')
    for value in (private, public):
        if not isinstance(value, str) or not re.fullmatch(r'[A-Za-z0-9_-]{43}', value):
            raise m.Failure('Неизвестный формат xray x25519. Ключи не выводятся; установка остановлена.')
        try:
            if len(base64.urlsafe_b64decode(value + '=')) != 32:
                raise ValueError('Length')
        except ValueError as exc:
            raise m.Failure('Xray вернул некорректный ключ.') from exc
    return private, public


def build_profile(domain, private, short_id, inbound_tag='VLESS_REALITY'):
    return {
        'log': {'loglevel': 'warning', 'access': '/var/log/remnanode/access.log',
                'error': '/var/log/remnanode/error.log'},
        'inbounds': [{
            'tag': inbound_tag, 'listen': '0.0.0.0', 'port': 443, 'protocol': 'vless',
            'settings': {'clients': [], 'decryption': 'none'},
            'streamSettings': {'network': 'raw', 'security': 'reality', 'realitySettings': {
                'show': False, 'target': '127.0.0.1:9443', 'xver': 0,
                'serverNames': [domain], 'privateKey': private, 'shortIds': [short_id]}},
            'sniffing': {'enabled': True, 'destOverride': ['http', 'tls', 'quic']}}],
        'outbounds': [{'tag': 'DIRECT', 'protocol': 'freedom'}, {'tag': 'BLOCK', 'protocol': 'blackhole'}]
    }


def generate_profile(image, directory, domain):
    output = m.run(['docker', 'run', '--rm', '--network', 'none', '--entrypoint', XRAY,
                    image, 'x25519'], capture=True)
    private, public = parse_keypair(output)
    short_id = secrets.token_hex(8)
    inbound_tag = 'VLESS_REALITY_' + short_id
    profile = build_profile(domain, private, short_id, inbound_tag)
    m.write_json(directory / 'config-profile.json', profile)
    logs = directory / 'validation-logs'
    logs.mkdir(mode=0o700)
    m.run(['docker', 'run', '--rm', '--network', 'none', '--entrypoint', XRAY,
           '--mount', f'type=bind,src={directory / "config-profile.json"},dst=/config.json,readonly',
           '--mount', f'type=bind,src={logs},dst=/var/log/remnanode',
           image, 'run', '-test', '-config', '/config.json'])
    version = m.run(['docker', 'run', '--rm', '--network', 'none', '--entrypoint', XRAY,
                     image, 'version'], capture=True)
    m.atomic_write(directory / 'xray-version.txt', version)
    m.write_json(directory / 'host-settings.json', {
        'address': domain, 'port': 443, 'sni': domain, 'security': 'reality',
        'transport': 'raw', 'flow': 'xtls-rprx-vision', 'publicKey': public,
        'shortId': short_id, 'fingerprint': 'chrome', 'inboundTag': inbound_tag})
    return public, short_id


def backend_config(domain):
    return '''{
    admin off
    https_port 9443
    auto_https disable_redirects
    servers {
        protocols h1 h2
    }
}
http://DOMAIN {
    redir https://DOMAIN{uri} permanent
}
https://DOMAIN {
    bind 127.0.0.1
    root * /var/www/html
    encode gzip
    tls {
        issuer acme {
            disable_tlsalpn_challenge
        }
    }
    file_server
    log {
        output file /var/log/caddy/access.log {
            roll_size 10MB
            roll_keep 5
            roll_keep_for 720h
        }
        format json
    }
}
'''.replace('DOMAIN', domain)


def prepare_backend(source, image, domain):
    m.site_tool('copy', '--source', source, '--output', m.WEB / 'html')
    m.atomic_write(m.WEB / 'Caddyfile', backend_config(domain))
    (m.WEB / 'logs').mkdir(mode=0o750, exist_ok=True)
    m.write_json(m.WEB / 'docker-compose.yml', {
        'services': {'caddy': {
            'image': image, 'container_name': 'remnanode-web', 'restart': 'unless-stopped',
            'network_mode': 'host', 'volumes': ['./html:/var/www/html:ro',
                './Caddyfile:/etc/caddy/Caddyfile:ro', './logs:/var/log/caddy',
                'caddy_data:/data', 'caddy_config:/config'],
            'logging': {'driver': 'json-file', 'options': {'max-size': '10m', 'max-file': '3'}}}},
        'volumes': {'caddy_data': {}, 'caddy_config': {}}})
    m.compose(m.WEB, 'config', '--quiet')
    m.compose(m.WEB, 'run', '--rm', '--no-deps', 'caddy', 'caddy', 'validate',
              '--config', '/etc/caddy/Caddyfile', '--adapter', 'caddyfile')


def install_selfsteal_command():
    if sys.platform != 'linux':
        return
    target = Path('/usr/local/bin/selfsteal')
    script = m.BASE / 'selfsteal.py'
    wrapper = '#!/bin/sh\nexec /usr/bin/python3 ' + shlex.quote(str(script)) + ' "$@"\n'
    if target.exists() or target.is_symlink():
        if target.is_symlink() or target.read_text(encoding='utf-8') != wrapper:
            raise m.Failure('Команда /usr/local/bin/selfsteal уже занята; чужой файл не перезаписывается.')
        return
    m.atomic_write(target, wrapper, mode=0o755)


def prepare_node(secret, image):
    logdir = m.secure_path('/var/log/remnanode', directory=True, allow_system_parent=True)
    logdir.mkdir(mode=0o750, exist_ok=True)
    m.write_json(m.NODE / 'docker-compose.yml', {'services': {'remnanode': {
        'image': image, 'container_name': 'remnanode', 'hostname': 'remnanode',
        'network_mode': 'host', 'restart': 'unless-stopped', 'cap_add': ['NET_ADMIN'],
        'ulimits': {'nofile': {'soft': 1048576, 'hard': 1048576}},
        'environment': {'NODE_PORT': '2222', 'SECRET_KEY': secret.replace('$', '$$')},
        'volumes': ['/var/log/remnanode:/var/log/remnanode'],
        'logging': {'driver': 'json-file', 'options': {'max-size': '10m', 'max-file': '3'}}}}})
    m.compose(m.NODE, 'config', '--quiet')


def confirm_ssh():
    print('\nUFW настроен, но пока действует таймер автоматического восстановления (5 минут).')
    print('Откройте НОВОЕ SSH-подключение к серверу. Не закрывайте текущую сессию.')
    print('Если вход не работает, ничего не подтверждайте: firewall восстановится автоматически.')
    print('При установке из консоли провайдера также проверьте SSH отдельным подключением.')
    # A signal deadline prevents confirmation after the rollback window has expired.
    def expired(signum, frame):
        raise m.Failure('Истекло время подтверждения SSH; требуется восстановление firewall.')
    previous = signal.signal(signal.SIGALRM, expired)
    signal.alarm(180)
    try:
        if input('Новое SSH-подключение работает? Введите SSH РАБОТАЕТ: ').strip() != 'SSH РАБОТАЕТ':
            raise m.Failure('SSH не подтверждён. Изменения отменяются.')
    finally:
        signal.alarm(0)
        signal.signal(signal.SIGALRM, previous)


def archive_failed(directory, label):
    if directory.exists():
        target = m.backup_dir(label) / directory.name
        directory.rename(target)
        print('Сохранены файлы неудачной установки:', target)


def install(settings, bootstrap):
    from design_state import prepare_design
    manifest_path = prepare_design(settings)
    bootstrap.ensure_packages()
    bootstrap.ensure_docker()
    for name in ('remnanode', 'remnanode-web', 'caddy-selfsteal'):
        if m.inspect(name) is not None:
            raise m.Failure('Контейнер уже существует: ' + name)
    for port in (80, 443, 2222, BACKEND_PORT):
        m.assert_free(port)
    node_image, caddy_image = resolve_image(NODE_IMAGE), resolve_image(CADDY_IMAGE)
    print('Образы закреплены:', node_image, caddy_image)
    guard = None
    node_owned = web_owned = False
    attempted_start = False
    deployment = m.backup_dir('setup')
    m.write_json(deployment / 'install-state.json', {'domain': settings.domain, 'node_image': node_image,
                 'caddy_image': caddy_image, 'status': 'preparing'})
    if manifest_path is not None:
        m.atomic_write(deployment / 'site-manifest.json', manifest_path.read_text(encoding='utf-8'))
    with tempfile.TemporaryDirectory(prefix='remnanode-site-', dir='/opt') as temp:
        source = settings.source
        if source is None:
            source = str(Path(temp) / 'public')
            command = [sys.executable, m.BASE / 'studio_site.py', '--theme', settings.theme,
                       '--output', source, '--manifest', manifest_path]
            if settings.title:
                command += ['--title', settings.title]
            m.run(command)
        m.site_tool('validate', '--source', source)
        try:
            public, short_id = generate_profile(node_image, deployment, settings.domain)
            # Ownership flags are set immediately after mkdir, before the first possible write failure.
            m.secure_path(m.WEB)
            m.secure_path(m.NODE)
            m.WEB.mkdir(mode=0o755)
            web_owned = True
            prepare_backend(source, caddy_image, settings.domain)
            m.NODE.mkdir(mode=0o700)
            node_owned = True
            prepare_node(settings.secret, node_image)
            bootstrap.install_logrotate()
            guard = bootstrap.prepare_firewall(settings.panel_ip, settings.ssh_ports)
            guard.apply()
            confirm_ssh()
            guard.commit()
            attempted_start = True
            m.compose(m.WEB, 'up', '-d', '--no-build', '--pull', 'never')
            m.wait_https(settings.domain, BACKEND_PORT,
                         (m.WEB / 'html/index.html').read_text(encoding='utf-8'), timeout=180)
            m.compose(m.NODE, 'up', '-d', '--no-build', '--pull', 'never')
            m.wait_container('remnanode', 2222)
            for name in ('config-profile.json', 'host-settings.json', 'xray-version.txt'):
                m.atomic_write(m.NODE / name, (deployment / name).read_text(encoding='utf-8'))
            m.write_json(m.NODE / 'managed.json', {'version': 2, 'panel_ip': settings.panel_ip,
                         'domain': settings.domain, 'image': node_image, 'inbound_applied': False})
            m.write_json(m.WEB / 'managed.json', {'version': 2, 'domain': settings.domain,
                         'image': caddy_image, 'https_port': BACKEND_PORT, 'purpose': 'local-backend'})
            install_selfsteal_command()
            m.write_json(deployment / 'install-state.json', {'status': 'ready-for-panel',
                         'domain': settings.domain, 'node_image': node_image, 'caddy_image': caddy_image})
            write_instructions(settings, public, short_id)
        except BaseException:
            # Do not restore old firewall or move mounts unless every attempted service is stopped.
            if attempted_start:
                if node_owned:
                    m.compose(m.NODE, 'down')
                    m.confirm_stopped('remnanode')
                if web_owned:
                    m.compose(m.WEB, 'down')
                    m.confirm_stopped('remnanode-web')
            if guard is not None:
                guard.rollback()
            if node_owned:
                archive_failed(m.NODE, 'failed-node-wizard')
            if web_owned:
                archive_failed(m.WEB, 'failed-web-wizard')
            raise
    settings.secret = ''
    print('\nУстановка подготовлена: нода доступна API панели, сертификат и сайт проверены на localhost:9443.')
    print('Публичный 443 начнёт работать ПОСЛЕ применения профиля из панели.')
    print('Инструкция:', m.NODE / 'PANEL-SETUP.txt')
    print('Профиль с ПРИВАТНЫМ ключом:', m.NODE / 'config-profile.json', '(права 600)')
    print('Настройки Host без приватного ключа:', m.NODE / 'host-settings.json')
    print('Резервирование и состояние:', deployment)
    if manifest_path is not None:
        print('Закрытый manifest дизайна (не в сайте):', manifest_path)


def write_instructions(settings, public, short_id):
    text = f'''УСТАНОВЛЕНО, НО ПРОФИЛЬ ЕЩЁ НУЖНО ПРИМЕНИТЬ В ПАНЕЛИ

1. Добавьте ноду в Remnawave: адрес {settings.domain} (либо IP сервера), API-порт 2222.
   Используйте тот SECRET_KEY, который был скопирован из формы панели при установке.
2. Создайте Config Profile. Содержимое /opt/remnanode/config-profile.json предназначено
   для серверной конфигурации; оно содержит ПРИВАТНЫЙ ключ, не отправляйте его клиентам.
   Xray проверил синтаксис этого файла, но схема конкретной версии панели не проверялась.
3. Назначьте профиль ноде, включите inbound VLESS_REALITY_{short_id} и свяжите его с нужным
   Internal Squad. Пустой clients — намеренно: пользователей должна подставить панель.
4. Создайте Host, свяжите с этим inbound и нодой:
   Address: {settings.domain} (DNS должен указывать непосредственно на сервер)
   Port: 443
   SNI: {settings.domain}
   Security: reality; transport: raw (TCP); flow: xtls-rprx-vision
   Public Key: {public}
   Short ID: {short_id}
   Fingerprint: chrome
   Названия полей могут отличаться в вашей версии панели.
5. На сервере inbound использует target 127.0.0.1:9443, xver 0.
   Не открывайте 9443 наружу. Caddy работает без обязательного PROXY header.
6. Настройки log в профиле направляют Xray access/error в /var/log/remnanode.
   logrotate: 50M, 5 архивов, compress, copytruncate. Порог проверяется по расписанию.
7. После применения профиля проверьте публичный HTTPS и подключение пользователя
   с внешнего клиента. Проверка localhost не заменяет внешнюю проверку TCP/443.
   Для IPv6 inbound этого примера слушает IPv4; не публикуйте AAAA для VPN-адреса,
   пока не настроен и не проверен IPv6 inbound в панели.

Docker-образы закреплены по digest в Compose. Сертификаты Caddy — в постоянном volume.
Переустановка мастером поверх текущей установки запрещена. Для замены сайта используйте
manage.py publish-site --container remnanode-web --domain {settings.domain} --port 9443 ...
'''
    m.atomic_write(m.NODE / 'PANEL-SETUP.txt', text)


def main():
    os.umask(0o077)
    def interrupted(signum, frame):
        raise KeyboardInterrupt
    signal.signal(signal.SIGTERM, interrupted)
    preflight()
    import bootstrap
    ssh_ports = bootstrap.discover_ssh_ports()
    settings = collect_settings(ssh_ports)
    if settings is None:
        print('Установка отменена, системные изменения не выполнялись.')
        return
    with m.lock():
        preflight()
        install(settings, bootstrap)


if __name__ == '__main__':
    try:
        main()
    except (m.Failure, OSError, ValueError, EOFError) as error:
        print('ОШИБКА:', error, file=sys.stderr)
        print('Не перезапускайте удаление/установку вслепую. Проверьте журналы и /var/backups/remnanode-local.', file=sys.stderr)
        sys.exit(1)
    except KeyboardInterrupt:
        print('Установка прервана. Проверьте состояние служб и резервирование.', file=sys.stderr)
        sys.exit(130)
