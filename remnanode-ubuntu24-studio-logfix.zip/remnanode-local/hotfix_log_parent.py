#!/usr/bin/env python3
"""Apply only the known root:syslog /var/log compatibility fix, with backups."""
import ast
import os
from pathlib import Path
import shutil
import tempfile

root = Path('/opt/remnanode-local')
if os.geteuid() != 0:
    raise SystemExit('Запустите от root.')

old_header = 'def secure_path(path, *, directory=None):'
new_header = 'def secure_path(path, *, directory=None, allow_system_parent=False):'
old_check = '        if info.st_uid != 0 or info.st_mode & 0o022:\n'
new_check = '''        trusted_log_parent = False
        if (allow_system_parent and path == Path(os.path.abspath('/var/log/remnanode')) and
                part == Path(os.path.abspath('/var/log')) and stat.S_ISDIR(info.st_mode) and
                info.st_uid == 0 and not info.st_mode & 0o002):
            import grp
            try:
                trusted_log_parent = info.st_gid == grp.getgrnam('syslog').gr_gid
            except KeyError:
                pass
        if info.st_uid != 0 or (info.st_mode & 0o022 and not trusted_log_parent):
'''
changes = {}
for name in ('manage.py', 'installer.py'):
    path = root / name
    if path.is_symlink() or not path.is_file():
        raise SystemExit('Неверный путь: ' + str(path))
    text = path.read_text(encoding='utf-8')
    original = text
    if name == 'manage.py':
        if old_header not in text or text.count(old_check) != 1:
            raise SystemExit('Версия manage.py отличается или исправление уже применено; ничего не менялось.')
        text = text.replace(old_header, new_header, 1).replace(old_check, new_check, 1)
    old_call = "secure_path('/var/log/remnanode', directory=True)"
    new_call = "secure_path('/var/log/remnanode', directory=True, allow_system_parent=True)"
    if text.count(old_call) != 1:
        raise SystemExit('Неожиданный вызов в ' + name + '; ничего не менялось.')
    text = text.replace(old_call, new_call, 1)
    ast.parse(text, filename=name)
    changes[path] = (original, text)

os.umask(0o077)
backup = Path(tempfile.mkdtemp(prefix='remnanode-logfix-', dir='/root'))
for path, (original, text) in changes.items():
    shutil.copy2(path, backup / path.name)
for path, (original, text) in changes.items():
    fd, temporary = tempfile.mkstemp(prefix='.logfix-', dir=root)
    with os.fdopen(fd, 'w', encoding='utf-8', newline='\n') as stream:
        stream.write(text)
        stream.flush()
        os.fsync(stream.fileno())
    os.chmod(temporary, path.stat().st_mode & 0o777)
    os.replace(temporary, path)
print('Исправление применено. Резервная копия:', backup)
print('Права /var/log не менялись. SHA256SUMS прежнего комплекта больше не соответствует двум исправленным файлам.')
