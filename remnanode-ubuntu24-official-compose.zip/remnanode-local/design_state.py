"""Private, replayable design reservations; no state is written into a website."""
import getpass
import hashlib
import json
from pathlib import Path
import secrets
import uuid

import manage as m
from design_catalog import VERSION, all_compositions, validate_manifest

STATE = Path('/var/lib/remnanode-design')


def fingerprint(settings):
    data = {'domain': settings.domain, 'theme': settings.theme, 'title': settings.title}
    return hashlib.sha256(json.dumps(data, sort_keys=True, ensure_ascii=False).encode('utf-8')).hexdigest()


def private_file(path):
    m.secure_path(path, directory=False)
    if path.exists() and path.stat().st_mode & 0o077:
        raise m.Failure('Состояние дизайна должно иметь закрытые права 600.')
    return path


def read_object(path):
    if path.stat().st_size > 32768:
        raise m.Failure('Некорректный размер состояния дизайна.')
    try:
        return json.loads(path.read_text(encoding='utf-8'))
    except (ValueError, UnicodeError) as exc:
        raise m.Failure('Повреждено состояние дизайна; автоматический сброс запрещён.') from exc


def prepare_design(settings):
    if settings.source is not None:
        return None
    m.secure_path(STATE, directory=True)
    if not STATE.exists():
        STATE.mkdir(mode=0o700)
    if STATE.stat().st_mode & 0o077:
        raise m.Failure('Каталог состояния дизайна должен иметь права 700.')
    pending_path = private_file(STATE / 'request.json')
    manifest_path = private_file(STATE / 'site-manifest.json')
    identity = fingerprint(settings)
    if pending_path.exists():
        request = read_object(pending_path)
        if (not isinstance(request, dict) or set(request) != {'identity', 'request_id', 'registry_url', 'mode'} or
                request['identity'] != identity or request['mode'] not in ('registry', 'offline')):
            raise m.Failure('Сохранён другой/некорректный запрос дизайна. Изучите private state; он не удаляется автоматически.')
        try:
            if str(uuid.UUID(request['request_id'])) != request['request_id']:
                raise ValueError()
        except (ValueError, TypeError, AttributeError) as exc:
            raise m.Failure('Некорректный идентификатор запроса дизайна.') from exc
    else:
        print('\nДля неповторяющихся композиций на РАЗНЫХ серверах нужен один общий реестр.')
        print('Введите HTTPS URL реестра. Для автономного режима БЕЗ такой гарантии введите АВТОНОМНО.')
        target = input('Реестр дизайнов: ').strip()
        if target == 'АВТОНОМНО':
            request = {'identity': identity, 'request_id': str(uuid.uuid4()), 'registry_url': None, 'mode': 'offline'}
        else:
            from registry_client import validate_registry_url
            try:
                validate_registry_url(target)
            except ValueError as exc:
                raise m.Failure('Нужен корректный HTTPS URL реестра; автоматического offline fallback нет.') from exc
            request = {'identity': identity, 'request_id': str(uuid.uuid4()), 'registry_url': target, 'mode': 'registry'}
        m.write_json(pending_path, request)
    if request['mode'] == 'registry':
        from registry_client import validate_registry_url
        try:
            validate_registry_url(request['registry_url'])
        except (ValueError, TypeError) as exc:
            raise m.Failure('Некорректный сохранённый URL реестра; автоматический сброс запрещён.') from exc
    elif request['registry_url'] is not None:
        raise m.Failure('Некорректное автономное состояние дизайна.')
    if manifest_path.exists():
        try:
            manifest = validate_manifest(read_object(manifest_path))
        except (ValueError, TypeError) as exc:
            raise m.Failure('Повреждён design manifest; повторная выдача вместо него запрещена.') from exc
        if manifest['request_id'] != request['request_id']:
            raise m.Failure('Manifest и запрос дизайна не соответствуют друг другу.')
        print('Повторно используется сохранённый дизайн:', manifest['composition']['direction'])
        return manifest_path
    if request['mode'] == 'offline':
        manifest = {'schema': 1, 'version': VERSION, 'request_id': request['request_id'],
                    'reservation_id': str(uuid.uuid4()), 'seed': secrets.token_hex(32),
                    'composition': secrets.choice(all_compositions())}
        print('Автономный режим: отсутствие повторов между серверами НЕ подтверждается.')
    else:
        from registry_client import reserve_remote, RegistryError
        token = getpass.getpass('Токен общего реестра (скрытый ввод, не сохраняется): ')
        try:
            manifest = reserve_remote(request['registry_url'], token, request['request_id'])
        except (RegistryError, ValueError) as exc:
            raise m.Failure('Реестр не подтвердил новый дизайн. Запрос сохранён для безопасного повтора; установка остановлена.') from exc
        finally:
            token = ''
    try:
        manifest = validate_manifest(manifest)
    except (ValueError, TypeError) as exc:
        raise m.Failure('Некорректный ответ дизайна; установка остановлена.') from exc
    if manifest['request_id'] != request['request_id']:
        raise m.Failure('Ответ дизайна относится к другому запросу.')
    m.write_json(manifest_path, manifest)
    label = 'Новая композиция подтверждена реестром:' if request['mode'] == 'registry' else 'Автономная композиция сохранена:'
    print(label, manifest['composition']['direction'])
    return manifest_path
