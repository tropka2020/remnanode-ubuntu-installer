"""Portable selfsteal contracts: mocks/tempdirs only, no Docker or network.

Run: python -B -m unittest discover -s tests -p test_selfsteal.py -v
Linux ownership, real TLS/ACME and Docker are deliberately not integration-tested.
"""
from contextlib import ExitStack, nullcontext
from copy import deepcopy
from datetime import datetime, timedelta, timezone
import importlib.util
import io
import json
import os
from pathlib import Path
import shlex
import socket
import ssl
import subprocess
import sys
import tempfile
import unittest
from unittest.mock import MagicMock, call, patch


PROJECT = Path(__file__).resolve().parents[1]


def load_module(name, filename):
    spec = importlib.util.spec_from_file_location(name, PROJECT / filename)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


# Isolate manage globals from other suites and never import bootstrap.
m = load_module("selfsteal_test_manage", "manage.py")
with patch.dict(sys.modules, {"manage": m}):
    manager = load_module("selfsteal_under_test", "selfsteal.py")
    installer = load_module("selfsteal_test_installer", "installer.py")

IMAGE = "caddy@sha256:" + "b" * 64
DOMAIN = "node.example.com"
NOW = datetime(2026, 10, 21, 12, 0, 0, tzinfo=timezone.utc)


class IsolatedCase(unittest.TestCase):
    def setUp(self):
        self.stack = ExitStack()
        self.addCleanup(self.stack.close)
        self.root = Path(self.stack.enter_context(
            tempfile.TemporaryDirectory(prefix="test-selfsteal-")))
        self.stdout = self.stack.enter_context(patch("sys.stdout", new_callable=io.StringIO))
        self.stderr = self.stack.enter_context(patch("sys.stderr", new_callable=io.StringIO))
        for target, name in ((subprocess, "run"), (subprocess, "Popen"),
                             (os, "system"), (socket, "socket"),
                             (socket, "getaddrinfo"), (socket, "create_connection")):
            self.patch(target, name, side_effect=AssertionError("External command/network forbidden"))
        self.web = self.root / "caddy"
        self.web.mkdir()
        (self.web / "logs").mkdir()
        self.metadata_path = self.web / "managed.json"
        self.caddyfile = self.web / "Caddyfile"
        self.access = self.web / "logs" / "access.log"
        for name, value in (("WEB", self.web), ("METADATA", self.metadata_path),
                            ("CADDYFILE", self.caddyfile), ("ACCESS_LOG", self.access)):
            self.patch(manager, name, new=value)
        self.patch(m, "WEB", new=self.web)
        self.metadata = {"version": 2, "purpose": "local-backend", "domain": DOMAIN,
                         "https_port": 9443, "image": IMAGE}
        self.write_metadata()
        self.caddyfile.write_text(
            "{\n admin off\n https_port 9443\n}\nhttps://node.example.com {\n"
            " bind 127.0.0.1\n root * /var/www/html\n file_server\n}\n", encoding="utf-8")
        self.container = {
            "Name": "/remnanode-web", "Config": {"Image": IMAGE},
            "State": {"Status": "running", "Running": True,
                      "StartedAt": "2026-10-20T12:00:00Z"},
            "RestartCount": 3,
            "Mounts": [
                {"Source": "/opt/caddy/Caddyfile", "Destination": "/etc/caddy/Caddyfile",
                 "Type": "bind", "RW": False},
                {"Source": "/opt/caddy/html", "Destination": "/var/www/html",
                 "Type": "bind", "RW": False},
                {"Source": "/opt/caddy/logs", "Destination": "/var/log/caddy",
                 "Type": "bind", "RW": True},
                {"Name": "caddy_caddy_data", "Destination": "/data", "Type": "volume"},
                {"Name": "caddy_caddy_config", "Destination": "/config", "Type": "volume"},
            ],
        }
        self.secure = self.patch(m, "secure_path", side_effect=self.safe_path)
        self.inspect = self.patch(m, "inspect", return_value=self.container)
        self.run = self.patch(m, "run", side_effect=AssertionError("Unexpected system command"))
        self.compose = self.patch(m, "compose", side_effect=AssertionError("Unexpected Compose command"))
        self.lock = self.patch(m, "lock", side_effect=lambda: nullcontext())
        self.stopped = self.patch(m, "confirm_stopped")
        # A missing write mock must never reach application or system files.
        original_open, original_mkdir = Path.open, Path.mkdir

        def safe_open(path, mode="r", *args, **kwargs):
            if any(flag in mode for flag in "wax+"):
                self.safe_path(path)
            return original_open(path, mode, *args, **kwargs)

        def safe_mkdir(path, *args, **kwargs):
            self.safe_path(path)
            return original_mkdir(path, *args, **kwargs)

        self.patch(Path, "open", new=safe_open)
        self.patch(Path, "mkdir", new=safe_mkdir)

    def patch(self, target, name, **kwargs):
        return self.stack.enter_context(patch.object(target, name, **kwargs))

    def safe_path(self, path, **kwargs):
        path = Path(path).absolute()
        if not path.is_relative_to(self.root):
            raise AssertionError("Non-test system path forbidden: " + str(path))
        return path

    def write_metadata(self, data=None):
        self.metadata_path.write_text(json.dumps(self.metadata if data is None else data), encoding="utf-8")

    def assert_no_mutations(self):
        self.run.assert_not_called()
        self.compose.assert_not_called()
        self.lock.assert_not_called()


class InstallationTests(IsolatedCase):
    def test_current_backend_is_accepted_without_mutation(self):
        self.assertEqual(manager.validate_installation(), self.metadata)
        self.inspect.assert_called_once_with("remnanode-web")
        self.assert_no_mutations()

    def test_rejects_legacy_or_unknown_metadata(self):
        variants = [{}, {"version": 1}, [], None]
        for field, value in (("version", 1), ("purpose", "selfsteal"),
                             ("https_port", 443), ("https_port", "9443"),
                             ("domain", "https://node.example.com"), ("domain", 123)):
            data = dict(self.metadata)
            data[field] = value
            variants.append(data)
        for data in variants:
            with self.subTest(data=data):
                self.metadata_path.write_text(json.dumps(data), encoding="utf-8")
                with self.assertRaises(manager.SelfstealError):
                    manager.validate_installation()
        self.assert_no_mutations()

    def test_corrupt_or_missing_metadata_is_rejected(self):
        self.metadata_path.write_text("{broken", encoding="utf-8")
        with self.assertRaises(manager.SelfstealError):
            manager.validate_installation()
        self.metadata_path.unlink()
        with self.assertRaises(manager.SelfstealError):
            manager.validate_installation()
        self.assert_no_mutations()

    def test_missing_container_or_foreign_image_is_rejected(self):
        for image in (None, "nginx:latest", "caddy:2", "caddy@sha256:" + "z" * 64):
            with self.subTest(image=image):
                obj = deepcopy(self.container)
                obj["Config"]["Image"] = image
                self.inspect.return_value = obj
                with self.assertRaises(manager.SelfstealError):
                    manager.validate_installation()
        self.inspect.return_value = None
        with self.assertRaises(manager.SelfstealError):
            manager.validate_installation()
        self.assert_no_mutations()

    def test_container_image_must_match_metadata(self):
        self.container["Config"]["Image"] = "caddy@sha256:" + "a" * 64
        with self.assertRaises(manager.SelfstealError):
            manager.validate_installation()
        self.assert_no_mutations()

    def test_metadata_requires_valid_pinned_image(self):
        for value in (None, "caddy:latest", "nginx@sha256:" + "b" * 64):
            with self.subTest(image=value):
                self.metadata["image"] = value
                self.write_metadata()
                with self.assertRaises(manager.SelfstealError):
                    manager.validate_installation()
        self.assert_no_mutations()

    def test_foreign_or_missing_mounts_are_rejected(self):
        for mutate in ("missing", "legacy-source", "wrong-destination", "volume-instead-of-bind"):
            with self.subTest(mutate=mutate):
                obj = deepcopy(self.container)
                if mutate == "missing":
                    obj["Mounts"] = []
                elif mutate == "legacy-source":
                    obj["Mounts"][0]["Source"] = "/opt/nginx-selfsteal/Caddyfile"
                elif mutate == "wrong-destination":
                    obj["Mounts"][1]["Destination"] = "/usr/share/nginx/html"
                else:
                    obj["Mounts"][0]["Type"] = "volume"
                self.inspect.return_value = obj
                with self.assertRaises(manager.SelfstealError):
                    manager.validate_installation()
        self.assert_no_mutations()

    def test_foreign_caddyfile_is_rejected(self):
        self.caddyfile.write_text("https://foreign.example {\n file_server\n}\n", encoding="utf-8")
        with self.assertRaises(manager.SelfstealError):
            manager.validate_installation()
        self.assert_no_mutations()

    def test_docker_unavailable_is_failure_not_absence_or_success(self):
        self.inspect.side_effect = m.Failure("Docker unavailable")
        self.assertEqual(manager.main(["status"]), 1)
        self.assertIn("Docker unavailable", self.stderr.getvalue())
        self.assert_no_mutations()


class ServiceTests(IsolatedCase):
    def test_start_stop_restart_only_target_web_under_lock(self):
        for action in ("start", "stop", "restart"):
            with self.subTest(action=action):
                self.run.reset_mock(side_effect=True)
                self.lock.reset_mock()
                self.stopped.reset_mock()
                entered = []

                class Locked:
                    def __enter__(inner):
                        entered.append(True)

                    def __exit__(inner, *args):
                        entered.pop()

                self.lock.side_effect = Locked

                def command(argv, **kwargs):
                    self.assertTrue(entered, "Service mutation must hold the shared lock")
                    self.assertEqual(argv, ["docker", action, "remnanode-web"])
                    self.assertNotIn("remnanode", argv)

                self.run.side_effect = command
                manager.service_action(action, confirm=True)
                self.run.assert_called_once_with(["docker", action, "remnanode-web"], timeout=60)
                self.lock.assert_called_once_with()
                if action == "stop":
                    self.stopped.assert_called_once_with("remnanode-web")
                else:
                    self.stopped.assert_not_called()
        self.compose.assert_not_called()

    def test_stop_and_restart_require_explicit_confirmation(self):
        for action in ("stop", "restart"):
            with self.subTest(action=action), self.assertRaises(manager.SelfstealError):
                manager.service_action(action)
        self.assert_no_mutations()

    def test_unknown_action_never_runs_command(self):
        with self.assertRaises(manager.SelfstealError):
            manager.service_action("remove", confirm=True)
        self.assert_no_mutations()

    def test_invalid_installation_prevents_confirmed_stop(self):
        self.metadata["purpose"] = "legacy"
        self.write_metadata()
        with self.assertRaises(manager.SelfstealError):
            manager.service_action("stop", confirm=True)
        self.assert_no_mutations()

    def test_start_failure_and_not_running_state_are_not_success(self):
        self.run.side_effect = m.Failure("Docker failed")
        with self.assertRaises(m.Failure):
            manager.service_action("start")
        self.run.side_effect = None
        self.container["State"] = {"Status": "exited", "Running": False}
        with self.assertRaises(manager.SelfstealError):
            manager.service_action("start")

    def test_stop_requires_confirmed_container_stop(self):
        self.run.side_effect = None
        self.stopped.side_effect = m.Failure("still running")
        with self.assertRaises(m.Failure):
            manager.service_action("stop", confirm=True)
        self.assertNotIn("Caddy выключен", self.stdout.getvalue())


class WrapperTests(unittest.TestCase):
    def setUp(self):
        self.stack = ExitStack()
        self.addCleanup(self.stack.close)
        self.root = Path(self.stack.enter_context(
            tempfile.TemporaryDirectory(prefix="test-selfsteal-wrapper-")))
        self.target = self.root / "usr" / "local" / "bin" / "selfsteal"
        self.target.parent.mkdir(parents=True)
        self.target_factory = self.stack.enter_context(patch.object(
            installer, "Path",
            side_effect=lambda value: self.target if value == "/usr/local/bin/selfsteal" else Path(value)))
        self.platform = self.stack.enter_context(patch.object(installer.sys, "platform", "linux"))
        self.atomic = self.stack.enter_context(patch.object(installer.m, "atomic_write"))
        self.failure = getattr(installer.m, "Failure")

    def test_foreign_usr_local_wrapper_is_rejected_without_overwrite(self):
        foreign = "#!/bin/sh\necho foreign-selfsteal\n"
        self.target.write_text(foreign, encoding="utf-8")
        with self.assertRaises(self.failure):
            installer.install_selfsteal_command()
        self.atomic.assert_not_called()
        self.assertEqual(self.target.read_text(encoding="utf-8"), foreign)

    def test_existing_identical_wrapper_is_left_untouched(self):
        wrapper = "#!/bin/sh\nexec /usr/bin/python3 " + shlex.quote(str(installer.m.BASE / "selfsteal.py")) + " \"$@\"\n"
        self.target.write_text(wrapper, encoding="utf-8")
        installer.install_selfsteal_command()
        self.atomic.assert_not_called()

    def test_missing_wrapper_is_written_to_only_target(self):
        installer.install_selfsteal_command()
        self.atomic.assert_called_once()
        path, text = self.atomic.call_args.args[:2]
        self.assertEqual(path, self.target)
        self.assertIn("selfsteal.py", text)
        self.assertEqual(self.atomic.call_args.kwargs, {"mode": 0o755})

    def test_symlink_conflict_is_rejected_before_read_or_write(self):
        destination = self.root / "foreign-target"
        destination.write_text("foreign", encoding="utf-8")
        try:
            self.target.symlink_to(destination)
        except OSError as exc:
            self.skipTest("symlink fixture unavailable: " + str(exc))
        with self.assertRaises(self.failure):
            installer.install_selfsteal_command()
        self.atomic.assert_not_called()

    def test_windows_skips_system_wrapper_installation(self):
        self.platform = self.stack.enter_context(patch.object(installer.sys, "platform", "win32"))
        installer.install_selfsteal_command()
        self.atomic.assert_not_called()
        self.assertFalse(self.target.exists())


class CertificateTests(IsolatedCase):
    def setUp(self):
        super().setUp()

        class FrozenDatetime(datetime):
            @classmethod
            def now(cls, tz=None):
                return NOW.astimezone(tz) if tz is not None else NOW.replace(tzinfo=None)

        self.patch(manager, "datetime", new=FrozenDatetime)
        self.raw = MagicMock(name="raw_socket")
        self.connect = self.patch(socket, "create_connection", return_value=self.raw)
        self.tls = MagicMock(name="tls_socket")
        self.context = MagicMock(name="verified_context")
        self.context.wrap_socket.return_value.__enter__.return_value = self.tls
        self.factory = self.patch(ssl, "create_default_context", return_value=self.context)
        self.unverified = self.patch(ssl, "_create_unverified_context",
                                     side_effect=AssertionError("TLS verification must not be disabled"))
        self.tls.getpeercert.return_value = {"notAfter": "Nov  1 00:00:00 2026 GMT"}

    def test_certificate_uses_local_backend_sni_and_verified_tls(self):
        status = manager.certificate_status()
        self.connect.assert_called_once_with(("127.0.0.1", 9443), timeout=8)
        self.factory.assert_called_once_with()
        self.context.wrap_socket.assert_called_once_with(
            self.raw.__enter__.return_value, server_hostname=DOMAIN)
        self.unverified.assert_not_called()
        self.assertTrue(status["verified"])
        self.assertEqual(status["domain"], DOMAIN)
        self.assertEqual(status["expires_at"], datetime(2026, 11, 1, tzinfo=timezone.utc))
        self.assertEqual(status["expires_at"].utcoffset(), timedelta(0))
        self.assertEqual(status["days_left"], 10)
        self.assert_no_mutations()

    def test_days_are_full_utc_days_at_boundaries(self):
        for offset, expected in ((0, 0), (86399, 0), (86400, 1), (172799, 1)):
            with self.subTest(offset=offset):
                expires = NOW + timedelta(seconds=offset)
                self.tls.getpeercert.return_value = {
                    "notAfter": expires.strftime("%b %d %H:%M:%S %Y GMT")}
                self.assertEqual(manager.certificate_status()["days_left"], expected)

    def test_expired_untrusted_or_wrong_hostname_is_never_reported_verified(self):
        for reason in ("certificate has expired", "self-signed certificate", "Hostname mismatch"):
            with self.subTest(reason=reason):
                self.context.wrap_socket.side_effect = ssl.SSLCertVerificationError(1, reason)
                with self.assertRaises(manager.SelfstealError):
                    manager.certificate_status()
                self.unverified.assert_not_called()
        self.assert_no_mutations()

    def test_stopped_backend_connection_refused_is_failure(self):
        self.container["State"] = {"Status": "exited", "Running": False}
        self.connect.side_effect = ConnectionRefusedError("backend stopped")
        with self.assertRaises(manager.SelfstealError):
            manager.certificate_status()
        self.assert_no_mutations()

    def test_missing_certificate_or_expiry_is_failure(self):
        for cert in ({}, {"subject": ()}):
            with self.subTest(cert=cert):
                self.tls.getpeercert.return_value = cert
                with self.assertRaises(manager.SelfstealError):
                    manager.certificate_status()


class LogTests(IsolatedCase):
    def test_visits_returns_requested_tail_without_service_mutation(self):
        self.access.write_text("first\nsecond\nthird\n", encoding="utf-8")
        self.assertEqual(manager.show_logs("visits", 2), "second\nthird\n")
        self.assert_no_mutations()

    def test_large_log_reads_at_most_configured_byte_bound(self):
        data = b"OLD_SENTINEL\n" + b"x" * (manager.MAX_LOG_BYTES * 3) + b"\nlast\n"
        reads = []

        class BoundedStream(io.BytesIO):
            def read(inner, size=-1):
                reads.append(size)
                self.assertGreaterEqual(size, 0, "Unbounded log reads are forbidden")
                self.assertLessEqual(size, manager.MAX_LOG_BYTES)
                return super().read(size)

        self.access.write_bytes(data)
        original_open = Path.open

        def open_log(path, *args, **kwargs):
            if path == self.access:
                return BoundedStream(data)
            return original_open(path, *args, **kwargs)

        self.patch(Path, "open", new=open_log)
        text = manager.show_logs("visits", 1000)
        self.assertTrue(reads)
        self.assertNotIn("OLD_SENTINEL", text)
        self.assertTrue(text.endswith("last\n"))
        self.assertLessEqual(len(text.encode("utf-8")), manager.MAX_LOG_BYTES + 1)
        self.assert_no_mutations()

    def test_missing_and_empty_access_log_are_safe(self):
        self.assertTrue(manager.show_logs("visits", 1))
        self.access.write_bytes(b"")
        self.assertEqual(manager.show_logs("visits", 1), "")
        self.assert_no_mutations()

    def test_access_log_terminal_controls_are_escaped(self):
        self.access.write_text("request /\x1b[2J\x00\x07\x9b31m END\n", encoding="utf-8")
        text = manager.show_logs("visits", 1)
        self.assertNotRegex(text, r"[\x00-\x08\x0b-\x1f\x7f-\x9f]")
        self.assertIn("END", text)
        self.assert_no_mutations()

    def test_error_logs_are_bounded_and_only_read_web(self):
        self.run.side_effect = None
        self.run.return_value = "ACME test\n"
        self.assertEqual(manager.show_logs("errors", 17), "ACME test\n")
        self.run.assert_called_once_with(
            ["docker", "logs", "--tail", "17", "--timestamps", "remnanode-web"],
            capture=True, combine_output=True, timeout=30)
        self.lock.assert_not_called()
        self.compose.assert_not_called()

    def test_error_log_terminal_controls_are_escaped(self):
        self.run.side_effect = None
        self.run.return_value = "ACME \x1b]0;injected\x07\x00 END\n"
        text = manager.show_logs("errors", 1)
        self.assertNotRegex(text, r"[\x00-\x08\x0b-\x1f\x7f-\x9f]")
        self.assertIn("END", text)

    def test_invalid_line_limits_or_kind_never_run_docker(self):
        for lines in (-1, 0, 1001):
            with self.subTest(lines=lines), self.assertRaises(manager.SelfstealError):
                manager.show_logs("visits", lines)
        with self.assertRaises(manager.SelfstealError):
            manager.show_logs("unknown", 100)
        self.assert_no_mutations()

    def test_line_limit_endpoints_are_accepted(self):
        self.access.write_text("a\nb\n", encoding="utf-8")
        self.assertEqual(manager.show_logs("visits", 1), "b\n")
        self.assertEqual(manager.show_logs("visits", 1000), "a\nb\n")


class CommandAndMenuTests(IsolatedCase):
    def test_empty_argv_and_explicit_menu_dispatch_without_lock(self):
        menu = self.patch(manager, "menu")
        for argv in ([], ["menu"]):
            with self.subTest(argv=argv):
                self.assertEqual(manager.main(argv), 0)
        self.assertEqual(menu.call_count, 2)
        self.assert_no_mutations()

    def test_cli_dispatches_service_and_log_arguments(self):
        service = self.patch(manager, "service_action")
        logs = self.patch(manager, "show_logs", return_value="TEST_LOG")
        self.assertEqual(manager.main(["restart", "--confirm"]), 0)
        service.assert_called_once_with("restart", confirm=True)
        self.assertEqual(manager.main(["logs", "--kind", "errors", "--lines", "25"]), 0)
        logs.assert_called_once_with("errors", 25)
        self.assertIn("TEST_LOG", self.stdout.getvalue())
        self.assert_no_mutations()

    def test_cli_unconfirmed_stop_is_nonzero_and_no_mutation(self):
        self.assertEqual(manager.main(["stop"]), 1)
        self.assertTrue(self.stderr.getvalue())
        self.assert_no_mutations()

    def test_invalid_cli_input_is_rejected(self):
        for argv in (["delete"], ["logs", "--kind", "other"], ["logs", "--lines", "abc"]):
            with self.subTest(argv=argv), self.assertRaises(SystemExit) as caught:
                manager.main(argv)
            self.assertEqual(caught.exception.code, 2)
        self.assert_no_mutations()

    def test_menu_exit_does_not_validate_or_change_installation(self):
        self.stack.enter_context(patch("builtins.input", return_value="0"))
        manager.menu()
        self.inspect.assert_not_called()
        self.assert_no_mutations()

    def test_menu_start_status_and_log_dispatch(self):
        status = self.patch(manager, "print_status")
        service = self.patch(manager, "service_action")
        logs = self.patch(manager, "show_logs", return_value="sample")
        self.stack.enter_context(patch("builtins.input", side_effect=["1", "2", "6", "7", "0"]))
        manager.menu()
        status.assert_called_once_with()
        service.assert_called_once_with("start")
        self.assertEqual(logs.call_args_list, [call("visits"), call("errors")])
        self.assert_no_mutations()

    def test_menu_stop_restart_cannot_bypass_confirmation(self):
        service = self.patch(manager, "service_action")
        self.stack.enter_context(patch("builtins.input", side_effect=["3", "", "4", "no", "0"]))
        manager.menu()
        service.assert_not_called()
        self.assert_no_mutations()

    def test_menu_confirmed_stop_restart_warns_about_backend(self):
        service = self.patch(manager, "service_action")
        inputs = self.stack.enter_context(patch(
            "builtins.input", side_effect=["3", "ПОДТВЕРЖДАЮ", "4", "ПОДТВЕРЖДАЮ", "0"]))
        manager.menu()
        self.assertEqual(service.call_args_list,
                         [call("stop", confirm=True), call("restart", confirm=True)])
        prompts = " ".join(str(item) for item in inputs.call_args_list)
        self.assertIn("backend", prompts)
        self.assert_no_mutations()

    def test_renew_check_never_claims_forced_issue_or_mutates(self):
        cert = self.patch(manager, "certificate_status", return_value={"days_left": 30})
        self.assertEqual(manager.main(["renew-check"]), 0)
        cert.assert_called_once_with()
        self.assertIn("автомат", self.stdout.getvalue().lower())
        self.assert_no_mutations()

    def test_menu_acme_declined_restart_does_not_mutate(self):
        self.patch(manager, "certificate_status", return_value={"days_left": 30})
        service = self.patch(manager, "service_action")
        self.stack.enter_context(patch("builtins.input", side_effect=["5", "n", "0"]))
        manager.menu()
        service.assert_not_called()
        self.assert_no_mutations()


if __name__ == "__main__":
    unittest.main()
