"""Bootstrap safety tests: all privileged commands are mocked, including on Windows."""
import contextlib
import importlib.util
import os
from pathlib import Path
import tempfile
import unittest
from types import SimpleNamespace
from unittest.mock import MagicMock, patch

spec = importlib.util.spec_from_file_location('bootstrap_tested', Path(__file__).parents[1] / 'bootstrap.py')
b = importlib.util.module_from_spec(spec)
spec.loader.exec_module(b)

PANEL = '198.51.100.7'
CONNECTION = '203.0.113.9 50123 192.0.2.1 22'
INACTIVE = 'Status: inactive\n'
ACTIVE_SSH = 'Status: active\n\n[ 1] 22/tcp ALLOW IN 203.0.113.0/24\n'


def final_status(panel=PANEL):
    v4 = [f'2222/tcp ALLOW IN {panel}', '2222/tcp DENY IN Anywhere',
          '9443/tcp DENY IN Anywhere', '80/tcp ALLOW IN Anywhere', '443/tcp ALLOW IN Anywhere']
    v6 = ['2222/tcp (v6) DENY IN Anywhere (v6)', '9443/tcp (v6) DENY IN Anywhere (v6)',
          '80/tcp (v6) ALLOW IN Anywhere (v6)', '443/tcp (v6) ALLOW IN Anywhere (v6)']
    return 'Status: active\n' + '\n'.join(f'[{i}] {row}' for i, row in enumerate(v4 + ['22/tcp ALLOW IN Anywhere'] + v6, 1))


def write(path, text, mode=0o600):
    Path(path).write_text(text, encoding='utf-8')


def safe(path, **kwargs):
    return Path(path)


class PackagesTests(unittest.TestCase):
    def test_packages_do_not_install_or_modify_ssh(self):
        with patch.object(b, '_ubuntu'), patch.object(b, 'run') as run:
            b.ensure_packages()
        install = run.call_args_list[1].args[0]
        self.assertIn('ufw', install)
        self.assertNotIn('openssh-server', install)
        self.assertFalse(any('ssh' in str(call.args[0]) for call in run.call_args_list))

    def test_working_docker_is_never_reinstalled(self):
        with patch.object(b, '_ubuntu'), patch.object(b.shutil, 'which', return_value='/usr/bin/docker'), \
                patch.object(b, 'run') as run:
            b.ensure_docker()
        self.assertEqual([call.args[0] for call in run.call_args_list],
                         [['docker', 'info'], ['docker', 'compose', 'version']])

    def test_broken_docker_refuses_replacement(self):
        with patch.object(b, '_ubuntu'), patch.object(b.shutil, 'which', return_value='docker'), \
                patch.object(b, 'run', side_effect=b.Failure('broken')) as run:
            with self.assertRaises(b.Failure):
                b.ensure_docker()
        self.assertEqual(run.call_count, 1)

    def test_conflicting_packages_refused(self):
        with patch.object(b, '_ubuntu'), patch.object(b.shutil, 'which', return_value=None), \
                patch.object(b, '_installed', return_value=True), patch.object(b, 'run') as run:
            with self.assertRaises(b.Failure):
                b.ensure_docker()
        run.assert_not_called()

    def test_trusted_key_installs_only_official_packages_for_noble(self):
        with tempfile.TemporaryDirectory() as tmp:
            def command(args, **kwargs):
                if args[0] == 'dpkg':
                    return 'arm64\n'
                if args[0] == 'curl':
                    Path(args[args.index('--output') + 1]).write_text('trusted key')
                if args[0] == 'gpg':
                    return 'pub:::::::::\nfpr:::::::::' + b.DOCKER_FINGERPRINT + ':\nsub:::::::::\nfpr:::::::::SUBKEY:\n'
                return SimpleNamespace(returncode=0, stdout='')
            def secure(path, **kwargs):
                return Path(tmp) / Path(path).name
            with patch.object(b, '_ubuntu'), patch.object(b.shutil, 'which', return_value=None), \
                    patch.object(b, '_installed', return_value=False), patch.object(b, 'run', side_effect=command) as run, \
                    patch.object(b, 'secure_path', side_effect=secure), patch.object(b, 'atomic_write', side_effect=write):
                b.ensure_docker()
            source = (Path(tmp) / 'remnanode-docker.list').read_text()
            self.assertIn('arch=arm64', source)
            self.assertIn('https://download.docker.com/linux/ubuntu noble stable', source)
            installs = [c.args[0] for c in run.call_args_list if c.args[0][:2] == ['apt-get', 'install']]
            self.assertEqual(len(installs), 1)
            self.assertIn('docker-compose-plugin', installs[0])
            self.assertFalse(any(c.args[0][0] in ('sh', 'bash') for c in run.call_args_list))

    def test_new_keyring_chmod_overrides_umask(self):
        path = MagicMock()
        path.exists.return_value = False
        with patch.object(b, 'secure_path', return_value=path), patch.object(b.os, 'chmod') as chmod:
            b._prepare_keyring_directory('/etc/apt/keyrings')
        path.mkdir.assert_called_once_with(mode=0o755, parents=True)
        chmod.assert_called_once_with(path, 0o755)

    def test_existing_keyring_not_accessible_to_apt_is_refused(self):
        path = MagicMock()
        path.exists.return_value = True
        path.stat.return_value.st_mode = 0o40700
        with patch.object(b, 'secure_path', return_value=path), patch.object(b.os, 'chmod') as chmod:
            with self.assertRaises(b.Failure):
                b._prepare_keyring_directory('/etc/apt/keyrings')
        chmod.assert_not_called()

    def test_bad_downloaded_key_is_not_installed(self):
        with tempfile.TemporaryDirectory() as tmp:
            def command(args, **kwargs):
                if args[0] == 'dpkg':
                    return 'amd64\n'
                if args[0] == 'curl':
                    Path(args[args.index('--output') + 1]).write_text('untrusted key')
                if args[0] == 'gpg':
                    return 'pub:::::::::\nfpr:::::::::WRONG:\n'
                return SimpleNamespace(returncode=0, stdout='')
            def secure(path, **kwargs):
                return Path(tmp) / Path(path).name
            with patch.object(b, '_ubuntu'), patch.object(b.shutil, 'which', return_value=None), \
                    patch.object(b, '_installed', return_value=False), patch.object(b, 'run', side_effect=command), \
                    patch.object(b, 'secure_path', side_effect=secure), patch.object(b, 'atomic_write') as atomic:
                with self.assertRaisesRegex(b.Failure, 'Fingerprint'):
                    b.ensure_docker()
            atomic.assert_not_called()


class SshTests(unittest.TestCase):
    def discover(self, listener, connection=CONNECTION):
        with patch.dict(os.environ, {'SSH_CONNECTION': connection}), \
                patch.object(b, 'run', return_value=listener):
            return b.discover_ssh_ports()

    def test_sshd_ipv4_ipv6_deduplication(self):
        rows = ('LISTEN 0 128 0.0.0.0:22 0.0.0.0:* users:(("sshd",pid=1,fd=3))\n'
                'LISTEN 0 128 [::]:22 [::]:* users:(("sshd",pid=1,fd=4))\n')
        self.assertEqual(self.discover(rows), [22])

    def test_custom_ports(self):
        rows = 'LISTEN 0 128 192.0.2.1:5022 0.0.0.0:* users:(("sshd",pid=1,fd=3))'
        self.assertEqual(self.discover(rows, CONNECTION.rsplit(' ', 1)[0] + ' 5022'), [5022])

    def test_missing_inconsistent_reserved_and_loopback_refused(self):
        for rows in ('',
                     'LISTEN 0 128 0.0.0.0:23 0.0.0.0:* users:(("sshd",pid=1,fd=3))',
                     'LISTEN 0 128 0.0.0.0:443 0.0.0.0:* users:(("sshd",pid=1,fd=3))',
                     'LISTEN 0 128 127.0.0.1:22 0.0.0.0:* users:(("sshd",pid=1,fd=3))'):
            with self.subTest(rows=rows), self.assertRaises(b.Failure):
                self.discover(rows)

    def test_socket_activation_verified_against_service_and_sshd(self):
        replies = ['LISTEN 0 4096 *:22 *:* users:(("systemd",pid=1,fd=3))',
                   SimpleNamespace(returncode=0, stdout='active\n'), 'port 22\n', '[::]:22 (Stream)\n']
        with patch.dict(os.environ, {'SSH_CONNECTION': CONNECTION}), patch.object(b, 'run', side_effect=replies):
            self.assertEqual(b.discover_ssh_ports(), [22])

    def test_unrelated_systemd_listener_not_ssh(self):
        replies = ['LISTEN 0 4096 *:22 *:* users:(("systemd",pid=1,fd=3))',
                   SimpleNamespace(returncode=0, stdout='active\n'), 'port 22\n', '[::]:2223 (Stream)\n']
        with patch.dict(os.environ, {'SSH_CONNECTION': CONNECTION}), patch.object(b, 'run', side_effect=replies):
            with self.assertRaises(b.Failure):
                b.discover_ssh_ports()

    def test_bad_connection_refused(self):
        with patch.dict(os.environ, {'SSH_CONNECTION': 'bad value'}), self.assertRaises(b.Failure):
            b._connection()


class LogrotateTests(unittest.TestCase):
    def test_new_config_validated_without_force(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / 'remnanode'
            with patch.object(b, 'LOGROTATE', path), patch.object(b, 'secure_path', side_effect=safe), \
                    patch.object(b, 'atomic_write', side_effect=write), patch.object(b, 'run') as run:
                self.assertIsNone(b.install_logrotate())
            self.assertEqual(path.read_text(), b.LOGROTATE_TEXT)
            self.assertEqual(run.call_args_list[0].args[0], ['logrotate', '-d', path])
            self.assertEqual(run.call_args_list[1].args[0], ['systemctl', 'enable', '--now', 'logrotate.timer'])

    def test_unknown_existing_file_not_overwritten(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / 'remnanode'
            path.write_text('owner configuration')
            with patch.object(b, 'LOGROTATE', path), patch.object(b, 'secure_path', side_effect=safe), \
                    patch.object(b, 'run') as run, self.assertRaises(b.Failure):
                b.install_logrotate()
            self.assertEqual(path.read_text(), 'owner configuration')
            run.assert_not_called()

    def test_failed_validation_removes_only_new_file(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / 'remnanode'
            with patch.object(b, 'LOGROTATE', path), patch.object(b, 'secure_path', side_effect=safe), \
                    patch.object(b, 'atomic_write', side_effect=write), \
                    patch.object(b, 'run', side_effect=b.Failure('bad')), self.assertRaises(b.Failure):
                b.install_logrotate()
            self.assertFalse(path.exists())


class FirewallTests(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory()
        self.addCleanup(self.temporary.cleanup)
        self.folder = Path(self.temporary.name)
        self.default = self.folder / 'ufw-default'
        self.default.write_text('IPV6=no\nDEFAULT_INPUT_POLICY="DROP"\n')
        self.guard = b.FirewallGuard(PANEL, [22], self.folder, False, INACTIVE)
        lock = patch.object(b, '_firewall_lock', side_effect=contextlib.nullcontext)
        lock.start()
        self.addCleanup(lock.stop)

    def test_apply_orders_timer_ssh_and_enable_and_keeps_rollback(self):
        with patch.object(b, 'UFW_DEFAULT', self.default), patch.object(b, 'atomic_write', side_effect=write), \
                patch.object(b, '_status', side_effect=[INACTIVE, final_status()]), \
                patch.object(b, 'run', side_effect=lambda args, **kw: '0\n' if 'show' in args else None) as run:
            self.guard.apply()
        commands = [call.args[0] for call in run.call_args_list]
        ssh = commands.index(['ufw', 'allow', 'in', 'to', 'any', 'port', '22', 'proto', 'tcp'])
        enable = commands.index(['ufw', '--force', 'enable'])
        self.assertLess(ssh, enable)
        self.assertEqual(commands[0][:3], ['systemctl', 'is-active', '--quiet'])
        self.assertFalse(any(cmd[:2] == ['systemctl', 'stop'] for cmd in commands))
        self.assertIn('IPV6=yes', self.default.read_text())

    def test_active_apply_preserves_restricted_ssh_and_deletes_old_owned_rules(self):
        self.default.write_text('IPV6=yes\n')
        original = ACTIVE_SSH + '[ 2] 80/tcp ALLOW IN Anywhere # remnanode-bootstrap-http\n'
        self.guard.original = original
        self.guard.was_active = True
        with patch.dict(os.environ, {'SSH_CONNECTION': CONNECTION}), \
                patch.object(b, 'UFW_DEFAULT', self.default), patch.object(b, 'atomic_write', side_effect=write), \
                patch.object(b, '_status', side_effect=[original, final_status()]), \
                patch.object(b, 'run', side_effect=lambda args, **kw: '0\n' if 'show' in args else None) as run:
            self.guard.apply()
        commands = [c.args[0] for c in run.call_args_list]
        self.assertIn(['ufw', '--force', 'delete', '2'], commands)
        self.assertIn(['ufw', 'reload'], commands)
        self.assertFalse(any('22' in cmd for cmd in commands))
        self.assertNotIn(['ufw', 'default', 'deny', 'incoming'], commands)

    def test_commit_expiring_during_stop_does_not_report_success(self):
        self.guard.applied = True
        replies = [None, '0\n', None, '456\n']
        with patch.object(b, 'run', side_effect=replies), patch.object(b, '_status', return_value=final_status()):
            with self.assertRaises(b.Failure):
                self.guard.commit()
        self.assertFalse(self.guard.finished)

    def test_unavailable_service_property_refused_before_mutation(self):
        with patch.object(b, '_status', return_value=INACTIVE), \
                patch.object(b, 'run', side_effect=[None, '', None, None]) as run:
            with self.assertRaises(b.Failure):
                self.guard.apply()
        commands = [c.args[0] for c in run.call_args_list]
        self.assertFalse(any(cmd[0] == 'ufw' for cmd in commands))
        self.assertIn([self.guard.script], commands)

    def test_watchdog_start_during_apply_restores_only_after_unlock(self):
        held = []

        @contextlib.contextmanager
        def lock():
            held.append(True)
            try:
                yield
            finally:
                held.pop()

        def run(args, **kwargs):
            if args == [self.guard.script]:
                self.assertFalse(held, 'rollback shell would deadlock under Python lock')
            elif args[0] == 'ufw':
                self.assertTrue(held)
            return None

        with patch.object(b, '_firewall_lock', side_effect=lock), \
                patch.object(b, 'UFW_DEFAULT', self.default), patch.object(b, 'atomic_write', side_effect=write), \
                patch.object(b, '_status', side_effect=[INACTIVE, final_status()]), \
                patch.object(self.guard, '_unexpired', side_effect=[None, b.Failure('timer fired')]) as check, \
                patch.object(b, 'run', side_effect=run) as command:
            with self.assertRaises(b.Failure):
                self.guard.apply()
        self.assertEqual(check.call_count, 2)
        self.assertFalse(self.guard.applied)
        self.assertIn([self.guard.script], [c.args[0] for c in command.call_args_list])

    def test_apply_commands_share_120_second_deadline(self):
        # Deadline established at t=0, then no command may start after t=120.
        with patch.object(b, '_status', return_value=INACTIVE), \
                patch.object(b.time, 'monotonic', side_effect=[0, 121]), \
                patch.object(b, 'run') as run:
            with self.assertRaisesRegex(b.Failure, '120'):
                self.guard.apply()
        commands = [c.args[0] for c in run.call_args_list]
        self.assertEqual(commands[0], [self.guard.script])
        self.assertFalse(any(cmd[0] == 'ufw' for cmd in commands))

    def test_commit_requires_applied_state(self):
        with patch.object(b, 'run') as run, self.assertRaises(b.Failure):
            self.guard.commit()
        run.assert_not_called()

    def test_commit_rejects_expired_or_previously_executed_timer(self):
        self.guard.applied = True
        with patch.object(b, 'run', side_effect=[None, '12345\n']) as run, self.assertRaises(b.Failure):
            self.guard.commit()
        self.assertFalse(any(c.args[0][:2] == ['systemctl', 'stop'] for c in run.call_args_list))

    def test_commit_verifies_rules_then_rollback_after_commit_supported(self):
        self.guard.applied = True
        with patch.object(b, '_status', return_value=final_status()), \
                patch.object(b, 'run', side_effect=lambda args, **kw: '0\n' if 'show' in args else None) as run:
            self.guard.commit()
            self.guard.rollback()
            self.guard.rollback()
        commands = [c.args[0] for c in run.call_args_list]
        self.assertEqual(commands.count([self.guard.script]), 1)
        self.assertTrue(self.guard.restored)

    def test_rollback_failure_does_not_cancel_timer(self):
        with patch.object(b, 'run', side_effect=b.Failure('restore failure')) as run, self.assertRaises(b.Failure):
            self.guard.rollback()
        self.assertEqual(run.call_count, 1)
        self.assertFalse(self.guard.restored)

    def test_apply_error_restores_before_cancel(self):
        with patch.object(b, '_status', side_effect=b.Failure('changed')), patch.object(b, 'run') as run:
            with self.assertRaises(b.Failure):
                self.guard.apply()
        self.assertEqual(run.call_args_list[0].args[0], [self.guard.script])
        self.assertEqual(run.call_args_list[1].args[0], ['systemctl', 'stop', self.guard.unit + '.timer'])

    def test_priority_check_rejects_open_api_and_missing_ipv6(self):
        b._verify_rules(final_status(), PANEL)
        for status in (final_status().replace('2222/tcp DENY IN Anywhere', '2222/tcp ALLOW IN Anywhere'),
                       final_status().split('[7]')[0],
                       final_status().replace('9443/tcp DENY IN Anywhere', '9443/tcp ALLOW IN Anywhere')):
            with self.assertRaises(b.Failure):
                b._verify_rules(status, PANEL)

    def test_existing_restricted_ssh_is_proven_without_widening(self):
        with patch.dict(os.environ, {'SSH_CONNECTION': CONNECTION}):
            b._active_ssh_safe(ACTIVE_SSH, [22])
            for status in (ACTIVE_SSH.replace('203.0.113.0/24', '198.51.100.0/24'),
                           ACTIVE_SSH.replace('ALLOW', 'DENY'),
                           ACTIVE_SSH.replace('22/tcp', 'OpenSSH')):
                with self.assertRaises(b.Failure):
                    b._active_ssh_safe(status, [22])

    def test_prepare_snapshot_and_arm_before_any_mutation(self):
        ufw = self.folder / 'ufw'
        ufw.mkdir()
        (ufw / 'ufw.conf').write_text('ENABLED=no\n')
        backup = self.folder / 'backup'
        backup.mkdir()
        def run(args, **kwargs):
            if args[:3] == ['ufw', 'show', 'added']:
                return 'Added user rules (see ufw status for running firewall):\n(none)\n'
            return SimpleNamespace(returncode=0, stdout='')
        with patch.object(b, '_ubuntu'), patch.object(b, 'discover_ssh_ports', return_value=[22]), \
                patch.object(b, '_status', return_value=INACTIVE), patch.object(b, 'UFW_DIR', ufw), \
                patch.object(b, 'UFW_DEFAULT', self.default), patch.object(b, 'secure_path', side_effect=safe), \
                patch.object(b, 'backup_dir', return_value=backup), patch.object(b, 'atomic_write', side_effect=write), \
                patch.object(b.shutil, 'which', return_value='/usr/bin/flock'), \
                patch.object(b, 'run', side_effect=run) as command:
            guard = b.prepare_firewall(PANEL, [22])
        self.assertEqual(self.default.read_text().splitlines()[0], 'IPV6=no')
        self.assertEqual((backup / 'etc-ufw' / 'ufw.conf').read_text(), 'ENABLED=no\n')
        self.assertIn('ufw --force disable', guard.script.read_text())
        self.assertIn('flock -x 9', guard.script.read_text())
        self.assertIn(str(b.FIREWALL_LOCK), guard.script.read_text())
        commands = [c.args[0] for c in command.call_args_list]
        timer = [cmd for cmd in commands if cmd[0] == 'systemd-run'][0]
        self.assertIn('--on-active=5m', timer)
        self.assertFalse(any(cmd[:2] == ['ufw', 'allow'] for cmd in commands))


if __name__ == '__main__':
    unittest.main()
