#!/usr/bin/env python3
"""Safe Caddy manager for the local Remnawave web backend.

This module never installs or executes the third-party selfsteal.sh script.
"""
import argparse
from contextlib import contextmanager
from datetime import datetime, timezone
import json
from pathlib import Path
import re
import socket
import string
import ssl
import subprocess
import sys

import manage as m

WEB = Path('/opt/caddy')
CONTAINER = 'remnanode-web'
METADATA = WEB / 'managed.json'
CADDYFILE = WEB / 'Caddyfile'
ACCESS_LOG = WEB / 'logs' / 'access.log'
MAX_LOG_BYTES = 128 * 1024


class SelfstealError(Exception):
    pass


def _json(path):
    try:
        m.secure_path(path, directory=False)
        data = json.loads(path.read_text(encoding='utf-8'))
    except (OSError, ValueError, UnicodeError) as exc:
        raise SelfstealError('Не удалось прочитать metadata Caddy.') from exc
    if (not isinstance(data, dict) or data.get('version') != 2 or
            data.get('purpose') != 'local-backend' or data.get('https_port') != 9443 or
            not isinstance(data.get('domain'), str) or not m.DOMAIN.fullmatch(data['domain'])):
        raise SelfstealError('Установка не распознана как управляемый backend Caddy.')
    return data


def validate_installation():
    metadata = _json(METADATA)
    if not WEB.is_dir() or not CADDYFILE.is_file():
        raise SelfstealError('Каталог Caddy или Caddyfile отсутствует.')
    if '127.0.0.1' not in CADDYFILE.read_text(encoding='utf-8') or '9443' not in CADDYFILE.read_text(encoding='utf-8'):
        raise SelfstealError('Caddyfile не подтверждает локальный backend 9443.')
    obj = m.inspect(CONTAINER)
    if obj is None:
        raise SelfstealError('Контейнер remnanode-web не найден.')
    image = obj.get('Config', {}).get('Image', '')
    if (not isinstance(image, str) or not re.fullmatch(r'caddy@sha256:[0-9a-f]{64}', image) or
            metadata.get('image') != image):
        raise SelfstealError('Образ Caddy не закреплён digest или схема неизвестна.')
    mounts = obj.get('Mounts', [])
    required = {('/opt/caddy/Caddyfile', '/etc/caddy/Caddyfile', 'bind'),
                ('/opt/caddy/html', '/var/www/html', 'bind')}
    actual = {(x.get('Source'), x.get('Destination'), x.get('Type')) for x in mounts}
    if not required.issubset(actual):
        raise SelfstealError('Mounts Caddy не соответствуют управляемой установке.')
    return metadata


def service_action(action, *, confirm=False):
    if action not in ('start', 'stop', 'restart'):
        raise SelfstealError('Неизвестное действие Caddy.')
    validate_installation()
    if action in ('stop', 'restart') and not confirm:
        raise SelfstealError('Остановка/перезапуск требует явного подтверждения.')
    with m.lock():
        m.run(['docker', action, CONTAINER], timeout=60)
        state = m.inspect(CONTAINER)
        if action == 'stop':
            m.confirm_stopped(CONTAINER)
        elif not state or not state.get('State', {}).get('Running'):
            raise SelfstealError('Caddy не подтвердил состояние после запуска.')
    print({'start': 'Caddy включён.', 'stop': 'Caddy выключен.', 'restart': 'Caddy перезапущен.'}[action])


def _certificate(domain, port=9443, verify=True):
    context = ssl.create_default_context() if verify else ssl._create_unverified_context()
    with socket.create_connection(('127.0.0.1', port), timeout=8) as raw:
        with context.wrap_socket(raw, server_hostname=domain) as conn:
            cert = conn.getpeercert()
            if not cert:
                raise SelfstealError('Сертификат не предоставлен.')
    not_after = cert.get('notAfter')
    if not not_after:
        raise SelfstealError('В сертификате нет срока действия.')
    timestamp = ssl.cert_time_to_seconds(not_after)
    now = datetime.now(timezone.utc).timestamp()
    return {'domain': domain, 'not_after': not_after, 'expires_at': datetime.fromtimestamp(timestamp, timezone.utc),
            'days_left': int((timestamp - now) // 86400), 'verified': verify}


def certificate_status(*, verify=True):
    metadata = validate_installation()
    try:
        status = _certificate(metadata['domain'], metadata['https_port'], verify=verify)
    except (OSError, ssl.SSLError, SelfstealError) as exc:
        raise SelfstealError('TLS-проверка Caddy не пройдена: ' + type(exc).__name__) from None
    return status


def _safe_tail(path, max_bytes=MAX_LOG_BYTES):
    m.secure_path(path, directory=False)
    with path.open('rb') as stream:
        stream.seek(0, 2)
        size = stream.tell()
        stream.seek(max(0, size - max_bytes))
        data = stream.read(max_bytes)
    text = data.decode('utf-8', errors='replace')
    safe = ''.join(ch if ch in '\n\r\t' or ch in string.printable else '\ufffd' for ch in text)
    return safe[-max_bytes:]


def show_logs(kind='visits', lines=100):
    if not 1 <= lines <= 1000:
        raise SelfstealError('Число строк должно быть от 1 до 1000.')
    validate_installation()
    if kind == 'visits':
        if not ACCESS_LOG.exists():
            return 'Журнал посещений ещё не создан.\n'
        text = _safe_tail(ACCESS_LOG)
        return '\n'.join(text.splitlines()[-lines:]) + ('\n' if text else '')
    if kind == 'errors':
        result = m.run(['docker', 'logs', '--tail', str(lines), '--timestamps', CONTAINER], capture=True, combine_output=True, timeout=30)
        return ''.join(ch if ch in '\n\r\t' or ch in string.printable else '\ufffd' for ch in result)
    raise SelfstealError('Тип журнала: visits или errors.')


def print_status():
    metadata = validate_installation()
    obj = m.inspect(CONTAINER)
    state = obj.get('State', {})
    print('Контейнер:', CONTAINER)
    print('Состояние:', state.get('Status', 'unknown'))
    print('Перезапуски:', state.get('RestartCount', 'unknown'))
    try:
        cert = certificate_status()
        print('Домен:', cert['domain'])
        print('Сертификат истекает (UTC):', cert['expires_at'].isoformat())
        print('Осталось полных дней:', cert['days_left'])
        print('TLS цепочка и имя: проверены')
    except SelfstealError as exc:
        print('TLS:', exc)


def menu():
    while True:
        print('\nSelfsteal — безопасное управление Caddy backend')
        print('1. Статус и срок сертификата')
        print('2. Включить Caddy')
        print('3. Выключить Caddy')
        print('4. Перезапустить Caddy')
        print('5. Проверить/возобновить ACME')
        print('6. Логи посещений сайта')
        print('7. Ошибки Caddy/ACME')
        print('0. Выход')
        choice = input('Выберите действие: ').strip()
        if choice == '0': return
        if choice == '1': print_status()
        elif choice == '2': service_action('start')
        elif choice in ('3', '4'):
            if input('Сайт и backend будут недоступны. Введите ПОДТВЕРЖДАЮ: ').strip() == 'ПОДТВЕРЖДАЮ':
                service_action('stop' if choice == '3' else 'restart', confirm=True)
        elif choice == '5':
            certificate_status()
            print('Действующий сертификат проверен; Caddy продлевает его автоматически. Принудительная выдача не выполняется.')
            if input('Перезапустить Caddy для возобновления штатной ACME-автоматизации? [y/N]: ').lower() == 'y':
                service_action('restart', confirm=True)
                print_status()
        elif choice in ('6', '7'):
            print(show_logs('visits' if choice == '6' else 'errors'))
        else: print('Неизвестный пункт.')


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('action', nargs='?', choices=('menu', 'status', 'start', 'stop', 'restart', 'renew-check', 'logs'))
    parser.add_argument('--confirm', action='store_true')
    parser.add_argument('--kind', choices=('visits', 'errors'), default='visits')
    parser.add_argument('--lines', type=int, default=100)
    args = parser.parse_args(argv)
    try:
        action = args.action or 'menu'
        if action == 'menu': menu()
        elif action == 'status': print_status()
        elif action in ('start', 'stop', 'restart'):
            service_action(action, confirm=args.confirm)
        elif action == 'renew-check':
            certificate_status()
            print('Сертификат действующий; Caddy управляет продлением автоматически. Принудительный выпуск не выполнялся.')
        elif action == 'logs': print(show_logs(args.kind, args.lines))
        return 0
    except (SelfstealError, m.Failure, OSError, ValueError) as exc:
        print('ОШИБКА:', str(exc), file=sys.stderr)
        return 1


if __name__ == '__main__':
    raise SystemExit(main())
