#!/usr/bin/env python3
"""Fail-closed Ubuntu 24.04 bootstrap; callers must hold manage.lock().

FirewallGuard.commit() is an explicit assertion by the caller that a NEW SSH
login succeeded. It must never be called automatically after apply().
"""
import contextlib
import ipaddress
import os
from pathlib import Path
import re
import shlex
import shutil
import tempfile
import time
import uuid

from manage import Failure, run, secure_path, atomic_write, backup_dir

ENV = {**os.environ, 'LC_ALL': 'C', 'LANG': 'C'}
PACKAGES = ('ca-certificates', 'curl', 'gnupg', 'ufw', 'logrotate', 'iproute2', 'dnsutils')
DOCKER_FINGERPRINT = '9DC858229FC7DD38854AE2D88D81803C0EBFCD88'
CONFLICTS = ('docker.io', 'docker-compose', 'docker-compose-v2', 'docker-doc',
             'podman-docker', 'containerd', 'runc')
UFW_DIR = Path('/etc/ufw')
UFW_DEFAULT = Path('/etc/default/ufw')
LOGROTATE = Path('/etc/logrotate.d/remnanode')
LOGROTATE_TEXT = '''/var/log/remnanode/*.log {
    size 50M
    rotate 5
    compress
    missingok
    notifempty
    copytruncate
}
'''
RESERVED = {80, 443, 2222, 9443}
MARKER = 'remnanode-bootstrap-'
FIREWALL_LOCK = Path('/run/remnanode-ufw.lock')


@contextlib.contextmanager
def _firewall_lock():
    # The restore shell uses flock on this same inode. Never unlink this file.
    import fcntl
    import stat
    secure_path(FIREWALL_LOCK, directory=False)
    fd = os.open(FIREWALL_LOCK, os.O_CREAT | os.O_RDWR | os.O_NOFOLLOW, 0o600)
    try:
        info = os.fstat(fd)
        if (info.st_uid != 0 or info.st_nlink != 1 or not stat.S_ISREG(info.st_mode)
                or info.st_mode & 0o077):
            raise Failure('Небезопасный lock firewall.')
        fcntl.flock(fd, fcntl.LOCK_EX)
        try:
            yield
        finally:
            fcntl.flock(fd, fcntl.LOCK_UN)
    finally:
        os.close(fd)


def _ubuntu():
    if not hasattr(os, 'geteuid') or os.geteuid() != 0:
        raise Failure('Bootstrap требует root на Ubuntu 24.04.')
    info = Path('/etc/os-release').read_text(encoding='utf-8')
    if not (re.search(r'^ID=[\"\']?ubuntu[\"\']?$', info, re.M) and
            re.search(r'^VERSION_ID=[\"\']?24\.04[\"\']?$', info, re.M)):
        raise Failure('Bootstrap поддерживает только Ubuntu 24.04.')


def ensure_packages():
    """Install prerequisites, never install/reconfigure an SSH server."""
    _ubuntu()
    run(['apt-get', 'update'], timeout=600, env=ENV)
    run(['apt-get', 'install', '-y', '--no-install-recommends', *PACKAGES],
        timeout=900, env={**ENV, 'DEBIAN_FRONTEND': 'noninteractive'})


def _installed(package):
    result = run(['dpkg-query', '-W', '-f=${Status}', package], check=False)
    if result.returncode not in (0, 1):
        raise Failure('Не удалось проверить пакеты Docker.')
    return result.returncode == 0 and result.stdout.strip().endswith(' ok installed')


def _prepare_keyring_directory(path):
    path = secure_path(path, directory=True)
    if not path.exists():
        path.mkdir(mode=0o755, parents=True)
        os.chmod(path, 0o755)  # mkdir mode alone is reduced by installer umask 077.
    elif path.stat().st_mode & 0o005 != 0o005:
        raise Failure('Каталог Docker keyring недоступен _apt; настройте права вручную.')


def ensure_docker():
    """Keep a working Docker/Compose; otherwise use the fingerprint-checked repo."""
    _ubuntu()
    if shutil.which('docker'):
        # A broken existing installation is not permission to replace it.
        run(['docker', 'info'])
        run(['docker', 'compose', 'version'])
        return
    if any(_installed(package) for package in (*CONFLICTS, 'docker-ce', 'docker-ce-cli')):
        raise Failure('Обнаружены существующие/конфликтующие пакеты Docker; исправьте вручную.')
    arch = run(['dpkg', '--print-architecture'], capture=True).strip()
    if arch not in ('amd64', 'arm64'):
        raise Failure('Docker bootstrap поддерживает только amd64/arm64.')
    key = secure_path('/etc/apt/keyrings/remnanode-docker.asc', directory=False)
    source = secure_path('/etc/apt/sources.list.d/remnanode-docker.list', directory=False)
    repo = (f'deb [arch={arch} signed-by={key}] '
            'https://download.docker.com/linux/ubuntu noble stable\n')
    # Do not merge or silently replace someone else's Docker repository/key.
    sources = [Path('/etc/apt/sources.list')]
    sources += list(Path('/etc/apt/sources.list.d').glob('*.list'))
    sources += list(Path('/etc/apt/sources.list.d').glob('*.sources'))
    for path in sources:
        if path.exists() and path != source and 'download.docker.com' in path.read_text():
            raise Failure('Найден другой репозиторий Docker; проверьте его вручную.')
    if source.exists() and source.read_text() != repo:
        raise Failure('Неизвестное содержимое Docker apt source; перезапись запрещена.')
    _prepare_keyring_directory(key.parent)
    with tempfile.TemporaryDirectory(prefix='docker-key-') as temporary:
        downloaded = Path(temporary) / 'docker.asc'
        run(['curl', '--fail', '--silent', '--show-error', '--location',
             '--proto', '=https', '--proto-redir', '=https', '--max-time', '60',
             '--output', downloaded, 'https://download.docker.com/linux/ubuntu/gpg'])
        listing = run(['gpg', '--batch', '--no-options', '--homedir', temporary,
                       '--show-keys', '--with-colons', downloaded], capture=True)
        # Accept exactly the known primary key; subkey fingerprints are separate.
        primaries = []
        need_primary = False
        for line in listing.splitlines():
            fields = line.split(':')
            if fields[0] == 'pub':
                need_primary = True
            elif fields[0] == 'sub':
                need_primary = False
            elif fields[0] == 'fpr' and need_primary and len(fields) > 9:
                primaries.append(fields[9])
                need_primary = False
        if primaries != [DOCKER_FINGERPRINT]:
            raise Failure('Fingerprint ключа Docker не совпадает с доверенным.')
        key_text = downloaded.read_text(encoding='ascii')
        if key.exists() and key.read_text(encoding='ascii') != key_text:
            raise Failure('Существующий Docker key отличается; перезапись запрещена.')
        atomic_write(key, key_text, mode=0o644)
    atomic_write(source, repo, mode=0o644)
    run(['apt-get', 'update'], timeout=600, env=ENV)
    run(['apt-get', 'install', '-y', '--no-install-recommends', 'docker-ce',
         'docker-ce-cli', 'containerd.io', 'docker-buildx-plugin', 'docker-compose-plugin'],
        timeout=900, env={**ENV, 'DEBIAN_FRONTEND': 'noninteractive'})
    run(['systemctl', 'enable', '--now', 'docker.service'])
    run(['docker', 'info'])
    run(['docker', 'compose', 'version'])


def _connection():
    value = os.environ.get('SSH_CONNECTION')
    if not value:
        return None
    try:
        client, client_port, server, server_port = value.split()
        ipaddress.ip_address(client)
        ipaddress.ip_address(server)
        if not 1 <= int(client_port) <= 65535 or not 1 <= int(server_port) <= 65535:
            raise ValueError()
        return client, int(server_port)
    except ValueError as exc:
        raise Failure('SSH_CONNECTION некорректен; SSH безопасность не подтверждена.') from exc


def _validate_ports(ports):
    ports = list(ports)
    if not ports or any(type(p) is not int or not 1 <= p <= 65535 for p in ports):
        raise Failure('Не удалось определить SSH порты.')
    if RESERVED.intersection(ports):
        raise Failure('SSH конфликтует с портами 80/443/2222/9443; измените схему вручную.')
    return sorted(set(ports))


def discover_ssh_ports():
    """Find actual sshd listeners, including verified systemd socket activation."""
    output = run(['ss', '-H', '-ltnp'], capture=True, env=ENV)
    ports = set()
    addresses = {}
    systemd_ports = set()
    for line in output.splitlines():
        fields = line.split()
        if len(fields) < 5 or fields[0] != 'LISTEN':
            continue
        try:
            port = int(fields[3].rsplit(':', 1)[1])
        except (ValueError, IndexError):
            continue
        address = fields[3].rsplit(':', 1)[0].strip('[]')
        if re.search(r'\("sshd"', line):
            ports.add(port)
            addresses.setdefault(port, set()).add(address)
        elif re.search(r'\("systemd"', line):
            systemd_ports.add(port)
            addresses.setdefault(port, set()).add(address)
    if systemd_ports:
        result = run(['systemctl', 'is-active', 'ssh.socket'], check=False, env=ENV)
        if result.returncode == 0 and result.stdout.strip() == 'active':
            config = run(['/usr/sbin/sshd', '-T'], capture=True, env=ENV)
            configured = {int(p) for p in re.findall(r'^port (\d+)$', config, re.M)}
            if not configured:
                raise Failure('sshd -T не подтвердил порты socket activation.')
            listen = run(['systemctl', 'show', 'ssh.socket', '--property=Listen', '--value'],
                         capture=True, env=ENV)
            socket_ports = set()
            for endpoint in re.findall(r'(\S+) \(Stream\)', listen):
                try:
                    socket_ports.add(int(endpoint.rsplit(':', 1)[-1]))
                except ValueError:
                    raise Failure('Неизвестный Listen ssh.socket.')
            matched = systemd_ports.intersection(configured, socket_ports)
            if not matched:
                raise Failure('ssh.socket, sshd -T и фактические listeners не согласованы.')
            ports.update(matched)
    ports = _validate_ports(ports)
    current = _connection()
    if current:
        if current[1] not in ports:
            raise Failure('SSH_CONNECTION не совпадает с обнаруженными SSH listeners.')
        server = os.environ['SSH_CONNECTION'].split()[2]
        candidates = addresses.get(current[1], set())
        wildcards = {'*', '0.0.0.0'} if ipaddress.ip_address(server).version == 4 else {'*', '::'}
        if server not in candidates and not candidates.intersection(wildcards):
            raise Failure('SSH listener не соответствует адресу SSH_CONNECTION.')
    return ports


def install_logrotate():
    """Install only into a free path (or reuse identical config); return backup/None."""
    path = secure_path(LOGROTATE, directory=False)
    if path.exists() and path.read_text() != LOGROTATE_TEXT:
        raise Failure('Неизвестный logrotate config; автоматическая перезапись запрещена.')
    created = not path.exists()
    if created:
        atomic_write(path, LOGROTATE_TEXT, mode=0o644)
    try:
        run(['logrotate', '-d', path])
        run(['systemctl', 'enable', '--now', 'logrotate.timer'])
    except BaseException:
        if created:
            path.unlink()
        raise
    return None  # No existing content was overwritten, so no backup is needed.


def _status(command=None):
    return (command or run)(['ufw', 'status', 'numbered'], capture=True, env=ENV)


def _rows(status):
    result = []
    for line in status.splitlines():
        match = re.match(r'^\[\s*(\d+)\]\s+(.+)$', line.strip())
        if match:
            body, _, comment = match[2].partition('#')
            result.append((int(match[1]), ' '.join(body.split()), comment.strip()))
    return result


def _active_ssh_safe(status, ports):
    """Prove the current SSH flow using simple ordered UFW rules, else refuse."""
    connection = _connection()
    if not connection or connection[1] not in ports:
        raise Failure('Активный UFW требует подтверждённый текущий SSH_CONNECTION.')
    client = ipaddress.ip_address(connection[0])
    current_port = connection[1]
    for _, row, comment in _rows(status):
        if comment.startswith(MARKER):
            continue
        ipv6 = '(v6)' in row
        if ipv6 != (client.version == 6):
            continue
        row = row.replace(' (v6)', '')
        match = re.fullmatch(r'(Anywhere|\d+(?:/tcp)?) (ALLOW|LIMIT|DENY|REJECT) IN (\S+)', row)
        if not match:
            # Unknown earlier rules could affect the connection; no guessing.
            raise Failure('Неизвестное правило активного UFW; проверьте SSH вручную.')
        target, action, origin = match.groups()
        if target != 'Anywhere' and int(target.split('/')[0]) != current_port:
            continue
        try:
            applies = origin == 'Anywhere' or client in ipaddress.ip_network(origin, strict=False)
        except ValueError as exc:
            raise Failure('Неизвестный источник правила UFW.') from exc
        if applies:
            if action not in ('ALLOW', 'LIMIT'):
                break
            return
    raise Failure('Активный UFW не подтвердил разрешение текущего SSH; изменения запрещены.')


def _secure_tree(path):
    secure_path(path, directory=True)
    for root, directories, files in os.walk(path):
        for name in directories:
            secure_path(Path(root) / name, directory=True)
        for name in files:
            secure_path(Path(root) / name, directory=False)


class FirewallGuard:
    """Five-minute rollback transaction. Caller owns prompt/new-login verification."""
    def __init__(self, panel, ports, folder, active, original):
        self.panel_ip = panel
        self.ssh_ports = ports
        self.backup = folder
        self.was_active = active
        self.original = original
        self.script = folder / 'restore-ufw.sh'
        self.unit = 'remnanode-ufw-rollback-' + uuid.uuid4().hex
        self.applied = False
        self.finished = False
        self.restored = False

    def _unexpired(self, command=None):
        command = command or run
        command(['systemctl', 'is-active', '--quiet', self.unit + '.timer'])
        stamp = command(['systemctl', 'show', self.unit + '.service',
                     '--property=ExecMainStartTimestampMonotonic', '--value'],
                    capture=True).strip()
        if stamp != '0':
            raise Failure('Rollback service уже запускался или его состояние неизвестно.')

    def _cancel(self):
        # Stop the timer, not a possibly running restoration service.
        run(['systemctl', 'stop', self.unit + '.timer'])

    def apply(self):
        if self.finished or self.applied:
            raise Failure('Firewall transaction уже применена или завершена.')
        try:
            with _firewall_lock():
                self._apply_locked()
        except BaseException:
            # Restore shell acquires the same lock: release it before invoking.
            self.rollback()
            raise
        return self

    def _apply_locked(self):
        deadline = time.monotonic() + 120

        def command(args, **kwargs):
            remaining = deadline - time.monotonic()
            if remaining <= 0:
                raise Failure('Превышен общий таймаут firewall apply (120 секунд).')
            return run(args, timeout=min(120, remaining), **kwargs)

        if _status(command) != self.original:
            raise Failure('UFW изменился после snapshot; операция отменена.')
        self._unexpired(command)
        config = UFW_DEFAULT.read_text()
        if len(re.findall(r'^IPV6=.*$', config, re.M)) != 1:
            raise Failure('Неоднозначный IPV6 в /etc/default/ufw.')
        atomic_write(UFW_DEFAULT, re.sub(r'^IPV6=.*$', 'IPV6=yes', config, flags=re.M), mode=0o644)
        # Remove only previously validated rules owned by this module.
        for number, _, comment in reversed(_rows(self.original)):
            if comment.startswith(MARKER):
                command(['ufw', '--force', 'delete', str(number)])
        rules = [(['allow', 'in', 'from', self.panel_ip, 'to', 'any', 'port', '2222',
                   'proto', 'tcp'], 'panel'),
                 (['deny', 'in', 'to', 'any', 'port', '2222', 'proto', 'tcp'], 'api-deny'),
                 (['deny', 'in', 'to', 'any', 'port', '9443', 'proto', 'tcp'], 'backend-deny'),
                 (['allow', 'in', 'to', 'any', 'port', '80', 'proto', 'tcp'], 'http'),
                 (['allow', 'in', 'to', 'any', 'port', '443', 'proto', 'tcp'], 'https')]
        if not self.was_active:
            # Add SSH before enabling. No SSH rules are added to an active firewall.
            for port in self.ssh_ports:
                command(['ufw', 'allow', 'in', 'to', 'any', 'port', str(port), 'proto', 'tcp'])
            command(['ufw', 'default', 'deny', 'incoming'])
        for args, label in reversed(rules):
            command(['ufw', 'insert', '1', *args, 'comment', MARKER + label])
        command(['ufw', 'reload'] if self.was_active else ['ufw', '--force', 'enable'])
        verified = _status(command)
        _verify_rules(verified, self.panel_ip)
        if self.was_active:
            _active_ssh_safe(verified, self.ssh_ports)
        self._unexpired(command)
        self.applied = True

    def commit(self):
        """Call ONLY after the user explicitly confirms a successful new SSH login."""
        if not self.applied or self.finished:
            raise Failure('Нет применённой firewall transaction для подтверждения.')
        with _firewall_lock():
            # Serialize with restoration; an already started service is refused.
            self._unexpired()
            _verify_rules(_status(), self.panel_ip)
            self._cancel()
            # Recheck after stopping the timer to close expiry during verification.
            stamp = run(['systemctl', 'show', self.unit + '.service',
                         '--property=ExecMainStartTimestampMonotonic', '--value'],
                        capture=True).strip()
            if stamp != '0':
                raise Failure('Rollback service запустился во время подтверждения; commit запрещён.')
            _verify_rules(_status(), self.panel_ip)
            self.finished = True

    def rollback(self):
        """Restore even after commit, e.g. after stopping a failed deployment."""
        if self.restored:
            return
        run([self.script])  # On failure leave timer armed, allowing another attempt.
        self._cancel()
        self.finished = True
        self.restored = True


def _verify_rules(status, panel):
    if not status.startswith('Status: active'):
        raise Failure('UFW не подтвердил активное состояние.')
    rows = [row for _, row, _ in _rows(status)]
    v4 = [r for r in rows if '(v6)' not in r]
    v6 = [r for r in rows if '(v6)' in r]
    if (v4[:5] != [f'2222/tcp ALLOW IN {panel}', '2222/tcp DENY IN Anywhere',
                   '9443/tcp DENY IN Anywhere', '80/tcp ALLOW IN Anywhere',
                   '443/tcp ALLOW IN Anywhere'] or
            v6[:4] != ['2222/tcp (v6) DENY IN Anywhere (v6)',
                       '9443/tcp (v6) DENY IN Anywhere (v6)',
                       '80/tcp (v6) ALLOW IN Anywhere (v6)',
                       '443/tcp (v6) ALLOW IN Anywhere (v6)']):
        raise Failure('Не подтверждён приоритет IPv4/IPv6 правил API, backend и сайта.')


def prepare_firewall(panel_ip, ssh_ports):
    """Snapshot, arm rollback BEFORE changes, and return an unapplied guard."""
    _ubuntu()
    if not shutil.which('flock'):
        raise Failure('Для безопасного rollback требуется util-linux flock.')
    with _firewall_lock():
        pass  # Create/validate the persistent root-only inode before arming timer.
    try:
        panel = ipaddress.IPv4Address(panel_ip)
        if panel.is_unspecified or panel.is_multicast or panel.is_loopback or int(panel) == 0xffffffff:
            raise ValueError()
    except (ValueError, ipaddress.AddressValueError) as exc:
        raise Failure('Нужен корректный IPv4 панели.') from exc
    ports = _validate_ports(ssh_ports)
    if ports != discover_ssh_ports():
        raise Failure('Переданные SSH порты не совпадают с обнаруженными.')
    status = _status()
    if not re.match(r'^Status: (active|inactive)\s*(?:\n|$)', status):
        raise Failure('Неизвестный статус UFW.')
    active = status.startswith('Status: active')
    _secure_tree(UFW_DIR)
    config = secure_path(UFW_DEFAULT, directory=False).read_text()
    if active:
        if not re.search(r'^IPV6=yes$', config, re.M):
            raise Failure('Активный UFW без IPV6=yes требует ручной настройки.')
        _active_ssh_safe(status, ports)
    else:
        added = run(['ufw', 'show', 'added'], capture=True, env=ENV)
        if any(line.strip().startswith('ufw ') for line in added.splitlines()):
            raise Failure('Неактивный UFW содержит прежние правила; требуется ручная проверка.')
    # Reserved comments are not permission to delete arbitrary rules.
    allowed_labels = {'panel', 'api-deny', 'backend-deny', 'http', 'https'}
    for _, row, comment in _rows(status):
        if comment.startswith(MARKER):
            if comment[len(MARKER):] not in allowed_labels or not re.match(r'^(2222|9443|80|443)/tcp ', row):
                raise Failure('Неизвестное управляемое правило UFW; удаление запрещено.')
    folder = backup_dir('bootstrap-ufw')
    shutil.copytree(UFW_DIR, folder / 'etc-ufw', copy_function=shutil.copy2)
    shutil.copy2(UFW_DEFAULT, folder / 'default-ufw')
    guard = FirewallGuard(str(panel), ports, folder, active, status)
    # All interpolated paths are generated locally, quoted, and root-owned.
    script = ('#!/bin/sh\nset -eu\nPATH=/usr/sbin:/usr/bin:/sbin:/bin\nexport PATH\n'
              '[ "$(id -u)" = 0 ] || exit 1\n' +
              'exec 9<> ' + shlex.quote(str(FIREWALL_LOCK)) + '\nflock -x 9\n' +
              'cp -a -- ' + shlex.quote(str(folder / 'etc-ufw') + '/.') + ' /etc/ufw/\n' +
              'cp -a -- ' + shlex.quote(str(folder / 'default-ufw')) + ' /etc/default/ufw\n' +
              ('ufw reload\n' if active else 'ufw --force disable\n'))
    atomic_write(guard.script, script, mode=0o700)
    run(['systemd-run', '--unit=' + guard.unit, '--on-active=5m', '--timer-property=AccuracySec=1s',
         '--property=Type=oneshot', str(guard.script)])
    run(['systemctl', 'is-active', '--quiet', guard.unit + '.timer'])
    return guard
