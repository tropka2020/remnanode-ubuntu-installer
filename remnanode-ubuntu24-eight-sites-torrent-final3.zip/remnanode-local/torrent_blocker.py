"""Conservative, offline-testable orchestration of the unmodified upstream installer.

APT/package files and firewall rules are deliberately NOT owned by this wrapper.
A rollback quiesces the service and records retained resources, never uninstalls
packages, deletes a discovered tree, or flushes somebody else's firewall.
"""
from dataclasses import dataclass
from datetime import datetime, timezone
import hashlib
import ipaddress
import json
import shlex
import os
from pathlib import Path
import re
import shutil
import signal
import stat
import subprocess
import sys
import tempfile
import time
from urllib.parse import urlparse

import manage as m
import torrent_release

DEFAULT_UPSTREAM_INSTALLER_URL = torrent_release.API_URL
LOG_FILE = "/var/log/remnanode/access.log"
BLOCK_MODE = "iptables"
SERVICE = "tblocker.service"
CONFIG = "/opt/tblocker/config.yaml"
READINESS_TIMEOUT = 15
STABLE_SECONDS = 1.5


@dataclass(frozen=True)
class InstallPaths:
    blocker_dir: Path = Path("/opt/tblocker")
    config: Path = Path(CONFIG)
    unit: Path = Path("/etc/systemd/system/tblocker.service")
    backup_dir: Path = Path("/var/backups/remnanode-local")
    download_dir: Path = Path("/opt")
    log: Path = Path(LOG_FILE)
    # These are explicit system paths, not paths discovered in a new tree.
    vendor_units: tuple = (Path("/usr/lib/systemd/system/tblocker.service"),
                           Path("/lib/systemd/system/tblocker.service"))
    runtime_unit: Path = Path("/run/systemd/system/tblocker.service")


def _bytes(value):
    if value is None:
        return b""
    return value if isinstance(value, bytes) else str(value).encode("utf-8", "backslashreplace")


def _stdout(result):
    value = getattr(result, "stdout", "")
    return _bytes(value).decode("utf-8", "replace")


def _code(result):
    value = getattr(result, "returncode", None)
    if not isinstance(value, int):
        raise m.Failure("Команда не вернула exitcode; состояние неизвестно.")
    return value


def _trusted_directory(path):
    info = path.lstat()
    if not stat.S_ISDIR(info.st_mode):
        raise m.Failure("Небезопасный каталог: " + str(path))
    if os.name == "posix" and (info.st_uid != 0 or info.st_mode & 0o022):
        raise m.Failure("Каталог не root-owned или доступен для записи: " + str(path))


def _ancestors(path):
    """Validate existing ancestors; never follow arbitrary symlinks.

    Ubuntu's /lib alias is resolved only by _unit_paths, not generally here.
    """
    path = Path(path)
    if not path.is_absolute() or ".." in path.parts:
        raise m.Failure("Требуется абсолютный безопасный путь.")
    for parent in reversed((path, *path.parents)):
        if parent.exists() or parent.is_symlink():
            _trusted_directory(parent)


def _private_dir(path):
    path = Path(path)
    _ancestors(path.parent)
    path.mkdir(mode=0o700, parents=True, exist_ok=True)
    _trusted_directory(path)
    os.chmod(path, 0o700)
    return path


def _log_parent(path):
    if Path(path) == Path(LOG_FILE):
        m.secure_path(path.parent, directory=True, allow_system_parent=True)
    else:
        _ancestors(path.parent)


def _safe_file(path):
    if Path(path) == Path(LOG_FILE):
        _log_parent(path)
    else:
        _ancestors(path.parent)
    info = path.lstat()
    if not stat.S_ISREG(info.st_mode) or info.st_nlink != 1:
        raise m.Failure("Небезопасный обычный файл: " + str(path))
    if os.name == "posix" and (info.st_uid != 0 or info.st_mode & 0o022):
        raise m.Failure("Файл не root-owned или доступен для записи: " + str(path))
    return info


def _write_private(path, content):
    # Every diagnostic name is new. No symlink following or overwriting.
    fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL | getattr(os, "O_NOFOLLOW", 0), 0o600)
    with os.fdopen(fd, "wb") as stream:
        stream.write(_bytes(content))
    os.chmod(path, 0o600)


class Diagnostics:
    def __init__(self, backup):
        self.backup = _private_dir(backup)
        self.directory = Path(tempfile.mkdtemp(prefix="tblocker-", dir=self.backup))
        os.chmod(self.directory, 0o700)
        self.sequence = 0

    def paths(self, phase):
        self.sequence += 1
        stem = self.directory / (f"{self.sequence:03d}-" + phase)
        return Path(str(stem) + ".stdout"), Path(str(stem) + ".stderr"), Path(str(stem) + ".json")

    def execute(self, phase, operation, *, allowed=(0,), streamed=False):
        stdout, stderr, metadata = self.paths(phase)
        started = datetime.now(timezone.utc).isoformat()
        error = None
        result = None
        code = None
        try:
            if streamed:
                result = operation(stdout, stderr)
            else:
                result = operation()
            code = _code(result)
        except BaseException as exc:
            error = exc
            code = 124 if isinstance(exc, subprocess.TimeoutExpired) else getattr(exc, "returncode", None)
        for path, name in ((stdout, "stdout"), (stderr, "stderr")):
            if not path.exists():
                data = getattr(error if error else result, name, b"")
                if error and name == "stdout":
                    data = getattr(error, "output", data)
                _write_private(path, data)
        _write_private(metadata, json.dumps({
            "phase": phase, "started_utc": started,
            "finished_utc": datetime.now(timezone.utc).isoformat(), "exitcode": code,
            # Exception messages may contain secrets: persist only in private diagnostics.
            "exception": repr(error) if error else None,
        }, ensure_ascii=False, indent=2))
        if error or code not in allowed:
            message = (f"tblocker phase={phase} exitcode={code if code is not None else 'unknown'}; "
                       f"stdout={stdout}; stderr={stderr}; metadata={metadata}")
            if isinstance(error, (KeyboardInterrupt, SystemExit)):
                raise error
            raise m.Failure(message) from error
        return result


def _kill_group(process):
    """Only called for a Popen created with start_new_session=True on Linux."""
    try:
        os.killpg(process.pid, signal.SIGKILL)
    except ProcessLookupError:
        pass
    process.wait()  # reap before allowing rollback to touch anything


@dataclass
class CommandRunner:
    run: object
    which: object = shutil.which
    download: object = None
    child: object = None
    child_running: bool = False

    def __post_init__(self):
        if self.download is None:
            self.download = self._download
        if self.child is None:
            self.child = self._child

    def _download(self, url, destination, *, timeout=600, stdout_path, stderr_path):
        return self._child([
            "curl", "--disable", "--fail", "--silent", "--show-error", "--location",
            "--proto", "=https", "--proto-redir", "=https", "--connect-timeout", "30",
            "--max-time", str(timeout), "--max-filesize", str(torrent_release.MAX_PACKAGE),
            "--output", str(destination), "--", url,
        ], input_text="", cwd=destination.parent, timeout=timeout,
            stdout_path=stdout_path, stderr_path=stderr_path)

    def _child(self, argv, *, input_text, cwd, stdout_path, stderr_path, timeout=900):
        _root_preflight()
        stdin = Path(cwd) / ("stdin-" + os.urandom(8).hex())
        _write_private(stdin, input_text)
        _write_private(stdout_path, b"")
        _write_private(stderr_path, b"")
        try:
            with stdin.open("rb") as source, Path(stdout_path).open("ab") as out, Path(stderr_path).open("ab") as err:
                process = subprocess.Popen(
                    [str(item) for item in argv], stdin=source, stdout=out, stderr=err,
                    cwd=str(cwd), start_new_session=True,
                    env={**os.environ, "LC_ALL": "C", "LANG": "C", "DEBIAN_FRONTEND": "noninteractive"},
                )
                self.child_running = True
                try:
                    code = process.wait(timeout=timeout)
                finally:
                    # Also quiesce background descendants on an otherwise successful exit.
                    # systemd-owned services have a separate session and are stopped by rollback.
                    _kill_group(process)
                    self.child_running = False
                return subprocess.CompletedProcess(argv, code)
        finally:
            stdin.unlink()


def _root_preflight():
    if sys.platform != "linux" or not hasattr(os, "geteuid") or os.geteuid() != 0:
        raise m.Failure("Установка torrent blocker требует root на Linux.")


def _unit_paths(paths):
    units = [paths.unit, paths.runtime_unit]
    for unit in paths.vendor_units:
        # /lib -> /usr/lib is a standard Ubuntu alias; no other alias is allowed.
        unit = Path(unit)
        if str(unit) == "/lib/systemd/system/tblocker.service" and Path("/lib").is_symlink():
            if Path("/lib").resolve() != Path("/usr/lib"):
                raise m.Failure("Неизвестный /lib alias.")
            unit = Path("/usr/lib/systemd/system/tblocker.service")
        units.append(unit)
    return tuple(dict.fromkeys(units))


def _command(runner, diagnostics, phase, args, *, allowed=(0,), timeout=15):
    return diagnostics.execute(phase, lambda: runner.run(
        args, capture=False, check=False, timeout=timeout,
        env={**os.environ, "LC_ALL": "C", "LANG": "C", "DEBIAN_FRONTEND": "noninteractive"}), allowed=allowed)


def _show(runner, diagnostics, phase):
    result = _command(runner, diagnostics, phase, [
        "systemctl", "show", SERVICE, "--property=LoadState,ActiveState,SubState,UnitFileState,"
        "FragmentPath,DropInPaths,ExecMainStatus,Result,NRestarts",
    ], allowed=(0, 1))
    values = {}
    for line in _stdout(result).splitlines():
        if "=" in line:
            key, value = line.split("=", 1)
            if key in values:
                raise m.Failure("Повторяющееся systemctl property.")
            values[key] = value
    required = {"LoadState", "ActiveState", "SubState", "UnitFileState", "FragmentPath",
                "DropInPaths", "ExecMainStatus", "Result", "NRestarts"}
    if not required.issubset(values):
        raise m.Failure("Неполный systemctl show; состояние неизвестно.")
    return values


def _validate_firewall_snapshot(result, *, allow_owned=False):
    text = _stdout(result)
    if _code(result) != 0 or "*filter\n" not in text or "COMMIT" not in text:
        raise m.Failure("Состояние iptables неизвестно.")
    # The upstream dynamically creates T<IP> chains. Any existing T* chain or
    # reference is ambiguous: do not claim it, delete it, or proceed over it.
    inspected = text
    if allow_owned:
        inspected = "\n".join(line for line in text.splitlines() if RAW_CHAIN not in line)
    if re.search(r"^:T\S*\s|(?:^|\s)-(?:j|g)\s+T\S*", inspected, re.MULTILINE):
        raise m.Failure("Найдены чужие/неизвестные T* chains; ручная проверка firewall.")


RAW_CHAIN = "TBLOCKER_BLOCKED"


def _raw_rules(result):
    """Return only an exact upstream raw chain; reject additional users/rules."""
    _validate_firewall_snapshot(result, allow_owned=True)
    table = None
    declaration = False
    jumps, drops = [], []
    for line in _stdout(result).splitlines():
        if line.startswith("*"):
            table = line[1:]
        elif line == "COMMIT":
            table = None
        elif RAW_CHAIN in line:
            if table != "raw":
                raise m.Failure("Неизвестный пользователь TBLOCKER_BLOCKED вне raw.")
            if line == ":TBLOCKER_BLOCKED - [0:0]":
                if declaration:
                    raise m.Failure("Повторяющийся raw chain.")
                declaration = True
                continue
            words = shlex.split(line)
            if words == ["-A", "PREROUTING", "-j", RAW_CHAIN]:
                jumps.append(words)
            elif len(words) == 6 and words[:3] == ["-A", RAW_CHAIN, "-s"] and words[4:] == ["-j", "DROP"]:
                try:
                    network = ipaddress.IPv4Network(words[3], strict=True)
                except ValueError as exc:
                    raise m.Failure("Неизвестный source в raw chain.") from exc
                if network.prefixlen != 32:
                    raise m.Failure("В raw chain найден не одиночный IPv4.")
                drops.append(words)
            else:
                raise m.Failure("Неизвестные правила/ссылки TBLOCKER_BLOCKED; сохранены.")
    if not declaration:
        if jumps or drops:
            raise m.Failure("Raw chain declaration отсутствует.")
        return ()
    if len(jumps) != 1 or len({tuple(rule) for rule in drops}) != len(drops):
        raise m.Failure("Неоднозначный jump или duplicate raw rules.")
    return tuple(tuple(rule) for rule in jumps + drops)


def preflight(*, runner, paths=InstallPaths(), diagnostics=None):
    """Read-only inspection; diagnostic files are the only writes."""
    _root_preflight()
    for name in ("curl", "iptables", "iptables-save", "conntrack", "systemctl", "dpkg", "dpkg-query", "dpkg-deb", "apt-get"): 
        if runner.which(name) is None:
            raise m.Failure("Не найдена обязательная команда: " + name)
    for directory in (paths.download_dir, paths.blocker_dir.parent, paths.backup_dir):
        _ancestors(directory)
    _log_parent(paths.log)
    units = _unit_paths(paths)
    for target in (paths.blocker_dir, paths.config, *units):
        _ancestors(target.parent)
        if target.exists() or target.is_symlink():
            raise m.Failure("Найдена существующая/чужая цель tblocker: " + str(target))
    for unit in units:
        dropins = Path(str(unit) + ".d")
        if dropins.exists() or dropins.is_symlink():
            raise m.Failure("Найдены чужие drop-ins: " + str(dropins))
    if diagnostics is None:
        # Public preflight stays usable independently and uses the same checks.
        def cmd(phase, args, allowed=(0,)):
            result = runner.run(args, capture=False, check=False, timeout=15,
                                env={**os.environ, "LC_ALL": "C", "LANG": "C"})
            if _code(result) not in allowed:
                raise m.Failure("Не удалось проверить " + phase)
            return result
        class ReadOnlyDiagnostics:
            def execute(self, phase, operation, **kwargs):
                result = operation()
                if _code(result) not in kwargs.get("allowed", (0,)):
                    raise m.Failure("Не удалось проверить " + phase)
                return result
        diagnostics = ReadOnlyDiagnostics()
    else:
        def cmd(phase, args, allowed=(0,)):
            return _command(runner, diagnostics, phase, args, allowed=allowed)
    state = _show(runner, diagnostics, "preflight-service")
    if (state["LoadState"] != "not-found" or state["FragmentPath"] or state["DropInPaths"] or
            state["ActiveState"] != "inactive" or state["UnitFileState"] not in ("", "not-found")):
        raise m.Failure("Найден чужой tblocker.service или неизвестное состояние.")
    package = cmd("preflight-package", ["dpkg-query", "-W", "-f=${db:Status-Abbrev}", "tblocker"], (0, 1))
    if _code(package) != 1 or _stdout(package).strip():
        raise m.Failure("Найдено существующее/частичное package state tblocker.")
    # Exit 1 is only accepted for dpkg-query's precise absent-package diagnostic.
    if not re.search(r"no packages found matching tblocker", _bytes(getattr(package, "stderr", b"")).decode("utf-8", "replace")):
        raise m.Failure("Отсутствие пакета tblocker не подтверждено.")
    _validate_firewall_snapshot(cmd("preflight-firewall", ["iptables-save"]))
    backend = _stdout(cmd("preflight-backend", ["iptables", "--version"]))
    if not re.fullmatch(r"iptables v[\d.]+ \((nf_tables|legacy)\)\s*", backend):
        raise m.Failure("Неизвестный iptables backend.")
    if runner.which("ufw"):
        ufw = _stdout(cmd("preflight-ufw", ["ufw", "status"]))
        if not re.match(r"^Status: (active|inactive)(?:\s|$)", ufw):
            raise m.Failure("Неизвестное состояние UFW.")
    if paths.log.exists() or paths.log.is_symlink():
        _safe_file(paths.log)
    return True


def _prepare_log(paths):
    _log_parent(paths.log)
    paths.log.parent.mkdir(mode=0o755, parents=True, exist_ok=True)
    _log_parent(paths.log)
    try:
        fd = os.open(paths.log, os.O_WRONLY | os.O_CREAT | os.O_EXCL | getattr(os, "O_NOFOLLOW", 0), 0o600)
    except FileExistsError:
        _safe_file(paths.log)
        return False
    else:
        os.close(fd)
        _safe_file(paths.log)
        return True


def _block_package_start(paths):
    """Own a temporary runtime condition; enabling the package remains possible."""
    directory = Path(str(paths.runtime_unit) + '.d')
    _ancestors(directory.parent)
    directory.mkdir(mode=0o700, parents=True, exist_ok=False)
    gate = directory / '90-remnanode-install-gate.conf'
    missing = directory / ('not-created-' + os.urandom(16).hex())
    content = '[Unit]\nConditionPathExists=' + str(missing) + '\n'
    _write_private(gate, content)
    return gate, content


def _release_package_start(gate):
    if gate is None:
        return
    path, expected = gate
    _safe_file(path)
    if path.read_text(encoding='utf-8') != expected:
        raise m.Failure('Runtime gate tblocker изменён; автоматическое удаление запрещено.')
    path.unlink()
    if not any(path.parent.iterdir()):
        path.parent.rmdir()


def _parse_config(path):
    """Read only the upstream flat scalar contract; never execute YAML tags.

    Unknown flat scalar keys are tolerated for forward compatibility; nested
    structures/tags/aliases are rejected rather than ambiguously interpreted.
    """
    values = {}
    for line in path.read_text(encoding="utf-8").splitlines():
        if not line.strip() or line.lstrip().startswith("#"):
            continue
        match = re.fullmatch(r"([A-Za-z][A-Za-z0-9_]*):\s*(.*?)\s*", line)
        if not match:
            raise m.Failure("Неизвестный формат upstream config.yaml.")
        key, value = match.groups()
        if key in values:
            raise m.Failure("Повторяющийся ключ upstream config.yaml.")
        if value.startswith('"'):
            try:
                value, end = json.JSONDecoder().raw_decode(value)
                trailing = match.group(2)[end:].strip()
                if trailing and not trailing.startswith("#"):
                    raise ValueError("trailing scalar")
                if not isinstance(value, str):
                    raise ValueError("non-string scalar")
            except ValueError as exc:
                raise m.Failure("Неизвестный YAML scalar.") from exc
        elif value.startswith("'"):
            quoted = re.fullmatch(r"'((?:[^']|'')*)'\s*(?:#.*)?", value)
            if not quoted:
                raise m.Failure("Неизвестный YAML scalar.")
            value = quoted.group(1).replace("''", "'")
        else:
            value = value.split(" #", 1)[0].strip()
            if value.startswith(("!", "&", "*", "[", "{", "|", ">")):
                raise m.Failure("Неизвестный YAML scalar.")
        values[key] = value
    return values


def _verify_config(paths):
    _safe_file(paths.config)
    values = _parse_config(paths.config)
    if any(values.get(key) != value for key, value in {
        "LogFile": LOG_FILE, "BlockMode": BLOCK_MODE, "TorrentTag": "TORRENT",
    }.items()):
        raise m.Failure("Upstream config.yaml не подтверждает LogFile/BlockMode/TorrentTag TORRENT.")
    for key, value in values.items():
        if "webhook" in key.lower() and str(value).lower() not in ("", "false", "null", "~", "0"):
            raise m.Failure("Upstream неожиданно включил webhook.")


def _verify_result(paths, runner, diagnostics):
    _verify_config(paths)
    deadline = time.monotonic() + READINESS_TIMEOUT
    stable_since = None
    stable_restarts = None
    while time.monotonic() < deadline:
        state = _show(runner, diagnostics, "readiness")
        if state["FragmentPath"] not in {str(path) for path in _unit_paths(paths)} or state["DropInPaths"]:
            raise m.Failure("Неподтверждённый FragmentPath/drop-ins tblocker.service.")
        _safe_file(Path(state["FragmentPath"]))
        try:
            restarts = int(state["NRestarts"])
            status = int(state["ExecMainStatus"])
        except ValueError as exc:
            raise m.Failure("Неизвестные числовые service properties.") from exc
        if restarts < 0 or restarts > 0 or status != 0 or state["Result"] != "success":
            raise m.Failure("tblocker.service завершился ошибкой или перезапускается.")
        ready = (state["LoadState"] == "loaded" and state["ActiveState"] == "active" and
                 state["SubState"] == "running" and state["UnitFileState"] == "enabled")
        now = time.monotonic()
        if ready:
            if stable_since is None or stable_restarts != restarts:
                stable_since, stable_restarts = now, restarts
            if now - stable_since >= STABLE_SECONDS:
                return
        else:
            stable_since = None
        time.sleep(min(0.25, max(0, deadline - now)))
    raise m.Failure("Истёк bounded readiness timeout tblocker.service.")


class Transaction:
    """Rollback is service quiescence, NOT a package uninstallation."""
    def __init__(self, paths, backup, runner, diagnostics=None):
        self.paths, self.backup, self.runner = paths, Path(backup), runner
        self.diagnostics = diagnostics or Diagnostics(backup)
        self.service_started = False
        self.child_attempted = False
        self.log_created = False
        self.start_gate = None
        self.raw_owned = None
        self.owned_files = []  # Kept for callers; discovered/package files never become owned.
        self.retained_resources = []
        self._done = False

    def rollback(self):
        if self._done:
            return
        if getattr(self.runner, "child_running", False):
            raise m.Failure("Откат запрещён: installer child ещё не завершён; " + str(self.diagnostics.directory))
        if self.child_attempted:
            state = _show(self.runner, self.diagnostics, "rollback-before-stop")
            if state['LoadState'] != 'not-found':
                _command(self.runner, self.diagnostics, "rollback-stop", ["systemctl", "stop", SERVICE], timeout=60)
                _command(self.runner, self.diagnostics, "rollback-disable", ["systemctl", "disable", SERVICE], timeout=60)
            state = _show(self.runner, self.diagnostics, "rollback-verify")
            if state["ActiveState"] != "inactive" or state["UnitFileState"] not in ("disabled", "not-found", ""):
                raise m.Failure("Откат остановлен: inactive/disabled не подтверждены; " + str(self.diagnostics.directory))
        if self.start_gate is not None:
            _release_package_start(self.start_gate)
            self.start_gate = None
            _command(self.runner, self.diagnostics, 'rollback-gate-reload', ['systemctl', 'daemon-reload'])
        firewall_error = None
        if self.child_attempted:
            try:
                current = _raw_rules(_command(self.runner, self.diagnostics, "rollback-firewall", ["iptables-save"]))
                if current and (self.raw_owned is None or current != self.raw_owned):
                    raise m.Failure("Принадлежность/неизменность raw chain не подтверждена; правила сохранены.")
                if current:
                    # Exact individual deletions only; never -F, restore, or unknown chains.
                    for rule in current:
                        _command(self.runner, self.diagnostics, "rollback-rule",
                                 ["iptables", "-t", "raw", "-D", *rule[1:]])
                    _command(self.runner, self.diagnostics, "rollback-chain",
                             ["iptables", "-t", "raw", "-X", RAW_CHAIN])
            except m.Failure as error:
                firewall_error = error
        # No tree traversal/copy/unlink: unexpected state and package ownership
        # are not inferred from a snapshot. Preserve everything for recovery.
        self.retained_resources = [
            "APT package/database, repository/keyring, dependencies and caches may have changed; retained",
            "Upstream config/binary/units/drop-ins and all unknown files: retained, not wrapper-owned",
            "Firewall: only validated unchanged owned raw rules may be removed; no flush; other state retained",
            "conntrack state and /etc/modules-load.d/conntrack.conf: retained if changed by upstream", 
            "Package-owned service unit retained but disabled; do not restart without reviewing config/rules",
            f"Access log {self.paths.log}: retained; created_by_wrapper={self.log_created}",
        ]
        _write_private(self.diagnostics.directory / "retained-resources.json",
                       json.dumps(self.retained_resources, ensure_ascii=False, indent=2))
        self.service_started = False
        if firewall_error:
            raise m.Failure("Неполный откат firewall; правила сохранены, требуется ручная проверка; "
                            + str(self.diagnostics.directory)) from firewall_error
        self._done = True


def install(*, upstream_url=DEFAULT_UPSTREAM_INSTALLER_URL, runner=None,
            paths=InstallPaths(), backup=None, defaults=None):
    """Keep parent API: install(runner=CommandRunner(run=m.run), defaults=...)."""
    if not isinstance(upstream_url, str):
        raise m.Failure("Требуется HTTPS URL upstream installer.")
    parsed = urlparse(upstream_url)
    if parsed.scheme != "https" or not parsed.netloc or parsed.username or parsed.password or parsed.fragment:
        raise m.Failure("Разрешён только HTTPS upstream URL без credentials/fragment.")
    if defaults is not None and defaults != {"LogFile": LOG_FILE, "BlockMode": BLOCK_MODE}:
        raise m.Failure("Поддерживаются только безопасные defaults LogFile/BlockMode.")
    _root_preflight()
    runner = runner or CommandRunner(run=m.run)
    if backup is None:
        _private_dir(paths.backup_dir)
        backup = Path(tempfile.mkdtemp(prefix="tblocker-", dir=paths.backup_dir))
    diagnostics = Diagnostics(backup)
    change = Transaction(paths, backup, runner, diagnostics)
    phase = "preflight"
    try:
        preflight(runner=runner, paths=paths, diagnostics=diagnostics)
        work = _private_dir(diagnostics.directory / "work")
        phase = "release-metadata"
        metadata_path = work / "release.json"

        def download(url, destination, label):
            diagnostics.execute(label, lambda out, err: runner.download(
                url, destination, timeout=600, stdout_path=out, stderr_path=err), streamed=True)
            _safe_file(destination)
            os.chmod(destination, 0o600)

        download(upstream_url, metadata_path, phase)
        arch = _stdout(_command(runner, diagnostics, "architecture", ["dpkg", "--print-architecture"])).strip()
        release = torrent_release.select_release(metadata_path.read_bytes(), arch)
        phase = "checksums"
        checksums = work / "checksums.txt"
        download(release["checksums_url"], checksums, phase)
        expected = torrent_release.package_digest(checksums.read_bytes(), release)
        phase = "download-package"
        package = work / release["name"]
        download(release["url"], package, phase)
        torrent_release.verify_package(package.read_bytes(), release, expected)
        _write_private(diagnostics.directory / "release-source.json", json.dumps({
            **release, "api_url": upstream_url, "sha256": expected,
            "downloaded_utc": datetime.now(timezone.utc).isoformat(), "path": str(package),
        }, indent=2))
        phase = "verify-package"
        for field, expected_field in (("Package", "tblocker"), ("Architecture", arch), ("Version", release["version"])):
            actual = _stdout(_command(runner, diagnostics, "package-" + field.lower(),
                                      ["dpkg-deb", "--field", str(package), field])).strip()
            if actual != expected_field:
                raise m.Failure("Содержимое DEB не соответствует release metadata: " + field)
        phase = "prepare-log"
        change.log_created = _prepare_log(paths)
        phase = "package-gate"
        change.start_gate = _block_package_start(paths)
        _command(runner, diagnostics, 'gate-reload', ['systemctl', 'daemon-reload'])
        phase = "package-install"
        change.child_attempted = True
        try:
            # The official package provides config.yaml; no private YAML writer
            # and no fragile interactive-script responses are involved.
            diagnostics.execute(phase, lambda out, err: runner.child(
                ["apt-get", "-o", "DPkg::Lock::Timeout=120", "install", "-y",
                 "--no-install-recommends", str(package)], input_text="", cwd=work,
                timeout=900, stdout_path=out, stderr_path=err), streamed=True)
            phase = "verify-config"
            _verify_config(paths)
            installed = _stdout(_command(runner, diagnostics, "installed-package",
                ["dpkg-query", "-W", "-f=${Status}|${Version}|${Architecture}", "tblocker"])).strip()
            if installed != "install ok installed|" + release["version"] + "|" + arch:
                raise m.Failure("Установленный пакет не соответствует проверенному latest DEB.")
            phase = "release-package-gate"
            _release_package_start(change.start_gate)
            change.start_gate = None
            _command(runner, diagnostics, "daemon-reload", ["systemctl", "daemon-reload"])
            phase = "service-start"
            _command(runner, diagnostics, "service-enable", ["systemctl", "enable", SERVICE])
            _command(runner, diagnostics, phase, ["systemctl", "start", SERVICE], timeout=60)
        finally:
            if not getattr(runner, "child_running", False):
                try:
                    change.raw_owned = _raw_rules(_command(runner, diagnostics, "post-child-firewall", ["iptables-save"]))
                except Exception as snapshot_error:
                    _write_private(diagnostics.directory / "firewall-ownership-error.json",
                                   json.dumps({"exception": repr(snapshot_error)}))
        phase = "verify"
        if change.raw_owned is None:
            raise m.Failure("Не подтверждена принадлежность raw chain; установка остановлена.")
        _verify_result(paths, runner, diagnostics)
        change.service_started = True
        _write_private(diagnostics.directory / "success.json", json.dumps({"verified_utc": datetime.now(timezone.utc).isoformat()}))
        return change
    except BaseException as exc:
        try:
            _write_private(diagnostics.directory / "failure.json", json.dumps({
                "phase": phase, "exception": repr(exc), "time_utc": datetime.now(timezone.utc).isoformat(),
            }, ensure_ascii=False, indent=2))
        except BaseException:
            # A full/unwritable diagnostics disk must never bypass rollback.
            pass
        rollback_error = None
        try:
            change.rollback()
        except BaseException as error:
            rollback_error = error
            _write_private(diagnostics.directory / "rollback-failure.json", json.dumps({"exception": repr(error)}, ensure_ascii=False))
        if isinstance(exc, (KeyboardInterrupt, SystemExit)):
            raise
        # Include only our sanitized command failure, never external diagnostics.
        detail = str(exc) if isinstance(exc, m.Failure) and str(exc).startswith("tblocker phase=") else ""
        rollback_detail = (str(rollback_error) if isinstance(rollback_error, m.Failure) and
                           str(rollback_error).startswith("tblocker phase=") else "")
        raise m.Failure(
            f"tblocker phase={phase}; применение не подтверждено. {detail} "
            + ("Откат НЕ подтверждён; package unit/правила требуют ручной проверки. " + rollback_detail if rollback_error
               else ("Сервис остановлен/отключён; package unit и ресурсы сохранены. " if change.child_attempted
                     else "Installer не запускался; диагностика сохранена. "))
            + f"Диагностика={diagnostics.directory}; причина={diagnostics.directory / 'failure.json'}"
        ) from exc


__all__ = ["BLOCK_MODE", "CONFIG", "CommandRunner", "DEFAULT_UPSTREAM_INSTALLER_URL",
           "InstallPaths", "LOG_FILE", "SERVICE", "Transaction", "install", "preflight"]
