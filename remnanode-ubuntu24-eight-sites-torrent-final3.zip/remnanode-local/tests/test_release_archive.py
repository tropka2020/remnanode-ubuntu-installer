"""Temporary release snapshots and offline download-validator contracts.

Never build an archive or rewrite SHA256SUMS in the working project; never run
an installer, browser, network request or host command from the release.
"""
import ast
import hashlib
import json
from pathlib import Path
import shutil
import stat
import subprocess
import sys
import tempfile
import unittest
import warnings
import zipfile

import build_release
import premium_site

PROJECT = Path(__file__).resolve().parents[1]
PREFIX = 'remnanode-local/'


class ReleaseArchiveTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.temporary = tempfile.TemporaryDirectory(prefix='release-contract-')
        cls.addClassCleanup(cls.temporary.cleanup)
        cls.root = Path(cls.temporary.name)
        cls.source = cls.root / 'source'
        cls.source.mkdir()
        cls.inventory = (set(build_release.MODULES + build_release.DOCS + build_release.FIXTURES)
                         | {'build_release.py'}
                         | {'premium_assets/' + name for name in premium_site.ASSET_FILES}
                         | {p.relative_to(PROJECT).as_posix()
                            for p in (PROJECT / 'tests').glob('test_*.py')})
        for name in cls.inventory:
            target = cls.source / name
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(PROJECT / name, target)
        # These must never enter the allowlisted release, even next to fixtures.
        for name in ('.env', 'secret.key', 'private.json', 'tests/fixtures/private.json',
                     'remnanode-ubuntu24-premium-v2.zip', 'old-release.zip'):
            (cls.source / name).write_bytes(b'private-or-old-sentinel')
        cls.original_sums = (PROJECT / 'SHA256SUMS').read_bytes()
        cls.result = cls.run_builder()
        if cls.result.returncode:
            raise AssertionError(cls.result.stdout + cls.result.stderr)
        cls.archive = cls.source / 'remnanode-ubuntu24-eight-sites.zip'
        cls.extracted = cls.root / 'extracted'
        with zipfile.ZipFile(cls.archive) as archive:
            archive.extractall(cls.extracted)
        cls.release = cls.extracted / 'remnanode-local'

    @classmethod
    def run_builder(cls):
        script = ('import runpy,sys; sys.path.insert(0,sys.argv[1]); '
                  'sys.argv=[sys.argv[1]+"/build_release.py"]; '
                  'runpy.run_path(sys.argv[0],run_name="__main__")')
        return subprocess.run([sys.executable, '-I', '-B', '-c', script, str(cls.source)],
                              cwd=cls.source, capture_output=True, text=True, timeout=60)

    def test_exact_inventory_frozen_fixture_and_internal_checksums(self):
        with zipfile.ZipFile(self.archive) as archive:
            names = archive.namelist()
            expected = {PREFIX + name for name in self.inventory | {'SHA256SUMS'}}
            self.assertEqual(set(names), expected)
            self.assertEqual(len(names), len(expected))
            self.assertIsNone(archive.testzip())
            for info in archive.infolist():
                self.assertFalse(info.is_dir())
                self.assertEqual(stat.S_IFMT(info.external_attr >> 16), stat.S_IFREG)
            manifest = archive.read(PREFIX + 'SHA256SUMS').decode('utf-8')
            checksums = dict(line.split('  ', 1)[::-1] for line in manifest.splitlines())
            self.assertEqual(set(checksums), self.inventory)
            self.assertEqual(len(manifest.splitlines()), len(self.inventory))
            for name, digest in checksums.items():
                self.assertEqual(hashlib.sha256(archive.read(PREFIX + name)).hexdigest(), digest, name)
            fixture = 'tests/fixtures/premium-original-output-sha256.json'
            self.assertIn(fixture, build_release.FIXTURES)
            self.assertEqual(archive.read(PREFIX + fixture), (PROJECT / fixture).read_bytes())
        self.assertEqual((self.source / 'SHA256SUMS').read_text(encoding='utf-8'), manifest)
        self.assertEqual((PROJECT / 'SHA256SUMS').read_bytes(), self.original_sums)
        self.assertIn('premium_expanded.py', build_release.MODULES)
        self.assertIn('download-install.sh', build_release.MODULES)

    def test_existing_archives_and_checksums_are_not_overwritten(self):
        before = self.archive.read_bytes()
        sums = (self.source / 'SHA256SUMS').read_bytes()
        result = self.run_builder()
        self.assertNotEqual(result.returncode, 0)
        self.assertIn('Archive exists', result.stdout + result.stderr)
        self.assertEqual(self.archive.read_bytes(), before)
        self.assertEqual((self.source / 'SHA256SUMS').read_bytes(), sums)
        self.assertEqual((self.source / 'remnanode-ubuntu24-premium-v2.zip').read_bytes(),
                         b'private-or-old-sentinel')

    def test_download_validator_accepts_complete_built_release(self):
        helper = (self.release / 'download-install.sh').read_text(encoding='utf-8')
        validator = helper.split("<<'PY_RELEASE'\n", 1)[1].split('\nPY_RELEASE\n', 1)[0]
        destination = self.root / 'helper-extracted'
        result = subprocess.run([sys.executable, '-I', '-B', '-c', validator, str(self.archive),
                                 hashlib.sha256(self.archive.read_bytes()).hexdigest(), str(destination)],
                                cwd=self.root, capture_output=True, text=True, timeout=30)
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertEqual({p.relative_to(destination / 'remnanode-local').as_posix()
                          for p in destination.rglob('*') if p.is_file()},
                         self.inventory | {'SHA256SUMS'})

    def test_extracted_python_syntax_and_all_module_safe_imports(self):
        for path in self.release.rglob('*.py'):
            ast.parse(path.read_text(encoding='utf-8'), filename=str(path))
        # Isolated Python cannot find the working project's modules. Audit hooks
        # reject network/process/host writes even if a main guard regresses.
        script = r'''
import importlib.util, json, os, pathlib, sys
root = pathlib.Path(sys.argv[1]).resolve()
sys.path.insert(0, str(root))
def audit(event, args):
    if (event.startswith(('subprocess.', 'socket.'))
            or event in {'os.system', 'os.posix_spawn', 'os.exec', 'os.fork',
                         'os.mkdir', 'os.remove', 'os.rename', 'os.rmdir',
                         'os.chmod', 'os.chown', 'sqlite3.connect'}):
        raise AssertionError('Import side effect: ' + event)
    if event == 'open' and args[2] & (os.O_WRONLY | os.O_RDWR | os.O_CREAT | os.O_TRUNC | os.O_APPEND):
        raise AssertionError('Import write: ' + str(args[0]))
sys.addaudithook(audit)
for filename in json.loads(sys.argv[2]):
    if not filename.endswith('.py'):
        continue
    name = pathlib.Path(filename).stem
    if name == 'site':  # Python preloads its own standard-library site module.
        name = 'release_site_under_test'
    spec = importlib.util.spec_from_file_location(name, root / filename)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    assert pathlib.Path(module.__file__).resolve().parent == root
import premium_site, command_runtime
assert len(premium_site.TEMPLATES) == 8
assert 'premium_expanded.py' in command_runtime.MODULES
assert set(command_runtime.MODULES) <= set(json.loads(sys.argv[2]))
assert tuple(command_runtime.ASSET_FILES) == tuple(premium_site.ASSET_FILES)
print('All extracted modules imported safely; eight themes available.')
'''
        result = subprocess.run([sys.executable, '-I', '-B', '-c', script, str(self.release),
                                 json.dumps(build_release.MODULES)], cwd=self.root,
                                capture_output=True, text=True, timeout=30)
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertIn('All extracted modules imported safely', result.stdout)


class DownloadValidatorTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.helper = (PROJECT / 'download-install.sh').read_text(encoding='utf-8')
        cls.validator = cls.helper.split("<<'PY_RELEASE'\n", 1)[1].split('\nPY_RELEASE\n', 1)[0]

    def setUp(self):
        temporary = tempfile.TemporaryDirectory(prefix='download-contract-')
        self.addCleanup(temporary.cleanup)
        self.root = Path(temporary.name)
        self.archive = self.root / 'release.zip'
        self.destination = self.root / 'extracted'

    def write_archive(self, extra=(), manifest=None, payload=b'#!/bin/bash\nexit 99\n'):
        if manifest is None:
            manifest = hashlib.sha256(payload).hexdigest() + '  install-remnanode.sh\n'
        with warnings.catch_warnings():
            warnings.simplefilter('ignore', UserWarning)  # Deliberate duplicate members.
            with zipfile.ZipFile(self.archive, 'w') as archive:
                archive.writestr(PREFIX + 'install-remnanode.sh', payload)
                archive.writestr(PREFIX + 'SHA256SUMS', manifest)
                for name, value in extra:
                    if isinstance(name, str):
                        info = zipfile.ZipInfo('placeholder')
                        # Keep hostile bytes verbatim; ZipInfo's constructor
                        # otherwise normalizes backslashes on Windows.
                        info.filename = info.orig_filename = name
                        name = info
                    archive.writestr(name, value)

    def validate(self, digest=None):
        digest = digest or hashlib.sha256(self.archive.read_bytes()).hexdigest()
        return subprocess.run([sys.executable, '-I', '-B', '-c', self.validator,
                               str(self.archive), digest, str(self.destination)],
                              cwd=self.root, capture_output=True, text=True, timeout=15)

    def test_verified_archive_checks_extracted_root_without_running_shell(self):
        self.write_archive(extra=[(PREFIX + 'assets/', b'')])
        result = self.validate()
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertIn('inner checksums verified', result.stdout)
        self.assertEqual((self.destination / PREFIX / 'install-remnanode.sh').read_bytes(),
                         b'#!/bin/bash\nexit 99\n')

    def test_fixed_outer_hash_rejected_before_extraction(self):
        self.write_archive()
        result = self.validate('0' * 64)
        self.assertNotEqual(result.returncode, 0)
        self.assertIn('ZIP SHA256 mismatch', result.stderr)
        self.assertFalse(self.destination.exists())

    def test_unsafe_paths_duplicates_and_special_types_before_extraction(self):
        cases = ['../escape', '/absolute', 'wrong-root/file', PREFIX + '../escape',
                 PREFIX + './alias', PREFIX + 'a//b', PREFIX + 'a//', PREFIX + 'a\\b',
                 PREFIX + 'C:drive', PREFIX + 'a\nb', PREFIX + 'install-remnanode.sh',
                 PREFIX + 'install-remnanode.sh/child', PREFIX + 'SHA256SUMS/']
        for kind in (stat.S_IFLNK, stat.S_IFIFO, stat.S_IFSOCK, stat.S_IFCHR, stat.S_IFBLK):
            info = zipfile.ZipInfo(PREFIX + 'special-' + str(kind))
            info.create_system = 3
            info.external_attr = (kind | 0o777) << 16
            cases.append(info)
        for index, name in enumerate(cases):
            with self.subTest(name=str(name)):
                self.destination = self.root / ('case-' + str(index))
                self.write_archive(extra=[(name, b'bad')])
                result = self.validate()
                self.assertNotEqual(result.returncode, 0, result.stdout)
                self.assertFalse(self.destination.exists())
                self.assertFalse((self.root / 'escape').exists())

    def test_inner_checksums_exact_inventory_and_paths_fail_closed(self):
        payload_hash = hashlib.sha256(b'#!/bin/bash\nexit 99\n').hexdigest()
        valid = payload_hash + '  install-remnanode.sh\n'
        cases = [('', ()), (valid + valid, ()), ('0' * 64 + '  install-remnanode.sh\n', ()),
                 (payload_hash + '  ../escape\n', ()), ('not a checksum\n', ()),
                 (valid, [(PREFIX + 'unlisted.txt', b'unlisted')]),
                 (valid + payload_hash + '  missing.txt\n', ())]
        for index, (manifest, extra) in enumerate(cases):
            with self.subTest(index=index):
                self.destination = self.root / ('case-' + str(index))
                self.write_archive(extra=extra, manifest=manifest)
                result = self.validate()
                self.assertNotEqual(result.returncode, 0, result.stdout)
                self.assertNotIn('checksums verified', result.stdout)

    @unittest.skipUnless(shutil.which('bash'), 'Bash is unavailable')
    def test_helper_syntax_and_early_usage_rejection_do_not_touch_host(self):
        # Only the argument guards may execute: without URL/hash, /opt and
        # network are unreachable. Syntax checking does not execute the script.
        syntax = subprocess.run(['bash', '-n'], input=self.helper, capture_output=True,
                                text=True, timeout=10)
        self.assertEqual(syntax.returncode, 0, syntax.stderr)
        helper_path = (PROJECT / 'download-install.sh').as_posix()
        usage = subprocess.run(['bash', helper_path], capture_output=True,
                               text=True, encoding='utf-8', timeout=10)
        self.assertEqual(usage.returncode, 1, usage.stdout + usage.stderr)
        self.assertIn('HTTPS_ZIP_URL ZIP_SHA256', usage.stderr)

    def test_helper_child_shell_private_staging_and_no_clobber_contract(self):
        self.assertIn('"${BASH_SOURCE[0]}" != "$0"', self.helper)
        self.assertIn('sudo --preserve-env=SSH_CONNECTION bash', self.helper)
        self.assertIn('mktemp -d /opt/.remnanode-download.', self.helper)
        self.assertIn("--proto '=https' --proto-redir '=https'", self.helper)
        self.assertIn('mv -T -n -- "$WORK/extracted/remnanode-local" "$TARGET"', self.helper)
        recheck = '[[ ! -e "$WORK/extracted/remnanode-local" && ! -L "$WORK/extracted/remnanode-local" ]]'
        self.assertLess(self.helper.index('mv -T -n'), self.helper.index(recheck))
        self.assertLess(self.helper.index(recheck), self.helper.index('bash "$TARGET/install-remnanode.sh" wizard'))
        self.assertNotRegex(self.helper, r'(?m)^\s*(?:source|\.)\s')


if __name__ == '__main__':
    unittest.main()
