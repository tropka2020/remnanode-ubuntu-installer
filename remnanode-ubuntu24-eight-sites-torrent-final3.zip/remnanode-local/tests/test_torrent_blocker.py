"""Offline tests: all host, network, APT, service and firewall boundaries are fake."""
import hashlib
import io
import importlib.util
import json
import os
from pathlib import Path
import stat
import subprocess
import tarfile
import tempfile
from types import SimpleNamespace
import unittest
from unittest.mock import Mock, patch

PROJECT = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location("torrent_blocker_tested", PROJECT / "torrent_blocker.py")
torrent = importlib.util.module_from_spec(spec)
spec.loader.exec_module(torrent)

BASE_FIREWALL = "*raw\n:PREROUTING ACCEPT [0:0]\nCOMMIT\n*filter\n:INPUT ACCEPT [0:0]\nCOMMIT\n"
OWN_FIREWALL = ("*raw\n:PREROUTING ACCEPT [0:0]\n:TBLOCKER_BLOCKED - [0:0]\n"
                "-A PREROUTING -j TBLOCKER_BLOCKED\n"
                "-A TBLOCKER_BLOCKED -s 192.0.2.1/32 -j DROP\nCOMMIT\n"
                "*filter\n:INPUT ACCEPT [0:0]\nCOMMIT\n")
CONFIG = ('LogFile: "/var/log/remnanode/access.log" # upstream comment\n'
          "BlockMode: 'iptables' # mode\nTorrentTag: TORRENT\n"
          'WebhookURL: ""\nWebhookEnabled: false\n')
def deb_fixture(version, arch):
    """A tiny ar/DEB archive; dpkg inspection is still strictly fake."""
    def archive(entries):
        stream = io.BytesIO()
        with tarfile.open(fileobj=stream, mode="w:gz") as tar:
            for name, content in entries.items():
                info = tarfile.TarInfo(name)
                info.size = len(content)
                info.mode = 0o644
                tar.addfile(info, io.BytesIO(content))
        return stream.getvalue()

    control = (f"Package: tblocker\nVersion: {version}\nArchitecture: {arch}\n"
               "Maintainer: Offline tests <tests@example.invalid>\n"
               "Description: Isolated package fixture\n").encode()
    members = {"debian-binary": b"2.0\n",
               "control.tar.gz": archive({"control": control}),
               "data.tar.gz": archive({"opt/tblocker/config.yaml": CONFIG.encode(),
                   "usr/lib/systemd/system/tblocker.service":
                   b"[Service]\nExecStart=/opt/tblocker/tblocker\n"})}
    data = b"!<arch>\n"
    for name, content in members.items():
        header = f"{name + '/':<16}{0:<12}{0:<6}{0:<6}{'100644':<8}{len(content):<10}`\n"
        data += header.encode() + content + (b"\n" if len(content) % 2 else b"")
    return data


def result(code=0, stdout="", stderr=""):
    return SimpleNamespace(returncode=code, stdout=stdout, stderr=stderr)


class FakeRunner:
    def __init__(self, paths):
        self.paths = paths
        self.calls = []
        self.download_calls = []
        self.child_calls = []
        self.child_running = False
        self.active, self.enabled, self.loaded = "inactive", "", "not-found"
        self.fragment = ""
        self.restarts, self.status, self.service_result = "0", "0", "success"
        self.dropins = ""
        self.firewall = BASE_FIREWALL
        self.backend = "iptables v1.8.10 (nf_tables)\n"
        self.ufw = "Status: active\n"
        self.package = result(1, "", "dpkg-query: no packages found matching tblocker\n")
        self.arch = "amd64"
        self.set_release("v4.5.6")
        self.download_result = result()
        self.download_failures = {}
        self.installed_override = None
        self.installed = False
        self.events = []
        self.start_snapshots = []
        self.daemon_reloaded = False
        self.reload_gates = []
        self.applied_gate = None
        self.child_result = result(0, "apt stdout SECRET", "apt stderr SECRET")
        self.child_error = None
        self.partial = True
        self.stop_code = self.disable_code = 0
        self.stop_changes_state = True
        self.readiness_inactive = False
        self.config = CONFIG
        self.create_config = True
        self.service_failures = {}
        self.commands = {"curl", "iptables", "iptables-save", "conntrack", "systemctl",
                         "dpkg", "dpkg-query", "dpkg-deb", "apt-get", "ufw"}

    def set_release(self, tag, arch="amd64", *, api_digest=True):
        self.tag, self.version = tag, tag.removeprefix("v")
        self.package_name = f"tblocker_{self.version}_linux_{arch}.deb"
        self.package_bytes = deb_fixture(self.version, arch)
        self.sha256 = hashlib.sha256(self.package_bytes).hexdigest()
        self.package_url = torrent.torrent_release.PREFIX + tag + "/" + self.package_name
        self.checksums_url = torrent.torrent_release.PREFIX + tag + "/checksums.txt"
        asset = {"name": self.package_name, "size": len(self.package_bytes),
                 "browser_download_url": self.package_url}
        if api_digest:
            asset["digest"] = "sha256:" + self.sha256
        self.metadata = {"tag_name": tag, "draft": False, "prerelease": False,
                         "assets": [asset, {"name": "checksums.txt",
                                            "browser_download_url": self.checksums_url}]}
        self.checksums = (self.sha256 + "  " + self.package_name + "\n").encode()
        self.deb_fields = {"Package": "tblocker", "Architecture": arch, "Version": self.version}

    def which(self, name):
        return "/usr/bin/" + name if name in self.commands else None

    def run(self, args, **kwargs):
        self.calls.append((list(args), kwargs))
        self.events.append(tuple(args))
        failure_key = tuple(args)
        if args == ["systemctl", "daemon-reload"]:
            failure_key = (*args, sum(event == tuple(args) for event in self.events))
        if failure_key in self.service_failures:
            return self.service_failures[failure_key]
        if tuple(args) in self.service_failures:
            return self.service_failures[tuple(args)]
        if args == ["dpkg", "--print-architecture"]:
            return result(0, self.arch + "\n")
        if args[:2] == ["dpkg-deb", "--field"]:
            if len(args) != 4 or Path(args[2]).name != self.package_name:
                raise AssertionError("Unexpected DEB field query: " + repr(args))
            return result(0, self.deb_fields[args[3]] + "\n")
        if args == ["systemctl", "daemon-reload"]:
            self.daemon_reloaded = True
            gate = Path(str(self.paths.runtime_unit) + ".d") / "90-remnanode-install-gate.conf"
            self.applied_gate = gate.read_text() if gate.exists() else None
            self.reload_gates.append(self.applied_gate)
            self.events.append(("reload-gate", self.applied_gate))
            self.dropins = str(gate) if self.applied_gate else ""
            if self.paths.vendor_units[0].exists():
                self.loaded = "loaded"
            return result()
        if args == ["systemctl", "enable", torrent.SERVICE]:
            self.enabled = "enabled"
            return result()
        if args == ["systemctl", "start", torrent.SERVICE]:
            if self.applied_gate is not None:
                raise AssertionError("Explicit service start attempted before gate removal/reload")
            self.start_snapshots.append({"config": self.paths.config.read_text(),
                "log": self.paths.log.read_bytes(), "loaded": self.loaded,
                "enabled": self.enabled, "reloaded": self.daemon_reloaded,
                "installed": self.installed})
            self.active = "active"
            self.firewall = OWN_FIREWALL
            return result()
        if args == ["iptables-save"]:
            return result(0, self.firewall)
        if args == ["iptables", "--version"]:
            return result(0, self.backend)
        if args == ["ufw", "status"]:
            return result(0, self.ufw)
        if args == ["dpkg-query", "-W", "-f=${db:Status-Abbrev}", "tblocker"]:
            return self.package
        if args == ["dpkg-query", "-W", "-f=${Status}|${Version}|${Architecture}", "tblocker"]:
            if self.installed_override is not None:
                return self.installed_override
            if not self.installed:
                return self.package
            return result(0, f"install ok installed|{self.version}|{self.arch}\n")
        if args[:2] == ["systemctl", "show"]:
            values = dict(LoadState=self.loaded, ActiveState=self.active,
                          SubState="running" if self.active == "active" else "dead",
                          UnitFileState=self.enabled, FragmentPath=self.fragment,
                          DropInPaths=self.dropins, ExecMainStatus=self.status,
                          Result=self.service_result, NRestarts=self.restarts)
            if self.readiness_inactive and self.loaded == "loaded":
                values["ActiveState"] = "activating"
            return result(0, "".join(f"{key}={value}\n" for key, value in values.items()))
        if args == ["systemctl", "stop", torrent.SERVICE]:
            if not self.stop_code and self.stop_changes_state:
                self.active = "inactive"
                self.readiness_inactive = False
            return result(self.stop_code, "", "stop SECRET" if self.stop_code else "")
        if args == ["systemctl", "disable", torrent.SERVICE]:
            if not self.disable_code:
                self.enabled = "disabled"
            return result(self.disable_code)
        if args[:4] == ["iptables", "-t", "raw", "-D"]:
            line = "-A " + " ".join(args[4:]) + "\n"
            if line not in self.firewall:
                return result(1, "", "rule absent")
            self.firewall = self.firewall.replace(line, "", 1)
            return result()
        if args == ["iptables", "-t", "raw", "-X", torrent.RAW_CHAIN]:
            self.firewall = self.firewall.replace(":TBLOCKER_BLOCKED - [0:0]\n", "")
            return result()
        raise AssertionError("Unexpected command (no real host fallback): " + repr(args))

    def download(self, url, destination, **kwargs):
        self.download_calls.append((url, destination, kwargs))
        self.events.append(("download", url))
        payloads = {torrent.torrent_release.API_URL: json.dumps(self.metadata).encode(),
                    self.checksums_url: self.checksums, self.package_url: self.package_bytes}
        if url not in payloads:
            raise AssertionError("Unexpected download (no network fallback): " + repr(url))
        destination.write_bytes(payloads[url])
        outcome = self.download_failures.get(url, self.download_result)
        if isinstance(outcome, BaseException):
            raise outcome
        return outcome

    def child(self, argv, **kwargs):
        self.child_calls.append((argv, kwargs))
        self.events.append(("child", *argv))
        expected = ["apt-get", "-o", "DPkg::Lock::Timeout=120", "install", "-y",
                    "--no-install-recommends", str(kwargs["cwd"] / self.package_name)]
        if argv != expected or kwargs["input_text"] != "":
            raise AssertionError("Unexpected package child: " + repr((argv, kwargs)))
        gate = Path(str(self.paths.runtime_unit) + ".d") / "90-remnanode-install-gate.conf"
        if not gate.exists() or self.applied_gate != gate.read_text():
            raise AssertionError("APT must run with an existing, reloaded start gate")
        lines = self.applied_gate.splitlines()
        if len(lines) != 2 or lines[0] != "[Unit]" or not lines[1].startswith("ConditionPathExists="):
            raise AssertionError("Unexpected systemd gate content")
        missing = Path(lines[1].split("=", 1)[1])
        if missing.parent != gate.parent or missing.exists():
            raise AssertionError("Gate must require an absent path inside its private directory")
        self.events.append(("apt-gate", self.applied_gate))
        if self.partial:
            self.paths.blocker_dir.mkdir(parents=True, exist_ok=True)
            if self.create_config:
                self.paths.config.write_text(self.config, encoding="utf-8")
            unit = self.paths.vendor_units[0]
            unit.parent.mkdir(parents=True, exist_ok=True)
            unit.write_text("[Service]\nExecStart=/opt/tblocker/tblocker\n", encoding="utf-8")
            self.fragment = str(unit)
            self.loaded, self.active, self.enabled = "loaded", "inactive", "disabled"
            self.installed = not self.child_error and self.child_result.returncode == 0
            self.package = result(0, "ii " if self.installed else "iU ")
            # APT may leave files/unpacked state even when it exits nonzero.
            # Package installation alone never starts the fake service or raw chain.
            self.events.append(("package-resources", self.active, self.enabled, self.firewall))
        if self.child_error:
            raise self.child_error
        return self.child_result


class TorrentBlockerTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory(prefix="torrent-blocker-")
        self.addCleanup(self.tmp.cleanup)
        self.root = Path(self.tmp.name)
        self.assertEqual(list(self.root.iterdir()), [], "Fresh test root must be empty")
        # Any missed fake must fail closed, never spawn a command or open a network socket.
        for target in ("subprocess.Popen", "socket.socket.connect", "socket.create_connection"):
            guard = patch(target, side_effect=AssertionError("Real host/network operation forbidden"))
            guard.start()
            self.addCleanup(guard.stop)
        self.paths = torrent.InstallPaths(
            blocker_dir=self.root / "opt/tblocker", config=self.root / "opt/tblocker/config.yaml",
            unit=self.root / "etc/systemd/system/tblocker.service",
            vendor_units=(self.root / "usr/lib/systemd/system/tblocker.service",
                          self.root / "lib/systemd/system/tblocker.service"),
            runtime_unit=self.root / "run/systemd/system/tblocker.service",
            backup_dir=self.root / "backups", download_dir=self.root / "opt",
            log=self.root / "var/log/remnanode/access.log")
        self.paths.download_dir.mkdir()
        self.backup = self.root / "backup"
        self.runner = FakeRunner(self.paths)
        self.assertFalse(self.runner.child_running)
        self.assertFalse(self.runner.calls or self.runner.download_calls or self.runner.child_calls)
        self.assertEqual(self.runner.firewall, BASE_FIREWALL)
        self.assertEqual((self.runner.active, self.runner.loaded), ("inactive", "not-found"))
        # No production root/Linux check is bypassed outside these offline tests.
        self.guard = patch.object(torrent, "_root_preflight")
        self.guard.start()
        self.addCleanup(self.guard.stop)
        # The isolated test tree may sit below /tmp (not a production ancestor).
        original = torrent._ancestors
        def isolated_ancestors(path):
            path = Path(path)
            if path == self.root or self.root in path.parents:
                for part in (path, *path.parents):
                    if part == self.root.parent:
                        break
                    if part.exists() or part.is_symlink():
                        torrent._trusted_directory(part)
            else:
                original(path)
        self.scope = patch.object(torrent, "_ancestors", side_effect=isolated_ancestors)
        self.scope.start()
        self.addCleanup(self.scope.stop)
        self.clock = 0
        def monotonic():
            self.clock += 0.5
            return self.clock
        timer = patch.object(torrent.time, "monotonic", side_effect=monotonic)
        timer.start()
        self.addCleanup(timer.stop)
        sleeper = patch.object(torrent.time, "sleep")
        sleeper.start()
        self.addCleanup(sleeper.stop)

    def install(self, **kwargs):
        return torrent.install(runner=self.runner, paths=self.paths, backup=self.backup, **kwargs)

    def diagnostic(self, glob):
        return list(self.backup.rglob(glob))

    def assert_no_firewall_mutation(self):
        self.assertFalse(any(args[:3] == ["iptables", "-t", "raw"] for args, _ in self.runner.calls))

    def test_latest_deb_empty_stdin_private_cwd_and_debian_vendor_unit(self):
        change = self.install(defaults={"LogFile": torrent.LOG_FILE, "BlockMode": "iptables"})
        self.assertEqual([url for url, _, _ in self.runner.download_calls],
                         [torrent.torrent_release.API_URL, self.runner.checksums_url, self.runner.package_url])
        self.assertEqual(len(self.runner.child_calls), 1)
        argv, kwargs = self.runner.child_calls[0]
        package = kwargs["cwd"] / self.runner.package_name
        self.assertEqual(argv, ["apt-get", "-o", "DPkg::Lock::Timeout=120", "install", "-y",
                                "--no-install-recommends", str(package)])
        self.assertEqual(kwargs["input_text"], "")
        self.assertTrue(self.backup in kwargs["cwd"].parents)
        self.assertTrue(kwargs["cwd"].is_absolute())
        self.assertEqual(package.read_bytes(), self.runner.package_bytes)
        self.assertTrue(change.log_created)
        self.assertEqual(self.paths.log.read_bytes(), b"")
        self.assertEqual(self.paths.config.read_text(), CONFIG)
        self.assertEqual(self.runner.fragment, str(self.paths.vendor_units[0]))
        self.assertTrue(change.service_started)
        self.assertEqual(change.owned_files, [])
        self.assertTrue(self.diagnostic("success.json"))
        self.assertGreaterEqual(sum(args[:2] == ["systemctl", "show"] for args, _ in self.runner.calls), 3)
        for url, _, _ in self.runner.download_calls:
            self.assertNotIn("/main/", url)
            self.assertNotIn("install.sh", url)
        self.assertFalse(any(args[0] == "bash" for args, _ in self.runner.calls))

    def test_diagnostics_persist_release_deb_hash_outputs_and_private_modes(self):
        change = self.install()
        data = json.loads(self.diagnostic("release-source.json")[0].read_text())
        package = Path(data["path"])
        self.assertEqual(data["sha256"], hashlib.sha256(package.read_bytes()).hexdigest())
        self.assertEqual(data["sha256"], self.runner.sha256)
        self.assertEqual(data["api_url"], torrent.torrent_release.API_URL)
        self.assertEqual(data["url"], self.runner.package_url)
        self.assertEqual(data["checksums_url"], self.runner.checksums_url)
        self.assertEqual((data["tag"], data["version"], data["arch"], data["name"], data["size"]),
                         (self.runner.tag, self.runner.version, self.runner.arch,
                          self.runner.package_name, len(self.runner.package_bytes)))
        self.assertTrue(data["downloaded_utc"])
        self.assertEqual(self.diagnostic("release.json")[0].read_bytes(), json.dumps(self.runner.metadata).encode())
        self.assertEqual(self.diagnostic("checksums.txt")[0].read_bytes(), self.runner.checksums)
        self.assertEqual(self.diagnostic("*-package-install.stdout")[0].read_text(), "apt stdout SECRET")
        self.assertEqual(self.diagnostic("*-package-install.stderr")[0].read_text(), "apt stderr SECRET")
        change.rollback()
        self.assertEqual(package.read_bytes(), self.runner.package_bytes)
        self.assertTrue(self.diagnostic("release-source.json"))
        self.assertFalse(self.diagnostic("upstream-installer.sh"))
        if os.name == "posix":
            for item in (self.backup, *self.backup.rglob("*")):
                self.assertEqual(stat.S_IMODE(item.stat().st_mode), 0o700 if item.is_dir() else 0o600)

    def assert_before_apt_failure(self):
        self.assertFalse(self.runner.child_calls)
        self.assertFalse(self.paths.log.exists())
        self.assertFalse(self.paths.blocker_dir.exists())
        self.assertFalse(self.runner.installed)
        self.assertFalse(any(args[:2] in (["systemctl", "start"], ["systemctl", "enable"])
                             for args, _ in self.runner.calls))
        self.assertEqual(self.runner.firewall, BASE_FIREWALL)
        self.assert_no_firewall_mutation()
        self.assertFalse(self.diagnostic("success.json"))

    def test_config_and_installed_metadata_verified_before_explicit_start(self):
        self.install()
        events = self.runner.events
        resources = next(event for event in events if event[0] == "package-resources")
        self.assertEqual(resources[1:], ("inactive", "disabled", BASE_FIREWALL))
        query = ("dpkg-query", "-W", "-f=${Status}|${Version}|${Architecture}", "tblocker")
        reload = ("systemctl", "daemon-reload")
        enable = ("systemctl", "enable", torrent.SERVICE)
        start = ("systemctl", "start", torrent.SERVICE)
        reload_indices = [i for i, event in enumerate(events) if event == reload]
        self.assertEqual(len(reload_indices), 2)
        child = next(event for event in events if event[0] == "child")
        self.assertLess(reload_indices[0], events.index(child))
        self.assertLess(events.index(resources), events.index(query))
        self.assertLess(events.index(query), reload_indices[1])
        self.assertLess(reload_indices[1], events.index(enable))
        self.assertLess(events.index(enable), events.index(start))
        apt_gate = next(event[1] for event in events if event[0] == "apt-gate")
        self.assertEqual(self.runner.reload_gates, [apt_gate, None])
        self.assertIn("ConditionPathExists=", self.runner.reload_gates[0])
        self.assertFalse(Path(str(self.paths.runtime_unit) + ".d").exists())
        self.assertEqual(self.runner.dropins, "")
        self.assertTrue(self.diagnostic("*-gate-reload.json"))
        self.assertTrue(self.diagnostic("*-daemon-reload.json"))
        self.assertEqual(self.runner.start_snapshots, [{"config": CONFIG, "log": b"",
            "loaded": "loaded", "enabled": "enabled", "reloaded": True, "installed": True}])
        for field in ("Package", "Architecture", "Version"):
            inspection = next(event for event in events if event[:2] == ("dpkg-deb", "--field")
                              and event[-1] == field)
            child = next(event for event in events if event[0] == "child")
            self.assertLess(events.index(inspection), events.index(child))

    def test_latest_tag_is_not_pinned_to_fixture_or_previous_release(self):
        self.runner.set_release("v27.8.91")
        self.install()
        source = json.loads(self.diagnostic("release-source.json")[0].read_text())
        self.assertEqual((source["tag"], source["version"]), ("v27.8.91", "27.8.91"))
        self.assertEqual(self.runner.download_calls[0][0], torrent.torrent_release.API_URL)
        self.assertEqual(self.runner.child_calls[0][0][-1], source["path"])
        self.assertIn("tblocker_27.8.91_linux_amd64.deb", source["path"])

    def test_arm64_release_and_deb_fields(self):
        self.runner.arch = "arm64"
        self.runner.set_release("v8.9.10", "arm64")
        self.install()
        source = json.loads(self.diagnostic("release-source.json")[0].read_text())
        self.assertEqual(source["arch"], "arm64")
        self.assertEqual(source["name"], "tblocker_8.9.10_linux_arm64.deb")

    def test_checksum_manifest_without_optional_api_digest(self):
        self.runner.set_release("v9.8.7", api_digest=False)
        self.install()
        source = json.loads(self.diagnostic("release-source.json")[0].read_text())
        self.assertIsNone(source["digest"])
        self.assertEqual(source["sha256"], self.runner.sha256)

    def test_corrupt_deb_checksum_rejected_before_apt(self):
        self.runner.package_bytes = self.runner.package_bytes[:-1] + bytes([self.runner.package_bytes[-1] ^ 1])
        with self.assertRaisesRegex(torrent.m.Failure, "phase=download-package") as caught:
            self.install()
        self.assertIsInstance(caught.exception.__cause__, ValueError)
        self.assertIn("SHA256 mismatch", str(caught.exception.__cause__))
        self.assertEqual(self.diagnostic("*.deb")[0].read_bytes(), self.runner.package_bytes)
        self.assert_before_apt_failure()

    def test_invalid_deb_magic_even_with_matching_checksum_rejected_before_apt(self):
        self.runner.package_bytes = b"BADDEB!!" + self.runner.package_bytes[8:]
        digest = hashlib.sha256(self.runner.package_bytes).hexdigest()
        self.runner.metadata["assets"][0]["digest"] = "sha256:" + digest
        self.runner.checksums = (digest + "  " + self.runner.package_name + "\n").encode()
        with self.assertRaisesRegex(torrent.m.Failure, "phase=download-package") as caught:
            self.install()
        self.assertIn("Not a Debian archive", str(caught.exception.__cause__))
        self.assert_before_apt_failure()

    def test_truncated_deb_rejected_before_apt(self):
        self.runner.package_bytes = self.runner.package_bytes[:-1]
        with self.assertRaises(torrent.m.Failure) as caught:
            self.install()
        self.assertIn("size mismatch", str(caught.exception.__cause__))
        self.assert_before_apt_failure()

    def test_mismatched_or_missing_checksum_manifest_rejected_before_package_download(self):
        for checksums in (b"", b"malformed\n",
                          ("0" * 64 + "  " + self.runner.package_name + "\n").encode()):
            with self.subTest(checksums=checksums):
                self.runner.checksums = checksums
                self.runner.download_calls.clear()
                with self.assertRaisesRegex(torrent.m.Failure, "phase=checksums"):
                    self.install()
                self.assertEqual(len(self.runner.download_calls), 2)
                self.assert_before_apt_failure()

    def test_deb_package_architecture_version_mismatch_rejected_before_apt(self):
        for field, value in (("Package", "foreign-package"), ("Architecture", "arm64"),
                             ("Version", "0.0.1")):
            with self.subTest(field=field):
                original = self.runner.deb_fields[field]
                self.runner.deb_fields[field] = value
                try:
                    with self.assertRaisesRegex(torrent.m.Failure, "phase=verify-package") as caught:
                        self.install()
                    self.assertIn(field, str(caught.exception.__cause__))
                    self.assert_before_apt_failure()
                finally:
                    self.runner.deb_fields[field] = original

    def test_unknown_architecture_refused_without_package_or_apt(self):
        self.runner.arch = "riscv64"
        with self.assertRaisesRegex(torrent.m.Failure, "phase=release-metadata") as caught:
            self.install()
        self.assertIn("Unsupported package architecture", str(caught.exception.__cause__))
        self.assertEqual(len(self.runner.download_calls), 1)
        self.assert_before_apt_failure()

    def test_api_http_error_private_diagnostics_without_package_or_apt(self):
        self.runner.download_result = result(22, "", "GitHub API rate limit SECRET")
        with self.assertRaisesRegex(torrent.m.Failure, "phase=release-metadata.*exitcode=22") as caught:
            self.install()
        self.assertNotIn("SECRET", str(caught.exception))
        self.assertEqual(self.diagnostic("*-release-metadata.stderr")[0].read_text(),
                         "GitHub API rate limit SECRET")
        self.assertEqual(len(self.runner.download_calls), 1)
        self.assert_before_apt_failure()

    def test_api_error_json_or_missing_deb_refused_before_apt(self):
        for metadata in ({"message": "API rate limit SECRET"},
                         {**self.runner.metadata, "assets": []}):
            with self.subTest(metadata=metadata):
                self.runner.metadata = metadata
                with self.assertRaisesRegex(torrent.m.Failure, "phase=release-metadata") as caught:
                    self.install()
                self.assertNotIn("SECRET", str(caught.exception))
                self.assert_before_apt_failure()

    def test_invalid_package_config_refused_before_enable_start(self):
        self.runner.config = CONFIG.replace("TorrentTag: TORRENT", "TorrentTag: torrent")
        with self.assertRaisesRegex(torrent.m.Failure, "phase=verify-config"):
            self.install()
        self.assertTrue(self.paths.config.exists())
        self.assertEqual(self.paths.config.read_text(), self.runner.config)
        self.assertTrue(self.paths.vendor_units[0].exists())
        self.assertTrue(self.runner.installed)
        self.assertFalse(self.runner.start_snapshots)
        self.assertFalse(any(args[:2] in (["systemctl", "start"], ["systemctl", "enable"])
                             for args, _ in self.runner.calls))
        self.assertEqual(len(self.runner.reload_gates), 2)
        self.assertIn("ConditionPathExists=", self.runner.reload_gates[0])
        self.assertIsNone(self.runner.reload_gates[1])
        self.assertTrue(self.diagnostic("*-gate-reload.json"))
        self.assertTrue(self.diagnostic("*-rollback-gate-reload.json"))
        self.assertFalse(self.diagnostic("*-daemon-reload.json"))
        self.assertFalse(Path(str(self.paths.runtime_unit) + ".d").exists())
        self.assertEqual((self.runner.active, self.runner.enabled), ("inactive", "disabled"))
        self.assertEqual(self.runner.firewall, BASE_FIREWALL)
        self.assertTrue(self.diagnostic("retained-resources.json"))

    def test_missing_package_config_refused_before_start(self):
        self.runner.create_config = False
        with self.assertRaisesRegex(torrent.m.Failure, "phase=verify-config"):
            self.install()
        self.assertTrue(self.runner.installed)
        self.assertTrue(self.paths.vendor_units[0].exists())
        self.assertFalse(self.paths.config.exists())
        self.assertFalse(self.runner.start_snapshots)
        self.assertEqual((self.runner.active, self.runner.enabled), ("inactive", "disabled"))
        self.assertTrue(self.diagnostic("retained-resources.json"))
        self.assert_no_firewall_mutation()

    def assert_service_command_failure(self, args, label):
        key = (*args, 2) if args == ["systemctl", "daemon-reload"] else tuple(args)
        self.runner.service_failures[key] = result(5, "", "service failure SECRET")
        with self.assertRaises(torrent.m.Failure) as caught:
            self.install()
        self.assertIn(f"phase={label} exitcode=5", str(caught.exception))
        self.assertNotIn("SECRET", str(caught.exception))
        self.assertEqual(self.diagnostic(f"*-{label}.stderr")[0].read_text(), "service failure SECRET")
        self.assertTrue(self.runner.installed)
        self.assertTrue(self.paths.config.exists())
        self.assertTrue(self.paths.vendor_units[0].exists())
        self.assertFalse(self.runner.start_snapshots)
        self.assertEqual((self.runner.active, self.runner.enabled), ("inactive", "disabled"))
        self.assertEqual(self.runner.firewall, BASE_FIREWALL)
        self.assertTrue(self.diagnostic("retained-resources.json"))
        self.assertFalse(self.diagnostic("success.json"))
        self.assert_no_firewall_mutation()

    def test_daemon_reload_failure_rolls_back_without_start(self):
        self.assert_service_command_failure(["systemctl", "daemon-reload"], "daemon-reload")
        failure = json.loads(self.diagnostic("failure.json")[0].read_text())
        self.assertEqual(failure["phase"], "release-package-gate")
        self.assertTrue(self.diagnostic("*-gate-reload.json"))
        self.assertEqual(len(self.runner.reload_gates), 1)
        self.assertIn("ConditionPathExists=", self.runner.reload_gates[0])
        self.assertFalse(Path(str(self.paths.runtime_unit) + ".d").exists())
        self.assertFalse(any(args[:2] == ["systemctl", "enable"] for args, _ in self.runner.calls))

    def test_enable_failure_rolls_back_without_start(self):
        self.assert_service_command_failure(["systemctl", "enable", torrent.SERVICE], "service-enable")
        self.assertFalse(any(args[:2] == ["systemctl", "start"] for args, _ in self.runner.calls))

    def test_start_failure_retains_installed_package_and_disables_service(self):
        self.assert_service_command_failure(["systemctl", "start", torrent.SERVICE], "service-start")

    def assert_installed_metadata_failure(self, response):
        self.runner.installed_override = response
        with self.assertRaisesRegex(torrent.m.Failure, "phase=verify-config"):
            self.install()
        self.assertFalse(self.runner.start_snapshots)
        self.assertFalse(any(args[:2] == ["systemctl", "enable"] for args, _ in self.runner.calls))
        self.assertEqual((self.runner.active, self.runner.enabled), ("inactive", "disabled"))
        self.assertTrue(self.paths.config.exists())
        self.assertTrue(self.paths.vendor_units[0].exists())
        self.assertTrue(self.diagnostic("retained-resources.json"))
        self.assert_no_firewall_mutation()

    def test_missing_installed_package_refused_even_after_successful_apt(self):
        self.assert_installed_metadata_failure(result(1, "", "dpkg-query: no packages found matching tblocker"))

    def test_partial_installed_status_refused_after_successful_apt(self):
        self.assert_installed_metadata_failure(result(0, f"install ok unpacked|{self.runner.version}|amd64"))

    def test_wrong_installed_version_refused_after_successful_apt(self):
        self.assert_installed_metadata_failure(result(0, "install ok installed|0.0.1|amd64"))

    def test_wrong_installed_architecture_refused_after_successful_apt(self):
        self.assert_installed_metadata_failure(result(0, f"install ok installed|{self.runner.version}|arm64"))

    def test_active_service_with_missing_package_refused_at_preflight(self):
        self.runner.active = "active"
        with self.assertRaisesRegex(torrent.m.Failure, "phase=preflight"):
            self.install()
        self.assertEqual(self.runner.active, "active")
        self.assert_before_apt_failure()
        self.assertFalse(any(args[:2] in (["systemctl", "stop"], ["systemctl", "disable"])
                             for args, _ in self.runner.calls))

    def test_rollback_stops_verifies_and_only_removes_exact_owned_raw_rules(self):
        change = self.install()
        unknown = self.paths.blocker_dir / "not-ours"
        unknown.write_text("retain")
        change.rollback()
        self.assertEqual(self.runner.active, "inactive")
        self.assertEqual(self.runner.enabled, "disabled")
        self.assertTrue(self.paths.config.exists())
        self.assertTrue(Path(self.runner.fragment).exists())
        self.assertTrue(unknown.exists())
        self.assertEqual(self.runner.firewall, BASE_FIREWALL)
        self.assertTrue(change.retained_resources)
        self.assertTrue(self.diagnostic("retained-resources.json"))
        args = [args for args, _ in self.runner.calls]
        stop_index = args.index(["systemctl", "stop", torrent.SERVICE])
        deletion_index = next(i for i, arg in enumerate(args) if arg[:4] == ["iptables", "-t", "raw", "-D"])
        self.assertLess(stop_index, deletion_index)
        self.assertTrue(any(arg[:2] == ["systemctl", "show"] for arg in args[stop_index + 1:deletion_index]))
        count = len(args)
        change.rollback()
        self.assertEqual(len(self.runner.calls), count)
        self.assertFalse(any("-F" in arg or arg[0] in ("nft", "iptables-restore") for arg in args))

    def test_nonzero_apt_partial_install_retained_error_not_swallowed(self):
        self.runner.child_result = result(42, "apt stdout SECRET", "GPG exact stderr SECRET")
        with self.assertRaises(torrent.m.Failure) as caught:
            self.install()
        message = str(caught.exception)
        self.assertIn("phase=package-install", message)
        self.assertIn("exitcode=42", message)
        self.assertIn("stdout=", message)
        self.assertIn("stderr=", message)
        self.assertNotIn("SECRET", message)
        self.assertEqual(self.diagnostic("*-package-install.stderr")[0].read_text(), "GPG exact stderr SECRET")
        self.assertTrue(self.paths.config.exists())
        self.assertTrue(self.paths.vendor_units[0].exists())
        self.assertFalse(self.runner.installed)
        self.assertEqual(self.runner.package.stdout, "iU ")
        self.assertEqual((self.runner.active, self.runner.enabled), ("inactive", "disabled"))
        self.assertFalse(self.runner.start_snapshots)
        self.assertEqual(self.runner.firewall, BASE_FIREWALL)
        self.assert_no_firewall_mutation()
        self.assertTrue(self.diagnostic("release-source.json"))
        self.assertEqual(self.diagnostic("*.deb")[0].read_bytes(), self.runner.package_bytes)
        self.assertTrue(self.diagnostic("retained-resources.json"))

    def test_timeout_partial_output_is_retained_and_rolls_back_partial_child(self):
        self.runner.child_error = subprocess.TimeoutExpired(["apt-get"], 900,
            output=b"partial stdout SECRET", stderr=b"partial stderr SECRET")
        with self.assertRaisesRegex(torrent.m.Failure, "exitcode=124"):
            self.install()
        self.assertEqual(self.diagnostic("*-package-install.stdout")[0].read_bytes(), b"partial stdout SECRET")
        self.assertEqual(self.diagnostic("*-package-install.stderr")[0].read_bytes(), b"partial stderr SECRET")
        self.assertEqual(self.runner.active, "inactive")

    def test_unknown_external_exception_is_saved_not_printed(self):
        self.runner.child_error = RuntimeError("private upstream SECRET details")
        with self.assertRaises(torrent.m.Failure) as caught:
            self.install()
        self.assertNotIn("SECRET", str(caught.exception))
        self.assertIn("private upstream SECRET", self.diagnostic("*-package-install.json")[0].read_text())

    def test_failed_package_download_keeps_partial_deb_diagnostics_without_child(self):
        self.runner.download_failures[self.runner.package_url] = result(22, "", "HTTP failure SECRET")
        with self.assertRaisesRegex(torrent.m.Failure, "phase=download-package.*exitcode=22") as caught:
            self.install()
        self.assertNotIn("SECRET", str(caught.exception))
        self.assertFalse(self.runner.child_calls)
        self.assertFalse(self.paths.log.exists())
        self.assertEqual(self.diagnostic("*.deb")[0].read_bytes(), self.runner.package_bytes)
        self.assertFalse(self.diagnostic("release-source.json"))
        self.assertEqual(self.diagnostic("*-download-package.stderr")[0].read_text(), "HTTP failure SECRET")

    def test_download_timeout_partial_output(self):
        self.runner.download_result = subprocess.TimeoutExpired("curl", 600, output=b"partial", stderr=b"network")
        with self.assertRaisesRegex(torrent.m.Failure, "exitcode=124"):
            self.install()
        self.assertEqual(self.diagnostic("*-release-metadata.stderr")[0].read_bytes(), b"network")
        self.assertFalse(self.runner.child_calls)
        self.assertFalse(self.paths.log.exists())

    def test_missing_log_is_secure_empty_and_existing_log_not_truncated(self):
        self.paths.log.parent.mkdir(parents=True)
        self.paths.log.write_bytes(b"existing log contents\n")
        change = self.install()
        self.assertFalse(change.log_created)
        self.assertEqual(self.paths.log.read_bytes(), b"existing log contents\n")
        self.assertEqual(self.runner.child_calls[0][1]["input_text"], "")

    def test_hardlinked_log_rejected_before_download(self):
        self.paths.log.parent.mkdir(parents=True)
        source = self.root / "other"
        source.write_text("untouched")
        os.link(source, self.paths.log)
        with self.assertRaises(torrent.m.Failure):
            self.install()
        self.assertFalse(self.runner.download_calls)
        self.assertEqual(source.read_text(), "untouched")

    def test_directory_log_rejected(self):
        self.paths.log.mkdir(parents=True)
        with self.assertRaises(torrent.m.Failure):
            self.install()
        self.assertFalse(self.runner.download_calls)

    def test_symlink_log_rejected(self):
        self.paths.log.parent.mkdir(parents=True)
        source = self.root / "other"
        source.write_text("untouched")
        try:
            self.paths.log.symlink_to(source)
        except OSError:
            self.skipTest("Windows account cannot create symlinks")
        with self.assertRaises(torrent.m.Failure):
            self.install()
        self.assertFalse(self.runner.download_calls)
        self.assertEqual(source.read_text(), "untouched")

    def test_stop_failure_never_deletes_or_mutates_firewall(self):
        change = self.install()
        self.runner.stop_code = 5
        with self.assertRaisesRegex(torrent.m.Failure, "phase=rollback-stop exitcode=5"):
            change.rollback()
        self.assertTrue(self.paths.config.exists())
        self.assertEqual(self.runner.firewall, OWN_FIREWALL)
        self.assert_no_firewall_mutation()

    def test_stop_success_but_still_active_refuses_cleanup(self):
        change = self.install()
        self.runner.stop_changes_state = False
        with self.assertRaisesRegex(torrent.m.Failure, "inactive/disabled"):
            change.rollback()
        self.assert_no_firewall_mutation()
        self.assertTrue(self.paths.config.exists())

    def test_disable_failure_refuses_cleanup(self):
        change = self.install()
        self.runner.disable_code = 7
        with self.assertRaisesRegex(torrent.m.Failure, "phase=rollback-disable exitcode=7"):
            change.rollback()
        self.assert_no_firewall_mutation()

    def test_child_failure_and_stop_failure_both_persist(self):
        self.runner.child_result = result(42, "", "apt cause SECRET")
        self.runner.stop_code = 5
        with self.assertRaises(torrent.m.Failure) as caught:
            self.install()
        self.assertIn("exitcode=42", str(caught.exception))
        self.assertIn("exitcode=5", str(caught.exception))
        self.assertIn("Откат НЕ подтверждён", str(caught.exception))
        self.assertTrue(self.diagnostic("rollback-failure.json"))
        self.assertTrue(self.paths.config.exists())
        self.assert_no_firewall_mutation()

    def test_running_child_blocks_rollback(self):
        change = self.install()
        self.runner.child_running = True
        count = len(self.runner.calls)
        with self.assertRaisesRegex(torrent.m.Failure, "child"):
            change.rollback()
        self.assertEqual(len(self.runner.calls), count)

    def test_changed_raw_rules_are_preserved_and_incomplete_is_explicit(self):
        change = self.install()
        self.runner.firewall = OWN_FIREWALL.replace("192.0.2.1/32", "192.0.2.2/32")
        with self.assertRaisesRegex(torrent.m.Failure, "Неполный откат firewall"):
            change.rollback()
        self.assert_no_firewall_mutation()
        self.assertTrue(self.diagnostic("retained-resources.json"))

    def test_unknown_raw_rule_prevents_any_cleanup(self):
        change = self.install()
        self.runner.firewall = OWN_FIREWALL.replace("-s 192.0.2.1/32 -j DROP", "-j ACCEPT")
        with self.assertRaisesRegex(torrent.m.Failure, "Неполный откат"):
            change.rollback()
        self.assert_no_firewall_mutation()

    def test_preflight_foreign_service_refused(self):
        self.runner.loaded, self.runner.active = "loaded", "active"
        with self.assertRaises(torrent.m.Failure):
            self.install()
        self.assertFalse(self.runner.download_calls)

    def test_preflight_package_partial_installed_or_unknown_refused(self):
        for package in (result(0, "ii "), result(0, "rc "), result(1, "", "database error"), result(2, "", "fatal")):
            with self.subTest(package=package):
                self.runner.package = package
                with self.assertRaises(torrent.m.Failure):
                    self.install()
                self.assertFalse(self.runner.download_calls)

    def test_preflight_existing_vendor_unit_dropins_and_tree_refused(self):
        for target in (self.paths.vendor_units[0], Path(str(self.paths.unit) + ".d"), self.paths.blocker_dir):
            with self.subTest(target=target):
                target.parent.mkdir(parents=True, exist_ok=True)
                target.mkdir() if target.suffix == ".d" or target == self.paths.blocker_dir else target.write_text("foreign")
                with self.assertRaises(torrent.m.Failure):
                    self.install()
                target.rmdir() if target.is_dir() else target.unlink()
                self.assertFalse(self.runner.download_calls)

    def test_preflight_unknown_firewall_chain_or_backend_refused(self):
        for firewall in ("garbage", OWN_FIREWALL, BASE_FIREWALL.replace(":INPUT", ":Tcustom - [0:0]\n:INPUT"),
                         BASE_FIREWALL.replace("COMMIT", "-A INPUT -j Tforeign\nCOMMIT", 1)):
            with self.subTest(firewall=firewall):
                self.runner.firewall = firewall
                with self.assertRaises(torrent.m.Failure):
                    self.install()
                self.assertFalse(self.runner.download_calls)
                self.assert_no_firewall_mutation()
        self.runner.firewall = BASE_FIREWALL
        self.runner.backend = "unknown"
        with self.assertRaises(torrent.m.Failure):
            self.install()

    def test_unknown_ufw_and_missing_dependency_refused(self):
        self.runner.ufw = "unparseable"
        with self.assertRaises(torrent.m.Failure):
            self.install()
        self.runner.commands.remove("conntrack")
        with self.assertRaises(torrent.m.Failure):
            self.install()
        self.assertTrue(any("conntrack" in path.read_text() for path in self.diagnostic("failure.json")))
        self.assertFalse(self.runner.download_calls)

    def test_bad_config_contract_webhook_and_duplicate_rejected(self):
        self.paths.blocker_dir.mkdir()
        diagnostics = torrent.Diagnostics(self.backup)
        for config in (CONFIG.replace("TORRENT", "torrent"), CONFIG.replace("iptables", "nft"),
                       CONFIG.replace('WebhookURL: ""', 'WebhookURL: "https://secret"'),
                       CONFIG + "TorrentTag: TORRENT\n", CONFIG + "Nested:\n  key: value\n",
                       CONFIG + "Value: !!python/object:danger\n"):
            with self.subTest(config=config):
                self.paths.config.write_text(config)
                with self.assertRaises(torrent.m.Failure):
                    torrent._verify_result(self.paths, self.runner, diagnostics)
        self.assertFalse(self.runner.calls)
        self.assertTrue(self.paths.config.exists())

    def _config_file(self):
        path = self.root / "valid.yaml"
        path.write_text(CONFIG)
        return path

    def test_quoted_inline_comments_and_hash_inside_string(self):
        values = torrent._parse_config(self._config_file())
        self.assertEqual(values["LogFile"], torrent.LOG_FILE)
        self.assertEqual(values["BlockMode"], "iptables")
        self.assertEqual(values["WebhookURL"], "")
        path = self.root / "hash.yaml"
        path.write_text('Value: "a#b" # comment\nOther: \'a#b\' # comment\n')
        self.assertEqual(torrent._parse_config(path), {"Value": "a#b", "Other": "a#b"})

    def test_restart_loop_exec_error_and_unknown_fragment_rejected(self):
        self.install()
        diagnostics = torrent.Diagnostics(self.backup)
        for attribute, value in (("restarts", "1"), ("status", "2"), ("service_result", "exit-code"),
                                 ("fragment", str(self.root / "unknown.service")), ("dropins", "unknown")):
            with self.subTest(attribute=attribute):
                previous = getattr(self.runner, attribute)
                setattr(self.runner, attribute, value)
                with self.assertRaises(torrent.m.Failure):
                    torrent._verify_result(self.paths, self.runner, diagnostics)
                setattr(self.runner, attribute, previous)

    def test_raw_validator_refuses_crossrefs_duplicates_and_wide_sources(self):
        for firewall in (OWN_FIREWALL.replace("192.0.2.1/32", "192.0.2.0/24"),
                         OWN_FIREWALL.replace("-j TBLOCKER_BLOCKED", "-g TBLOCKER_BLOCKED"),
                         OWN_FIREWALL.replace("-A PREROUTING -j TBLOCKER_BLOCKED\n",
                                              "-A PREROUTING -j TBLOCKER_BLOCKED\n" * 2),
                         OWN_FIREWALL.replace("-A TBLOCKER_BLOCKED -s 192.0.2.1/32 -j DROP\n",
                                              "-A INPUT -j TBLOCKER_BLOCKED\n")):
            with self.subTest(firewall=firewall), self.assertRaises(torrent.m.Failure):
                torrent._raw_rules(result(0, firewall))

    def test_bounded_readiness_timeout(self):
        self.runner.readiness_inactive = True
        with self.assertRaises(torrent.m.Failure):
            self.install()
        self.assertTrue(self.diagnostic("failure.json"))
        self.assertLess(len(self.runner.calls), 50)
        self.assertEqual(self.runner.active, "inactive")

    def test_invalid_url_defaults_and_platform_fail_before_commands(self):
        for kwargs in ({"upstream_url": "http://example.test/script"},
                       {"upstream_url": "https://user:secret@example.test/script"},
                       {"upstream_url": 123}, {"defaults": {"LogFile": "/tmp/other"}}):
            with self.assertRaises(torrent.m.Failure):
                self.install(**kwargs)
        self.assertFalse(self.runner.calls)
        self.guard.stop()
        with patch.object(torrent.sys, "platform", "win32"):
            with self.assertRaisesRegex(torrent.m.Failure, "root на Linux"):
                self.install()

    def test_exact_system_log_parent_exception_only(self):
        with patch.object(torrent.m, "secure_path") as secure:
            torrent._log_parent(Path(torrent.LOG_FILE))
            secure.assert_called_once_with(Path("/var/log/remnanode"), directory=True, allow_system_parent=True)
            secure.reset_mock()
            torrent._log_parent(self.paths.log)
            secure.assert_not_called()

    def test_parent_commandrunner_api_and_safe_download_argv(self):
        run = Mock()
        runner = torrent.CommandRunner(run=run)
        with patch.object(runner, "_child", return_value=result()) as child:
            runner.download(torrent.torrent_release.API_URL, self.root / "release.json",
                            stdout_path=self.root / "out", stderr_path=self.root / "err", timeout=600)
        args = child.call_args.args[0]
        self.assertEqual(args[0], "curl")
        self.assertNotIn("bash", args)
        self.assertIn("--proto-redir", args)
        self.assertFalse(run.called)

    def test_child_timeout_kills_group_waits_then_allows_rollback(self):
        runner = torrent.CommandRunner(run=Mock())
        work = self.root / "work"
        work.mkdir()
        process = Mock(pid=123456)
        process.wait.side_effect = [subprocess.TimeoutExpired("apt-get", 1), -9]
        with patch.object(torrent.subprocess, "Popen", return_value=process) as popen, \
                patch.object(torrent.os, "killpg", create=True) as killpg, \
                patch.object(torrent.signal, "SIGKILL", 9, create=True):
            with self.assertRaises(subprocess.TimeoutExpired):
                runner.child(["apt-get", "install", "-y", "./fixture.deb"], input_text="",
                             cwd=work, stdout_path=work / "out", stderr_path=work / "err", timeout=1)
            killpg.assert_called_once_with(123456, torrent.signal.SIGKILL)
            self.assertEqual(process.wait.call_count, 2)
            self.assertFalse(runner.child_running)
            kwargs = popen.call_args.kwargs
            self.assertTrue(kwargs["start_new_session"])
            self.assertEqual(kwargs["cwd"], str(work))
            self.assertEqual(kwargs["env"]["DEBIAN_FRONTEND"], "noninteractive")
            self.assertNotIn("shell", kwargs)
        self.assertFalse(list(work.glob("stdin-*")))


if __name__ == "__main__":
    unittest.main()
