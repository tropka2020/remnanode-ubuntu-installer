"""Portable host-feature contracts. No server commands, network or system writes.

Run: python -B -m unittest discover -s tests -p test_host_features.py -v
Linux ownership/service behavior is mocked, not integration-tested on Windows.
"""
from contextlib import ExitStack
import hashlib
import importlib.util
import io
import json
import os
from pathlib import Path
import socket
import stat
import subprocess
import sys
import tempfile
import traceback
from types import SimpleNamespace
import unittest
from unittest.mock import patch

PROJECT = Path(__file__).resolve().parents[1]


def load(name, filename):
    spec = importlib.util.spec_from_file_location(name, PROJECT / filename)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


m = load('host_features_test_manage', 'manage.py')
with patch.dict(sys.modules, {'manage': m}):
    host = load('host_features_under_test', 'host_features.py')


class HostCase(unittest.TestCase):
    def setUp(self):
        self.stack = ExitStack()
        self.addCleanup(self.stack.close)
        self.root = Path(self.stack.enter_context(tempfile.TemporaryDirectory(prefix='host-features-')))
        self.patch(host, 'ROOT', new=self.root)
        self.patch(host.sys, 'platform', new='linux')
        self.patch(host.os, 'geteuid', return_value=0, create=True)
        self.stack.enter_context(patch.dict(os.environ, {'SSH_CONNECTION': '192.0.2.10 55555 192.0.2.20 2200'}))
        for target, name in ((subprocess, 'run'), (subprocess, 'Popen'),
                             (os, 'system'), (socket, 'socket'),
                             (socket, 'create_connection'), (socket, 'getaddrinfo')):
            self.patch(target, name, side_effect=AssertionError('Real external calls forbidden'))
        self.secure = self.patch(m, 'secure_path', side_effect=self.safe_path)
        self.patch(m, 'backup_dir', side_effect=self.backup)
        self.patch(m, 'BACKUPS', new=self.root / 'backups')
        self.clock = 0.0
        self.patch(host.time, 'monotonic', side_effect=lambda: self.clock)
        self.patch(host.time, 'sleep', side_effect=self.advance_clock)
        self.conffiles = ''
        self.dependencies = True
        self.package_version = '1.1.0-1ubuntu1'
        original_open, original_mkdir, original_unlink = Path.open, Path.mkdir, Path.unlink

        def safe_open(path, mode='r', *args, **kwargs):
            if any(flag in mode for flag in 'wax+'):
                self.safe_path(path)
            return original_open(path, mode, *args, **kwargs)

        def safe_mkdir(path, *args, **kwargs):
            self.safe_path(path)
            return original_mkdir(path, *args, **kwargs)

        def safe_unlink(path, *args, **kwargs):
            self.safe_path(path)
            return original_unlink(path, *args, **kwargs)

        self.patch(Path, 'open', new=safe_open)
        self.patch(Path, 'mkdir', new=safe_mkdir)
        self.patch(Path, 'unlink', new=safe_unlink)
        self.disk = self.patch(host, '_disk_snapshot', return_value=[
            {'path': '/', 'free_bytes': 4 * host.GIB, 'free_inodes': 20000}])
        self.cc = 'cubic'
        self.qdisc = 'fq_codel'
        self.actual = [{'kind': 'noqueue', 'dev': 'lo'}, {'kind': 'fq_codel', 'dev': 'eth0'}]
        self.module = '/lib/modules/test/tcp_bbr.ko'
        self.installed = False
        self.active = 'unknown'
        self.enabled = 'not-found'
        self.calls = []
        self.failure = None
        self.run = self.patch(m, 'run', side_effect=self.command)

    def advance_clock(self, seconds):
        self.clock += seconds

    def patch(self, target, name, **kwargs):
        return self.stack.enter_context(patch.object(target, name, **kwargs))

    def safe_path(self, path, **kwargs):
        path = Path(path).absolute()
        if not path.is_relative_to(self.root):
            raise AssertionError('Non-test path forbidden: ' + str(path))
        if path.is_symlink():
            raise m.Failure('Unsafe symlink')
        return path

    def backup(self, label):
        path = self.root / 'backups' / (label + '-' + str(len(list((self.root / 'backups').glob('*')))))
        path.mkdir(parents=True)
        return path

    def write(self, name, text):
        path = host._path(name)
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(text, encoding='utf-8')
        return path

    def command(self, args, **kwargs):
        args = [str(arg) for arg in args]
        self.calls.append(args)
        self.assertGreater(kwargs.get('timeout', 0), 0)
        self.assertLessEqual(kwargs['timeout'], 900)
        if self.failure is not None:
            self.failure(args)
        if args[:2] == ['sysctl', '-n']:
            return {host.CC: self.cc, host.QDISC: self.qdisc,
                    'net.ipv4.tcp_available_congestion_control': 'cubic bbr'}[args[2]]
        if args[:2] == ['sysctl', '-w']:
            self.assertEqual(args[2].split('=')[0], host.CC)
            self.cc = args[2].split('=')[1]
            return SimpleNamespace(returncode=0, stdout='')
        if args == ['tc', '-j', 'qdisc', 'show']:
            return json.dumps(self.actual)
        if args == ['modinfo', '-F', 'filename', 'tcp_bbr']:
            return self.module
        if args == ['modprobe', 'tcp_bbr']:
            return SimpleNamespace(returncode=0, stdout='')
        if args == ['uname', '-r']:
            return 'test-kernel'
        if args == ['nproc']:
            return '2'
        if args == ['systemd-detect-virt']:
            return 'kvm'
        if args == ['free', '-b']:
            return 'Mem: 2000000000 500000000 1500000000'
        if args == ['dpkg-query', '-W', '-f=${Version}', 'fail2ban']:
            return self.package_version
        if args == ['dpkg-query', '-W', '-f=${Conffiles}', 'fail2ban']:
            return self.conffiles
        if args[:1] == ['dpkg-query']:
            self.assertIn(args[-1], ('fail2ban', 'python3-systemd', 'nftables'))
            installed = self.installed if args[-1] == 'fail2ban' else self.dependencies
            return SimpleNamespace(returncode=0 if installed else 1,
                                   stdout='install ok installed' if installed else '')
        if args == ['systemctl', 'is-active', 'fail2ban']:
            return SimpleNamespace(returncode={'active': 0, 'inactive': 3, 'unknown': 4,
                                               'failed': 3}[self.active], stdout=self.active)
        if args == ['systemctl', 'is-enabled', 'fail2ban']:
            return SimpleNamespace(returncode=0 if self.enabled == 'enabled' else 1, stdout=self.enabled)
        if args[:2] == ['apt-get', 'update']:
            self.assertTrue(host._path(host.POLICY_FILE).is_file())
            return SimpleNamespace(returncode=0, stdout='')
        if args[:2] == ['apt-get', 'install']:
            self.assertTrue(host._path(host.POLICY_FILE).is_file())
            self.installed = True
            self.active = 'inactive'
            self.enabled = 'disabled'
            self.write('/etc/fail2ban/action.d/nftables-multiport.conf', '[Definition]\n')
            self.write(host.F2B_SERVER, '#!/usr/bin/python3\n# package server\n')
            return SimpleNamespace(returncode=0, stdout='')
        if args == ['fail2ban-client', '-t']:
            self.assertTrue(host._path(host.JAIL_FILE).is_file())
            self.assertFalse(host._path(host.POLICY_FILE).exists())
            return SimpleNamespace(returncode=0, stdout='OK')
        if args == ['systemctl', 'enable', '--now', 'fail2ban']:
            self.active, self.enabled = 'active', 'enabled'
            return SimpleNamespace(returncode=0, stdout='')
        if args == ['fail2ban-client', 'ping']:
            return SimpleNamespace(returncode=0, stdout='Server replied: pong')
        if args == ['fail2ban-client', 'status', 'sshd']:
            return SimpleNamespace(returncode=0, stdout='Status for the jail: sshd')
        if args == ['systemctl', 'stop', 'fail2ban']:
            self.active = 'inactive'
            return SimpleNamespace(returncode=0, stdout='')
        if args == ['systemctl', 'disable', 'fail2ban']:
            self.enabled = 'disabled'
            return SimpleNamespace(returncode=0, stdout='')
        raise AssertionError('Unexpected external command: ' + repr(args))

    def fail_on(self, expected):
        def fail(args):
            if args == expected:
                raise m.Failure('SECRET_DIAGNOSTIC')
        self.failure = fail

    def assert_no_writes(self):
        self.assertEqual(list(self.root.iterdir()), [])


class CapacityTests(HostCase):
    def test_default_is_2_gib_and_threshold_is_inclusive(self):
        self.disk.return_value[0].update(free_bytes=2 * host.GIB, free_inodes=10000)
        self.assertEqual(host.preflight_capacity(), self.disk.return_value)
        self.run.assert_not_called()
        self.assert_no_writes()

    def test_low_space_or_inodes_warn_without_blocking_or_cleanup(self):
        for field, value in (('free_bytes', 0), ('free_bytes', host.GIB - 1),
                             ('free_bytes', 2 * host.GIB - 1), ('free_inodes', 9999)):
            with self.subTest(field=field, value=value):
                self.disk.return_value = [{'path': '/var/lib/docker', 'free_bytes': 4 * host.GIB,
                                           'free_inodes': 20000, field: value}]
                with patch('builtins.print') as output:
                    self.assertEqual(host.preflight_capacity(), self.disk.return_value)
                self.assertTrue(output.called)
                self.assertIn('ПРЕДУПРЕЖДЕНИЕ', output.call_args.args[0])
        self.run.assert_not_called()
        self.assert_no_writes()

    def test_cannot_disable_capacity_floor(self):
        for value in (0, host.GIB - 1, True, 'invalid'):
            with self.subTest(value=value), self.assertRaises(m.Failure):
                host.preflight_capacity(value)
        self.disk.assert_not_called()

    def test_optional_floor_and_unknown_unlimited_inodes(self):
        self.disk.return_value[0].update(free_bytes=host.GIB, free_inodes=None)
        self.assertTrue(host.preflight_capacity(host.GIB))

    def test_observation_failure_is_controlled(self):
        self.disk.side_effect = OSError('disk unavailable')
        with self.assertRaises(m.Failure):
            host.preflight_capacity()
        self.assert_no_writes()

    def test_snapshot_checks_ancestor_of_each_download_path(self):
        self.write('/var/lib/docker/keep', 'keep')
        self.disk.side_effect = None
        with patch.object(host.shutil, 'disk_usage', return_value=SimpleNamespace(free=3 * host.GIB, total=5 * host.GIB)) as usage:
            with patch.object(host.os, 'statvfs', create=True,
                              return_value=SimpleNamespace(f_favail=12345, f_files=100000)):
                snapshot = self.disk_snapshot_original()
        self.assertEqual([item['path'] for item in snapshot],
                         ['/', '/var/lib/docker', '/var/cache/apt/archives', '/opt'])
        self.assertEqual(snapshot[0]['free_inodes'], 12345)
        self.assertEqual(usage.call_count, 4)

    @staticmethod
    def disk_snapshot_original():
        # A fresh isolated module retains the real function, with the same temp ROOT.
        with patch.dict(sys.modules, {'manage': m}):
            real = load('host_features_disk_test', 'host_features.py')
        real.ROOT = host.ROOT
        return real._disk_snapshot()


class InspectionTests(HostCase):
    def test_read_only_bounded_commands(self):
        data = host.inspect_performance()
        self.assertEqual(data['congestion_control'], 'cubic')
        self.assertEqual(data['default_qdisc'], 'fq_codel')
        self.assertEqual(data['qdiscs'], self.actual)
        self.assertEqual(data['disk'], self.disk.return_value)
        self.assertEqual(data['errors'], [])
        self.assertEqual(data['cpu_count'], '2')
        self.assertEqual(data['virtualization'], 'kvm')
        self.assertIn('2000000000', data['memory'])
        self.assertEqual(len(self.calls), 9)
        self.assertTrue(all(entry.kwargs['timeout'] <= 10 for entry in self.run.call_args_list))
        self.assert_no_writes()

    def test_unavailable_observations_do_not_trigger_changes(self):
        self.run.side_effect = m.Failure('SECRET_DIAGNOSTIC')
        data = host.inspect_performance()
        self.assertEqual(len(data['errors']), 9)
        self.assertNotIn('SECRET_DIAGNOSTIC', json.dumps(data))
        self.assert_no_writes()


class BBRTests(HostCase):
    def test_apply_only_cc_preserves_qdisc_and_leaves_module_loaded_on_rollback(self):
        change = host.configure_bbr()
        self.assertIn('включён и проверен', change.status)
        self.assertEqual(self.cc, 'bbr')
        self.assertEqual(host._path(host.MODULE_FILE).read_text(), host.MODULE_TEXT)
        self.assertEqual(host._path(host.SYSCTL_FILE).read_text(), host.SYSCTL_TEXT)
        self.assertTrue((change.backup / 'rollback.py').is_file())
        state = json.loads((change.backup / 'state.json').read_text())
        self.assertEqual(state['old_cc'], 'cubic')
        self.assertEqual(len(state['files']), 2)
        self.assertEqual([args for args in self.calls if args[:2] == ['sysctl', '-w']],
                         [['sysctl', '-w', host.CC + '=bbr']])
        change.rollback()
        self.assertEqual(self.cc, 'cubic')
        self.assertFalse(host._path(host.MODULE_FILE).exists())
        self.assertFalse(host._path(host.SYSCTL_FILE).exists())
        self.assertFalse(any(args[:1] == ['tc'] and 'show' not in args for args in self.calls))
        self.assertFalse(any(args[:2] == ['modprobe', '-r'] for args in self.calls))
        count = len(self.calls)
        change.rollback()
        self.assertEqual(len(self.calls), count)

    def test_both_supported_qdiscs_preserved(self):
        self.qdisc = 'fq'
        self.actual = [{'kind': 'mq'}, {'kind': 'fq'}]
        self.assertIn('включён', host.configure_bbr().status)
        self.assertEqual(self.qdisc, 'fq')

    def test_unknown_qdisc_current_or_module_skips_without_writes(self):
        for field, value in (('qdisc', 'pfifo_fast'), ('actual', [{'kind': 'cake'}]),
                             ('actual', []), ('actual', {}), ('module', ''), ('cc', 'bad value')):
            with self.subTest(field=field):
                old = getattr(self, field)
                setattr(self, field, value)
                change = host.configure_bbr()
                self.assertIn('пропущен', change.status)
                change.rollback()
                self.assert_no_writes()
                setattr(self, field, old)
        self.assertFalse(any(args[:2] == ['sysctl', '-w'] for args in self.calls))

    def test_read_failure_is_skip_not_error(self):
        self.fail_on(['modinfo', '-F', 'filename', 'tcp_bbr'])
        self.assertIn('пропущен', host.configure_bbr().status)
        self.assert_no_writes()

    def test_existing_external_config_is_respected(self):
        for name, text in (('/etc/sysctl.d/tuning.conf', host.CC + '=cubic\n'),
                           ('/etc/sysctl.d/tuning.conf', host.QDISC + '=fq\n'),
                           ('/etc/sysctl.d/tuning.conf', 'net/ipv4/tcp_congestion_control=cubic\n'),
                           ('/etc/modules-load.d/external.conf', 'tcp_bbr\n'),
                           (host.SYSCTL_FILE, 'external owner\n')):
            with self.subTest(name=name, text=text):
                path = self.write(name, text)
                self.assertIn('пропущен', host.configure_bbr().status)
                self.assertEqual(path.read_text(), text)
                path.unlink()
        self.assertFalse(any(args[:1] == ['modprobe'] for args in self.calls))

    def test_already_enabled_external_does_not_add_persistence(self):
        self.cc = 'bbr'
        change = host.configure_bbr()
        self.assertIn('извне', change.status)
        change.rollback()
        self.assert_no_writes()

    def test_idempotent_second_call_cannot_rollback_first_calls_changes(self):
        first = host.configure_bbr()
        count = len([args for args in self.calls if args[:2] == ['sysctl', '-w']])
        second = host.configure_bbr()
        self.assertIn('уже включён', second.status)
        second.rollback()
        self.assertEqual(self.cc, 'bbr')
        self.assertTrue(host._path(host.SYSCTL_FILE).exists())
        self.assertEqual(len([args for args in self.calls if args[:2] == ['sysctl', '-w']]), count)
        first.rollback()

    def test_runtime_rollback_failure_is_reported_and_keeps_journal(self):
        change = host.configure_bbr()
        self.fail_on(['sysctl', '-w', host.CC + '=cubic'])
        with self.assertRaises(m.Failure):
            change.rollback()
        state = json.loads((change.backup / 'state.json').read_text())
        self.assertTrue(state['cc_changed'])
        self.assertTrue(host._path(host.SYSCTL_FILE).exists())
        self.failure = None
        change.rollback()
        self.assertEqual(self.cc, 'cubic')

    def test_exclusive_file_creation_failure_restores_earlier_own_file(self):
        original = host.FeatureChange._new_file

        def write(change, path, text, mode=0o644):
            if path == host._path(host.SYSCTL_FILE):
                self.write(host.SYSCTL_FILE, 'concurrent owner')
            return original(change, path, text, mode)
        with patch.object(host.FeatureChange, '_new_file', new=write):
            with self.assertRaises(m.Failure):
                host.configure_bbr()
        self.assertFalse(host._path(host.MODULE_FILE).exists())
        self.assertEqual(host._path(host.SYSCTL_FILE).read_text(), 'concurrent owner')
        self.assertFalse(any(args[:2] == ['sysctl', '-w'] for args in self.calls))

    def test_failed_apply_rolls_back_files_and_safe_message(self):
        self.fail_on(['sysctl', '-w', host.CC + '=bbr'])
        with self.assertRaises(m.Failure) as caught:
            host.configure_bbr()
        self.assertNotIn('SECRET_DIAGNOSTIC', str(caught.exception))
        self.assertFalse(host._path(host.MODULE_FILE).exists())
        self.assertFalse(host._path(host.SYSCTL_FILE).exists())
        self.assertEqual(self.cc, 'cubic')

    def test_failed_verification_restores_runtime_value(self):
        original = self.command
        reads = 0

        def command(args, **kwargs):
            nonlocal reads
            if args == ['sysctl', '-n', host.CC]:
                reads += 1
                if reads == 2:
                    raise m.Failure('verification failed')
            return original(args, **kwargs)
        self.run.side_effect = command
        with self.assertRaises(m.Failure):
            host.configure_bbr()
        self.assertEqual(self.cc, 'cubic')
        self.assertFalse(host._path(host.SYSCTL_FILE).exists())

    def test_modprobe_failure_has_no_sysctl_write(self):
        self.fail_on(['modprobe', 'tcp_bbr'])
        with self.assertRaises(m.Failure):
            host.configure_bbr()
        self.assertFalse(any(args[:2] == ['sysctl', '-w'] for args in self.calls))

    def test_rollback_preserves_concurrent_file_and_runtime_changes(self):
        change = host.configure_bbr()
        path = self.write(host.SYSCTL_FILE, 'concurrent config\n')
        self.cc = 'reno'
        change.rollback()
        self.assertEqual(path.read_text(), 'concurrent config\n')
        self.assertEqual(self.cc, 'reno')
        self.assertFalse(host._path(host.MODULE_FILE).exists())

    def test_rollback_preserves_preexisting_own_exact_targets(self):
        module = self.write(host.MODULE_FILE, host.MODULE_TEXT)
        config = self.write(host.SYSCTL_FILE, host.SYSCTL_TEXT)
        change = host.configure_bbr()
        change.rollback()
        self.assertEqual(module.read_text(), host.MODULE_TEXT)
        self.assertEqual(config.read_text(), host.SYSCTL_TEXT)

    def test_root_required_before_commands(self):
        self.patch(host.os, 'geteuid', return_value=1000)
        with self.assertRaises(m.Failure):
            host.configure_bbr()
        self.run.assert_not_called()


class Fail2banTests(HostCase):
    def setUp(self):
        super().setUp()
        # Windows cannot represent POSIX ownership/modes. Mock just that metadata,
        # retaining real temporary files, identity, size and file type checks.
        self.metadata = {}
        self.path_modes = {}
        self.path_links = {}
        original_lstat = Path.lstat

        def lstat(path):
            info = original_lstat(path)
            mode = self.path_modes.get(path)
            if mode is None:
                mode = 0o700 if stat.S_ISDIR(info.st_mode) else 0o600
                if path.name == 'rollback.py':
                    mode = 0o700
            values = list(info)
            values[0] = stat.S_IFMT(info.st_mode) | mode
            values[4] = self.metadata.get(path, 0)
            values[3] = self.path_links.get(path, info.st_nlink)
            return os.stat_result(values)
        self.patch(Path, 'lstat', new=lstat)

    def legacy_package(self):
        self.installed, self.active, self.enabled = True, 'inactive', 'disabled'
        # Exact original geometry, without any provenance marker.
        change = host._change('fail2ban')
        for name, text in (
                ('jail.conf', '[DEFAULT]\n'), ('fail2ban.conf', '[Definition]\n'),
                ('jail.d/defaults-debian.conf', '[sshd]\nenabled = true\n'),
                ('action.d/nftables-multiport.conf', '[Definition]\n')):
            path = self.write('/etc/fail2ban/' + name, text)
            self.conffiles += ' /etc/fail2ban/' + name + ' ' + hashlib.md5(path.read_bytes()).hexdigest() + '\n'
        return change

    def receipted_package(self):
        change = self.legacy_package()
        self.write(host.F2B_SERVER, '#!/usr/bin/python3\n# package server\n')
        request = {'version': 2, 'package': 'fail2ban', 'source': 'apt-install',
                   'nonce': 'a' * 64}
        receipt = {'version': 1, 'nonce': request['nonce'], **host._fail2ban_install_identity()}
        m.write_json(change.backup / 'package-install.json', request)
        m.write_json(change.backup / 'package-receipt.json', receipt)
        return change

    def ensure(self, *, recover_legacy=False):
        return host.ensure_fail2ban([2200, 22, 2200], recover_legacy=recover_legacy)

    def test_new_install_validates_before_enable_with_exact_client_and_ports(self):
        change = self.ensure()
        self.assertIn('включён и проверен', change.status)
        jail = host._path(host.JAIL_FILE).read_text()
        for text in ('backend = systemd', 'port = 22,2200', 'banaction = nftables-multiport',
                     'maxretry = 5', 'findtime = 10m', 'bantime = 1h',
                     'ignoreip = 127.0.0.1/8 ::1 192.0.2.10'):
            self.assertIn(text, jail)
        self.assertNotIn('192.0.2.0', jail)
        self.assertLess(self.calls.index(['fail2ban-client', '-t']),
                        self.calls.index(['systemctl', 'enable', '--now', 'fail2ban']))
        self.assertLess(self.calls.index(['systemctl', 'enable', '--now', 'fail2ban']),
                        self.calls.index(['fail2ban-client', 'status', 'sshd']))
        apt = next(entry for entry in self.run.call_args_list if entry.args[0][:2] == ['apt-get', 'install'])
        for package in ('fail2ban', 'python3-systemd', 'nftables'):
            self.assertIn(package, apt.args[0])
        self.assertEqual(apt.kwargs['env']['DEBIAN_FRONTEND'], 'noninteractive')
        self.assertIn('Dpkg::Options::=--force-confold', apt.args[0])
        self.assertFalse(host._path(host.POLICY_FILE).exists())
        self.assertTrue(self.disk.called)
        change.rollback()
        self.assertFalse(host._path(host.JAIL_FILE).exists())
        self.assertEqual(self.active, 'inactive')
        self.assertEqual(self.enabled, 'disabled')
        self.assertTrue(self.installed)
        self.assertFalse(any('remove' in args or 'purge' in args for args in self.calls))
        self.assertFalse(any(args[0] in ('ufw', 'sshd', 'nft') for args in self.calls))

    def test_legacy_default_skip_and_explicit_resume_only_rolls_back_new_jail(self):
        prior = self.legacy_package()
        self.assertFalse((prior.backup / 'package-install.json').exists())
        before = (prior.backup / 'state.json').read_bytes()
        self.assertIn('пропущен', self.ensure().status)
        self.assertEqual(self.active, 'inactive')
        change = self.ensure(recover_legacy=True)
        self.assertIn('legacy восстановлено по разрешению', change.status)
        self.assertIn('включён и проверен', change.status)
        self.assertNotEqual(change.backup, prior.backup)
        self.assertFalse(any(args[0] == 'apt-get' for args in self.calls))
        self.assertEqual((prior.backup / 'state.json').read_bytes(), before)
        self.assertIn(host.ROLLBACK_SCRIPT, (change.backup / 'rollback.py').read_text())
        state = json.loads((change.backup / 'state.json').read_text())
        self.assertTrue(state['service_started'])
        self.assertFalse(state['package_enable_pending'])
        self.assertEqual(len(state['files']), 1)
        change.rollback()
        self.assertEqual((self.active, self.enabled), ('inactive', 'disabled'))
        self.assertTrue(host._path('/etc/fail2ban/jail.d/defaults-debian.conf').exists())
        self.assertFalse(host._path(host.JAIL_FILE).exists())
        # Explicit permission must not silently mint post-APT provenance.
        self.assertFalse((change.backup / 'package-install.json').exists())
        self.assertFalse((change.backup / 'package-receipt.json').exists())
        self.assertIn('пропущен', self.ensure().status)

    def test_receipt_resume_preserves_original_request_and_receipt(self):
        prior = self.receipted_package()
        request = (prior.backup / 'package-install.json').read_bytes()
        receipt = (prior.backup / 'package-receipt.json').read_bytes()
        change = self.ensure()
        self.assertIn('включён', change.status)
        self.assertNotIn('legacy', change.status)
        self.assertEqual((change.backup / 'package-install.json').read_bytes(), request)
        self.assertEqual((change.backup / 'package-receipt.json').read_bytes(), receipt)
        change.rollback()
        self.assertEqual((change.backup / 'package-receipt.json').read_bytes(), receipt)
        self.assertFalse(any(args[0] == 'apt-get' for args in self.calls))

    def test_old_static_marker_requires_explicit_legacy_permission(self):
        prior = self.legacy_package()
        m.write_json(prior.backup / 'package-install.json', host.F2B_PACKAGE_MARKER)
        self.assertIn('пропущен', self.ensure().status)
        self.assertIn('legacy восстановлено по разрешению',
                      self.ensure(recover_legacy=True).status)

    def test_stale_receipt_binary_identity_change_skips_even_with_legacy_permission(self):
        prior = self.receipted_package()
        binary = host._path(host.F2B_SERVER)
        original_stat = Path.stat
        for field in ('st_dev', 'st_ino', 'st_size', 'st_mtime_ns'):
            with self.subTest(field=field):
                def changed_stat(path, *args, **kwargs):
                    info = original_stat(path, *args, **kwargs)
                    if path != binary or kwargs.get('follow_symlinks') is False:
                        return info
                    values = {name: getattr(info, name) for name in
                              ('st_dev', 'st_ino', 'st_size', 'st_mtime_ns', 'st_mode')}
                    values[field] += 1
                    return SimpleNamespace(**values)
                with patch.object(Path, 'stat', new=changed_stat):
                    for permitted in (False, True):
                        self.assertIn('пропущен', self.ensure(recover_legacy=permitted).status)
        # Same-sized bytes with restored mtime must still fail the SHA256 check.
        info = binary.stat()
        text = binary.read_text()
        binary.write_text(text.replace('server', 'SERVER'))
        os.utime(binary, ns=(info.st_atime_ns, info.st_mtime_ns))
        self.assertIn('пропущен', self.ensure().status)
        self.assertEqual(list(m.BACKUPS.iterdir()), [prior.backup])
        self.assertFalse(any(args[0] in ('apt-get', 'fail2ban-client') for args in self.calls))

    def test_stale_receipt_version_or_nonce_mismatch_skips(self):
        prior = self.receipted_package()
        self.package_version = '1.1.0-2ubuntu1'
        for permitted in (False, True):
            self.assertIn('пропущен', self.ensure(recover_legacy=permitted).status)
        self.package_version = '1.1.0-1ubuntu1'
        path = prior.backup / 'package-receipt.json'
        receipt = json.loads(path.read_text())
        receipt['nonce'] = 'b' * 64
        m.write_json(path, receipt)
        self.assertIn('пропущен', self.ensure(recover_legacy=True).status)

    def test_missing_post_apt_receipt_does_not_fall_back_to_legacy(self):
        prior = self.receipted_package()
        (prior.backup / 'package-receipt.json').unlink()
        self.assertIn('пропущен', self.ensure().status)
        self.assertIn('пропущен', self.ensure(recover_legacy=True).status)

    def test_failed_apt_never_writes_success_receipt(self):
        def fail(args):
            if args[:2] == ['apt-get', 'install']:
                raise m.Failure('SECRET_APT')
        self.failure = fail
        with self.assertRaises(m.Failure):
            self.ensure()
        folder = next(m.BACKUPS.glob('fail2ban-*'))
        self.assertTrue((folder / 'package-install.json').exists())
        self.assertFalse((folder / 'package-receipt.json').exists())
        self.assertFalse(host._fail2ban_rollback_evidence(recover_legacy=True))

    def test_legacy_permission_does_not_bypass_baseline_or_completed_journal(self):
        prior = self.legacy_package()
        local = self.write('/etc/fail2ban/jail.local', 'external')
        self.assertIn('пропущен', self.ensure(recover_legacy=True).status)
        local.unlink()
        state = json.loads((prior.backup / 'state.json').read_text())
        state['service_started'] = True
        m.write_json(prior.backup / 'state.json', state)
        self.assertIn('пропущен', self.ensure(recover_legacy=True).status)
        self.assertFalse(any(args[0] in ('apt-get', 'fail2ban-client') for args in self.calls))

    def test_new_install_marker_precedes_apt_and_survives_rollback(self):
        def verify_marker(args):
            if args[:2] == ['apt-get', 'install']:
                folders = list(m.BACKUPS.glob('fail2ban-*'))
                self.assertEqual(len(folders), 1)
                request = json.loads((folders[0] / 'package-install.json').read_text())
                self.assertTrue(host._valid_fail2ban_request(request))
                self.assertFalse((folders[0] / 'package-receipt.json').exists())
        self.failure = verify_marker
        change = self.ensure()
        change.rollback()
        self.assertTrue((change.backup / 'package-install.json').is_file())
        receipt = json.loads((change.backup / 'package-receipt.json').read_text())
        request = json.loads((change.backup / 'package-install.json').read_text())
        self.assertEqual(receipt, {'version': 1, 'nonce': request['nonce'],
                                  **host._fail2ban_install_identity()})
        self.assertTrue(host._fail2ban_rollback_evidence())

    def test_modified_or_added_config_is_never_resumed(self):
        prior = self.receipted_package()
        for name in ('jail.local', 'jail.d/custom.local', 'jail.d/external.conf',
                     'filter.d/external.conf', 'jail.d/defaults-debian.conf'):
            with self.subTest(name=name):
                path = host._path('/etc/fail2ban/' + name)
                original = path.read_text() if path.exists() else None
                self.write('/etc/fail2ban/' + name, 'SECRET_CONFIGURATION')
                self.calls.clear()
                change = self.ensure()
                self.assertIn('пропущен', change.status)
                self.assertNotIn('включён', change.status)
                self.assertEqual(path.read_text(), 'SECRET_CONFIGURATION')
                self.assertFalse(any(args[0] in ('apt-get', 'fail2ban-client') or
                                     args[:2] in (['systemctl', 'enable'], ['systemctl', 'stop'])
                                     for args in self.calls))
                if original is None:
                    path.unlink()
                else:
                    path.write_text(original)
        self.assertEqual(list(m.BACKUPS.iterdir()), [prior.backup])

    def test_untrusted_or_unfinished_evidence_skips(self):
        prior = self.receipted_package()
        journal = prior.backup / 'state.json'
        script = prior.backup / 'rollback.py'
        initial = json.loads(journal.read_text())
        bad_states = [dict(initial, files=[{}]), dict(initial, service_started=True),
                      dict(initial, package_enable_pending=True), dict(initial, cc_changed=True),
                      dict(initial, service_started=0), dict(initial, extra=False), []]
        for state in bad_states:
            with self.subTest(state=state):
                m.write_json(journal, state)
                self.assertIn('пропущен', self.ensure().status)
        m.write_json(journal, initial)
        script.write_text(host.ROLLBACK_SCRIPT + '# edited\n')
        self.assertIn('пропущен', self.ensure().status)
        script.write_text(host.ROLLBACK_SCRIPT)
        for path in (m.BACKUPS, prior.backup, journal, script):
            with self.subTest(path=path):
                self.metadata[path] = 1000
                self.assertIn('пропущен', self.ensure().status)
                self.metadata.pop(path)
                self.path_modes[path] = 0o755 if path.is_dir() else 0o644
                self.assertIn('пропущен', self.ensure().status)
                self.path_modes.pop(path)
        self.assertFalse(any(args[0] in ('apt-get', 'fail2ban-client') for args in self.calls))

    def test_symlink_or_hardlink_backup_evidence_is_not_trusted(self):
        prior = self.receipted_package()
        for path in (prior.backup / 'rollback.py', prior.backup / 'state.json'):
            with self.subTest(path=path):
                self.path_links[path] = 2
                self.assertIn('пропущен', self.ensure().status)
                self.path_links.pop(path)
        original = Path.is_symlink
        for path in (prior.backup, prior.backup / 'rollback.py', prior.backup / 'state.json'):
            with self.subTest(symlink=path):
                with patch.object(Path, 'is_symlink', new=lambda item: item == path or original(item)):
                    self.assertIn('пропущен', self.ensure().status)
        self.assertFalse(any(args[0] in ('apt-get', 'fail2ban-client') for args in self.calls))

    def test_external_systemd_management_and_own_jail_prevent_resume(self):
        self.receipted_package()
        for name in (host.JAIL_FILE, host.POLICY_FILE,
                     '/etc/systemd/system/fail2ban.service',
                     '/etc/systemd/system/fail2ban.service.d/override.conf',
                     '/run/systemd/system/fail2ban.service.d/override.conf'):
            with self.subTest(name=name):
                path = self.write(name, 'external service/configuration')
                self.assertIn('пропущен', self.ensure().status)
                self.assertEqual(path.read_text(), 'external service/configuration')
                path.unlink()
                if path.parent.name == 'fail2ban.service.d':
                    path.parent.rmdir()
        self.assertFalse(any(args[0] in ('apt-get', 'fail2ban-client') for args in self.calls))

    def test_missing_or_conflicting_package_file_checksum_refuses_resume(self):
        self.receipted_package()
        jail = host._path('/etc/fail2ban/jail.conf')
        original = jail.read_text()
        jail.unlink()
        self.assertIn('пропущен', self.ensure().status)
        jail.write_text(original)
        digest = '0' * 32
        metadata = self.write('/var/lib/dpkg/info/fail2ban.md5sums',
                              digest + '  etc/fail2ban/jail.conf\n')
        self.assertIn('пропущен', self.ensure().status)
        metadata.write_text('invalid checksum file')
        self.assertIn('пропущен', self.ensure().status)
        self.assertFalse(any(args[0] in ('apt-get', 'fail2ban-client') for args in self.calls))

    def test_checksums_merge_md5sums_and_conffiles_without_network(self):
        self.receipted_package()
        # Action file is not a conffile in this synthetic package, so its checksum
        # comes only from md5sums. All effective files must still be accounted for.
        lines = self.conffiles.splitlines()
        action = lines.pop()
        name, digest = action.split()
        self.conffiles = '\n'.join(lines)
        self.write('/var/lib/dpkg/info/fail2ban.md5sums', digest + '  ' + name.lstrip('/') + '\n')
        self.assertIn('включён', self.ensure().status)
        self.assertFalse(any(args[0] == 'apt-get' for args in self.calls))

    def test_marker_malformed_or_insecure_is_not_a_legacy_fallback(self):
        prior = self.receipted_package()
        marker = prior.backup / 'package-install.json'
        for data in ({}, dict(host.F2B_PACKAGE_MARKER, version=True),
                     dict(host.F2B_PACKAGE_MARKER, source='external')):
            with self.subTest(data=data):
                m.write_json(marker, data)
                self.assertIn('пропущен', self.ensure().status)
        m.write_json(marker, host.F2B_PACKAGE_MARKER)
        self.path_modes[marker] = 0o644
        self.assertIn('пропущен', self.ensure().status)

    def test_resumed_readiness_timeout_rolls_back_and_allows_another_retry(self):
        self.receipted_package()
        self.fail_on(['fail2ban-client', 'status', 'sshd'])
        with patch('sys.stdout', new_callable=io.StringIO) as output:
            with self.assertRaises(m.Failure) as caught:
                self.ensure()
        self.assertEqual(self.clock, 30)
        self.assertEqual((self.active, self.enabled), ('inactive', 'disabled'))
        self.assertFalse(host._path(host.JAIL_FILE).exists())
        self.assertTrue(self.installed)
        formatted = ''.join(traceback.format_exception(caught.exception))
        self.assertNotIn('SECRET_DIAGNOSTIC', formatted + output.getvalue())
        self.failure = None
        self.assertIn('включён', self.ensure().status)
        self.assertFalse(any(args[0] == 'apt-get' for args in self.calls))

    def test_readiness_small_remaining_budget_is_passed_to_each_command(self):
        budgets = []

        def command(args, **kwargs):
            budgets.append(kwargs['timeout'])
            self.clock += kwargs['timeout']
            return SimpleNamespace(returncode=0 if len(budgets) == 1 else 255, stdout='pong')
        self.run.side_effect = command
        with self.assertRaises(m.Failure):
            host._wait_fail2ban(timeout=2.25)
        self.assertEqual(budgets, [2, 0.25])
        self.assertEqual(self.clock, 2.25)

    def test_readiness_cannot_succeed_after_deadline(self):
        def command(args, **kwargs):
            self.clock += 20
            return SimpleNamespace(returncode=0, stdout='OK')
        self.run.side_effect = command
        with self.assertRaises(m.Failure):
            host._wait_fail2ban()
        self.assertEqual(self.run.call_count, 2)

    def test_interrupt_is_not_swallowed_when_rollback_itself_fails(self):
        def fail(args):
            if args == ['fail2ban-client', 'ping']:
                raise KeyboardInterrupt()
            if args == ['systemctl', 'stop', 'fail2ban']:
                raise m.Failure('SECRET_DIAGNOSTIC')
        self.failure = fail
        with patch('sys.stdout', new_callable=io.StringIO) as output:
            with self.assertRaises(KeyboardInterrupt):
                self.ensure()
        self.assertIn('ручная проверка', output.getvalue())
        self.assertNotIn('SECRET_DIAGNOSTIC', output.getvalue())
        self.assertTrue(host._path(host.JAIL_FILE).exists())

    def test_marker_cannot_override_bad_legacy_proof(self):
        prior = self.receipted_package()
        m.write_json(prior.backup / 'package-install.json', host.F2B_PACKAGE_MARKER)
        (prior.backup / 'rollback.py').write_text('untrusted code')
        self.assertIn('пропущен', self.ensure().status)
        self.assertEqual(self.active, 'inactive')

    def test_other_backups_and_first_untrusted_candidate_do_not_grant_provenance(self):
        self.installed = True
        other = host._change('bbr')
        fake = self.backup('fail2ban')
        self.write(str(fake.relative_to(self.root) / 'state.json'), '{}')
        self.assertIn('пропущен', self.ensure().status)
        self.assertTrue(other.backup.exists())
        prior = self.receipted_package()
        self.assertIn('включён', self.ensure().status)
        self.assertTrue(prior.backup.exists())

    def test_missing_checksum_or_dependency_refuses_without_install(self):
        self.receipted_package()
        saved = self.conffiles
        for conffiles, dependencies in (('', True), (saved, False), ('malformed', True)):
            with self.subTest(conffiles=conffiles, dependencies=dependencies):
                self.conffiles, self.dependencies = conffiles, dependencies
                self.assertIn('пропущен', self.ensure().status)
        self.assertFalse(any(args[0] == 'apt-get' for args in self.calls))

    def test_legacy_active_enabled_or_unknown_service_is_not_resumed(self):
        self.receipted_package()
        for active, enabled in (('active', 'enabled'), ('failed', 'disabled'),
                                ('inactive', 'enabled'), ('unknown', 'not-found')):
            with self.subTest(active=active, enabled=enabled):
                self.active, self.enabled = active, enabled
                self.assertIn('пропущен', self.ensure().status)
        self.assertFalse(any(args[0] in ('apt-get', 'fail2ban-client') for args in self.calls))

    def test_readiness_missing_socket_then_success_does_not_stop_service(self):
        original = self.command
        attempts = 0

        def command(args, **kwargs):
            nonlocal attempts
            if args == ['fail2ban-client', 'ping']:
                attempts += 1
                if attempts < 3:
                    raise m.Failure('SECRET missing socket')
            return original(args, **kwargs)
        self.run.side_effect = command
        with patch('sys.stdout', new_callable=io.StringIO) as output:
            change = self.ensure()
        self.assertIn('включён', change.status)
        self.assertEqual(attempts, 3)
        self.assertEqual(self.clock, 2)
        self.assertEqual(self.active, 'active')
        self.assertNotIn(['systemctl', 'stop', 'fail2ban'], self.calls)
        self.assertNotIn('SECRET', output.getvalue())

    def test_readiness_missing_jail_retries_even_after_ping(self):
        original = self.command
        attempts = 0

        def command(args, **kwargs):
            nonlocal attempts
            if args == ['fail2ban-client', 'status', 'sshd']:
                attempts += 1
                if attempts == 1:
                    return SimpleNamespace(returncode=255, stdout='SECRET missing jail')
            return original(args, **kwargs)
        self.run.side_effect = command
        change = self.ensure()
        self.assertIn('включён', change.status)
        self.assertEqual(attempts, 2)
        self.assertEqual(self.clock, 1)
        self.assertEqual(self.calls.count(['fail2ban-client', 'ping']), 2)

    def test_readiness_failed_service_fails_fast_and_rolls_back(self):
        def fail(args):
            if args == ['fail2ban-client', 'ping']:
                self.active = 'failed'
                raise m.Failure('SECRET socket')
        self.failure = fail
        with self.assertRaises(m.Failure) as caught:
            self.ensure()
        self.assertEqual(self.clock, 0)
        self.assertIn('готовность ping/status sshd', str(caught.exception))
        self.assertNotIn('SECRET', str(caught.exception))
        self.assertEqual((self.active, self.enabled), ('inactive', 'disabled'))
        self.assertFalse(host._path(host.JAIL_FILE).exists())

    def test_readiness_budget_includes_commands_and_sleep(self):
        budgets = []

        def command(args, **kwargs):
            budgets.append(kwargs['timeout'])
            self.assertLessEqual(kwargs['timeout'], min(2, 4.5 - self.clock))
            self.clock += kwargs['timeout']
            raise m.Failure('SECRET timeout')
        self.run.side_effect = command
        with patch('sys.stdout', new_callable=io.StringIO) as output:
            with self.assertRaises(m.Failure) as caught:
                host._wait_fail2ban(timeout=4.5)
        self.assertEqual(self.clock, 4.5)
        self.assertEqual(budgets, [2, 2])
        self.assertNotIn('SECRET', output.getvalue() + str(caught.exception))

    def test_readiness_keyboard_interrupt_propagates_after_rollback(self):
        def interrupt(args):
            if args == ['fail2ban-client', 'ping']:
                raise KeyboardInterrupt()
        self.failure = interrupt
        with self.assertRaises(KeyboardInterrupt):
            self.ensure()
        self.assertEqual((self.active, self.enabled), ('inactive', 'disabled'))
        self.assertFalse(host._path(host.JAIL_FILE).exists())

    def test_existing_installed_active_external_is_never_touched(self):
        self.installed, self.active = True, 'active'
        path = self.write(host.JAIL_FILE, 'external config')
        change = self.ensure()
        self.assertIn('уже установлен', change.status)
        change.rollback()
        self.assertEqual(path.read_text(), 'external config')
        self.assertEqual(len(self.calls), 1)

    def test_existing_unknown_or_enabled_service_skipped(self):
        for active, enabled in (('active', 'enabled'), ('failed', 'disabled'),
                                ('inactive', 'enabled'), ('unknown', 'masked')):
            with self.subTest(active=active, enabled=enabled):
                self.active, self.enabled = active, enabled
                self.assertIn('пропущен', self.ensure().status)
                self.assert_no_writes()
        self.assertFalse(any(args[0] == 'apt-get' for args in self.calls))

    def test_external_config_and_policy_are_not_overwritten(self):
        for name in (host.JAIL_FILE, '/etc/fail2ban/jail.local', host.POLICY_FILE):
            with self.subTest(name=name):
                path = self.write(name, 'external')
                self.assertIn('пропущен', self.ensure().status)
                self.assertEqual(path.read_text(), 'external')
                path.unlink()
        self.assertFalse(any(args[0] == 'apt-get' for args in self.calls))

    def test_insufficient_capacity_warns_but_does_not_prevent_apt(self):
        self.disk.return_value[0]['free_bytes'] = 1
        with patch('builtins.print') as output:
            result = self.ensure()
        self.assertIn('включён', result.status)
        self.assertTrue(any(args[0] == 'apt-get' for args in self.calls))
        self.assertTrue(any('ПРЕДУПРЕЖДЕНИЕ' in str(entry) for entry in output.call_args_list))

    def test_apt_failure_removes_only_temporary_policy(self):
        self.fail_on(['apt-get', 'update'])
        with self.assertRaises(m.Failure) as caught:
            self.ensure()
        self.assertNotIn('SECRET_DIAGNOSTIC', str(caught.exception))
        self.assertFalse(host._path(host.POLICY_FILE).exists())
        self.assertFalse(host._path(host.JAIL_FILE).exists())
        self.assertFalse(any(args[:2] == ['systemctl', 'stop'] for args in self.calls))

    def test_partial_apt_failure_disables_only_newly_enabled_unit(self):
        def enable_and_fail(args):
            if args[:2] == ['apt-get', 'install']:
                self.installed, self.active, self.enabled = True, 'inactive', 'enabled'
                raise m.Failure('apt partially failed')
        self.failure = enable_and_fail
        with self.assertRaises(m.Failure):
            self.ensure()
        self.assertEqual(self.enabled, 'disabled')
        self.assertTrue(self.installed)
        self.assertFalse(host._path(host.POLICY_FILE).exists())
        self.assertFalse(any(args[:2] == ['systemctl', 'stop'] for args in self.calls))

    def test_config_validation_failure_removes_jail_without_starting_or_stopping(self):
        self.fail_on(['fail2ban-client', '-t'])
        with self.assertRaises(m.Failure):
            self.ensure()
        self.assertFalse(host._path(host.JAIL_FILE).exists())
        self.assertFalse(host._path(host.POLICY_FILE).exists())
        self.assertFalse(any(args[:2] in (['systemctl', 'enable'], ['systemctl', 'stop']) for args in self.calls))
        self.assertTrue(self.installed)

    def test_enable_failure_stops_only_originally_inactive_service(self):
        self.fail_on(['systemctl', 'enable', '--now', 'fail2ban'])
        with self.assertRaises(m.Failure):
            self.ensure()
        self.assertIn(['systemctl', 'stop', 'fail2ban'], self.calls)
        self.assertIn(['systemctl', 'disable', 'fail2ban'], self.calls)
        self.assertFalse(host._path(host.JAIL_FILE).exists())

    def test_failed_stop_retains_config_for_manual_recovery(self):
        change = self.ensure()
        self.fail_on(['systemctl', 'stop', 'fail2ban'])
        with self.assertRaises(m.Failure):
            change.rollback()
        self.assertTrue(host._path(host.JAIL_FILE).exists())
        self.assertTrue(json.loads((change.backup / 'state.json').read_text())['service_started'])
        self.failure = None
        change.rollback()
        self.assertFalse(host._path(host.JAIL_FILE).exists())

    def test_failed_apply_and_rollback_reports_private_recovery_path(self):
        def fail(args):
            if args in (['fail2ban-client', 'status', 'sshd'], ['systemctl', 'stop', 'fail2ban']):
                raise m.Failure('SECRET_DIAGNOSTIC')
        self.failure = fail
        with patch('sys.stdout', new_callable=io.StringIO) as output:
            with self.assertRaises(m.Failure) as caught:
                self.ensure()
        self.assertNotIn('SECRET_DIAGNOSTIC', output.getvalue())
        self.assertIn('ручная проверка', str(caught.exception))
        self.assertIn(str(self.root / 'backups'), str(caught.exception))
        self.assertNotIn('SECRET_DIAGNOSTIC', str(caught.exception))
        self.assertTrue(host._path(host.JAIL_FILE).exists())
        self.assertEqual(self.active, 'active')

    def test_missing_supported_action_does_not_start_service(self):
        original = self.command

        def command(args, **kwargs):
            result = original(args, **kwargs)
            if args[:2] == ['apt-get', 'install']:
                host._path('/etc/fail2ban/action.d/nftables-multiport.conf').unlink()
            return result
        self.run.side_effect = command
        with self.assertRaises(m.Failure):
            self.ensure()
        self.assertFalse(host._path(host.POLICY_FILE).exists())
        self.assertFalse(host._path(host.JAIL_FILE).exists())
        self.assertFalse(any(args[:2] == ['systemctl', 'enable'] for args in self.calls))

    def test_status_failure_stops_own_service_retains_packages(self):
        self.fail_on(['fail2ban-client', 'status', 'sshd'])
        with patch('sys.stdout', new_callable=io.StringIO) as output:
            with self.assertRaises(m.Failure):
                self.ensure()
        self.assertNotIn('SECRET_DIAGNOSTIC', output.getvalue())
        self.assertEqual(self.active, 'inactive')
        self.assertEqual(self.enabled, 'disabled')
        self.assertTrue(self.installed)
        self.assertFalse(host._path(host.JAIL_FILE).exists())

    def test_concurrent_jail_edit_does_not_stop_service_or_delete_file(self):
        change = self.ensure()
        path = self.write(host.JAIL_FILE, 'external edit')
        before = len(self.calls)
        with self.assertRaises(m.Failure):
            change.rollback()
        self.assertEqual(path.read_text(), 'external edit')
        self.assertEqual(len(self.calls), before)
        self.assertEqual(self.active, 'active')

    def test_concurrent_policy_edit_is_preserved_on_failure(self):
        def edit_and_fail(args):
            if args == ['apt-get', 'update']:
                self.write(host.POLICY_FILE, 'external edit')
                raise m.Failure('apt failed')
        self.failure = edit_and_fail
        with self.assertRaises(m.Failure):
            self.ensure()
        self.assertEqual(host._path(host.POLICY_FILE).read_text(), 'external edit')

    def test_invalid_ports_or_ssh_connection_fail_before_commands(self):
        for ports in ([], [0], [65536], [True], ['22']):
            with self.subTest(ports=ports), self.assertRaises(m.Failure):
                host.ensure_fail2ban(ports)
        for value in ('bad', '192.0.2.10 10 192.0.2.20 2222',
                      '192.0.2.10\nmalicious 10 192.0.2.20 22'):
            with self.subTest(value=value), patch.dict(os.environ, {'SSH_CONNECTION': value}):
                with self.assertRaises(m.Failure):
                    self.ensure()
        self.run.assert_not_called()
        self.assert_no_writes()

    def test_ipv6_client_is_exact_address_and_local_invocation_is_supported(self):
        with patch.dict(os.environ, {'SSH_CONNECTION': '2001:db8::10 55555 2001:db8::20 22'}):
            text = host._jail_text([22])
        self.assertIn('ignoreip = 127.0.0.1/8 ::1 2001:db8::10\n', text)
        with patch.dict(os.environ, {'SSH_CONNECTION': ''}):
            self.assertIn('ignoreip = 127.0.0.1/8 ::1\n', host._jail_text([22]))

    def test_keyboard_interrupt_also_rolls_back_policy(self):
        def interrupt(args):
            if args == ['apt-get', 'update']:
                raise KeyboardInterrupt()
        self.failure = interrupt
        with self.assertRaises(KeyboardInterrupt):
            self.ensure()
        self.assertFalse(host._path(host.POLICY_FILE).exists())


if __name__ == '__main__':
    unittest.main()
