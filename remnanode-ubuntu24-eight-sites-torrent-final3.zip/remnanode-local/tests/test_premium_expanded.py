"""Expanded renderer contracts, frozen legacy bytes and local-only integration."""
import copy
import functools
import hashlib
from html.parser import HTMLParser
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
import json
from pathlib import Path, PurePosixPath
import re
import subprocess
import sys
import tempfile
import threading
import unittest
from unittest import mock
from urllib.parse import unquote, urljoin, urlsplit
from urllib.request import urlopen

import command_runtime
import premium_expanded as expanded
import premium_site as premium

PROJECT = Path(__file__).resolve().parents[1]


class Document(HTMLParser):
    def __init__(self, data):
        super().__init__(convert_charrefs=True)
        self.links = []
        self.ids = set()
        self.tags = []
        self.text = []
        self.feed(data.decode('utf-8'))
        self.close()

    def handle_starttag(self, tag, attrs):
        attrs = dict(attrs)
        self.tags.append((tag, attrs))
        if 'id' in attrs:
            if attrs['id'] in self.ids:
                raise AssertionError('Duplicate id: ' + attrs['id'])
            self.ids.add(attrs['id'])
        for key in ('src', 'href'):
            if key in attrs:
                self.links.append(attrs[key])

    def handle_data(self, value):
        self.text.append(value)


class QuietHandler(SimpleHTTPRequestHandler):
    def log_message(self, *args):
        pass


def manifest(template, number=0):
    return {'schema': 1, 'version': 'premium-v1', 'template': template, 'seed': f'{number:064x}'}


def mock_assets(template):
    """A local contract fixture, never published or substituted for designer assets."""
    assets = {name: (premium.ASSET_ROOT / name).read_bytes() for name in (
        'fonts.css', 'Manrope.ttf', 'CormorantGaramond.ttf', 'CormorantGaramond-Italic.ttf',
        'Manrope-OFL.txt', 'CormorantGaramond-OFL.txt')}
    articles = []
    for number in range(5):
        articles.append({
            'id': f'{template}-story-{number}', 'theme': template, 'category': 'Наблюдения',
            'title': f'История {number}', 'subtitle': 'Внимательный взгляд на повседневность.',
            'image': f'{template}-photo.jpg', 'alt': 'Локальная иллюстрация', 'time': '5 минут',
            'caption': 'Иллюстрация к истории.', 'quote': 'Сначала наблюдать, затем делать выводы.',
            'note': 'На полях', 'noteText': 'Проверьте источники и условия использования.',
            'sections': [[f'Раздел {i}', 'Подробный текст наблюдения. ' * 20] for i in range(5)],
        })
    assets[template + '-editorial.json'] = json.dumps(articles, ensure_ascii=False).encode()
    assets[template + '.html'] = (b'<section><h1>@@TITLE@@</h1><a href="@@FEATURED_HREF@@">'
                                  b'@@FEATURED_TITLE@@</a>@@STORIES@@</section>')
    assets[template + '.css'] = f'body.theme-{template}{{background-image:var(--hero-image)}}'.encode()
    assets[template + '.js'] = b'"use strict";\n'
    assets[template + '-SOURCES.txt'] = b'Local test fixture only.\n'
    assets[template + '-photo.jpg'] = b'\xff\xd8fixture'
    return assets


class FrozenOriginalTests(unittest.TestCase):
    def test_original_six_manifests_match_every_frozen_file_hash(self):
        fixture = json.loads((PROJECT / 'tests/fixtures/premium-original-output-sha256.json').read_text())
        self.assertEqual(len(fixture), 6)
        for case, expected_hashes in fixture.items():
            template, seed = case.split(':')
            with self.subTest(template=template, seed=seed):
                files = premium.expected_files(dict(manifest(template), seed=seed))
                self.assertEqual({name: hashlib.sha256(data).hexdigest()
                                  for name, data in files.items()}, expected_hashes)

    def test_expanded_templates_append_without_changing_old_manifest_version(self):
        self.assertEqual(premium.TEMPLATES, ('north', 'still', 'ritual', *expanded.TEMPLATES))
        self.assertEqual(premium.VERSION, 'premium-v1')
        for template in expanded.TEMPLATES:
            self.assertTrue(premium.THEMES[template]['names'])
            self.assertEqual(premium.new_manifest(template)['template'], template)


class ExpandedContractTests(unittest.TestCase):
    def render(self, template, number=0, assets=None):
        with mock.patch.object(premium, '_read_assets', return_value=assets or mock_assets(template)):
            return premium.expected_files(manifest(template, number))

    def assert_site(self, template, files):
        self.assertLess(sum(map(len, files.values())), premium.MAX_BYTES)
        pages = {name: Document(data) for name, data in files.items() if name.endswith('.html')}
        articles = {name for name in pages if name.startswith('article-')}
        self.assertEqual(len(pages), 8)
        self.assertEqual(len(articles), 5)
        for name in ('index.html', 'notes.html'):
            self.assertTrue(articles.issubset(set(pages[name].links)), name)
        for name, page in pages.items():
            self.assertEqual(sum(tag == 'h1' for tag, _ in page.tags), 1, name)
            self.assertEqual(sum(tag == 'main' for tag, _ in page.tags), 1, name)
            self.assertTrue(any(tag == 'details' and attrs.get('class') == 'menu'
                                for tag, attrs in page.tags))
            self.assertIn(f'theme-{template}', files[name].decode())
            self.assertNotIn('@@', files[name].decode())
            # Progressive controls may start hidden until their script is ready;
            # editorial content itself must remain visible without JavaScript.
            for tag, attrs in page.tags:
                if 'hidden' in attrs:
                    self.assertNotIn(tag, ('main', 'article', 'section'))
                    self.assertFalse(set(attrs.get('class', '').split()) & {
                        'new-reader', 'new-reader-copy', 'new-stories', 'new-card'})
            scripts = [attrs for tag, attrs in page.tags if tag == 'script']
            self.assertEqual(scripts, [{'src': f'assets/{template}.js', 'defer': None}])
            for value in page.links:
                parsed = urlsplit(value)
                self.assertFalse(parsed.scheme or parsed.netloc, (name, value))
                self.assertFalse(parsed.path.startswith('/'), (name, value))
                target = unquote(parsed.path) or name
                self.assertIn(target, files, (name, value))
                if parsed.fragment:
                    self.assertIn(parsed.fragment, pages[target].ids, (name, value))
            if name in articles:
                self.assertEqual(sum(tag == 'section' for tag, _ in page.tags), 5)
                self.assertGreater(len(''.join(page.text)), 1500)
                self.assertTrue(any(value in articles - {name} for value in page.links))
        for name, data in files.items():
            if not name.endswith('.css'):
                continue
            for value in re.findall(r'url\([\s\'\"]*([^\)\'\"\s]+)', data.decode()):
                parsed = urlsplit(value)
                self.assertFalse(parsed.scheme or parsed.netloc)
                self.assertFalse(parsed.path.startswith('/'))
                target = (PurePosixPath(name).parent / unquote(parsed.path)).as_posix()
                self.assertIn(target, files, (name, value))
        self.assertNotIn('manifest.json', files)
        self.assertNotIn(manifest(template)['seed'], b''.join(files.values()).decode('latin1'))

    def test_all_five_contracts_deterministic_eight_pages_and_local_links(self):
        for template in expanded.TEMPLATES:
            with self.subTest(template=template):
                files = self.render(template)
                self.assertEqual(files, self.render(template))
                self.assert_site(template, files)

    def test_title_crop_order_and_layout_variations_preserve_authored_palette(self):
        for template in expanded.TEMPLATES:
            with self.subTest(template=template):
                files = [self.render(template, number) for number in range(12)]
                self.assertGreater(len({f['assets/variant.css'] for f in files}), 1)
                for item in files:
                    self.assertNotIn(b'--paper:', item['assets/variant.css'])
                    self.assertNotIn(b'--accent:', item['assets/variant.css'])
                self.assertGreater(len({re.search(rb'layout-([01])', f['index.html']).group(1)
                                        for f in files}), 1)
                self.assertGreater(len({tuple(re.findall(rb'href="(article-[^"]+)"', f['notes.html']))
                                        for f in files}), 3)
                self.assertGreater(len({re.search(rb'<title>(.*?)</title>', f['index.html']).group(1)
                                        for f in files}), 1)

    def test_editorial_and_title_escaped_without_mutating_input(self):
        assets = mock_assets('index')
        articles = json.loads(assets['index-editorial.json'])
        articles[0]['title'] = '<script>alert("x")</script> & title'
        assets['index-editorial.json'] = json.dumps(articles).encode()
        original = copy.deepcopy(assets)
        with mock.patch.dict(premium.THEMES['index'], names=('TYPE & <NOTES>',)):
            files = self.render('index', assets=assets)
        self.assertEqual(assets, original)
        self.assertIn(b'TYPE &amp; &lt;NOTES&gt;', files['index.html'])
        self.assertIn(b'&lt;script&gt;', files['article-index-story-0.html'])
        self.assertNotIn(b'<script>alert', b''.join(files.values()))

    def test_title_token_optional_navigation_still_has_randomized_title(self):
        assets = mock_assets('index')
        assets['index.html'] = b'<h1>Reading</h1>@@STORIES@@'
        files = self.render('index', assets=assets)
        self.assert_site('index', files)
        self.assertIn(b'class="new-brand"', files['index.html'])

    def test_invalid_editorial_and_unknown_template_token_fail_closed(self):
        for change in ('duplicate', 'path', 'remote-image', 'missing-image', 'sections', 'empty', 'theme'):
            assets = mock_assets('form')
            articles = json.loads(assets['form-editorial.json'])
            if change == 'duplicate':
                articles[1]['id'] = articles[0]['id']
            elif change == 'path':
                articles[0]['id'] = '../escape'
            elif change == 'remote-image':
                articles[0]['image'] = 'https://example.invalid/photo.jpg'
            elif change == 'missing-image':
                articles[0]['image'] = 'form-missing.jpg'
            elif change == 'sections':
                articles[0]['sections'] = [['One', 'Only']]
            elif change == 'empty':
                articles[0]['title'] = ''
            elif change == 'theme':
                articles[0]['theme'] = 'north'
            assets['form-editorial.json'] = json.dumps(articles).encode()
            with self.subTest(change=change), self.assertRaises(ValueError):
                self.render('form', assets=assets)
        for fragment in (b'<h1>@@TITLE@@</h1>', b'@@TITLE@@@@STORIES@@@@UNKNOWN@@'):
            assets = mock_assets('form')
            assets['form.html'] = fragment
            with self.assertRaises(ValueError):
                self.render('form', assets=assets)

    def test_exact_validation_rejects_theme_script_tampering_and_general_import_is_js_free(self):
        for template in expanded.TEMPLATES:
            with self.subTest(template=template), tempfile.TemporaryDirectory() as directory:
                root = Path(directory)
                assets = mock_assets(template)
                with mock.patch.object(premium, '_read_assets', return_value=assets):
                    source = premium.generate(manifest(template), root / 'source')
                    copied = premium.copy_generated(source, root / 'copy', manifest(template))
                    self.assertTrue((copied / 'index.html').is_file())
                    with self.assertRaises(premium.SiteError):
                        premium.site_tool.validate(source)
                    script = source / f'assets/{template}.js'
                    data = script.read_bytes()
                    script.write_bytes(bytes([data[0] ^ 1]) + data[1:])
                    with self.assertRaises(premium.SiteError):
                        premium.copy_generated(source, root / 'rejected', manifest(template))
                    self.assertFalse((root / 'rejected').exists())

    def test_reduced_motion_and_reader_theme_overrides_are_new_only(self):
        self.assertIn('prefers-reduced-motion:reduce', expanded.BASE_CSS)
        self.assertIn('animation:none!important', expanded.BASE_CSS)
        self.assertIn('transition:none!important', expanded.BASE_CSS)
        for template in expanded.TEMPLATES:
            self.assertIn(f'body.theme-{template} .new-reader', expanded.BASE_CSS)
        self.assertNotIn('body.north', expanded.BASE_CSS)
        self.assertNotIn('monospace', expanded.BASE_CSS)
        self.assertNotRegex(expanded.BASE_CSS, r'border(?:-(?:top|bottom|left|right))?\s*:')
        self.assertNotIn('text-transform:uppercase', expanded.BASE_CSS)
        files = self.render('index')
        self.assertNotIn(b'new-eyebrow', files['notes.html'])
        for name, data in files.items():
            if name.startswith('article-'):
                self.assertNotIn(b'new-chapter-number', data)


class ExpandedInstalledAssetsTests(ExpandedContractTests):
    """Real assets must be available: missing designer work is a visible blocker."""
    def render(self, template, number=0, assets=None):
        if assets is not None:
            return super().render(template, number, assets)
        return premium.expected_files(manifest(template, number))

    def test_explicit_runtime_assets_modules_and_aggregate_limit(self):
        self.assertIn('premium_expanded.py', command_runtime.MODULES)
        self.assertEqual(tuple(command_runtime.ASSET_FILES), tuple(premium.ASSET_FILES))
        self.assertEqual(set(premium.ASSET_FILES), {path.name for path in premium.ASSET_ROOT.iterdir()})
        self.assertEqual(len(premium.ASSET_FILES), len(set(premium.ASSET_FILES)))
        self.assertLessEqual(sum((premium.ASSET_ROOT / name).stat().st_size
                                 for name in premium.ASSET_FILES), premium.MAX_BYTES)
        for template in expanded.TEMPLATES:
            self.assertIn(template + '-editorial.json', premium.ASSET_FILES)
            self.assert_site(template, self.render(template))

    def test_root_and_nested_http_every_generated_local_resource(self):
        for template in expanded.TEMPLATES:
            with self.subTest(template=template), tempfile.TemporaryDirectory() as directory:
                root = Path(directory)
                files = self.render(template)
                for base in (root, root / 'nested' / 'publication'):
                    base.mkdir(parents=True, exist_ok=True)
                    for name, data in files.items():
                        target = base / name
                        target.parent.mkdir(parents=True, exist_ok=True)
                        target.write_bytes(data)
                handler = functools.partial(QuietHandler, directory=str(root))
                server = ThreadingHTTPServer(('127.0.0.1', 0), handler)
                thread = threading.Thread(target=server.serve_forever, daemon=True)
                thread.start()
                try:
                    for prefix in ('', 'nested/publication/'):
                        base = f'http://127.0.0.1:{server.server_port}/' + prefix
                        requests = {urljoin(base, name): data for name, data in files.items()}
                        for name, data in files.items():
                            if name.endswith('.html'):
                                for value in Document(data).links:
                                    parsed = urlsplit(value)
                                    target = unquote(parsed.path) or name
                                    requests[urljoin(urljoin(base, name), value).split('#')[0]] = files[target]
                        for url, expected in requests.items():
                            with urlopen(url, timeout=5) as response:
                                self.assertEqual(response.status, 200)
                                self.assertEqual(response.read(), expected)
                finally:
                    server.shutdown()
                    server.server_close()
                    thread.join(timeout=5)

    def test_css_background_urls_resolve_from_each_consumer_at_root_and_nested(self):
        pattern = r'url\([\s\'\"]*([^\)\'\"\s]+)'
        for template in expanded.TEMPLATES:
            files = self.render(template)
            variables = dict(re.findall(r'(--(?:hero|pause)-image):([^;}]+)',
                                        files['assets/variant.css'].decode()))
            self.assertEqual(set(variables), {'--hero-image', '--pause-image'})
            for base in ('http://127.0.0.1/', 'http://127.0.0.1/nested/publication/'):
                for name, data in files.items():
                    if not name.endswith('.css'):
                        continue
                    css = data.decode()
                    referenced = re.findall(r'var\((--(?:hero|pause)-image)\)', css)
                    values = [*re.findall(pattern, css), *(
                        value for variable in referenced for value in re.findall(pattern, variables[variable]))]
                    for value in values:
                        resolved = urljoin(urljoin(base, name), value)
                        self.assertTrue(resolved.startswith(base), (name, value, base))
                        target = unquote(resolved[len(base):])
                        self.assertIn(target, files, (name, value, base))

    def test_real_generate_copy_and_theme_script_tampering_all_five(self):
        for template in expanded.TEMPLATES:
            with self.subTest(template=template), tempfile.TemporaryDirectory() as directory:
                root = Path(directory)
                source = premium.generate(manifest(template), root / 'source')
                expected = self.render(template)
                copied = premium.copy_generated(source, root / 'copy', manifest(template))
                self.assertEqual({path.relative_to(copied).as_posix(): path.read_bytes()
                                  for path in copied.rglob('*') if path.is_file()}, expected)
                with self.assertRaises(premium.SiteError):
                    premium.site_tool.validate(source)
                script = source / f'assets/{template}.js'
                data = script.read_bytes()
                script.write_bytes(bytes([data[0] ^ 1]) + data[1:])
                with self.assertRaises(premium.SiteError):
                    premium.copy_generated(source, root / 'rejected', manifest(template))
                self.assertFalse((root / 'rejected').exists())
                script.write_bytes(data)
                (source / 'assets/extra.js').write_bytes(b'"use strict";')
                with self.assertRaises(premium.SiteError):
                    premium.copy_generated(source, root / 'extra-rejected', manifest(template))
                self.assertFalse((root / 'extra-rejected').exists())

    def test_isolated_explicit_runtime_generates_all_five_without_source_path(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            for name in command_runtime.MODULES:
                (root / name).write_bytes((PROJECT / name).read_bytes())
            (root / 'premium_assets').mkdir()
            for name in command_runtime.ASSET_FILES:
                (root / 'premium_assets' / name).write_bytes((premium.ASSET_ROOT / name).read_bytes())
            script = ('import sys; sys.path.insert(0,sys.argv[1]); import premium_site as p; '
                      'assert p.__file__.startswith(sys.argv[1]); '
                      '[(lambda f: (len([n for n in f if n.endswith(".html")]) == 8) or '
                      '(_ for _ in ()).throw(AssertionError(t)))(p.expected_files('
                      '{"schema":1,"version":"premium-v1","template":t,"seed":"0"*64})) '
                      'for t in ("index","form","afterlight","common","orbit")]')
            result = subprocess.run([sys.executable, '-I', '-c', script, str(root)],
                                    capture_output=True, text=True, timeout=30)
            self.assertEqual(result.returncode, 0, result.stdout + result.stderr)


if __name__ == '__main__':
    unittest.main()
