"""Pure latest-release parsing; no network or package-manager execution."""
import hashlib
import json
import unittest

import torrent_release as r


class ReleaseTests(unittest.TestCase):
    def setUp(self):
        self.data = b'!<arch>\n' + b'package-fixture'
        self.sha = hashlib.sha256(self.data).hexdigest()
        self.name = 'tblocker_4.5.6_linux_amd64.deb'
        self.meta = {'draft': False, 'prerelease': False, 'tag_name': 'v4.5.6', 'assets': [
            {'name': self.name, 'size': len(self.data), 'digest': 'sha256:' + self.sha,
             'browser_download_url': r.PREFIX + 'v4.5.6/' + self.name},
            {'name': 'checksums.txt', 'browser_download_url': r.PREFIX + 'v4.5.6/checksums.txt'}]}

    def selected(self):
        return r.select_release(json.dumps(self.meta).encode(), 'amd64')

    def test_latest_metadata_is_not_pinned_to_current_version(self):
        result = self.selected()
        self.assertEqual(result['version'], '4.5.6')
        digest = r.package_digest((self.sha + '  ' + self.name + '\n').encode(), result)
        r.verify_package(self.data, result, digest)

    def test_checksum_supported_when_api_digest_missing(self):
        self.meta['assets'][0].pop('digest')
        result = self.selected()
        self.assertEqual(r.package_digest((self.sha + ' *' + self.name).encode(), result), self.sha)

    def test_reject_external_asset_and_unsupported_architecture(self):
        self.meta['assets'][0]['browser_download_url'] = 'https://other.test/file.deb'
        with self.assertRaises(ValueError): self.selected()
        with self.assertRaises(ValueError): r.select_release(b'{}', 'i386')

    def test_reject_duplicate_or_missing_checksum_and_mismatched_digest(self):
        result = self.selected()
        for data in (b'', (self.sha + ' ' + self.name + '\n') .encode() * 2,
                     ('0' * 64 + ' ' + self.name).encode()):
            with self.subTest(data=data), self.assertRaises(ValueError):
                r.package_digest(data, result)

    def test_reject_corrupt_package(self):
        result = self.selected()
        with self.assertRaises(ValueError): r.verify_package(self.data + b'1', result, self.sha)
        with self.assertRaises(ValueError): r.verify_package(b'bad-data', result, self.sha)

    def test_reject_unpublished_or_ambiguous_assets(self):
        for change in ('draft', 'prerelease'):
            self.meta[change] = True
            with self.assertRaises(ValueError): self.selected()
            self.meta[change] = False
        self.meta['assets'].append(dict(self.meta['assets'][0]))
        with self.assertRaises(ValueError): self.selected()


if __name__ == '__main__':
    unittest.main()
