"""Optional conservative host features; callers hold manage.lock().

No benchmarks, cleanup, kernel downloads, reboot or network tuning bundles.
Call ensure_fail2ban ONLY after the automatic verified UFW/SSH commit.
Capacity observations warn below 2 GiB and 10,000 free inodes on download
and deployment filesystems; they do not block installation or remove data.
"""
import fnmatch
import hashlib
import ipaddress
import json
import os
from pathlib import Path
import re
import secrets
import shutil
import stat
import sys
import time

import manage as m

ROOT = Path('/')
GIB = 1024 ** 3
CC = 'net.ipv4.tcp_congestion_control'
QDISC = 'net.core.default_qdisc'
MODULE_FILE = '/etc/modules-load.d/90-remnanode-bbr.conf'
SYSCTL_FILE = '/etc/sysctl.d/99-zz-remnanode-bbr.conf'
JAIL_FILE = '/etc/fail2ban/jail.d/remnanode-sshd.local'
POLICY_FILE = '/usr/sbin/policy-rc.d'
MODULE_TEXT = '# Managed by remnanode host_features\ntcp_bbr\n'
SYSCTL_TEXT = '# Managed by remnanode host_features\n' + CC + ' = bbr\n'
ENV = {**os.environ, 'LC_ALL': 'C', 'LANG': 'C'}


def _path(name):
    return ROOT / name.lstrip('/')


def _root():
    if sys.platform != 'linux' or not hasattr(os, 'geteuid') or os.geteuid() != 0:
        raise m.Failure('Изменения host features требуют root на Linux.')


def _read(path):
    # Ubuntu's standard compatibility link points back to /etc/sysctl.conf.
    # No writable path follows links; this exception is strictly read-only.
    path = Path(path)
    if (path == _path('/etc/sysctl.d/99-sysctl.conf') and path.is_symlink() and
            path.resolve() == _path('/etc/sysctl.conf').resolve()):
        m.secure_path(path.parent, directory=True)
        path = path.resolve()
    path = m.secure_path(path, directory=False)
    with path.open('r', encoding='utf-8') as stream:
        text = stream.read(65537)
    if len(text) > 65536:
        raise m.Failure('Слишком большой системный конфиг; требуется ручная проверка.')
    return text


def _query(args):
    text = m.run(args, capture=True, timeout=10, env=ENV).strip()
    if len(text) > 65536:
        raise m.Failure('Слишком большой ответ диагностической команды.')
    return text


def _disk_snapshot():
    result = []
    for name in ('/', '/var/lib/docker', '/var/cache/apt/archives', '/opt'):
        path = _path(name)
        while not path.exists() and path != path.parent:
            path = path.parent
        usage = shutil.disk_usage(path)
        vfs = os.statvfs(path) if hasattr(os, 'statvfs') else None
        result.append({'path': name, 'filesystem_path': str(path),
                       'free_bytes': usage.free, 'total_bytes': usage.total,
                       'free_inodes': vfs.f_favail if vfs and vfs.f_files else None})
    return result


def preflight_capacity(min_free_bytes=2 * GIB):
    """Read-only capacity warnings; never prevent installation due to low space.

    A zero-inode-count filesystem has no meaningful inode limit. Unsupported
    statvfs is reported as unknown (e.g. portable local tests), never fabricated.
    """
    if type(min_free_bytes) is not int or min_free_bytes < GIB:
        raise m.Failure('Минимальный запас диска должен быть не меньше 1 GiB.')
    try:
        disks = _disk_snapshot()
    except OSError as exc:
        raise m.Failure('Не удалось проверить свободное место; загрузки не начаты.') from exc
    for disk in disks:
        if disk['free_bytes'] < min_free_bytes:
            print('[ПРЕДУПРЕЖДЕНИЕ] На ' + disk['path'] + ' свободно ' +
                  str(disk['free_bytes'] // (1024 ** 2)) +
                  ' MiB. Установка продолжается; при заполнении диска возможен сбой. '
                  'Автоматическая очистка не выполняется.', flush=True)
        if disk['free_inodes'] is not None and disk['free_inodes'] < 10000:
            print('[ПРЕДУПРЕЖДЕНИЕ] Мало свободных inode на ' + disk['path'] +
                  '. Установка продолжается без удаления данных.', flush=True)
    return disks


def inspect_performance():
    """Bounded read-only observations, not a claim of measured throughput."""
    result = {'errors': []}
    commands = {'kernel': ['uname', '-r'], 'cpu_count': ['nproc'],
                'virtualization': ['systemd-detect-virt'], 'memory': ['free', '-b'],
                'congestion_control': ['sysctl', '-n', CC],
                'default_qdisc': ['sysctl', '-n', QDISC],
                'available_congestion_controls': ['sysctl', '-n', 'net.ipv4.tcp_available_congestion_control'],
                'qdiscs': ['tc', '-j', 'qdisc', 'show'],
                'bbr_module': ['modinfo', '-F', 'filename', 'tcp_bbr']}
    for key, args in commands.items():
        try:
            text = _query(args)
            result[key] = json.loads(text) if key == 'qdiscs' else text[:65536]
        except (m.Failure, ValueError, OSError):
            result[key] = None
            result['errors'].append(key + ': недоступно')
    try:
        result['disk'] = _disk_snapshot()
    except OSError:
        result['disk'] = []
        result['errors'].append('disk: недоступно')
    return result


# The private standalone recovery script does not import the installer. It uses
# the same compare-before-delete policy as in-process rollback. No module unload.
ROLLBACK_SCRIPT = '''#!/usr/bin/python3
import fcntl, json, os, pathlib, stat, subprocess, tempfile
if os.geteuid() != 0:
    raise RuntimeError('Recovery requires root')
base = pathlib.Path(__file__).resolve().parent
def safe(path):
    path = pathlib.Path(path)
    for part in [*reversed(path.parents), path]:
        if not part.exists() and not part.is_symlink():
            continue
        info = part.lstat()
        if stat.S_ISLNK(info.st_mode) or info.st_uid != 0 or info.st_mode & 0o022:
            raise RuntimeError('Unsafe recovery path')
    return path
def command(args):
    return subprocess.run(args, capture_output=True, text=True, timeout=30, check=True)
def owned(item):
    path = safe(item['path'])
    return (path.is_file() and path.stat().st_nlink == 1 and
            [path.stat().st_dev, path.stat().st_ino] == item['identity'] and
            path.read_text(encoding='utf-8') == item['text'])
safe(base)
lock = safe('/run/remnanode-local.lock')
fd = os.open(lock, os.O_CREAT | os.O_RDWR | os.O_NOFOLLOW, 0o600)
info = os.fstat(fd)
if info.st_uid != 0 or info.st_nlink != 1 or not stat.S_ISREG(info.st_mode):
    raise RuntimeError('Unsafe recovery lock')
fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
state_path = safe(base / 'state.json')
if state_path.stat().st_mode & 0o077:
    raise RuntimeError('Recovery journal must be private')
state = json.loads(state_path.read_text())
def save():
    fd, name = tempfile.mkstemp(prefix='.rollback-', dir=base)
    try:
        with os.fdopen(fd, 'w') as stream:
            json.dump(state, stream)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(name, state_path)
    finally:
        if os.path.exists(name):
            os.unlink(name)
if state.get('service_started'):
    if not all(owned(i) for i in state['files']):
        raise RuntimeError('Service configuration changed; manual rollback required')
    command(['/usr/bin/systemctl', 'stop', 'fail2ban'])
    command(['/usr/bin/systemctl', 'disable', 'fail2ban'])
    state['service_started'] = False
    save()
if state.get('package_enable_pending'):
    active = subprocess.run(['/usr/bin/systemctl', 'is-active', 'fail2ban'], capture_output=True, text=True, timeout=10)
    if active.stdout.strip() not in ('inactive', 'unknown') or active.returncode not in (3, 4):
        raise RuntimeError('Unexpected Fail2ban activation; manual recovery required')
    enabled = subprocess.run(['/usr/bin/systemctl', 'is-enabled', 'fail2ban'], capture_output=True, text=True, timeout=10)
    if enabled.stdout.strip() == 'enabled' and enabled.returncode == 0:
        command(['/usr/bin/systemctl', 'disable', 'fail2ban'])
    elif enabled.stdout.strip() not in ('disabled', 'not-found'):
        raise RuntimeError('Unknown Fail2ban enablement state')
    state['package_enable_pending'] = False
    save()
if state.get('cc_changed'):
    current = command(['/usr/sbin/sysctl', '-n', 'net.ipv4.tcp_congestion_control']).stdout.strip()
    if current == 'bbr':
        command(['/usr/sbin/sysctl', '-w', 'net.ipv4.tcp_congestion_control=' + state['old_cc']])
    state['cc_changed'] = False
    save()
for item in list(reversed(state['files'])):
    if owned(item):
        safe(item['path']).unlink()
    state['files'].remove(item)
    save()
'''


class FeatureChange:
    """An invocation's changes only; skipped/idempotent results roll back nothing."""
    def __init__(self, status, *, backup=None):
        self.status = status
        self.backup = backup
        self._state = {'files': [], 'cc_changed': False, 'service_started': False,
                       'package_enable_pending': False}
        self._done = False

    def _save(self):
        if self.backup is not None:
            m.write_json(self.backup / 'state.json', self._state)

    def _new_file(self, path, text, mode=0o644):
        path = m.secure_path(path, directory=False)
        m.secure_path(path.parent, directory=True)
        path.parent.mkdir(mode=0o755, parents=True, exist_ok=True)
        flags = os.O_WRONLY | os.O_CREAT | os.O_EXCL | getattr(os, 'O_NOFOLLOW', 0)
        fd = os.open(path, flags, mode)
        info = os.fstat(fd)
        item = {'path': str(path), 'text': text, 'identity': [info.st_dev, info.st_ino]}
        self._state['files'].append(item)
        try:
            with os.fdopen(fd, 'w', encoding='utf-8', newline='\n') as stream:
                stream.write(text)
                stream.flush()
                os.fsync(stream.fileno())
            os.chmod(path, mode)
            self._save()
        except BaseException:
            # A partial write is still ours; do not leave a truncated policy/jail.
            current = path.lstat()
            if [current.st_dev, current.st_ino] == item['identity']:
                path.unlink()
            self._state['files'].remove(item)
            raise
        return item

    def _owned(self, item):
        path = m.secure_path(item['path'], directory=False)
        return (path.is_file() and [path.stat().st_dev, path.stat().st_ino] == item['identity']
                and _read(path) == item['text'])

    def rollback(self):
        if self._done:
            return
        if self._state['service_started']:
            # Do not stop a service now using a concurrently edited config.
            if not all(self._owned(item) for item in self._state['files']):
                raise m.Failure('Конфигурация Fail2ban изменилась; нужен ручной откат: ' + str(self.backup))
            m.run(['systemctl', 'stop', 'fail2ban'], timeout=30, env=ENV)
            m.run(['systemctl', 'disable', 'fail2ban'], timeout=30, env=ENV)
            self._state['service_started'] = False
            self._save()
        if self._state['package_enable_pending']:
            active = m.run(['systemctl', 'is-active', 'fail2ban'], check=False, timeout=10, env=ENV)
            if active.stdout.strip() not in ('inactive', 'unknown') or active.returncode not in (3, 4):
                raise m.Failure('Fail2ban неожиданно активен; состояние сохранено для ручного отката.')
            enabled = m.run(['systemctl', 'is-enabled', 'fail2ban'], check=False, timeout=10, env=ENV)
            if enabled.stdout.strip() == 'enabled' and enabled.returncode == 0:
                m.run(['systemctl', 'disable', 'fail2ban'], timeout=30, env=ENV)
            elif enabled.stdout.strip() not in ('disabled', 'not-found'):
                raise m.Failure('Неизвестное автозапуск-состояние Fail2ban; нужен ручной откат.')
            self._state['package_enable_pending'] = False
            self._save()
        if self._state['cc_changed']:
            if _query(['sysctl', '-n', CC]) == 'bbr':
                m.run(['sysctl', '-w', CC + '=' + self._state['old_cc']], timeout=10, env=ENV)
            self._state['cc_changed'] = False
            self._save()
        for item in list(reversed(self._state['files'])):
            if self._owned(item):
                Path(item['path']).unlink()
            self._state['files'].remove(item)
            self._save()
        self._done = True


def _change(label):
    folder = m.secure_path(m.backup_dir(label), directory=True)
    os.chmod(folder, 0o700)
    change = FeatureChange('', backup=folder)
    change._save()
    m.atomic_write(folder / 'rollback.py', ROLLBACK_SCRIPT, mode=0o700)
    return change


def _failed(change, feature, exc, *, redact=False):
    try:
        change.rollback()
    except BaseException as rollback_error:
        if redact and isinstance(rollback_error, (KeyboardInterrupt, SystemExit)):
            raise
        if redact and isinstance(exc, (KeyboardInterrupt, SystemExit)):
            print(feature + ': откат не подтверждён; нужна ручная проверка. Копия: ' +
                  str(change.backup), flush=True)
            raise exc from None
        raise m.Failure(feature + ': ошибка применения и отката; нужна ручная проверка. Копия: ' +
                        str(change.backup)) from (None if redact else rollback_error)
    if isinstance(exc, (KeyboardInterrupt, SystemExit)):
        raise exc
    raise m.Failure(feature + ': применение не подтверждено; собственные изменения отменены. Копия: ' +
                    str(change.backup)) from (None if redact else exc)


def _config_files(directories, suffix):
    files = []
    for name in directories:
        directory = _path(name)
        # /lib is a root-owned compatibility link on Ubuntu's merged /usr.
        # Resolve only this known read-only alias, never installation targets.
        if name.startswith('/lib/') and _path('/lib').is_symlink():
            m.secure_path(_path('/lib').parent, directory=True)
            if _path('/lib').resolve() != _path('/usr/lib').resolve():
                raise m.Failure('Неизвестный системный alias /lib.')
            directory = directory.resolve()
        directory = m.secure_path(directory, directory=True)
        if directory.exists():
            files.extend(directory.glob('*' + suffix))
    if len(files) > 512:
        raise m.Failure('Слишком много конфигов; требуется ручная проверка.')
    return files


def _bbr_conflict():
    files = _config_files(('/etc/sysctl.d', '/run/sysctl.d', '/usr/local/lib/sysctl.d',
                           '/usr/lib/sysctl.d', '/lib/sysctl.d'), '.conf')
    if _path('/etc/sysctl.conf').exists():
        files.append(_path('/etc/sysctl.conf'))
    for path in files:
        if path == _path(SYSCTL_FILE):
            continue
        for line in _read(path).splitlines():
            line = line.split('#', 1)[0].split(';', 1)[0].strip().lstrip('-')
            key = line.split('=', 1)[0].strip().replace('/', '.')
            if any(fnmatch.fnmatchcase(setting, key) for setting in (CC, QDISC)):
                return 'найден внешний sysctl-конфиг; перезапись запрещена'
    files = _config_files(('/etc/modules-load.d', '/run/modules-load.d', '/usr/lib/modules-load.d'), '.conf')
    if _path('/etc/modules').exists():
        files.append(_path('/etc/modules'))
    for path in files:
        if path != _path(MODULE_FILE) and any(
                line.split('#', 1)[0].strip() == 'tcp_bbr' for line in _read(path).splitlines()):
            return 'найдена внешняя настройка модуля BBR'
    return None


def configure_bbr():
    """Only set TCP congestion control; never change default/actual qdisc."""
    _root()
    try:
        old = _query(['sysctl', '-n', CC])
        default = _query(['sysctl', '-n', QDISC])
        actual = json.loads(_query(['tc', '-j', 'qdisc', 'show']))
        module = _query(['modinfo', '-F', 'filename', 'tcp_bbr'])
        if not re.fullmatch(r'[a-z0-9_]+', old) or default not in ('fq', 'fq_codel'):
            return FeatureChange('BBR пропущен: неизвестный congestion control или default qdisc (нужен fq/fq_codel).')
        if (not isinstance(actual, list) or not actual or not all(
                isinstance(row, dict) and row.get('kind') in ('fq', 'fq_codel', 'mq', 'noqueue')
                for row in actual)):
            return FeatureChange('BBR пропущен: фактический tc qdisc неизвестен; не изменён.')
        if not module:
            return FeatureChange('BBR пропущен: модуль ядра недоступен.')
        conflict = _bbr_conflict()
        if conflict:
            return FeatureChange('BBR пропущен: ' + conflict + '.')
        targets = ((_path(MODULE_FILE), MODULE_TEXT), (_path(SYSCTL_FILE), SYSCTL_TEXT))
        for path, text in targets:
            m.secure_path(path, directory=False)
            if path.exists() and _read(path) != text:
                return FeatureChange('BBR пропущен: существующий целевой конфиг не принадлежит установщику.')
        if old == 'bbr':
            if all(path.exists() for path, text in targets):
                return FeatureChange('BBR уже включён; собственная persistence подтверждена, изменений нет.')
            return FeatureChange('BBR уже включён извне; persistence не изменена.')
    except (m.Failure, OSError, ValueError):
        return FeatureChange('BBR пропущен: поддержка ядра, qdisc или безопасное чтение конфигов не подтверждены.')
    change = _change('bbr')
    change._state['old_cc'] = old
    change._state['old_default_qdisc'] = default
    change._state['old_actual_qdiscs'] = actual
    change._save()
    try:
        m.run(['modprobe', 'tcp_bbr'], timeout=15, env=ENV)
        for path, text in targets:
            if not path.exists():
                change._new_file(path, text)
        # Journal before the command: sysctl can apply yet fail verification.
        change._state['cc_changed'] = True
        change._save()
        m.run(['sysctl', '-w', CC + '=bbr'], timeout=10, env=ENV)
        if _query(['sysctl', '-n', CC]) != 'bbr':
            raise m.Failure('BBR не подтверждён.')
    except BaseException as exc:
        _failed(change, 'BBR', exc)
    change.status = 'BBR включён и проверен; qdisc ' + default + ' сохранён. Откат: ' + str(change.backup / 'rollback.py')
    return change


def _installed(package):
    result = m.run(['dpkg-query', '-W', '-f=${Status}', package], check=False, timeout=10, env=ENV)
    if result.returncode not in (0, 1):
        raise m.Failure('Не удалось безопасно проверить пакет ' + package + '.')
    return result.returncode == 0 and result.stdout.strip() == 'install ok installed'


def _jail_text(ssh_ports):
    ports = list(ssh_ports)
    if not ports or any(type(p) is not int or not 1 <= p <= 65535 for p in ports):
        raise m.Failure('Fail2ban: нужны подтверждённые действительные SSH-порты.')
    ignore = ['127.0.0.1/8', '::1']
    connection = os.environ.get('SSH_CONNECTION')
    if connection:
        try:
            client, client_port, server, server_port = connection.split()
            client = ipaddress.ip_address(client)
            ipaddress.ip_address(server)
            if (not 1 <= int(client_port) <= 65535 or
                    int(server_port) not in ports or client.is_unspecified or client.is_multicast):
                raise ValueError()
        except ValueError as exc:
            raise m.Failure('Fail2ban: SSH_CONNECTION некорректен; изменения запрещены.') from exc
        ignore.append(str(client))  # Exact address, never the client's whole subnet.
    return ('# Managed by remnanode host_features\n[sshd]\nenabled = true\n'
            'backend = systemd\nfilter = sshd\nport = ' + ','.join(map(str, sorted(set(ports)))) +
            '\nbanaction = nftables-multiport\nmaxretry = 5\nfindtime = 10m\nbantime = 1h\n'
            'ignoreip = ' + ' '.join(ignore) + '\n')


# Installation evidence lives outside state.json and survives both rollbacks.
# Root is trusted. This is local reinstall detection, not cryptographic attestation.
F2B_PACKAGE_MARKER = {'version': 1, 'package': 'fail2ban', 'source': 'apt-install'}
F2B_SERVER = '/usr/bin/fail2ban-server'


def _fail2ban_install_identity():
    version = _query(['dpkg-query', '-W', '-f=${Version}', 'fail2ban'])
    if not re.fullmatch(r'[0-9][a-zA-Z0-9.+:~\-]{0,255}', version):
        raise m.Failure('Fail2ban: версия пакета не подтверждена.')
    binary = m.secure_path(_path(F2B_SERVER), directory=False)
    before = binary.stat()
    if not binary.is_file() or before.st_size > 16 * 1024 * 1024:
        raise m.Failure('Fail2ban: identity исполняемого файла не подтверждена.')
    def identity(info):
        return {'dev': info.st_dev, 'ino': info.st_ino, 'size': info.st_size,
                'mtime_ns': info.st_mtime_ns}
    digest = hashlib.sha256(binary.read_bytes()).hexdigest()
    if identity(before) != identity(binary.stat()):
        raise m.Failure('Fail2ban: исполняемый файл изменился при проверке.')
    return {'package_version': version, 'binary': {'path': F2B_SERVER,
            **identity(before), 'sha256': digest}}


def _valid_fail2ban_request(data):
    return (isinstance(data, dict) and
            data.keys() == {'version', 'package', 'source', 'nonce'} and
            type(data['version']) is int and data['version'] == 2 and
            data['package'] == 'fail2ban' and data['source'] == 'apt-install' and
            isinstance(data['nonce'], str) and re.fullmatch(r'[0-9a-f]{64}', data['nonce']) is not None)


def _private_backup_path(path, *, directory=False):
    path = m.secure_path(path, directory=directory)
    info = path.lstat()
    modes = (0o700,) if directory else (0o600,)
    if path.name == 'rollback.py' and not directory:
        modes = (0o600, 0o700)  # Original standalone scripts were executable.
    if (info.st_uid != 0 or stat.S_IMODE(info.st_mode) not in modes or
            (not directory and info.st_nlink != 1)):
        raise m.Failure('Fail2ban: небезопасное свидетельство предыдущей установки.')
    return path


def _fail2ban_rollback_evidence(*, recover_legacy=False):
    """Return matching post-APT receipt, or explicit legacy permission evidence.

    Never execute discovered code. Completed legacy journals cannot distinguish a
    later external reinstall, so they require opt-in and never become receipts.
    """
    base = m.secure_path(m.BACKUPS, directory=True)
    if not base.exists():
        return False
    _private_backup_path(base, directory=True)
    found = False
    for index, folder in enumerate(base.glob('fail2ban-*')):
        if index >= 128:
            return False
        try:
            _private_backup_path(folder, directory=True)
            script = _private_backup_path(folder / 'rollback.py')
            journal = _private_backup_path(folder / 'state.json')
            if _read(script) != ROLLBACK_SCRIPT:
                continue
            state = json.loads(_read(journal))
            expected = {'files': [], 'cc_changed': False, 'service_started': False,
                        'package_enable_pending': False}
            if (not isinstance(state, dict) or state.keys() != expected.keys() or
                    state['files'] != [] or any(type(state[key]) is not bool or state[key]
                                               for key in expected if key != 'files')):
                return False  # An unfinished known transaction needs manual recovery.
            marker = folder / 'package-install.json'
            receipt_path = folder / 'package-receipt.json'
            data = None
            if marker.exists() or marker.is_symlink():
                data = json.loads(_read(_private_backup_path(marker)))
            if _valid_fail2ban_request(data):
                receipt = json.loads(_read(_private_backup_path(receipt_path)))
                expected_receipt = {'version': 1, 'nonce': data['nonce'],
                                    **_fail2ban_install_identity()}
                if (receipt == expected_receipt and type(receipt.get('version')) is int and
                        all(type(receipt.get('binary', {}).get(key)) is int
                            for key in ('dev', 'ino', 'size', 'mtime_ns'))):
                    found = {'legacy': False, 'request': data, 'receipt': receipt}
            elif recover_legacy and (data is None or
                    (data == F2B_PACKAGE_MARKER and type(data.get('version')) is int)):
                # An existing receipt must never fall back to legacy on mismatch.
                if not receipt_path.exists() and not receipt_path.is_symlink() and not found:
                    found = {'legacy': True}
        except (m.Failure, OSError, ValueError, UnicodeError):
            continue
    return found


def _fail2ban_package_baseline():
    """Reject additions/edits, including external .conf, not just *.local.

    Debian conffiles may be absent from md5sums, hence both dpkg sources are used.
    Package ownership alone would accept an administrator's edited defaults.
    """
    # A local unit/drop-in can replace ExecStart or feed an unrelated config even
    # when /etc/fail2ban is pristine. Never start an externally managed unit.
    for base in ('/etc/systemd/system', '/run/systemd/system', '/usr/local/lib/systemd/system'):
        for name in ('fail2ban.service', 'fail2ban.service.d', 'service.d'):
            override = m.secure_path(_path(base) / name)
            if override.exists():
                return False
    hashes = {}
    metadata = _path('/var/lib/dpkg/info/fail2ban.md5sums')
    if metadata.exists() or metadata.is_symlink():
        for line in _read(metadata).splitlines():
            match = re.fullmatch(r'([0-9a-f]{32})  (\S+)', line)
            if not match:
                return False
            digest, name = match.groups()
            if name.startswith('etc/fail2ban/'):
                hashes['/' + name] = digest
    conffiles = _query(['dpkg-query', '-W', '-f=${Conffiles}', 'fail2ban'])
    for line in conffiles.splitlines():
        match = re.fullmatch(r'\s*(/\S+) ([0-9a-f]{32})', line)
        if not match:
            return False
        name, digest = match.groups()
        if name.startswith('/etc/fail2ban/'):
            if name in hashes and hashes[name] != digest:
                return False
            hashes[name] = digest
    if not {'/etc/fail2ban/jail.conf', '/etc/fail2ban/fail2ban.conf'} <= hashes.keys():
        return False
    directory = m.secure_path(_path('/etc/fail2ban'), directory=True)
    seen = set()
    for index, path in enumerate(directory.rglob('*')):
        if index >= 4096:
            return False
        m.secure_path(path)
        if path.is_dir():
            continue
        path = m.secure_path(path, directory=False)
        name = '/' + path.relative_to(ROOT).as_posix()
        if path.suffix == '.local' or name not in hashes:
            return False
        # _read bounds configuration size; hash the original bytes (not newline
        # normalization). System configuration is UTF-8 on supported hosts.
        _read(path)
        if hashlib.md5(path.read_bytes()).hexdigest() != hashes[name]:
            return False
        seen.add(name)
    return seen == hashes.keys()


def _wait_fail2ban(timeout=30):
    """Wait for BOTH the socket and sshd jail within one monotonic budget.

    Only fixed stages are printed; client output may contain configuration data.
    KeyboardInterrupt/SystemExit intentionally propagate to the caller's rollback.
    """
    deadline = time.monotonic() + timeout
    stage = 'ping'

    def probe(args):
        remaining = deadline - time.monotonic()
        if remaining <= 0:
            return False
        try:
            result = m.run(args, check=False, timeout=min(2, remaining), env=ENV)
            return result.returncode == 0 and time.monotonic() <= deadline
        except (m.Failure, OSError):
            return False

    while time.monotonic() < deadline:
        stage = 'ping'
        if probe(['fail2ban-client', 'ping']):
            stage = 'status sshd'
            if probe(['fail2ban-client', 'status', 'sshd']):
                return
        remaining = deadline - time.monotonic()
        if remaining <= 0:
            break
        # is-active is advisory except for the definite failed state.
        try:
            result = m.run(['systemctl', 'is-active', 'fail2ban'], check=False,
                           timeout=min(2, remaining), env=ENV)
        except (m.Failure, OSError):
            result = None
        if result is not None and result.stdout.strip() == 'failed':
            raise m.Failure('Fail2ban: этап готовности service failed.')
        print('Fail2ban: ожидание готовности (' + stage + ').', flush=True)
        remaining = deadline - time.monotonic()
        if remaining > 0:
            time.sleep(min(1, remaining))
    raise m.Failure('Fail2ban: таймаут готовности (' + stage + ').')


def ensure_fail2ban(ssh_ports, *, recover_legacy=False):
    """AFTER automatic verified UFW/SSH commit, install or resume rolled-back APT.

    Return FeatureChange, including a truthful skipped status for unknown/external
    installs. Default resume requires a matching post-APT package/binary receipt,
    completed private journal, known recovery code, inactive/disabled service and
    unmodified package configuration baseline. recover_legacy=True explicitly
    permits old journals without proving current package provenance; it never
    promotes them into automatic-resume receipts. Root remains trusted.
    Retain packages on rollback; never overwrite/reload external configurations.
    """
    _root()
    if type(recover_legacy) is not bool:
        raise m.Failure('Fail2ban: recover_legacy должен быть bool.')
    text = _jail_text(ssh_ports)
    evidence = None
    installed = _installed('fail2ban')
    if installed:
        try:
            evidence = _fail2ban_rollback_evidence(recover_legacy=recover_legacy)
        except (m.Failure, OSError, ValueError, UnicodeError):
            evidence = False
        if not evidence:
            return FeatureChange('Fail2ban пропущен: пакет уже установлен; происхождение и завершённый откат не подтверждены.')
    active = m.run(['systemctl', 'is-active', 'fail2ban'], check=False, timeout=10, env=ENV)
    enabled = m.run(['systemctl', 'is-enabled', 'fail2ban'], check=False, timeout=10, env=ENV)
    if (active.stdout.strip() not in ('inactive', 'unknown') or active.returncode not in (3, 4) or
            enabled.stdout.strip() not in ('disabled', 'not-found') or enabled.returncode == 0):
        return FeatureChange('Fail2ban пропущен: состояние существующей службы неизвестно/активно.')
    jail = m.secure_path(_path(JAIL_FILE), directory=False)
    policy = m.secure_path(_path(POLICY_FILE), directory=False)
    directory = m.secure_path(_path('/etc/fail2ban'), directory=True)
    if installed:
        try:
            baseline = (active.stdout.strip() == 'inactive' and active.returncode == 3 and
                        enabled.stdout.strip() == 'disabled' and enabled.returncode == 1 and
                        not jail.exists() and not policy.exists() and _fail2ban_package_baseline())
            dependencies = baseline and _installed('python3-systemd') and _installed('nftables')
        except (m.Failure, OSError, ValueError, UnicodeError):
            dependencies = False
        if not dependencies:
            return FeatureChange('Fail2ban пропущен: безопасное возобновление не подтверждено; конфиги и служба не изменены.')
    elif policy.exists() or (directory.exists() and any(directory.iterdir())):
        return FeatureChange('Fail2ban пропущен: найдены внешние конфиги или policy-rc.d; они не изменены.')
    if not installed:
        preflight_capacity()
    change = _change('fail2ban')
    stage = 'подготовка пакетов'
    try:
        if installed and not evidence['legacy']:
            # Copy the original successful APT receipt, never mint one on resume.
            m.write_json(change.backup / 'package-install.json', evidence['request'])
            m.write_json(change.backup / 'package-receipt.json', evidence['receipt'])
        if not installed:
            _install_fail2ban_packages(change, policy)
        stage = 'проверка конфигурации'
        # Ubuntu supplies this action; do not guess iptables/nft syntax ourselves.
        action = _path('/etc/fail2ban/action.d/nftables-multiport.conf')
        if not m.secure_path(action, directory=False).is_file():
            raise m.Failure('Пакет не содержит поддерживаемый nftables action.')
        # Do not overwrite a file unexpectedly created by APT or another owner.
        change._new_file(jail, text)
        m.run(['fail2ban-client', '-t'], timeout=30, env=ENV)
        stage = 'запуск службы'
        change._state['service_started'] = True
        change._save()
        m.run(['systemctl', 'enable', '--now', 'fail2ban'], timeout=60, env=ENV)
        stage = 'готовность ping/status sshd'
        _wait_fail2ban()
    except BaseException as exc:
        # Static stage, no exception/client/configuration output in diagnostics.
        print('Fail2ban: применение не подтверждено; этап: ' + stage + '.', flush=True)
        _failed(change, 'Fail2ban (' + stage + ')', exc, redact=True)
    label = ('Fail2ban legacy восстановлено по разрешению; SSH включён и проверен'
             if installed and evidence['legacy'] else 'Fail2ban SSH включён и проверен')
    change.status = label + ' (systemd/nftables); текущий SSH-клиент исключён. Откат: ' + str(change.backup / 'rollback.py')
    return change


def _install_fail2ban_packages(change, policy):
    # Scope suppression to this service, preserving normal package behavior.
    item = change._new_file(policy, '#!/bin/sh\ncase "$1" in\n'
                            '  fail2ban|fail2ban.service) exit 101 ;;\nesac\nexit 0\n', mode=0o755)
    apt_env = {**ENV, 'DEBIAN_FRONTEND': 'noninteractive', 'NEEDRESTART_MODE': 'l'}
    request = {'version': 2, 'package': 'fail2ban', 'source': 'apt-install',
               'nonce': secrets.token_hex(32)}
    m.write_json(change.backup / 'package-install.json', request)
    m.run(['apt-get', 'update'], timeout=600, env=apt_env)
    change._state['package_enable_pending'] = True
    change._save()
    m.run(['apt-get', 'install', '-y', '--no-install-recommends',
           '-o', 'Dpkg::Options::=--force-confdef', '-o', 'Dpkg::Options::=--force-confold',
           'fail2ban', 'python3-systemd', 'nftables'], timeout=900, env=apt_env)
    m.write_json(change.backup / 'package-receipt.json',
                 {'version': 1, 'nonce': request['nonce'], **_fail2ban_install_identity()})
    # Ensure no unexpected activation slipped through a maintainer script.
    state = m.run(['systemctl', 'is-active', 'fail2ban'], check=False, timeout=10, env=ENV)
    if state.stdout.strip() != 'inactive' or state.returncode != 3:
        raise m.Failure('Fail2ban неожиданно активен; требуется ручная проверка.')
    # deb-systemd-helper may enable the unit despite policy-rc.d. Keep it
    # disabled until validation, including across a failed/cancelled install.
    m.run(['systemctl', 'disable', 'fail2ban'], timeout=30, env=ENV)
    change._state['package_enable_pending'] = False
    change._save()
    if not change._owned(item):
        raise m.Failure('policy-rc.d изменён другим процессом.')
    policy.unlink()
    change._state['files'].remove(item)
    change._save()
