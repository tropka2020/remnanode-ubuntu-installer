/* An illustrative, offline selector. No geolocation, weather or ephemeris claims. */
(() => {
  'use strict';
  if (!document.body.classList.contains('theme-orbit')) return;
  const planner = document.querySelector('[data-orbit-planner]');
  if (!planner) return;
  const phaseSet = planner.querySelector('.orbit-phase-set');
  const place = planner.querySelector('#orbit-place');
  const heading = planner.querySelector('[data-orbit-heading]');
  const target = planner.querySelector('[data-orbit-target]');
  const placeTip = planner.querySelector('[data-orbit-place-tip]');
  const read = planner.querySelector('[data-orbit-read]');
  if (!phaseSet || !place || !heading || !target || !placeTip || !read) return;

  const scenarios = Object.freeze({
    new: {
      heading: 'Соберите знакомый узор',
      target: 'Вблизи новолуния лунный свет меньше мешает слабым объектам. Найдите на актуальной карте одно созвездие, видимое в вашем месте и в выбранное время, и сравните его рисунок с небом. Саму Луну около новолуния не ищите рядом с Солнцем.',
      href: 'article-orbit-seasonal-skies.html'
    },
    crescent: {
      heading: 'Заметьте пепельный свет',
      target: 'Если молодой серп уже хорошо виден после захода Солнца, попробуйте заметить слабый свет на остальной части лунного диска. Это солнечный свет, отражённый Землёй к Луне. Убывающий серп обычно удобнее наблюдать до рассвета; видимость нужно проверить отдельно.',
      href: 'article-orbit-lunar-phases.html'
    },
    quarter: {
      heading: 'Ищите границу света',
      target: 'Если Луна над горизонтом, сравните тёмное море и светлый край соседнего кратера. Для начала достаточно глаза; бинокль покажет больше деталей. Первая четверть обычно удобна вечером, последняя — во второй половине ночи и утром.',
      href: 'article-orbit-lunar-phases.html'
    },
    full: {
      heading: 'Сравните моря и лучи',
      target: 'При полной Луне тени короче, зато заметнее различие светлых и тёмных участков. Найдите один крупный тёмный участок и зарисуйте его положение. Не рассчитывайте в ту же ночь на лучший контраст слабых галактик и туманностей.',
      href: 'article-orbit-observation-log.html'
    }
  });
  const places = Object.freeze({
    city: 'В городе встаньте так, чтобы фонарь не светил прямо в глаза. Не выбирайте для наблюдений проезжую часть, крыши или закрытые территории. Луна и яркие звёздные узоры доступны даже без поездки за город.',
    dark: 'Вдали от прямого света дайте глазам время привыкнуть к темноте. При безлунном небе пробуйте слабые объекты; при яркой Луне смените задачу. Заранее проверьте доступ, связь и путь обратно.'
  });
  const update = () => {
    const selected = planner.querySelector('input[name="orbit-phase"]:checked');
    const scenario = scenarios[selected ? selected.value : 'quarter'] || scenarios.quarter;
    heading.textContent = scenario.heading;
    target.textContent = scenario.target;
    placeTip.textContent = places[place.value] || places.city;
    read.href = scenario.href;
  };
  // Bind only after the entire fallback has been located; failed initialization
  // leaves a readable default plan and disabled rather than misleading controls.
  phaseSet.addEventListener('change', update);
  place.addEventListener('change', update);
  update();
  phaseSet.disabled = false;
  place.disabled = false;
})();
