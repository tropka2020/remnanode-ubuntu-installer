(() => {
  'use strict';
  const root = document.querySelector('body.theme-form');
  if (!root) return;
  const image = root.querySelector('#form-material-image');
  const caption = root.querySelector('#form-material-caption');
  const credit = root.querySelector('.form-credit');
  const picker = root.querySelector('.form-material-picker');
  const start = root.querySelector('.form-start');
  const readingLabels = { clay: 'Читать о глине', wood: 'Читать о дереве', linen: 'Читать о льне', repair: 'Читать о починке', care: 'Читать об уходе' };
  const buttons = [...root.querySelectorAll('.form-material-option')];
  if (!image || !caption || !picker || !buttons.length) return;
  const credits = {
    clay: 'Фото: Vaija · CC BY-SA 4.0',
    wood: 'Фото: CEphoto, Uwe Aranas · CC BY-SA 3.0',
    linen: 'Фото: JohanahoJ · CC BY-SA 4.0',
    repair: 'Фото: photos-public-domain.com · CC0',
    care: 'Фото: Ken Rahaim / Smithsonian Institution'
  };
  let request = 0;
  picker.hidden = false;
  caption.setAttribute('aria-live', 'polite');
  buttons.forEach((button, index) => button.setAttribute('aria-pressed', String(index === 0)));
  const setMaterial = (button) => {
    const current = ++request;
    const candidate = new Image();
    candidate.onload = () => {
      if (current !== request) return;
      image.src = candidate.src;
      image.alt = button.dataset.alt || '';
      caption.textContent = button.dataset.caption || '';
      if (credit) credit.textContent = credits[button.dataset.material] || '';
      if (start) {
        start.href = 'article-form-' + button.dataset.material + '.html';
        start.firstChild.textContent = readingLabels[button.dataset.material] + ' ';
      }
      buttons.forEach((item) => {
        item.classList.toggle('is-active', item === button);
        item.setAttribute('aria-pressed', String(item === button));
      });
    };
    candidate.onerror = () => {
      if (current === request) caption.textContent = 'Изображение не загрузилось. Все пять историй доступны ниже.';
    };
    candidate.src = button.dataset.image;
  };
  buttons.forEach((button, index) => {
    button.addEventListener('click', () => setMaterial(button));
    button.addEventListener('keydown', (event) => {
      if (!['ArrowRight', 'ArrowDown', 'ArrowLeft', 'ArrowUp', 'Home', 'End'].includes(event.key)) return;
      event.preventDefault();
      const forward = event.key === 'ArrowRight' || event.key === 'ArrowDown';
      const target = event.key === 'Home' ? 0 : event.key === 'End' ? buttons.length - 1 : (index + (forward ? 1 : -1) + buttons.length) % buttons.length;
      buttons[target].focus();
      setMaterial(buttons[target]);
    });
  });
})();
