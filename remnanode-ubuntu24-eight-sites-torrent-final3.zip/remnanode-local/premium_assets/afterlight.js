(() => {
  const root = document.querySelector('.afterlight-page');
  if (!root) return;
  const buttons = root.querySelectorAll('[data-crop]');
  buttons.forEach((button) => {
    button.addEventListener('click', () => {
      const mode = button.dataset.crop || 'cover';
      root.dataset.crop = mode;
      buttons.forEach((item) => {
        const active = item === button;
        item.classList.toggle('is-active', active);
        item.setAttribute('aria-pressed', String(active));
      });
    });
  });
})();
