(() => {
  'use strict';
  const body = document.body;
  if (!body || !body.classList.contains('theme-index')) return;

  const form = document.querySelector('#index-notebook-form');
  const status = document.querySelector('#index-notebook-status');
  const exportButton = document.querySelector('#index-export');
  const clearButton = document.querySelector('#index-clear');
  if (!form || !status || !exportButton || !clearButton) return;

  const storageKey = 'index-reading-notebook-v1';
  const fields = {
    book: form.elements.book,
    page: form.elements.page,
    note: form.elements.note
  };
  let storageAvailable = true;

  const getEntry = () => ({
    book: fields.book.value.trim(),
    page: fields.page.value.trim(),
    note: fields.note.value.trim()
  });

  const hasEntry = entry => Boolean(entry.book || entry.page || entry.note);
  const setStatus = message => { status.textContent = message; };
  const syncButtons = () => {
    const available = hasEntry(getEntry());
    exportButton.disabled = !available;
    clearButton.disabled = !available;
  };

  try {
    const raw = localStorage.getItem(storageKey);
    if (raw) {
      const saved = JSON.parse(raw);
      ['book', 'page', 'note'].forEach(key => {
        if (typeof saved[key] === 'string') fields[key].value = saved[key];
      });
      setStatus('Последняя запись восстановлена из этого браузера.');
    }
  } catch (error) {
    storageAvailable = false;
    setStatus('Автосохранение недоступно. Текст остаётся в форме, пока открыта страница.');
  }

  form.addEventListener('input', syncButtons);
  form.addEventListener('submit', event => {
    event.preventDefault();
    const entry = getEntry();
    if (!hasEntry(entry)) {
      setStatus('Добавьте хотя бы одну деталь: книгу, страницу или мысль.');
      fields.book.focus();
      return;
    }
    if (storageAvailable) {
      try {
        localStorage.setItem(storageKey, JSON.stringify(entry));
        setStatus('Запись сохранена только в этом браузере.');
      } catch (error) {
        storageAvailable = false;
        setStatus('Не удалось записать в хранилище. Скопируйте текст вручную.');
      }
    }
    syncButtons();
  });

  clearButton.addEventListener('click', () => {
    if (!window.confirm('Удалить запись из формы и этого браузера?')) return;
    Object.values(fields).forEach(field => { field.value = ''; });
    if (storageAvailable) {
      try { localStorage.removeItem(storageKey); } catch (error) { storageAvailable = false; }
    }
    setStatus('Запись очищена.');
    syncButtons();
    fields.book.focus();
  });

  exportButton.addEventListener('click', () => {
    const entry = getEntry();
    const content = ['INDEX / читательский блокнот', '', `Книга: ${entry.book || 'нет записи'}`, `Страница: ${entry.page || 'нет записи'}`, '', entry.note || ''].join('\n');
    const blob = new Blob([content], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = 'index-reading-note.txt';
    link.click();
    URL.revokeObjectURL(url);
    setStatus('Текстовый файл подготовлен для скачивания.');
  });

  syncButtons();

  if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) return;
  const observer = 'IntersectionObserver' in window ? new IntersectionObserver(entries => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add('index-seen');
        observer.unobserve(entry.target);
      }
    });
  }, { threshold: 0.12 }) : null;
  if (observer) document.querySelectorAll('.index-manifesto, .index-section-heading, .new-card, .index-spread, .index-notebook, .index-close').forEach(node => observer.observe(node));
})();
