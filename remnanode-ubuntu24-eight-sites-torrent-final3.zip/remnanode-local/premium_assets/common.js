(() => {
  'use strict';
  const root = document.querySelector('[data-scaler]');
  if (!root) return;
  const input = root.querySelector('input[type="number"]');
  const output = root.querySelector('output');
  const quantities = document.querySelectorAll('[data-quantity]');
  if (!input || !output || !quantities.length) return;
  const base = Number(input.value) || 2;
  const format = value => Number.isInteger(value) ? String(value) : value.toFixed(1).replace('.0', '');
  const update = () => {
    const servings = Math.max(1, Math.min(12, Number(input.value) || base));
    input.value = servings;
    output.value = servings;
    output.textContent = servings;
    quantities.forEach(node => {
      const amount = Number(node.dataset.quantity) * servings / base;
      node.textContent = `${format(amount)} ${node.dataset.unit}`;
    });
  };
  input.addEventListener('input', update);
  input.addEventListener('change', update);
  update();
})();
