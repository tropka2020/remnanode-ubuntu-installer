"""Offline rendering for the expanded publications; no legacy rendering changes.

Installed assets are trusted source code. Imported sites still have to match the
complete renderer output, including every script byte, through premium_site.
"""
import html
import json
import re

TEMPLATES = ('index', 'form', 'afterlight', 'common', 'orbit')

THEMES = {
    'index': {
        'names': ('INDEX', 'MARGIN', 'READING ROOM', 'PRINT MATTER', 'FOLIO'),
        'label': 'Независимый журнал о книгах и чтении',
        'intro': 'Книги, полевые заметки и время на чтение. Внимательный взгляд на страницу и на то, что остаётся после неё.',
        'about': 'Мы пишем о чтении как о повседневной практике, а о книге — как о тексте и предмете. Здесь нет обязательного списка достижений, вымышленных рецензентов или обещаний прочитать всё.',
        'caution': 'Проверяйте права на тексты, переводы и изображения изданий перед собственным использованием. Иллюстрации не означают сотрудничества с авторами или издателями.',
    },
    'form': {
        'names': ('FORM', 'OBJECT STUDY', 'SOLID', 'MATTER', 'VOLUME'),
        'label': 'Независимый журнал о материале и ручном труде',
        'intro': 'Глина, дерево, лён и след руки. Истории о вещах, которые становятся своими через внимание и заботу.',
        'about': 'Мы рассматриваем материалы в их повседневной жизни: с царапиной на дереве, складкой на льне и следом починки. Здесь нет культа идеальной поверхности, вымышленных мастерских или обещаний вечной службы.',
        'caution': 'Учитывайте свойства конкретного материала и инструкции производителя. Опасные работы, химическую обработку и сложный ремонт доверяйте квалифицированным специалистам.',
    },
    'afterlight': {
        'names': ('AFTERLIGHT', 'LATE FRAME', 'BLUE HOUR', 'LAST LIGHT', 'NIGHT NOTES'),
        'label': 'Независимый журнал о фотографии и внимании',
        'intro': 'Свет, композиция и спокойный выбор кадра. Знакомые сцены, в которых можно заметить больше.',
        'about': 'Мы исследуем фотографическое наблюдение: как меняются свет, расстояние и внимание. Снимки служат иллюстрациями, а тексты не выдают их за собственные репортажи.',
        'caution': 'Уважайте частную жизнь и правила съёмки. Выбирайте безопасные общедоступные места, не выходите на проезжую часть ради кадра и проверяйте условия возвращения.',
    },
    'common': {
        'names': ('COMMON', 'AT TABLE', 'EVERYDAY CLUB', 'TOGETHER', 'GOOD COMPANY'),
        'label': 'Независимый журнал о домашней кухне',
        'intro': 'Рецепты и техники, которые помогают увереннее обращаться с продуктами, беречь вкус и не выбрасывать лишнее.',
        'about': 'Мы пишем о домашней кухне без кулинарных соревнований. Здесь важны доступные продукты, понятный порядок действий и пищевые привычки, которые подходят вашей повседневной жизни.',
        'caution': 'Учитывайте аллергии, индивидуальные ограничения и правила пищевой безопасности. Тексты не являются медицинскими или диетологическими рекомендациями.',
    },
    'orbit': {
        'names': ('ORBIT', 'SIGNAL', 'NEXT QUESTION', 'OPEN SYSTEM', 'NEW PERSPECTIVE'),
        'label': 'Независимый журнал о ночном небе',
        'intro': 'Луна, знакомые созвездия и первые записи в блокноте. Практика наблюдения без гонки за оборудованием.',
        'about': 'Мы начинаем знакомство с небом с одного наблюдения и одного вопроса. Иллюстрации космических агентств показывают объекты в определённых условиях и диапазонах: они не обещают такой же вид невооружённому глазу.',
        'caution': 'Проверяйте местные эфемериды, прогноз и безопасный доступ к площадке. Никогда не направляйте бинокль или телескоп на Солнце: это может привести к необратимой травме глаз.',
    },
}

BASE_CSS = r'''/* Expanded publications only. Authored theme CSS supplies the palette. */
body[class*="theme-"]{margin:0;background:var(--paper);color:var(--ink);font-family:Manrope,sans-serif;font-size:16px;line-height:1.6;overflow-wrap:break-word}
body[class*="theme-"] *,body[class*="theme-"] *::before,body[class*="theme-"] *::after{box-sizing:border-box}
body[class*="theme-"] a{color:inherit}body[class*="theme-"] img{max-width:100%;display:block}
body[class*="theme-"] a:focus-visible,body[class*="theme-"] summary:focus-visible{outline:3px solid var(--accent);outline-offset:5px}
body[class*="theme-"] .skip{position:absolute;left:16px;top:-100px;z-index:100;background:var(--paper);padding:12px 20px}.skip:focus{top:12px!important}
.new-nav{width:min(1440px,92%);margin:auto;min-height:104px;display:flex;align-items:center;justify-content:space-between;gap:24px}
.new-nav a,.new-footer a{text-decoration:none}.new-brand{font-size:28px;font-weight:650;letter-spacing:-.04em}.new-nav>nav,.new-footer nav{display:flex;gap:26px}.new-nav nav a{font-size:16px}.new-nav .menu{display:none;position:relative}.new-nav summary{cursor:pointer;list-style:none}.new-nav .menu-links{position:absolute;right:0;top:40px;min-width:210px;padding:20px;background:var(--paper);z-index:30}.new-nav .menu-links a{display:block;padding:10px}
.new-footer{width:min(1440px,92%);margin:100px auto 0;padding:50px 0;display:flex;justify-content:space-between;align-items:flex-start;gap:30px;font-size:16px}.new-footer>span{max-width:30em}.new-footer nav{flex-wrap:wrap}
.new-page-intro,.new-about,.new-archive,.new-related{width:min(1280px,88%);margin:70px auto}.new-page-intro h1{font-size:clamp(32px,6vw,88px);line-height:1.1;letter-spacing:-.05em;margin:20px 0 28px;text-wrap:balance}.new-page-intro>p{max-width:760px;font-size:clamp(18px,2vw,23px)}.new-about{max-width:850px;font-size:18px;line-height:1.85}.new-about h2{margin-top:2.5em;font-size:30px;line-height:1.2}
.new-stories{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:50px 28px}.new-card{min-width:0;display:block;text-decoration:none;padding-bottom:24px}.new-card img{width:100%;aspect-ratio:4/3;object-fit:cover;object-position:var(--crop)}.new-card-meta{display:flex;justify-content:space-between;gap:12px;margin-top:20px;font-size:16px}.new-card h3{font-size:clamp(24px,2.2vw,34px);line-height:1.2;letter-spacing:-.03em;margin:14px 0}.new-card p{font-size:16px;line-height:1.7;max-width:42em}.new-card-arrow{display:inline-block;color:var(--accent);font-size:24px}.new-card:hover h3{text-decoration:underline;text-underline-offset:5px}
.new-reader{width:min(1320px,88%);margin:70px auto}.new-reader-heading{max-width:1040px;margin:0 auto 48px}.new-reader-heading h1{font-size:clamp(30px,5.5vw,88px);line-height:1.1;letter-spacing:-.045em;margin:20px 0 28px;text-wrap:balance}.new-reader-deck{font-size:clamp(18px,2vw,25px);line-height:1.6;max-width:900px}.new-reader-meta{display:flex;flex-wrap:wrap;gap:24px;margin-top:30px;padding-top:24px;font-size:16px}.new-reader-cover{margin:0 0 65px}.new-reader-cover img{width:100%;max-height:680px;aspect-ratio:16/9;object-fit:cover;object-position:var(--crop)}.new-reader-cover figcaption{font-size:16px;padding:18px 0}.new-reader-layout{display:grid;grid-template-columns:minmax(160px,250px) minmax(0,720px);gap:8%;justify-content:center}.new-reader-note{font-size:16px;background:var(--wash);padding:26px;align-self:start}.new-reader-note h2{font-size:24px;line-height:1.3}.new-reader-copy{font-size:18px;line-height:1.9}.new-chapter{margin-bottom:54px;scroll-margin-top:30px}.new-chapter h2{font-size:clamp(25px,2.8vw,36px);line-height:1.25;letter-spacing:-.03em;margin:8px 0 20px}.new-reader-quote{font-size:clamp(28px,3vw,42px);line-height:1.35;letter-spacing:-.025em;margin:54px 0;padding:30px;background:var(--wash)}.new-reader-end{font-size:16px;margin-top:60px}.new-related{display:flex;justify-content:space-between;align-items:flex-start;gap:30px;padding-top:40px}.new-related>a:last-child{max-width:620px;font-size:clamp(24px,3vw,40px);line-height:1.2;text-decoration:none}.new-related-label{display:block;margin-bottom:15px;font-size:16px}
body.theme-index .new-reader-heading h1{font-family:"Cormorant Garamond",serif;font-weight:500}body.theme-index .new-reader-quote{font-family:"Cormorant Garamond",serif}body.theme-index .new-card img{aspect-ratio:1/1}
body.theme-form .new-reader-heading{margin-left:0;max-width:900px}body.theme-form .new-reader-heading h1{font-family:"Cormorant Garamond",serif;font-weight:400;letter-spacing:-.035em}body.theme-form .new-reader-cover{width:86%;margin-left:auto}body.theme-form .new-reader-quote{font-family:"Cormorant Garamond",serif}body.theme-form .new-card img{aspect-ratio:4/5}
body.theme-afterlight .new-reader-heading{text-align:center}body.theme-afterlight .new-reader-meta{justify-content:center}body.theme-afterlight .new-reader-cover img{aspect-ratio:21/10}body.theme-afterlight .new-reader-quote{font-family:"Cormorant Garamond",serif;font-style:italic}body.theme-afterlight .new-card img{aspect-ratio:3/4}
body.theme-common .new-reader-heading h1{font-family:"Cormorant Garamond",serif;font-weight:500}body.theme-common .new-reader-cover img{border-radius:5px}body.theme-common .new-reader-quote{font-family:"Cormorant Garamond",serif}
body.theme-orbit .new-reader-heading h1{font-family:"Cormorant Garamond",serif;font-weight:500}body.theme-orbit .new-reader-cover{padding:12px;background:var(--wash)}body.theme-orbit .new-reader-quote{font-family:"Cormorant Garamond",serif}
@media(min-width:1000px){body.layout-1 .new-archive .new-stories{grid-template-columns:repeat(2,minmax(0,1fr))}body.layout-1 .new-reader-heading{max-width:1120px}}
@media(max-width:800px){.new-nav{min-height:78px}.new-nav>nav{display:none}.new-nav .menu{display:block}.new-footer{flex-direction:column;margin-top:60px}.new-footer>span{max-width:none}.new-stories{grid-template-columns:repeat(2,minmax(0,1fr));gap:36px 20px}.new-reader{margin-top:45px}.new-reader-layout{grid-template-columns:1fr;gap:30px}.new-reader-note{max-width:600px;order:2}.new-reader-copy{font-size:18px}.new-reader-cover{margin-bottom:35px}body.theme-form .new-reader-cover{width:100%}.new-related{flex-direction:column}}
@media(max-width:520px){.new-stories{grid-template-columns:1fr}.new-nav{width:90%;gap:14px}.new-brand{font-size:23px}.new-reader,.new-page-intro,.new-archive,.new-about,.new-related{width:90%}.new-reader-heading h1{font-size:clamp(26px,6.8vw,35px);letter-spacing:-.025em}.new-reader-cover img{aspect-ratio:4/3!important}.new-footer nav{gap:18px}.new-reader-meta{gap:16px}.new-reader-quote{padding:24px}}
@media(prefers-reduced-motion:reduce){body[class*="theme-"] *,body[class*="theme-"] *::before,body[class*="theme-"] *::after{animation:none!important;transition:none!important;scroll-behavior:auto!important}}
'''


def _escape(value):
    return html.escape(str(value), quote=True)


def _link(article):
    return 'article-' + article['id'] + '.html'


def _articles(assets, template):
    """Reject malformed installed data before using identifiers as output paths."""
    try:
        articles = json.loads(assets[template + '-editorial.json'])
    except (UnicodeError, json.JSONDecodeError) as exc:
        raise ValueError('Invalid installed premium editorial JSON.') from exc
    fields = ('id', 'theme', 'category', 'title', 'subtitle', 'image', 'alt',
              'time', 'caption', 'quote', 'note', 'noteText')
    if type(articles) is not list or len(articles) != 5:
        raise ValueError('Premium installed editorial data must contain five articles per family.')
    ids = set()
    for article in articles:
        if (type(article) is not dict or
                any(type(article.get(field)) is not str or not article[field].strip()
                    for field in fields)):
            raise ValueError('Invalid installed premium article fields.')
        if (article['theme'] != template or
                re.fullmatch(re.escape(template) + r'-[a-z0-9]+(?:-[a-z0-9]+)*', article['id']) is None or
                article['id'] in ids):
            raise ValueError('Invalid or duplicate installed premium article identifier.')
        ids.add(article['id'])
        if (re.fullmatch(re.escape(template) + r'-[a-z0-9-]+\.jpg', article['image']) is None or
                article['image'] not in assets):
            raise ValueError('Premium articles require an installed, local theme image.')
        sections = article.get('sections')
        if (type(sections) is not list or len(sections) != 5 or
                any(type(section) is not list or len(section) != 2 or
                    any(type(value) is not str or not value.strip() for value in section)
                    for section in sections)):
            raise ValueError('Premium installed articles require five complete sections.')
    return articles


def _stories(articles):
    return '<div class="new-stories">' + ''.join(
        f'<a class="new-card" href="{_link(article)}">'
        f'<img src="assets/{_escape(article["image"])}" alt="{_escape(article["alt"])}" loading="lazy">'
        f'<div class="new-card-meta"><span>{_escape(article["category"])}</span>'
        f'<span>{_escape(article["time"])}</span></div><h3>{_escape(article["title"])}</h3>'
        f'<p>{_escape(article["subtitle"])}</p><span class="new-card-arrow" aria-hidden="true">↗</span></a>'
        for article in articles) + '</div>'


def _reader(template, article, following, title, number):
    chapters = []
    for index, (heading, text) in enumerate(article['sections']):
        chapters.append(f'<section class="new-chapter"><h2>{_escape(heading)}</h2>'
                        f'<p>{_escape(text)}</p></section>')
        if index == 1:
            chapters.append(f'<blockquote class="new-reader-quote"><p>{_escape(article["quote"])}</p></blockquote>')
    return (f'<article class="new-reader reader-{template}" aria-labelledby="story-title">'
            '<header class="new-reader-heading">'
            f'<h1 id="story-title">{_escape(article["title"])}</h1>'
            f'<p class="new-reader-deck">{_escape(article["subtitle"])}</p>'
            f'<div class="new-reader-meta"><span>История {number:02d} / 05</span>'
            f'<span>{_escape(article["time"])} на чтение</span><span>Редакционный материал</span></div></header>'
            '<figure class="new-reader-cover">'
            f'<img src="assets/{_escape(article["image"])}" alt="{_escape(article["alt"])}" fetchpriority="high">'
            f'<figcaption>{_escape(article["caption"])}</figcaption></figure>'
            '<div class="new-reader-layout"><aside class="new-reader-note">'
            f'<h2>{_escape(article["note"])}</h2><p>{_escape(article["noteText"])}</p></aside>'
            '<div class="new-reader-copy">' + ''.join(chapters) +
            f'<p class="new-reader-end">— {_escape(title)} —</p></div></div></article>'
            '<nav class="new-related" aria-label="Другие истории"><a href="notes.html">← Все истории</a>'
            f'<a href="{_link(following)}"><span class="new-related-label">Следующая история</span>'
            f'{_escape(following["title"])} ↗</a></nav>')


def render(manifest, assets, theme, choice, digest, max_bytes):
    """Render only expanded template IDs; caller validates manifest and assets."""
    template = manifest['template']
    if template not in TEMPLATES:
        raise ValueError('Unknown expanded premium template.')
    title = choice(manifest, 'publication-title', theme['names'])
    layout = choice(manifest, 'composition', (0, 1))
    crop = choice(manifest, 'crop', ('50% 49%', '59% 56%', '42% 45%'))
    articles = _articles(assets, template)
    articles.sort(key=lambda article: digest(manifest, 'article-order:' + article['id']))
    photos = sorted(name for name in assets if name.startswith(template + '-') and name.endswith('.jpg'))
    hero = choice(manifest, 'cover-image', photos)
    links = '<a href="index.html">Главная</a><a href="notes.html">Истории</a><a href="about.html">О журнале</a>'
    navigation = (f'<header class="new-nav"><a class="new-brand" href="index.html">{_escape(title)}</a>'
                  '<nav aria-label="Основная навигация">' + links + '</nav>'
                  '<details class="menu"><summary>Меню ＋</summary><div class="menu-links">' + links + '</div></details></header>')
    footer = (f'<footer class="new-footer"><a class="new-brand" href="index.html">{_escape(title)}</a>'
              f'<span>{_escape(theme["label"])}</span><nav aria-label="Внизу страницы">'
              '<a href="notes.html">Все истории</a><a href="about.html">О журнале</a>'
              '<a href="about.html#sources">Источники и права</a></nav></footer>')

    def page(page_title, body, home=False):
        document_title = title + ' — ' + theme['label'] if home else page_title + ' — ' + title
        return (f'<!doctype html>\n<html lang="ru"><head><meta charset="utf-8">'
                '<meta name="viewport" content="width=device-width,initial-scale=1">'
                f'<title>{_escape(document_title)}</title>'
                f'<meta name="description" content="{_escape(theme["intro"])}">'
                '<link rel="stylesheet" href="assets/fonts.css">'
                '<link rel="stylesheet" href="assets/expanded.css">'
                f'<link rel="stylesheet" href="assets/{template}.css">'
                '<link rel="stylesheet" href="assets/variant.css">'
                f'<script src="assets/{template}.js" defer></script></head>'
                f'<body class="theme-{template} layout-{layout} {"new-home" if home else "new-inner"}">'
                '<a class="skip" href="#content">К содержимому</a>' + navigation +
                '<main id="content">' + body + '</main>' + footer + '</body></html>\n').encode('utf-8')

    home = assets[template + '.html'].decode('utf-8')
    if '@@STORIES@@' not in home:
        raise ValueError('Installed premium home fragment is missing the stories token.')
    for token, replacement in (('@@TITLE@@', _escape(title)), ('@@STORIES@@', _stories(articles)),
                               ('@@FEATURED_HREF@@', _link(articles[0])),
                               ('@@FEATURED_TITLE@@', _escape(articles[0]['title']))):
        home = home.replace(token, replacement)
    if '@@' in home:
        raise ValueError('Unknown installed premium home fragment token.')
    notes = ('<header class="new-page-intro">'
             f'<h1>Истории и наблюдения.</h1><p>{_escape(theme["intro"])}</p></header>'
             '<section class="new-archive" aria-label="Все истории">' + _stories(articles) + '</section>')
    about = ('<header class="new-page-intro">'
             f'<h1>{_escape(title)}</h1><p>{_escape(theme["about"])}</p></header>'
             '<section class="new-about"><h2>Внимание вместо спешки</h2>'
             f'<p>{_escape(theme["caution"])}</p>'
             '<p>Это общие редакционные заметки. Здесь нет вымышленных авторов, отзывов, адресов '
             'и обещаний результата. Фотографии служат иллюстрациями, а не подтверждением посещения '
             'мест, авторства проектов или сотрудничества с изображёнными организациями.</p>'
             '<h2 id="sources">Фотографии и шрифты</h2><p>Происхождение локальных изображений и '
             'условия их использования перечислены в '
             f'<a href="assets/{template}-SOURCES.txt">источниках этой публикации</a>. '
             'Перед рекламным или иным чувствительным использованием проверьте права на изображённые '
             'произведения, бренды и людей; лицензия фотографии не заменяет дополнительные разрешения.</p>'
             '<p>Локальные шрифты распространяются по SIL Open Font License 1.1: '
             '<a href="assets/Manrope-OFL.txt">Manrope OFL</a>, '
             '<a href="assets/CormorantGaramond-OFL.txt">Cormorant Garamond OFL</a>.</p></section>')
    result = {'index.html': page(title, home, home=True), 'notes.html': page('Истории', notes),
              'about.html': page('О журнале', about), 'assets/expanded.css': BASE_CSS.encode('utf-8')}
    for index, article in enumerate(articles):
        result[_link(article)] = page(article['title'], _reader(
            template, article, articles[(index + 1) % 5], title, index + 1))
    # Theme stylesheets own colour. Variants never override an authored palette.
    result['assets/variant.css'] = (f'body.theme-{template}{{--crop:{crop};'
                                    f'--hero-image:url("{hero}");--pause-image:url("{hero}")}}\n').encode('utf-8')
    public_assets = ('fonts.css', 'Manrope.ttf', 'CormorantGaramond.ttf', 'CormorantGaramond-Italic.ttf',
                     'Manrope-OFL.txt', 'CormorantGaramond-OFL.txt', template + '.css',
                     template + '.js', template + '-SOURCES.txt')
    for name in (*public_assets, *photos):
        result['assets/' + name] = assets[name]
    if sum(map(len, result.values())) > max_bytes:
        raise ValueError('The premium site exceeds the size limit.')
    return result
