#!/usr/bin/env python3
"""Safe Caddy manager for the local Remnawave web backend.

This module never installs or executes the third-party selfsteal.sh script.
"""
import argparse
from contextlib import contextmanager
from datetime import datetime, timezone
import json
import os
from pathlib import Path
import re
import shutil
import tempfile
import socket
import string
import ssl
import subprocess
import sys

import manage as m

WEB = Path('/opt/caddy')
CONTAINER = 'remnanode-web'
METADATA = WEB / 'managed.json'
CADDYFILE = WEB / 'Caddyfile'
ACCESS_LOG = WEB / 'logs' / 'access.log'
MAX_LOG_BYTES = 128 * 1024
PRIVATE_MANIFEST = Path('/var/lib/remnanode-design/premium-manifest.json')
TEMPLATES = {'1': 'north', '2': 'still', '3': 'ritual', '4': 'index',
             '5': 'form', '6': 'afterlight', '7': 'common', '8': 'orbit'}


def require_root():
    if sys.platform != 'linux' or os.geteuid() != 0:
        raise SelfstealError('Изменения разрешены только от root на Linux.')


class SelfstealError(Exception):
    pass


def _json(path):
    try:
        m.secure_path(path, directory=False)
        data = json.loads(path.read_text(encoding='utf-8'))
    except (OSError, ValueError, UnicodeError) as exc:
        raise SelfstealError('Не удалось прочитать metadata Caddy.') from exc
    if (not isinstance(data, dict) or data.get('version') != 2 or
            data.get('purpose') != 'local-backend' or data.get('https_port') != 9443 or
            not isinstance(data.get('domain'), str) or not m.DOMAIN.fullmatch(data['domain'])):
        raise SelfstealError('Установка не распознана как управляемый backend Caddy.')
    return data


def validate_installation():
    metadata = _json(METADATA)
    m.secure_path(WEB, directory=True)
    m.secure_path(CADDYFILE, directory=False)
    if not WEB.is_dir() or not CADDYFILE.is_file():
        raise SelfstealError('Каталог Caddy или Caddyfile отсутствует.')
    if '127.0.0.1' not in CADDYFILE.read_text(encoding='utf-8') or '9443' not in CADDYFILE.read_text(encoding='utf-8'):
        raise SelfstealError('Caddyfile не подтверждает локальный backend 9443.')
    obj = m.inspect(CONTAINER)
    if obj is None:
        raise SelfstealError('Контейнер remnanode-web не найден.')
    image = obj.get('Config', {}).get('Image', '')
    if (not isinstance(image, str) or not re.fullmatch(r'caddy@sha256:[0-9a-f]{64}', image) or
            metadata.get('image') != image):
        raise SelfstealError('Образ Caddy не закреплён digest или схема неизвестна.')
    mounts = obj.get('Mounts', [])
    required = {('/opt/caddy/Caddyfile', '/etc/caddy/Caddyfile', 'bind'),
                ('/opt/caddy/html', '/var/www/html', 'bind')}
    actual = {(x.get('Source'), x.get('Destination'), x.get('Type')) for x in mounts}
    if not required.issubset(actual):
        raise SelfstealError('Mounts Caddy не соответствуют управляемой установке.')
    expected = {
        '/etc/caddy/Caddyfile': ('bind', '/opt/caddy/Caddyfile', False),
        '/var/www/html': ('bind', '/opt/caddy/html', False),
        '/var/log/caddy': ('bind', '/opt/caddy/logs', True),
        '/data': ('volume', 'caddy_caddy_data', True),
        '/config': ('volume', 'caddy_caddy_config', True),
    }
    if len(mounts) != len(expected):
        raise SelfstealError('Неизвестные дополнительные mounts Caddy.')
    for destination, (kind, source, writable) in expected.items():
        matched = [item for item in mounts if item.get('Destination') == destination]
        if len(matched) != 1:
            raise SelfstealError('Неизвестная схема mounts Caddy.')
        item = matched[0]
        if (item.get('Type') != kind or item.get('Source' if kind == 'bind' else 'Name') != source or
                item.get('RW', kind == 'volume') is not writable):
            raise SelfstealError('Mounts/readonly Caddy не соответствуют установке wizard v2.')
    text = CADDYFILE.read_text(encoding='utf-8')
    if (not re.search(r'^https://' + re.escape(metadata['domain']) + r'\s*\{', text, re.M) or
            not re.search(r'\broot\s+\*\s+/var/www/html\s*$', text, re.M)):
        raise SelfstealError('Домен или корень Caddyfile не соответствуют metadata.')
    return metadata


def service_action(action, *, confirm=False):
    if action not in ('start', 'stop', 'restart'):
        raise SelfstealError('Неизвестное действие Caddy.')
    require_root()
    validate_installation()
    if action in ('stop', 'restart') and not confirm:
        raise SelfstealError('Остановка/перезапуск требует явного подтверждения.')
    with m.lock():
        m.run(['docker', action, CONTAINER], timeout=60)
        state = m.inspect(CONTAINER)
        if action == 'stop':
            m.confirm_stopped(CONTAINER)
        elif not state or not state.get('State', {}).get('Running'):
            raise SelfstealError('Caddy не подтвердил состояние после запуска.')
    print({'start': 'Caddy включён.', 'stop': 'Caddy выключен.', 'restart': 'Caddy перезапущен.'}[action])


def _certificate(domain, port=9443, verify=True):
    context = ssl.create_default_context() if verify else ssl._create_unverified_context()
    with socket.create_connection(('127.0.0.1', port), timeout=8) as raw:
        with context.wrap_socket(raw, server_hostname=domain) as conn:
            cert = conn.getpeercert()
            if not cert:
                raise SelfstealError('Сертификат не предоставлен.')
    not_after = cert.get('notAfter')
    if not not_after:
        raise SelfstealError('В сертификате нет срока действия.')
    timestamp = ssl.cert_time_to_seconds(not_after)
    now = datetime.now(timezone.utc).timestamp()
    return {'domain': domain, 'not_after': not_after, 'expires_at': datetime.fromtimestamp(timestamp, timezone.utc),
            'days_left': int((timestamp - now) // 86400), 'verified': verify}


def certificate_status(*, verify=True):
    metadata = validate_installation()
    try:
        status = _certificate(metadata['domain'], metadata['https_port'], verify=verify)
    except (OSError, ssl.SSLError, SelfstealError) as exc:
        raise SelfstealError('TLS-проверка Caddy не пройдена: ' + type(exc).__name__) from None
    return status


def _safe_tail(path, max_bytes=MAX_LOG_BYTES):
    m.secure_path(path, directory=False)
    with path.open('rb') as stream:
        stream.seek(0, 2)
        size = stream.tell()
        stream.seek(max(0, size - max_bytes))
        data = stream.read(max_bytes)
    text = data.decode('utf-8', errors='replace')
    safe = ''.join(ch if ch in '\n\r\t' or ch in string.printable else '\ufffd' for ch in text)
    return safe[-max_bytes:]


def show_logs(kind='visits', lines=100):
    if not 1 <= lines <= 1000:
        raise SelfstealError('Число строк должно быть от 1 до 1000.')
    validate_installation()
    if kind == 'visits':
        if not ACCESS_LOG.exists():
            return 'Журнал посещений ещё не создан.\n'
        text = _safe_tail(ACCESS_LOG)
        return '\n'.join(text.splitlines()[-lines:]) + ('\n' if text else '')
    if kind == 'errors':
        result = m.run(['docker', 'logs', '--tail', str(lines), '--timestamps', CONTAINER], capture=True, combine_output=True, timeout=30)
        return ''.join(ch if ch in '\n\r\t' or ch in string.printable else '\ufffd' for ch in result)
    raise SelfstealError('Тип журнала: visits или errors.')


def _premium():
    # Legacy status/log/service commands must work without the new generator.
    import premium_site
    return premium_site


def _premium_call(premium, name, *args):
    try:
        return getattr(premium, name)(*args)
    except premium.SiteError as exc:
        raise SelfstealError('Premium генератор: ' + str(exc)) from exc


def _manifest_bytes():
    m.secure_path(PRIVATE_MANIFEST.parent, directory=True)
    m.secure_path(PRIVATE_MANIFEST, directory=False)
    if PRIVATE_MANIFEST.parent.exists() and PRIVATE_MANIFEST.parent.stat().st_mode & 0o077:
        raise SelfstealError('Каталог premium state должен иметь права 700.')
    if not PRIVATE_MANIFEST.exists():
        return None
    if PRIVATE_MANIFEST.stat().st_mode & 0o077 or PRIVATE_MANIFEST.stat().st_size > 32768:
        raise SelfstealError('Premium manifest должен иметь закрытые права и допустимый размер.')
    data = PRIVATE_MANIFEST.read_bytes()
    premium = _premium()
    try:
        premium.validate_manifest(json.loads(data))
    except (ValueError, TypeError, premium.SiteError) as exc:
        raise SelfstealError('Некорректный premium manifest; автоматический сброс запрещён.') from exc
    return data


def current_template():
    data = _manifest_bytes()
    return json.loads(data)['template'] if data is not None else 'legacy'


def _atomic_bytes(path, data):
    m.secure_path(path, directory=False)
    fd, filename = tempfile.mkstemp(prefix='.manifest-', dir=path.parent)
    try:
        with os.fdopen(fd, 'wb') as stream:
            stream.write(data)
            stream.flush()
            os.fsync(stream.fileno())
        os.chmod(filename, 0o600)
        os.replace(filename, path)
    finally:
        if os.path.exists(filename):
            os.unlink(filename)


def _safe_tree(root):
    m.secure_path(root, directory=True)
    if not root.is_dir():
        raise SelfstealError('Каталог сайта отсутствует.')
    for directory, dirs, files in os.walk(root, followlinks=False):
        for name in dirs:
            m.secure_path(Path(directory) / name, directory=True)
        for name in files:
            m.secure_path(Path(directory) / name, directory=False)


def switch_template(template, *, confirm=False):
    require_root()
    if not confirm:
        raise SelfstealError('Смена шаблона требует --confirm; будет краткий перерыв Caddy.')
    template = TEMPLATES.get(str(template), template)
    if template not in TEMPLATES.values():
            raise SelfstealError('Шаблон должен быть от 1 до 8.')
    with m.lock():
        metadata = validate_installation()
        old_manifest = _manifest_bytes()
        destination = WEB / 'html'
        _safe_tree(destination)
        old_index = (destination / 'index.html').read_text(encoding='utf-8')
        # Validate the existing domain, chain, certificate and served content first.
        m.check_https(metadata['domain'], 9443, old_index)
        premium = _premium()
        manifest = _premium_call(premium, 'validate_manifest',
                                 _premium_call(premium, 'new_manifest', template))
        expected = _premium_call(premium, 'expected_files', manifest)
        expected_index = expected['index.html'].decode('utf-8')
        PRIVATE_MANIFEST.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
        os.chmod(PRIVATE_MANIFEST.parent, 0o700)
        backup = m.backup_dir('premium-site')
        os.chmod(backup, 0o700)
        workspace = Path(tempfile.mkdtemp(prefix='.premium-', dir=WEB))
        os.chmod(workspace, 0o700)
        stage, old = workspace / 'html', workspace / 'previous-html'
        stop_attempted = stop_confirmed = old_moved = switched = manifest_attempted = False
        preserve = False
        try:
            _premium_call(premium, 'generate', manifest, workspace / 'generated')
            _premium_call(premium, 'copy_generated', workspace / 'generated', stage, manifest)
            _safe_tree(stage)
            # Generator validates exact bytes, including its trusted asset allowlist.
            actual = {str(path.relative_to(stage)).replace('\\', '/'): path.read_bytes()
                      for path in stage.rglob('*') if path.is_file()}
            if actual != expected:
                raise SelfstealError('Сгенерированный сайт не совпадает с manifest.')
            shutil.copytree(destination, backup / 'html')
            if old_manifest is not None:
                _atomic_bytes(backup / 'premium-manifest.json', old_manifest)
            _atomic_bytes(backup / 'restore.json', json.dumps({
                'manifest_existed': old_manifest is not None, 'domain': metadata['domain']
            }).encode('utf-8'))
            stop_attempted = True
            m.run(['docker', 'stop', '--time', '20', CONTAINER], timeout=45)
            m.confirm_stopped(CONTAINER)
            stop_confirmed = True
            destination.rename(old)
            old_moved = True
            stage.rename(destination)
            switched = True
            m.run(['docker', 'start', CONTAINER], timeout=60)
            m.wait_https(metadata['domain'], 9443, expected_index, timeout=60)
            manifest_attempted = True
            _atomic_bytes(PRIVATE_MANIFEST, (json.dumps(manifest, ensure_ascii=False,
                                                       sort_keys=True) + '\n').encode('utf-8'))
        except BaseException as original:
            # Any unresolved initial stop is treated as uncertain even if a later
            # probe happens to recover; retain candidate, previous and backup trees.
            if stop_attempted and not stop_confirmed:
                preserve = True
            try:
                if switched:
                    # Do not move or delete any possibly-live bind-mounted tree.
                    m.run(['docker', 'stop', '--time', '20', CONTAINER], timeout=45)
                    m.confirm_stopped(CONTAINER)
                    destination.rename(workspace / 'failed-html')
                    old.rename(destination)
                    old_moved = switched = False
                elif old_moved:
                    # Publication rename failed after moving the old tree; still stopped.
                    old.rename(destination)
                    old_moved = False
                elif stop_attempted and not stop_confirmed:
                    m.confirm_stopped(CONTAINER)
                if manifest_attempted:
                    if old_manifest is None:
                        m.secure_path(PRIVATE_MANIFEST, directory=False)
                        if PRIVATE_MANIFEST.exists():
                            PRIVATE_MANIFEST.unlink()
                    else:
                        _atomic_bytes(PRIVATE_MANIFEST, old_manifest)
                if stop_attempted and stop_confirmed:
                    m.run(['docker', 'start', CONTAINER], timeout=60)
                    m.wait_https(metadata['domain'], 9443, old_index, timeout=60)
            except BaseException as recovery:
                preserve = True
                # Private parents protect all retained candidate/previous trees.
                os.chmod(workspace, 0o700)
                os.chmod(backup, 0o700)
                if switched:
                    # Restrict the exposed candidate too; never delete a live tree.
                    os.chmod(destination, 0o700)
                raise SelfstealError('Остановка/восстановление Caddy не подтверждены. '
                                     'Все версии сохранены; private backup: ' + str(backup) +
                                     '; staging: ' + str(workspace)) from recovery
            raise original
        finally:
            if preserve:
                os.chmod(workspace, 0o700)
                os.chmod(backup, 0o700)
            else:
                shutil.rmtree(workspace)
        print('Шаблон сайта изменён:', template)
        print('Private backup:', backup)
        print('Нода, UFW, профили и тома сертификатов не изменялись.')


def install_command():
    require_root()
    import command_runtime
    with m.lock():
        command_runtime.check_conflict(m.BASE)
        validate_installation()
        command_runtime.install_runtime(m.BASE)
    print('Команда selfsteal установлена; службы и настройки не изменялись.')


def print_status():
    metadata = validate_installation()
    obj = m.inspect(CONTAINER)
    state = obj.get('State', {})
    print('Контейнер:', CONTAINER)
    print('Состояние:', state.get('Status', 'unknown'))
    print('Шаблон сайта:', current_template())
    print('Перезапуски:', state.get('RestartCount', 'unknown'))
    try:
        cert = certificate_status()
        print('Домен:', cert['domain'])
        print('Сертификат истекает (UTC):', cert['expires_at'].isoformat())
        print('Осталось полных дней:', cert['days_left'])
        print('TLS цепочка и имя: проверены')
    except SelfstealError as exc:
        print('TLS:', exc)


def menu():
    while True:
        print('\nSelfsteal — безопасное управление Caddy backend')
        print('1. Статус и срок сертификата')
        print('2. Включить Caddy')
        print('3. Выключить Caddy')
        print('4. Перезапустить Caddy')
        print('5. Проверить/возобновить ACME')
        print('6. Логи посещений сайта')
        print('7. Ошибки Caddy/ACME')
        print('8. Сменить шаблон сайта')
        print('0. Выход')
        choice = input('Выберите действие: ').strip()
        if choice == '0': return
        if choice == '1': print_status()
        elif choice == '2': service_action('start')
        elif choice in ('3', '4'):
            if input('Сайт и backend будут недоступны. Введите ПОДТВЕРЖДАЮ: ').strip() == 'ПОДТВЕРЖДАЮ':
                service_action('stop' if choice == '3' else 'restart', confirm=True)
        elif choice == '5':
            certificate_status()
            print('Действующий сертификат проверен; Caddy продлевает его автоматически. Принудительная выдача не выполняется.')
            if input('Перезапустить Caddy для возобновления штатной ACME-автоматизации? [y/N]: ').lower() == 'y':
                service_action('restart', confirm=True)
                print_status()
        elif choice in ('6', '7'):
            print(show_logs('visits' if choice == '6' else 'errors'))
        elif choice == '8':
            validate_installation()
            print('Текущий шаблон:', current_template())
            print('  '.join(number + '. ' + name.upper() for number, name in TEMPLATES.items()))
            template = input('Новый шаблон [1–8]: ').strip()
            if input('Сайт и backend будут недоступны. Введите ПОДТВЕРЖДАЮ: ').strip() == 'ПОДТВЕРЖДАЮ':
                switch_template(template, confirm=True)
        else: print('Неизвестный пункт.')


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('action', nargs='?', choices=('menu', 'status', 'start', 'stop', 'restart', 'renew-check', 'logs', 'template', 'install-command'))
    parser.add_argument('--confirm', action='store_true')
    parser.add_argument('--template', choices=tuple(TEMPLATES))
    template_flags = parser.add_mutually_exclusive_group()
    for number in TEMPLATES:
        template_flags.add_argument('--template' + number, action='store_const',
                                    const=number, dest='template_number')
    parser.add_argument('--kind', choices=('visits', 'errors'), default='visits')
    parser.add_argument('--lines', type=int, default=100)
    args = parser.parse_args(argv)
    try:
        action = args.action or 'menu'
        if action == 'menu': menu()
        elif action == 'status': print_status()
        elif action in ('start', 'stop', 'restart'):
            service_action(action, confirm=args.confirm)
        elif action == 'renew-check':
            certificate_status()
            print('Сертификат действующий; Caddy управляет продлением автоматически. Принудительный выпуск не выполнялся.')
        elif action == 'logs': print(show_logs(args.kind, args.lines))
        elif action == 'template':
            if args.template and args.template_number:
                raise SelfstealError('Укажите ровно один --template N или --templateN.')
            switch_template(args.template or args.template_number, confirm=args.confirm)
        elif action == 'install-command': install_command()
        return 0
    except (SelfstealError, m.Failure, OSError, ValueError) as exc:
        print('ОШИБКА:', str(exc), file=sys.stderr)
        return 1


if __name__ == '__main__':
    raise SystemExit(main())
