#!/usr/bin/env python3
"""Trusted, offline premium publications; exact rendering is the import authority.

The private four-field manifest belongs outside the published directory. This
module does not weaken site.py's general-purpose, JavaScript-free validator.
Source Python and premium_assets are trusted installed code, not import input.
"""
import hashlib
import html
import importlib.util
import json
import os
from pathlib import Path, PurePosixPath
import re
import secrets
import shutil
import stat
import tempfile

import premium_expanded

_SPEC = importlib.util.spec_from_file_location(
    'premium_site_output', Path(__file__).resolve().with_name('site.py'))
site_tool = importlib.util.module_from_spec(_SPEC)
_SPEC.loader.exec_module(site_tool)
SiteError = site_tool.SiteError

VERSION = 'premium-v1'
TEMPLATES = ('north', 'still', 'ritual') + premium_expanded.TEMPLATES
MAX_BYTES = 30 * 1024 * 1024
ASSET_ROOT = Path(__file__).resolve().with_name('premium_assets')
# Relative to premium_assets; used by the private-runtime installer as well.
ASSET_FILES = (
    'north.html', 'still.html', 'ritual.html', 'north.css', 'living.css',
    'articles.css', 'premium.css', 'enhance.js', 'fonts.css',
    'editorial.json', 'editorial-extra.json',
    'Manrope.ttf', 'CormorantGaramond.ttf', 'CormorantGaramond-Italic.ttf',
    'Manrope-OFL.txt', 'CormorantGaramond-OFL.txt', 'ASSET-SOURCES.txt',
    'mountain.jpg', 'forest.jpg', 'lake.jpg', 'night.jpg', 'meadow.jpg',
    'interior.jpg', 'coffee.jpg',
    'afterlight.html', 'afterlight.css', 'afterlight.js',
    'afterlight-editorial.json', 'afterlight-SOURCES.txt',
    'afterlight-forest.jpg', 'afterlight-window.jpg',
    'afterlight-night.jpg', 'afterlight-lake.jpg',
    'form.html', 'form.css', 'form.js', 'form-editorial.json', 'form-SOURCES.txt',
    'form-clay.jpg', 'form-wood.jpg', 'form-linen.jpg', 'form-repair.jpg', 'form-care.jpg',
    'common.html', 'common.css', 'common.js', 'common-editorial.json', 'common-SOURCES.txt',
    'common-coffee.jpg', 'common-light.jpg', 'common-roast.jpg', 'common-table.jpg',
    'orbit.html', 'orbit.css', 'orbit.js', 'orbit-editorial.json', 'orbit-SOURCES.txt',
    'orbit-sky.jpg', 'orbit-moon.jpg', 'orbit-city.jpg', 'orbit-pleiades.jpg',
    'index.html', 'index.css', 'index.js', 'index-editorial.json', 'index-SOURCES.txt',
    'index-hours-jpg.jpg', 'index-titlepage.jpg', 'index-gilded-jpg.jpg', 'index-ledger-jpg.jpg',
)

THEMES = {
    'north': {
        'names': ('NORTH', 'FARTHER', 'FIELDNOTES', 'OPEN AIR', 'WANDER'),
        'label': 'Независимый журнал о природе и наблюдении',
        'intro': 'Места, которые меняют взгляд. Истории, после которых хочется выйти. И немного тишины между ними.',
        'about': 'Здесь не собирают обязательные вершины и не выдают иллюстрации за проверенные маршруты. Эти заметки помогают внимательнее смотреть на знакомую дорогу, готовиться к прогулке и оставлять природу такой, какой её нашли.',
        'caution': 'Тексты не заменяют карту, местный прогноз, правила территории или помощь гида. Проверяйте условия перед выходом, выбирайте маршрут по опыту и оставляйте запас времени на возвращение.',
        'palettes': (
            ('#f5f4ed', '#202922', '#526746', '#e9ecdf', '#cdd3c8'),
            ('#f1f3f0', '#203137', '#4d686d', '#e3e9e7', '#c7d3d0'),
            ('#f5f0e5', '#30352a', '#6c6548', '#e9e1d1', '#d5ccba'),
        ),
        'photos': ('mountain.jpg', 'lake.jpg', 'forest.jpg'),
    },
    'still': {
        'names': ('STILL', 'QUIET FORM', 'ROOM & LIGHT', 'SOFT SPACE', 'IN PLACE'),
        'label': 'Независимые заметки о доме и повседневности',
        'intro': 'О свете, натуральных материалах и вещах, которые не требуют внимания, но делают каждый день лучше.',
        'about': 'Дом не обязан выглядеть как выставка. Здесь собраны наблюдения о свете, фактуре и удобстве: небольшие обратимые решения вместо списка обязательных покупок. Интерьер на фотографии служит поводом задать вопрос, а не обещанием готового результата.',
        'caution': 'Учитывайте правила ухода за конкретным материалом и безопасность дома. Изменение проводки и другие технические работы доверяйте квалифицированным специалистам.',
        'palettes': (
            ('#f8f6f1', '#302e2a', '#815b45', '#eeebe3', '#dcd5c9'),
            ('#f4f3ed', '#30382f', '#64735b', '#e7e9dd', '#ccd1c1'),
            ('#f7f1eb', '#3b3030', '#875b58', '#eee3dc', '#d9c9bf'),
        ),
        'photos': ('interior.jpg',),
    },
    'ritual': {
        'names': ('RITUAL', 'DAILY CUP', 'SLOW BREW', 'FIRST SIP', 'COMMON GROUND'),
        'label': 'Независимый журнал о кофе дома',
        'intro': 'Хорошее утро не обязано быть сложным. Разбираемся в зерне, вкусе и маленьких решениях, из которых складывается чашка.',
        'about': 'Кофе здесь — повседневный напиток, а не соревнование оборудования. Мы начинаем с понятных пропорций, безопасной питьевой воды и небольших сравнений. Удачный рецепт можно повторить, а чужой идеальный вкус не обязан становиться вашим.',
        'caution': 'Рецепты для фильтр-кофе — отправные точки, не универсальные инструкции. Соблюдайте руководство оборудования, осторожность с горячей водой и личные ограничения по кофеину.',
        'palettes': (
            ('#24241f', '#f1ebdf', '#d5dbb9', '#e9e8dc', '#494b3f'),
            ('#292220', '#f4eade', '#dfc49b', '#eee1d0', '#51453c'),
            ('#202a29', '#edf1e5', '#bed5c1', '#e3e9dd', '#40554b'),
        ),
        'photos': ('coffee.jpg',),
    },
}
THEMES.update(premium_expanded.THEMES)


def validate_manifest(manifest: dict) -> dict:
    """Return a defensive canonical copy, or ValueError; no self-asserted hashes."""
    if (type(manifest) is not dict or
            set(manifest) != {'schema', 'version', 'template', 'seed'} or
            type(manifest.get('schema')) is not int or manifest['schema'] != 1 or
            type(manifest.get('version')) is not str or manifest['version'] != VERSION or
            type(manifest.get('template')) is not str or manifest['template'] not in TEMPLATES or
            type(manifest.get('seed')) is not str or
            re.fullmatch(r'[0-9a-f]{64}', manifest['seed']) is None):
        raise ValueError('Invalid premium manifest; expected premium-v1 and a 64-character lowercase hex seed.')
    return {key: manifest[key] for key in ('schema', 'version', 'template', 'seed')}


def new_manifest(template: str) -> dict:
    return validate_manifest({'schema': 1, 'version': VERSION,
                              'template': template, 'seed': secrets.token_hex(32)})


def _escape(value):
    return html.escape(str(value), quote=True)


def _digest(manifest, purpose):
    return hashlib.sha256((VERSION + ':' + manifest['template'] + ':' +
                           manifest['seed'] + ':' + purpose).encode('ascii')).digest()


def _choice(manifest, purpose, values):
    return values[int.from_bytes(_digest(manifest, purpose)[:8], 'big') % len(values)]


def _read_assets():
    site_tool.check_ancestors(ASSET_ROOT)
    result = {}
    total = 0
    for name in ASSET_FILES:
        path = ASSET_ROOT / name
        info = site_tool.checked_stat(path)
        if not stat.S_ISREG(info.st_mode) or info.st_nlink != 1:
            site_tool.fail('Premium installed assets must be ordinary, unlinked files.')
        total += info.st_size
        if total > MAX_BYTES:
            site_tool.fail('Premium installed assets exceed the size limit.')
        result[name] = site_tool.read_regular(path, info)
    return result


def _link(article):
    return 'article-' + article['id'] + '.html'


def _image(article, extra=''):
    return (f'<img src="assets/{_escape(article["image"])}" alt="{_escape(article["alt"])}" '
            f'loading="lazy" {extra}>')


def _north_stories(articles):
    def card(article, lead=False):
        return (f'<a class="story {"story-lead" if lead else "story-tall"} reveal" href="{_link(article)}">'
                f'<div class="image">{_image(article)}<span class="image-pill">{_escape(article["category"])}</span>'
                '<span class="image-arrow" aria-hidden="true">↗</span></div>'
                f'<div class="story-category"><span>{_escape(article["category"])}</span>'
                f'<span>{_escape(article["time"])}</span></div><h3>{_escape(article["title"])}</h3>'
                f'<p>{_escape(article["subtitle"])}</p></a>')
    return ('<div class="editorial-grid">' + card(articles[0], True) +
            '<div class="story-column">' + card(articles[1]) +
            '<div class="editor-note reveal"><span class="asterisk" aria-hidden="true">✳</span>'
            '<div><span class="micro">ЗАМЕТКА НА ПОЛЯХ</span><p>Хорошее путешествие начинается с '
            '<em>любопытства.</em> Не с расстояния.</p></div></div></div></div>')


def _north_atlas(articles):
    tiles = []
    for index, article in enumerate(articles):
        tiles.append(f'<a class="atlas-tile reveal" href="{_link(article)}">{_image(article)}'
                     '<div class="tile-gradient"></div>'
                     f'<span class="tile-num">{index + 1:02d}</span><div class="tile-caption"><div>'
                     f'<span class="micro">{_escape(article["category"])}</span>'
                     f'<h3>{_escape(article["title"])}</h3></div>'
                     '<span class="tile-arrow" aria-hidden="true">↗</span></div></a>')
    return '<div class="atlas-grid">' + ''.join(tiles) + '</div>'


def _living_list(template, articles, all_images=False):
    if template == 'still':
        cards = []
        for index, article in enumerate(articles):
            cards.append(f'<a class="snote reveal" href="{_link(article)}">'
                         + (_image(article, 'class="note-image"') if all_images or index == 0 else '') +
                         f'<div class="snotehead"><span>{index + 1:02d} / {_escape(article["category"])}</span>'
                         '<span aria-hidden="true">↗</span></div>'
                         f'<h3>{_escape(article["title"])}</h3><p>{_escape(article["subtitle"])}</p></a>')
        return '<div class="snotes">' + ''.join(cards) + '</div>'
    return '<div class="rrows">' + ''.join(
        f'<a class="rrow reveal" href="{_link(article)}"><span class="num">{index + 1:02d}</span>'
        f'<h3>{_escape(article["title"])}</h3><p>{_escape(article["subtitle"])}</p>'
        '<span class="arrow" aria-hidden="true">↗</span></a>'
        for index, article in enumerate(articles)) + '</div>'


def _navigation(template, title, home):
    links = '<a href="index.html">Главная</a><a href="notes.html">Истории</a><a href="about.html">О журнале</a>'
    menu = ('<details class="menu"><summary>Меню ＋</summary>'
            '<div class="menu-links">' + links + '</div></details>')
    if template == 'north':
        return (f'<header class="site-nav {"" if home else "page-nav"}"><a class="brand" href="index.html">'
                f'<span class="brand-mark" aria-hidden="true">{_escape(title[0])}</span>'
                f'<span>{_escape(title)}<sup>JOURNAL</sup></span></a><nav aria-label="Основная навигация">'
                + links + '</nav><a class="nav-action" href="notes.html">Открыть журнал ↗</a>' + menu + '</header>')
    prefix = 's' if template == 'still' else 'r'
    return (f'<header class="{prefix}nav wrap"><a class="{prefix}logo" href="index.html">{_escape(title)}</a>'
            '<nav class="navlinks" aria-label="Основная навигация">' + links + '</nav>' + menu + '</header>')


def _footer(title, label):
    return (f'<footer class="publication-footer"><a class="brand" href="index.html">{_escape(title)}</a>'
            f'<span>{_escape(label)}.<br>Без спешки. Без лишнего.</span>'
            '<nav aria-label="Внизу страницы"><a href="notes.html">Все истории</a>'
            '<a href="about.html">О журнале</a><a href="about.html#sources">Источники и права</a></nav></footer>')


def _article_body(article, following, title, number):
    chapters = []
    for index, (heading, text) in enumerate(article['sections']):
        chapters.append(f'<section class="av-chapter"><span class="av-chapter-number" aria-hidden="true">'
                        f'{index + 1:02d}</span><h2>{_escape(heading)}</h2><p>{_escape(text)}</p></section>')
        if index == 1:
            chapters.append(f'<blockquote class="av-quote"><p>{_escape(article["quote"])}</p></blockquote>')
    return (f'<article class="av-article" aria-labelledby="av-title"><header class="av-heading">'
            f'<p class="av-eyebrow">{_escape(article["category"])}</p><h1 id="av-title">{_escape(article["title"])}</h1>'
            f'<p class="av-deck">{_escape(article["subtitle"])}</p><div class="av-meta">'
            f'<span>История {number:02d} / 05</span><span>{_escape(article["time"])} на чтение</span>'
            '<span>Редакционный материал</span></div></header><figure class="av-cover">'
            f'<img src="assets/{_escape(article["image"])}" alt="{_escape(article["alt"])}" fetchpriority="high">'
            f'<figcaption><span>{_escape(article["caption"])}</span><span>{_escape(title)}</span></figcaption></figure>'
            '<div class="av-editorial"><aside class="av-note"><span class="av-eyebrow">На полях</span>'
            f'<h2>{_escape(article["note"])}</h2><p>{_escape(article["noteText"])}</p></aside>'
            '<div class="av-copy">' + ''.join(chapters) +
            f'<p class="av-endmark">— {_escape(title)} —</p></div></div></article>'
            '<div class="av-footer"><a class="av-return" href="notes.html">← Все истории</a>'
            f'<a class="av-related" href="{_link(following)}"><span class="av-eyebrow">Следующая история</span>'
            f'<span class="av-related-title">{_escape(following["title"])}<span aria-hidden="true">↗</span></span></a></div>')


def expected_files(manifest: dict) -> dict[str, bytes]:
    """Authoritatively render all public bytes, without network access or sidecars."""
    manifest = validate_manifest(manifest)
    if manifest['template'] in premium_expanded.TEMPLATES:
        return premium_expanded.render(manifest, _read_assets(), THEMES[manifest['template']],
                                       _choice, _digest, MAX_BYTES)
    assets = _read_assets()
    template = manifest['template']
    theme = THEMES[template]
    title = _choice(manifest, 'publication-title', theme['names'])
    palette = _choice(manifest, 'palette', theme['palettes'])
    layout = _choice(manifest, 'composition', (0, 1))
    crop = _choice(manifest, 'crop', ('50% 49%', '59% 56%', '42% 45%'))
    hero = _choice(manifest, 'cover-image', theme['photos'])
    pause = _choice(manifest, 'pause-image', ('lake.jpg', 'forest.jpg')) if template == 'north' else hero
    articles = [a for name in ('editorial.json', 'editorial-extra.json')
                for a in json.loads(assets[name]) if a['theme'] == template]
    articles.sort(key=lambda article: _digest(manifest, 'article-order:' + article['id']))
    if len(articles) != 5:
        raise ValueError('Premium installed editorial data must contain five articles per family.')

    def page(page_title, body, home=False, reader=False):
        section_id = 'article-view' if reader else 'home'
        document_title = title + ' — ' + theme['label'] if home else page_title + ' — ' + title
        return (f'<!doctype html>\n<html lang="ru"><head><meta charset="utf-8">'
                '<meta name="viewport" content="width=device-width,initial-scale=1">'
                f'<title>{_escape(document_title)}</title>'
                f'<meta name="description" content="{_escape(theme["intro"])}">'
                '<link rel="stylesheet" href="assets/fonts.css">'
                f'<link rel="stylesheet" href="assets/{"north" if template == "north" else "living"}.css">'
                '<link rel="stylesheet" href="assets/articles.css">'
                '<link rel="stylesheet" href="assets/premium.css"><link rel="stylesheet" href="assets/variant.css">'
                '<script src="assets/enhance.js" defer></script></head>'
                f'<body class="{template} layout-{layout} {"home-" + template if home else "inner-page"}">'
                '<a class="skip" href="#content">К содержимому</a>'
                '<div class="reading-track" aria-hidden="true"><span></span></div>'
                + _navigation(template, title, home) +
                f'<main id="content"><div id="{section_id}" data-theme="{template}">{body}</div></main>'
                + _footer(title, theme['label']) + '</body></html>\n')

    if template == 'north':
        home = assets['north.html'].decode('utf-8')
        home = home.replace('@@TITLE@@', _escape(title)).replace('@@STORIES@@', _north_stories(articles[:2]))
        home = home.replace('@@ATLAS@@', _north_atlas(articles[2:]))
        home = home.replace('alt="Человек в большом природном пространстве"', 'alt="Дорога среди скал"')
    else:
        home = assets[template + '.html'].decode('utf-8')
        heading = 'Красота в простых решениях.' if template == 'still' else 'Хороший вкус — не случайность.'
        home += (f'<section class="{"seditorial" if template == "still" else "rjournal"}" id="stories">'
                 '<div class="wrap"><div class="sectionhead"><div><div class="eyebrow">'
                 f'ПЯТЬ ИСТОРИЙ / {_escape(title)}</div><h2>{heading}</h2></div>'
                 '<a href="notes.html">Все истории ↗</a></div>'
                 + _living_list(template, articles, bool(layout)) + '</div></section>')
    notes = ('<header class="page-intro"><span class="eyebrow">ПЯТЬ ИСТОРИЙ / ОДИН ЖУРНАЛ</span>'
             '<h1>Читать не спеша.</h1><p>' + _escape(theme['intro']) + '</p></header>')
    if template == 'north':
        notes += '<section class="container stories">' + _north_stories(articles[:2]) + _north_atlas(articles[2:]) + '</section>'
    else:
        notes += f'<section class="{"seditorial" if template == "still" else "rjournal"}"><div class="wrap">'
        notes += _living_list(template, articles, True) + '</div></section>'
    about = ('<header class="page-intro"><span class="eyebrow">О ЖУРНАЛЕ</span>'
             f'<h1>{_escape(title)}</h1><p>{_escape(theme["about"])}</p></header>'
             '<section class="about-copy"><h2>Наблюдать. Пробовать. Беречь.</h2>'
             f'<p>{_escape(theme["caution"])}</p><p>Это общие редакционные заметки, а не репортажи о '
             'конкретных объектах. Здесь нет вымышленных авторов, отзывов, адресов или обещаний результата.</p>'
             '<h2 id="sources">Фотографии и шрифты</h2><p>Фотографии из Unsplash использованы как иллюстрации. '
             'Они не подтверждают посещение мест, авторство интерьеров или происхождение кофе. '
             'Имена фотографов и точные локации не установлены; мы их не придумываем. '
             'Copyright-лицензия не гарантирует разрешения на изображённые бренды, людей и произведения искусства.</p>'
             '<p class="sources-note">Интерьерная иллюстрация кадрирована: настенные фотографии и обложки '
             'книг исключены, сохранены свет, окно, растение и диван. Это не утверждение о полной юридической '
             'проверке: перед рекламным или иным чувствительным использованием оцените необходимость '
             'дополнительных разрешений. Этот комплект — интегрированный журнал, не самостоятельный фотобанк.</p>'
             '<p><a href="assets/ASSET-SOURCES.txt">Исходные URL и условия использования</a>. '
             'Локальные Manrope и Cormorant Garamond распространяются по SIL Open Font License 1.1: '
             '<a href="assets/Manrope-OFL.txt">Manrope OFL</a>, '
             '<a href="assets/CormorantGaramond-OFL.txt">Cormorant Garamond OFL</a>.</p></section>')
    result = {'index.html': page(title, home, home=True).encode('utf-8'),
              'notes.html': page('Истории', notes).encode('utf-8'),
              'about.html': page('О журнале', about).encode('utf-8')}
    for index, article in enumerate(articles):
        result[_link(article)] = page(
            article['title'], _article_body(article, articles[(index + 1) % 5], title, index + 1),
            reader=True).encode('utf-8')
    variables = ';'.join(f'{key}:{value}' for key, value in zip(
        ('--paper', '--ink', '--accent', '--wash', '--line'), palette))
    # Keep declarations and consumers beside the images: var() URL substitution
    # must resolve correctly from every consuming stylesheet, including subpaths.
    result['assets/variant.css'] = (f':root{{{variables};--crop:{crop};'
                                    f'--hero-image:url("{hero}");--pause-image:url("{pause}")}}\n').encode('utf-8')
    public_assets = ['fonts.css', 'articles.css', 'premium.css', 'enhance.js',
                     'north.css' if template == 'north' else 'living.css',
                     'Manrope.ttf', 'CormorantGaramond.ttf', 'CormorantGaramond-Italic.ttf',
                     'Manrope-OFL.txt', 'CormorantGaramond-OFL.txt', 'ASSET-SOURCES.txt']
    photos = {a['image'] for a in articles} | {hero}
    if template == 'north':
        photos.add(pause)
    for name in public_assets + sorted(photos):
        result['assets/' + name] = assets[name]
    if sum(map(len, result.values())) > MAX_BYTES:
        site_tool.fail('The premium site exceeds the size limit.')
    return result


def _inventory(source, expected):
    """Exact inventory, including empty directories; no extension-based JS waiver."""
    source = site_tool.absolute(source)
    site_tool.check_ancestors(source)
    site_tool.checked_stat(source)
    if not site_tool.safe_name(source.name):
        site_tool.fail('The premium source directory has an unsafe name.')
    allowed_dirs = {p.as_posix() for name in expected for p in PurePosixPath(name).parents
                    if p.as_posix() != '.'}
    files = {}
    directories = set()
    total = 0
    entries = 0

    def visit(directory):
        nonlocal total, entries
        with os.scandir(directory) as iterator:
            for entry in iterator:
                entries += 1
                if entries > len(expected) + len(allowed_dirs):
                    site_tool.fail('The premium site contains unexpected entries.')
                if not site_tool.safe_name(entry.name):
                    site_tool.fail('Hidden or unsafe premium entries are not allowed.')
                path = Path(entry.path)
                name = path.relative_to(source).as_posix()
                info = site_tool.checked_stat(path)
                if stat.S_ISDIR(info.st_mode):
                    if name not in allowed_dirs:
                        site_tool.fail('The premium site contains an unexpected directory.')
                    directories.add(name)
                    visit(path)
                elif stat.S_ISREG(info.st_mode):
                    if info.st_nlink != 1:
                        site_tool.fail('Hard-linked premium files are not allowed.')
                    if name not in expected or info.st_size != len(expected[name]):
                        site_tool.fail('The premium site does not match the trusted render.')
                    total += info.st_size
                    if total > MAX_BYTES:
                        site_tool.fail('The premium site exceeds the size limit.')
                    files[name] = info
                else:
                    site_tool.fail('Only ordinary premium files and directories are allowed.')
    visit(source)
    if set(files) != set(expected) or directories != allowed_dirs:
        site_tool.fail('The premium site is incomplete or contains unexpected entries.')
    return source, files


def _verify(source, expected):
    source, inventory = _inventory(source, expected)
    for name, info in inventory.items():
        if site_tool.read_regular(source / name, info) != expected[name]:
            site_tool.fail('The premium site does not match the trusted render.')
    # Catch additions and identity changes that occurred while reading.
    _, after = _inventory(source, expected)
    for name, info in inventory.items():
        current = after[name]
        if (info.st_dev, info.st_ino, info.st_size, info.st_mtime_ns) != (
                current.st_dev, current.st_ino, current.st_size, current.st_mtime_ns):
            site_tool.fail('The premium source changed during validation.')
    return source


def _publish(expected, output, source=None):
    output = site_tool.prepare_output(output, source)
    staging = Path(tempfile.mkdtemp(prefix='.premium-staging-', dir=output.parent))
    try:
        public = staging / 'public'
        public.mkdir()
        for name, data in expected.items():
            target = public / name
            target.parent.mkdir(parents=True, exist_ok=True)
            with target.open('xb') as stream:
                stream.write(data)
        _verify(public, expected)
        for directory, _, names in os.walk(public):
            os.chmod(directory, 0o755)
            for name in names:
                os.chmod(Path(directory) / name, 0o644)
        site_tool.prepare_output(output, source)
        site_tool.rename_no_replace(public, output)
    finally:
        shutil.rmtree(staging)
    return output


def generate(manifest: dict, output) -> Path:
    """Render and atomically publish to an absent output; never overwrite."""
    return _publish(expected_files(manifest), output)


def copy_generated(source, output, manifest: dict) -> Path:
    """Accept only byte-for-byte renderer output for this private manifest.

    JavaScript is allowed only at the exact trusted filename and exact bytes.
    Source-supplied hashes, signatures or marker files grant no authority.
    Publication writes trusted rendered bytes, not a subsequently reopened input.
    """
    site_tool.prepare_output(output, source)
    expected = expected_files(manifest)
    source = _verify(source, expected)
    return _publish(expected, output, source)
