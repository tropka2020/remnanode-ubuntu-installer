"""Pure validation for dynamically selected official tblocker release assets."""
import hashlib
import json
import re
from urllib.parse import urlsplit

API_URL = 'https://api.github.com/repos/kutovoys/xray-torrent-blocker/releases/latest'
PREFIX = 'https://github.com/kutovoys/xray-torrent-blocker/releases/download/'
MAX_METADATA = 2 * 1024 * 1024
MAX_PACKAGE = 128 * 1024 * 1024


def official_download(value, tag):
    if not isinstance(value, str) or not value.startswith(PREFIX + tag + '/'):
        raise ValueError('Unexpected upstream asset URL')
    parsed = urlsplit(value)
    if parsed.query or parsed.fragment or parsed.username or parsed.password:
        raise ValueError('Unexpected upstream asset URL components')
    name = parsed.path.rsplit('/', 1)[-1]
    if not re.fullmatch(r'[A-Za-z0-9._-]+', name):
        raise ValueError('Unsafe upstream asset filename')
    return value


def select_release(data, arch):
    if arch not in ('amd64', 'arm64'):
        raise ValueError('Unsupported package architecture')
    if len(data) > MAX_METADATA:
        raise ValueError('Release metadata exceeds limit')
    metadata = json.loads(data)
    if not isinstance(metadata, dict) or metadata.get('draft') is not False or metadata.get('prerelease') is not False:
        raise ValueError('Expected a stable published release')
    tag = metadata.get('tag_name')
    if not isinstance(tag, str) or not re.fullmatch(r'v?[0-9]+\.[0-9]+\.[0-9]+(?:[-+][A-Za-z0-9.-]+)?', tag):
        raise ValueError('Unexpected release tag')
    assets = metadata.get('assets')
    if not isinstance(assets, list):
        raise ValueError('Release assets missing')
    version = tag.removeprefix('v')
    name = f'tblocker_{version}_linux_{arch}.deb'
    matches = [item for item in assets if isinstance(item, dict) and item.get('name') == name]
    if len(matches) != 1:
        raise ValueError('Expected exactly one official DEB for architecture')
    asset = matches[0]
    size = asset.get('size')
    if type(size) is not int or not 0 < size <= MAX_PACKAGE:
        raise ValueError('Invalid package size')
    digest = asset.get('digest')
    if digest is not None and not re.fullmatch(r'sha256:[0-9a-f]{64}', str(digest)):
        raise ValueError('Unexpected asset digest')
    checksums = [item for item in assets if isinstance(item, dict) and item.get('name') == 'checksums.txt']
    if len(checksums) != 1:
        raise ValueError('Expected official checksums.txt')
    return {
        'tag': tag, 'version': version, 'arch': arch, 'name': name, 'size': size,
        'url': official_download(asset.get('browser_download_url'), tag),
        'digest': digest.split(':', 1)[1] if digest else None,
        'checksums_url': official_download(checksums[0].get('browser_download_url'), tag),
    }


def package_digest(checksum_bytes, release):
    if len(checksum_bytes) > MAX_METADATA:
        raise ValueError('Checksum metadata exceeds limit')
    digests = []
    for line in checksum_bytes.decode('utf-8').splitlines():
        match = re.fullmatch(r'([0-9a-f]{64})[ \t]+\*?([^\s]+)', line)
        if not match:
            raise ValueError('Malformed release checksums')
        if match[2] == release['name']:
            digests.append(match[1])
    if len(digests) != 1:
        raise ValueError('Package checksum missing or duplicated')
    if release['digest'] is not None and release['digest'] != digests[0]:
        raise ValueError('GitHub asset digest disagrees with checksums.txt')
    return digests[0]


def verify_package(data, release, expected):
    if len(data) != release['size'] or len(data) > MAX_PACKAGE:
        raise ValueError('Package size mismatch')
    if not data.startswith(b'!<arch>\n'):
        raise ValueError('Not a Debian archive')
    if hashlib.sha256(data).hexdigest() != expected:
        raise ValueError('Package SHA256 mismatch')
