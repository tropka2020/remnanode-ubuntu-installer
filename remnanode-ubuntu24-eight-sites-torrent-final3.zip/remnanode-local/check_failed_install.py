#!/usr/bin/env python3
"""Read-only recovery summary. Never print profiles, Compose, keys or tokens."""
import json
import os
from pathlib import Path
import subprocess
import sys


def command(args):
    print('\n=== ' + ' '.join(args) + ' ===', flush=True)
    try:
        result = subprocess.run(args, capture_output=True, text=True, timeout=20)
        # Only fixed diagnostic commands below, with bounded output.
        output = (result.stdout + result.stderr)[-16000:]
        print(''.join(c if c in '\n\t' or c.isprintable() else '?' for c in output))
        print('exit:', result.returncode)
    except (OSError, subprocess.TimeoutExpired) as exc:
        print('недоступно:', type(exc).__name__)


def main():
    if sys.platform != 'linux' or os.geteuid() != 0:
        raise SystemExit('Запустите на сервере от root. Диагностика только чтение.')
    for args in (['df', '-hT', '/'], ['lsblk', '-o', 'NAME,SIZE,TYPE,FSTYPE,MOUNTPOINTS'],
                 ['docker', 'ps', '-a', '--format', 'table {{.Names}}\t{{.Status}}\t{{.Image}}'],
                 ['docker', 'volume', 'ls'],
                 ['dpkg-query', '-W', '-f=${Package}: ${Status}\n', 'fail2ban', 'python3-systemd', 'nftables', 'tblocker', 'conntrack'],
                 ['systemctl', 'show', 'tblocker.service', '--property=LoadState,ActiveState,SubState,UnitFileState,Result,ExecMainStatus,NRestarts'],
                 ['dpkg', '--audit'], ['systemctl', 'is-active', 'fail2ban'],
                 ['systemctl', 'is-enabled', 'fail2ban'], ['ufw', 'status'],
                 ['ss', '-lnt', 'sport = :22 or sport = :80 or sport = :443 or sport = :2222 or sport = :9443']):
        command(args)
    print('\n=== Известные пути (без чтения секретов) ===')
    for name in ('/opt/remnanode', '/opt/caddy', '/opt/remnanode-local',
                 '/var/log/remnanode', '/var/lib/remnanode-design',
                 '/usr/local/bin/selfsteal', '/usr/sbin/policy-rc.d',
                 '/opt/tblocker', '/etc/systemd/system/tblocker.service'):
        path = Path(name)
        if os.path.lexists(path):
            info = path.lstat()
            print(name, 'symlink' if path.is_symlink() else 'directory' if path.is_dir() else 'file',
                  oct(info.st_mode & 0o777), 'uid=' + str(info.st_uid))
        else:
            print(name, 'нет')
    print('\n=== Имена приватных журналов (содержимое не выводится) ===')
    base = Path('/var/backups/remnanode-local')
    if base.is_dir() and not base.is_symlink():
        for path in sorted(base.iterdir()):
            if path.is_symlink() or not path.is_dir():
                continue
            print(path.name, 'state.json=' + str((path / 'state.json').is_file()),
                  'rollback.py=' + str((path / 'rollback.py').is_file()))
    print('\nНичего не удалено, службы и настройки не изменялись.')


if __name__ == '__main__':
    main()
