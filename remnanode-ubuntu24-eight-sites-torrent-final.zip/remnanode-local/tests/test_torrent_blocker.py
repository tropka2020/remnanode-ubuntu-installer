"""Offline safety tests for torrent_blocker; no privileged/network commands run."""
from pathlib import Path
import importlib.util
import json
from types import SimpleNamespace
import unittest
from unittest.mock import patch
import tempfile

PROJECT = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location("torrent_blocker_tested", PROJECT / "torrent_blocker.py")
torrent = importlib.util.module_from_spec(spec)
spec.loader.exec_module(torrent)


class FakeRunner:
    def __init__(self, root, *, firewall="*filter\n-A INPUT -j ACCEPT\nCOMMIT\n"):
        self.root = Path(root)
        self.firewall = firewall
        self.calls = []
        self.child_calls = []
        self.download_calls = []
        self.active = "inactive"
        self.enabled = "disabled"
        self.restarts = "0\n"
        self.fail_child = False
        self.commands = {"curl", "bash", "iptables", "iptables-save", "conntrack", "systemctl"}

    def which(self, name):
        return "/usr/bin/" + name if name in self.commands else None

    def run(self, args, **kwargs):
        args = [str(item) for item in args]
        self.calls.append((args, kwargs))
        if args == ["iptables-save"]:
            return SimpleNamespace(returncode=0 if self.firewall else 1, stdout=self.firewall)
        if args == ["systemctl", "is-active", "tblocker.service"]:
            return SimpleNamespace(returncode=0 if self.active == "active" else 3,
                                   stdout=self.active + "\n")
        if args == ["systemctl", "is-enabled", "tblocker.service"]:
            return SimpleNamespace(returncode=0 if self.enabled == "enabled" else 1,
                                   stdout=self.enabled + "\n")
        if args[:3] == ["systemctl", "show", "tblocker.service"]:
            return SimpleNamespace(returncode=0, stdout=self.restarts)
        if args == ["systemctl", "stop", "tblocker.service"]:
            self.active = "inactive"
            return SimpleNamespace(returncode=0, stdout="")
        if args == ["systemctl", "disable", "tblocker.service"]:
            self.enabled = "disabled"
            return SimpleNamespace(returncode=0, stdout="")
        forbidden = {"ufw", "nft", "iptables", "ip6tables"}
        if args and args[0] in forbidden and args != ["iptables-save"]:
            raise AssertionError("firewall mutation is forbidden: " + repr(args))
        return SimpleNamespace(returncode=0, stdout="")

    def download(self, url, destination, *, timeout):
        self.download_calls.append((url, Path(destination), timeout))
        Path(destination).write_text("#!/usr/bin/env bash\n", encoding="utf-8")

    def child(self, argv, *, input_text, timeout):
        self.child_calls.append((list(map(str, argv)), input_text, timeout))
        if self.fail_child:
            raise torrent.m.Failure("hidden upstream failure")
        blocker = self.root / "opt" / "tblocker"
        blocker.mkdir(parents=True, exist_ok=True)
        (blocker / "config.yaml").write_text(
            "LogFile: /var/log/remnanode/access.log\nBlockMode: iptables\n",
            encoding="utf-8",
        )
        unit = self.root / "etc" / "systemd" / "system" / "tblocker.service"
        unit.parent.mkdir(parents=True, exist_ok=True)
        unit.write_text("[Unit]\nDescription=test\n", encoding="utf-8")
        self.active, self.enabled = "active", "enabled"
        return SimpleNamespace(returncode=0, stdout="")


class TorrentBlockerTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory(prefix="torrent-blocker-")
        self.addCleanup(self.tmp.cleanup)
        self.root = Path(self.tmp.name)
        (self.root / "opt").mkdir()
        self.paths = torrent.InstallPaths(
            blocker_dir=self.root / "opt" / "tblocker",
            config=self.root / "opt" / "tblocker" / "config.yaml",
            unit=self.root / "etc" / "systemd" / "system" / "tblocker.service",
            backup_dir=self.root / "backups",
            download_dir=self.root / "opt",
        )
        self.runner = FakeRunner(self.root)
        self.backup = self.root / "private-backup"

    def test_success_passes_defaults_to_child_and_verifies_upstream_outputs(self):
        change = torrent.install(runner=self.runner, paths=self.paths, backup=self.backup)
        self.assertTrue(self.paths.config.is_file())
        self.assertIn("LogFile: /var/log/remnanode/access.log", self.paths.config.read_text())
        self.assertIn("BlockMode: iptables", self.paths.config.read_text())
        self.assertEqual(self.runner.child_calls[0][1],
                         "/var/log/remnanode/access.log\ny\n1\n")
        self.assertEqual(self.runner.child_calls[0][0][0], "bash")
        self.assertEqual(self.runner.active, "active")
        self.assertEqual(self.runner.enabled, "enabled")
        self.assertTrue(change.owned_files)
        self.assertFalse(list(self.paths.download_dir.glob(".tblocker-install-*")))

    def test_rollback_stops_only_own_service_and_backs_up_then_removes_own_files(self):
        change = torrent.install(runner=self.runner, paths=self.paths, backup=self.backup)
        change.rollback()
        self.assertEqual(self.runner.active, "inactive")
        self.assertEqual(self.runner.enabled, "disabled")
        self.assertFalse(self.paths.blocker_dir.exists())
        self.assertFalse(self.paths.unit.exists())
        saved = list((self.backup / "files").rglob("*"))
        self.assertTrue(any(path.is_file() for path in saved))
        count = len(self.runner.calls)
        change.rollback()
        self.assertEqual(len(self.runner.calls), count)
        self.assertFalse(any(call[0][0] in ("ufw", "nft", "iptables", "ip6tables")
                             and call[0] != ["iptables-save"] for call in self.runner.calls))

    def test_preflight_refuses_active_or_foreign_service_without_download(self):
        self.runner.active = "active"
        with self.assertRaises(torrent.m.Failure):
            torrent.install(runner=self.runner, paths=self.paths, backup=self.backup)
        self.assertFalse(self.runner.download_calls)
        self.assertFalse(self.paths.blocker_dir.exists())

    def test_preflight_refuses_unknown_firewall_without_mutation(self):
        self.runner.firewall = "iptables-save output not parseable"
        with self.assertRaises(torrent.m.Failure):
            torrent.install(runner=self.runner, paths=self.paths, backup=self.backup)
        self.assertFalse(self.runner.download_calls)
        self.assertFalse(self.paths.blocker_dir.exists())
        self.assertFalse(any(call[0][0] in ("ufw", "nft", "iptables", "ip6tables")
                             and call[0] != ["iptables-save"] for call in self.runner.calls))

    def test_missing_conntrack_is_fail_closed(self):
        self.runner.commands.remove("conntrack")
        with self.assertRaisesRegex(torrent.m.Failure, "conntrack"):
            torrent.preflight(runner=self.runner, paths=self.paths)
        self.assertFalse(self.runner.download_calls)

    def test_upstream_failure_rolls_back_service_and_files_without_leaking_diagnostic(self):
        self.runner.fail_child = True
        with self.assertRaises(torrent.m.Failure) as caught:
            torrent.install(runner=self.runner, paths=self.paths, backup=self.backup)
        self.assertNotIn("hidden upstream failure", str(caught.exception))
        self.assertFalse(self.paths.blocker_dir.exists())
        self.assertFalse(self.paths.unit.exists())
        self.assertFalse(list(self.paths.download_dir.glob(".tblocker-install-*")))

    def test_bad_upstream_config_is_not_accepted(self):
        original = self.runner.child

        def child(argv, *, input_text, timeout):
            result = original(argv, input_text=input_text, timeout=timeout)
            self.paths.config.write_text("LogFile: /tmp/other\nBlockMode: iptables\n", encoding="utf-8")
            return result

        self.runner.child = child
        with self.assertRaises(torrent.m.Failure) as caught:
            torrent.install(runner=self.runner, paths=self.paths, backup=self.backup)
        self.assertNotIn("/tmp/other", str(caught.exception))
        self.assertFalse(self.paths.blocker_dir.exists())
        self.assertFalse(self.paths.unit.exists())

    def test_invalid_url_and_defaults_fail_before_preflight_or_download(self):
        for kwargs in (
            {"upstream_url": "http://example.test/install.sh"},
            {"defaults": {"LogFile": "/tmp/secret", "BlockMode": "iptables"}},
        ):
            with self.subTest(kwargs=kwargs), self.assertRaises(torrent.m.Failure):
                torrent.install(runner=self.runner, paths=self.paths, backup=self.backup, **kwargs)
        self.assertFalse(self.runner.calls)
        self.assertFalse(self.runner.download_calls)


if __name__ == "__main__":
    unittest.main()
