"""Install a self-contained, root-owned local manager; never deploy services."""
import ast
import os
from pathlib import Path
import shlex
import shutil
import sys
import tempfile

import manage as m

RUNTIME = Path('/usr/local/lib/remnanode-manager')
WRAPPER = Path('/usr/local/bin/selfsteal')
MARKER = '# remnanode-manager managed runtime v1'
MODULES = ('manage.py', 'progress.py', 'selfsteal.py', 'command_runtime.py',
           'site.py', 'themed_site.py', 'premium_site.py', 'premium_expanded.py',
           'design_catalog.py', 'torrent_blocker.py')
# Exact snapshot of premium_site.ASSET_FILES; deliberately no eager generator import.
ASSET_FILES = (
    'north.html', 'still.html', 'ritual.html', 'north.css', 'living.css',
    'articles.css', 'premium.css', 'enhance.js', 'fonts.css',
    'editorial.json', 'editorial-extra.json',
    'Manrope.ttf', 'CormorantGaramond.ttf', 'CormorantGaramond-Italic.ttf',
    'Manrope-OFL.txt', 'CormorantGaramond-OFL.txt', 'ASSET-SOURCES.txt',
    'mountain.jpg', 'forest.jpg', 'lake.jpg', 'night.jpg', 'meadow.jpg',
    'interior.jpg', 'coffee.jpg',
    'afterlight.html', 'afterlight.css', 'afterlight.js',
    'afterlight-editorial.json', 'afterlight-SOURCES.txt',
    'afterlight-forest.jpg', 'afterlight-window.jpg',
    'afterlight-night.jpg', 'afterlight-lake.jpg',
    'form.html', 'form.css', 'form.js', 'form-editorial.json', 'form-SOURCES.txt',
    'form-clay.jpg', 'form-wood.jpg', 'form-linen.jpg', 'form-repair.jpg', 'form-care.jpg',
    'common.html', 'common.css', 'common.js', 'common-editorial.json', 'common-SOURCES.txt',
    'common-coffee.jpg', 'common-light.jpg', 'common-roast.jpg', 'common-table.jpg',
    'orbit.html', 'orbit.css', 'orbit.js', 'orbit-editorial.json', 'orbit-SOURCES.txt',
    'orbit-sky.jpg', 'orbit-moon.jpg', 'orbit-city.jpg', 'orbit-pleiades.jpg',
    'index.html', 'index.css', 'index.js', 'index-editorial.json', 'index-SOURCES.txt',
    'index-hours-jpg.jpg', 'index-titlepage.jpg', 'index-gilded-jpg.jpg', 'index-ledger-jpg.jpg',
)


def require_root():
    if sys.platform != 'linux' or os.geteuid() != 0:
        raise m.Failure('Изменения разрешены только от root на Linux.')


def _wrapper():
    return ('#!/bin/sh\n' + MARKER + '\nexec /usr/bin/python3 ' +
            shlex.quote(str(RUNTIME / 'selfsteal.py')) + ' "$@"\n').encode('utf-8')


def check_conflict(source: Path):
    """Preflight without reading source or changing files; reject foreign commands."""
    for path, directory in ((WRAPPER, False), (RUNTIME, True)):
        m.secure_path(path, directory=directory)
    if WRAPPER.exists() and (WRAPPER.stat().st_size > 4096 or WRAPPER.read_bytes() != _wrapper()):
        raise m.Failure('Чужой /usr/local/bin/selfsteal: перезапись запрещена.')
    if RUNTIME.exists():
        marker = RUNTIME / '.managed-runtime'
        m.secure_path(marker, directory=False)
        if (not marker.is_file() or marker.stat().st_size > 4096 or
                marker.read_bytes() != (MARKER + '\n').encode()):
            raise m.Failure('Неизвестный каталог runtime: перезапись запрещена.')
        # Validate every previous entry before it can become a removable backup.
        for directory, dirs, files in os.walk(RUNTIME, followlinks=False):
            for name in dirs:
                m.secure_path(Path(directory) / name, directory=True)
            for name in files:
                m.secure_path(Path(directory) / name, directory=False)


def _asset_files(premium_source):
    # Read the trusted generator's explicit export without executing downloaded
    # Python or eagerly loading premium_site for legacy commands.
    try:
        tree = ast.parse(premium_source)
        exports = [node.value for node in tree.body if isinstance(node, ast.Assign)
                   and any(isinstance(target, ast.Name) and target.id == 'ASSET_FILES'
                           for target in node.targets)]
        if len(exports) != 1:
            raise ValueError('missing or duplicate export')
        names = ast.literal_eval(exports[0])
        if (not isinstance(names, (list, tuple)) or not names or
                any(not isinstance(name, str) or not name or name.startswith('.') or
                    '/' in name or '\\' in name or ':' in name or
                    any(ord(char) < 32 for char in name) for name in names) or
                len(names) != len(set(names))):
            raise ValueError('unsafe asset name')
        return tuple(names)
    except (SyntaxError, ValueError, TypeError) as exc:
        raise m.Failure('Неизвестный ASSET_FILES export premium генератора.') from exc


def _write(path, data, mode):
    with path.open('xb') as stream:
        stream.write(data)
        stream.flush()
        os.fsync(stream.fileno())
    os.chmod(path, mode)


def install_runtime(source: Path):
    """Copy only the runtime allowlist and atomically replace with rollback."""
    require_root()
    check_conflict(source)  # Foreign wrapper must fail before any source read.
    source = Path(source)
    m.secure_path(source, directory=True)
    payload = {}
    for name in MODULES:
        path = source / name
        m.secure_path(path, directory=False)
        payload[name] = path.read_bytes()
    m.secure_path(source / 'premium_assets', directory=True)
    for name in _asset_files(payload['premium_site.py']):
        path = source / 'premium_assets' / name
        m.secure_path(path, directory=False)
        payload['premium_assets/' + name] = path.read_bytes()
    RUNTIME.parent.mkdir(mode=0o755, parents=True, exist_ok=True)
    WRAPPER.parent.mkdir(mode=0o755, parents=True, exist_ok=True)
    staging = Path(tempfile.mkdtemp(prefix='.manager-stage-', dir=RUNTIME.parent))
    backup = staging / 'previous'
    candidate = staging / 'runtime'
    candidate.mkdir(mode=0o755)
    (candidate / 'premium_assets').mkdir(mode=0o755)
    wrapper_stage = None
    moved_old = installed = wrapper_replaced = False
    previous_wrapper = WRAPPER.read_bytes() if WRAPPER.exists() else None
    try:
        for name, data in payload.items():
            _write(candidate / name, data, 0o644)
        _write(candidate / '.managed-runtime', (MARKER + '\n').encode(), 0o644)
        os.chmod(candidate, 0o755)
        os.chmod(candidate / 'premium_assets', 0o755)
        fd, filename = tempfile.mkstemp(prefix='.selfsteal-', dir=WRAPPER.parent)
        os.close(fd)
        wrapper_stage = Path(filename)
        wrapper_stage.write_bytes(_wrapper())
        os.chmod(wrapper_stage, 0o755)
        if RUNTIME.exists():
            RUNTIME.rename(backup)
            moved_old = True
        candidate.rename(RUNTIME)
        installed = True
        os.replace(wrapper_stage, WRAPPER)
        wrapper_replaced = True
    except BaseException:
        if wrapper_replaced:
            if previous_wrapper is None:
                WRAPPER.unlink()
            else:
                # This branch also covers future checks added after wrapper installation.
                m.atomic_write(WRAPPER, previous_wrapper.decode('utf-8'), mode=0o755)
        if installed and RUNTIME.exists():
            RUNTIME.rename(staging / 'failed-runtime')
        if moved_old and not RUNTIME.exists() and backup.exists():
            backup.rename(RUNTIME)
        raise
    finally:
        if wrapper_stage is not None and wrapper_stage.exists():
            wrapper_stage.unlink()
        # Never delete the only surviving previous runtime if rollback itself failed.
        if not backup.exists():
            shutil.rmtree(staging, ignore_errors=True)
    if backup.exists():
        # Installation is committed. Cleanup failure must not report a failed
        # installation with a newly live runtime; an inaccessible backup is safe.
        shutil.rmtree(staging, ignore_errors=True)
