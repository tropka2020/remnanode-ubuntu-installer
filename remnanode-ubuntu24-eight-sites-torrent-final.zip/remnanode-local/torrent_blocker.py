"""Fail-closed orchestration for the upstream xray torrent blocker.

This module deliberately does not implement the blocker or author its YAML.  It
only downloads the upstream installer into a private temporary directory,
executes it as a child process, and verifies the result.  All command and
filesystem boundaries are injectable so development and tests never execute
APT, systemd, iptables, conntrack, or network commands.
"""
from dataclasses import dataclass
import hashlib
import os
from pathlib import Path
import shutil
import stat
import subprocess
import tempfile
from types import SimpleNamespace
from urllib.parse import urlparse

import manage as m

DEFAULT_UPSTREAM_INSTALLER_URL = "https://raw.githubusercontent.com/kutovoys/xray-torrent-blocker/main/install.sh"
LOG_FILE = "/var/log/remnanode/access.log"
BLOCK_MODE = "iptables"
SERVICE = "tblocker.service"
CONFIG = "/opt/tblocker/config.yaml"
MAX_RESTARTS = 3


@dataclass(frozen=True)
class InstallPaths:
    """Paths used by one transaction; tests provide a temporary tree."""

    blocker_dir: Path = Path("/opt/tblocker")
    config: Path = Path(CONFIG)
    unit: Path = Path("/etc/systemd/system/tblocker.service")
    backup_dir: Path = Path("/var/backups/remnanode-local")
    download_dir: Path = Path("/opt")


@dataclass
class CommandRunner:
    """Command boundary used by :func:`install`.

    ``run`` receives argv as a list and must return an object with
    ``returncode`` and ``stdout``.  ``download`` and ``child`` are separate
    methods to make it impossible for an implementation to accidentally pipe
    a network response into a shell.
    """

    run: object
    which: object = shutil.which
    download: object = None
    child: object = None

    def __post_init__(self):
        if self.download is None:
            self.download = self._download
        if self.child is None:
            self.child = self._child

    def _download(self, url, destination, *, timeout=600):
        return self.run(
            [
                "curl",
                "--disable",
                "--fail",
                "--silent",
                "--show-error",
                "--location",
                "--proto",
                "=https",
                "--proto-redir",
                "=https",
                "--connect-timeout",
                "30",
                "--max-time",
                str(timeout),
                "--output",
                str(destination),
                "--",
                url,
            ],
            timeout=timeout,
        )

    def _child(self, argv, *, input_text, timeout=900):
        # This is deliberately a child process, never shell=True/source/pipe.
        try:
            result = subprocess.run(
                [str(item) for item in argv],
                input=input_text,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True,
                encoding="utf-8",
                timeout=timeout,
                check=False,
                env={**os.environ, "LC_ALL": "C", "LANG": "C"},
            )
        except (OSError, subprocess.TimeoutExpired) as exc:
            raise m.Failure("Upstream torrent blocker installer недоступен или превысил таймаут.") from exc
        if result.returncode:
            raise m.Failure("Upstream torrent blocker installer завершился ошибкой; вывод скрыт.")
        return result


class Transaction:
    """Owns only the files created by this invocation and its service."""

    def __init__(self, paths, backup, runner, owned_files=()):
        self.paths = paths
        self.backup = backup
        self.runner = runner
        self.owned_files = list(owned_files)
        self.service_started = False
        self._done = False

    @staticmethod
    def _digest(path):
        return hashlib.sha256(path.read_bytes()).hexdigest()

    def _safe_file(self, path):
        path = Path(path)
        if path.is_symlink() or not path.is_file():
            raise m.Failure("Откат tblocker остановлен: небезопасный файл " + str(path))
        info = path.stat()
        if info.st_nlink != 1:
            raise m.Failure("Откат tblocker остановлен: hard link " + str(path))
        if os.name == "posix" and hasattr(os, "geteuid") and os.geteuid() == 0:
            if info.st_uid != 0 or info.st_mode & 0o022:
                raise m.Failure("Откат tblocker остановлен: файл не root-only " + str(path))
        return info

    def _snapshot_paths(self):
        result = []
        root = self.paths.blocker_dir
        if root.exists() or root.is_symlink():
            if root.is_symlink() or not root.is_dir():
                raise m.Failure("Откат tblocker остановлен: каталог подменён.")
            for directory, dirs, files in os.walk(root, topdown=True, followlinks=False):
                directory = Path(directory)
                for name in dirs:
                    item = directory / name
                    if item.is_symlink():
                        raise m.Failure("Откат tblocker остановлен: symlink в каталоге.")
                for name in files:
                    item = directory / name
                    self._safe_file(item)
                    result.append((item, self._digest(item)))
        unit = self.paths.unit
        if unit.exists() or unit.is_symlink():
            self._safe_file(unit)
            result.append((unit, self._digest(unit)))
        return result

    def rollback(self):
        if self._done:
            return
        current = self._snapshot_paths()
        expected = {(Path(path), digest) for path, digest in self.owned_files}
        actual = set(current)
        if not actual.issubset(expected):
            raise m.Failure(
                "Откат tblocker остановлен: обнаружены чужие/изменённые файлы; "
                "ручная проверка: " + str(self.backup)
            )
        if self.service_started:
            active = self.runner.run(["systemctl", "is-active", SERVICE], check=False, timeout=10)
            if _stdout(active).strip() == "active" and getattr(active, "returncode", 1) == 0:
                self.runner.run(["systemctl", "stop", SERVICE], timeout=60)
            enabled = self.runner.run(["systemctl", "is-enabled", SERVICE], check=False, timeout=10)
            if _stdout(enabled).strip() == "enabled" and getattr(enabled, "returncode", 1) == 0:
                self.runner.run(["systemctl", "disable", SERVICE], timeout=60)
            self.service_started = False
        # Preserve private diagnostics before deleting only the exact owned set.
        for path, digest in current:
            relative = path.name if path == self.paths.unit else path.relative_to(self.paths.blocker_dir)
            destination = self.backup / "files" / ("unit" if path == self.paths.unit else "tblocker") / relative
            destination.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
            shutil.copy2(path, destination)
        for path, _ in reversed(current):
            if path.exists() and not path.is_symlink():
                path.unlink()
        if self.paths.blocker_dir.exists() and not any(self.paths.blocker_dir.iterdir()):
            self.paths.blocker_dir.rmdir()
        self._done = True


def _stdout(result):
    value = getattr(result, "stdout", result)
    return value if isinstance(value, str) else ""


def _returncode(result):
    return getattr(result, "returncode", 0)


def _validate_url(url):
    if not isinstance(url, str):
        raise m.Failure("URL upstream installer должен быть строкой HTTPS.")
    parsed = urlparse(url)
    if parsed.scheme != "https" or not parsed.netloc or parsed.username or parsed.password:
        raise m.Failure("Upstream installer разрешён только по HTTPS без credentials.")
    return url


def _root_preflight():
    if os.name == "posix" and (not hasattr(os, "geteuid") or os.geteuid() != 0):
        raise m.Failure("Установка torrent blocker требует root на Linux.")


def _root_owned_private(path):
    path = Path(path)
    path.mkdir(mode=0o700, parents=True, exist_ok=False)
    os.chmod(path, 0o700)
    if os.name == "posix" and hasattr(os, "geteuid") and os.geteuid() == 0:
        info = path.stat()
        if info.st_uid != 0 or info.st_mode & 0o077:
            raise m.Failure("Временный каталог tblocker не является root-only.")
    return path


def _validate_firewall_snapshot(result):
    if _returncode(result) != 0:
        raise m.Failure("Состояние iptables неизвестно; установка tblocker запрещена.")
    text = _stdout(result)
    if not text or "*filter" not in text or "COMMIT" not in text:
        raise m.Failure("Состояние iptables не подтверждено; установка tblocker запрещена.")


def _validate_private_parent(path):
    """Reject a writable or substituted staging parent before downloading."""
    path = Path(path)
    if path.is_symlink() or not path.is_dir():
        raise m.Failure("Каталог загрузки tblocker не подтверждён.")
    if os.name == "posix":
        info = path.stat()
        if info.st_uid != 0 or info.st_mode & 0o022:
            raise m.Failure("Каталог загрузки tblocker не является root-owned private.")


def _service_state(runner, *, preflight=True):
    active = runner.run(["systemctl", "is-active", SERVICE], check=False, timeout=10)
    enabled = runner.run(["systemctl", "is-enabled", SERVICE], check=False, timeout=10)
    if preflight:
        active_text = _stdout(active).strip()
        enabled_text = _stdout(enabled).strip()
        if active_text == "active" or _returncode(active) == 0 or enabled_text == "enabled" or _returncode(enabled) == 0:
            raise m.Failure("Найден активный или чужой tblocker.service; перезапись запрещена.")
        # Failed/masked/static can represent a foreign or partially installed
        # unit. Only the two unambiguous absent/inactive states are accepted.
        if active_text not in ("inactive", "unknown") or enabled_text not in ("disabled", "not-found"):
            raise m.Failure("Неизвестное состояние tblocker.service; установка остановлена.")
    return active, enabled


def _parse_config(path):
    values = {}
    for line in path.read_text(encoding="utf-8").splitlines():
        stripped = line.strip()
        if not stripped or stripped.startswith("#"):
            continue
        if ":" not in stripped or stripped.startswith(("-", " ")):
            continue
        key, value = stripped.split(":", 1)
        key, value = key.strip(), value.strip()
        if key in values:
            raise m.Failure("В config.yaml обнаружен повторяющийся ключ.")
        if value.startswith(("'", '"')) and value[-1:] == value[:1]:
            value = value[1:-1]
        values[key] = value
    return values


def _verify_result(paths, runner):
    config = paths.config
    if config.is_symlink() or not config.is_file():
        raise m.Failure("Upstream не создал безопасный /opt/tblocker/config.yaml.")
    values = _parse_config(config)
    if values.get("LogFile") != LOG_FILE or values.get("BlockMode") != BLOCK_MODE:
        raise m.Failure("Upstream config.yaml не содержит требуемые LogFile/BlockMode.")
    active, enabled = _service_state(runner, preflight=False)
    if _stdout(active).strip() != "active" or _returncode(active) != 0:
        raise m.Failure("tblocker.service не active после установки.")
    if _stdout(enabled).strip() != "enabled" or _returncode(enabled) != 0:
        raise m.Failure("tblocker.service не enabled после установки.")
    restart = runner.run(
        ["systemctl", "show", SERVICE, "--property=NRestarts", "--value"],
        capture=True,
        timeout=10,
    )
    try:
        restarts = int(_stdout(restart).strip() or "0")
    except ValueError as exc:
        raise m.Failure("Не удалось подтвердить restart state tblocker.service.") from exc
    if _returncode(restart) != 0 or restarts > MAX_RESTARTS:
        raise m.Failure("tblocker.service выглядит как restart loop.")


def preflight(*, runner, paths=InstallPaths()):
    """Read-only checks before any download or filesystem mutation."""
    _root_preflight()
    for command in ("curl", "bash", "iptables", "iptables-save", "conntrack", "systemctl"):
        if runner.which(command) is None:
            raise m.Failure("Не найдена обязательная команда: " + command)
    for path in (paths.blocker_dir, paths.config, paths.unit):
        if path.exists() or path.is_symlink():
            raise m.Failure("Найдена существующая/чужая цель tblocker: " + str(path))
    _service_state(runner)
    _validate_firewall_snapshot(runner.run(["iptables-save"], capture=True, check=False, timeout=15))
    _validate_private_parent(paths.download_dir)
    return True


def install(*, upstream_url=DEFAULT_UPSTREAM_INSTALLER_URL, runner=None,
            paths=InstallPaths(), backup=None, defaults=None):
    """Install and verify upstream tblocker as a rollback-capable transaction.

    Exact parent-installer call contract::

        change = torrent_blocker.install(
            runner=torrent_blocker.CommandRunner(run=m.run),
            defaults={"LogFile": "/var/log/remnanode/access.log",
                      "BlockMode": "iptables"},
        )
        feature_changes.append(change)  # call change.rollback() on later failure

    The parent must invoke this after its own UFW/SSH transaction is committed
    and after Node/Caddy readiness.  A real runner is not used by development
    tests; pass an injected ``CommandRunner`` or a compatible fake.
    """
    _validate_url(upstream_url)
    if runner is None:
        runner = CommandRunner(run=m.run)
    if defaults is None:
        defaults = {"LogFile": LOG_FILE, "BlockMode": BLOCK_MODE}
    if defaults != {"LogFile": LOG_FILE, "BlockMode": BLOCK_MODE}:
        raise m.Failure("Поддерживаются только безопасные defaults LogFile/BlockMode.")
    preflight(runner=runner, paths=paths)
    if backup is None:
        backup = m.backup_dir("tblocker")
    backup = Path(backup)
    if not backup.exists():
        backup.mkdir(mode=0o700, parents=True, exist_ok=False)
    os.chmod(backup, 0o700)
    change = Transaction(paths, backup, runner)
    temporary = None
    try:
        temporary = Path(tempfile.mkdtemp(prefix=".tblocker-install-", dir=paths.download_dir))
        os.chmod(temporary, 0o700)
        downloaded = temporary / "upstream-installer"
        runner.download(upstream_url, downloaded, timeout=600)
        if downloaded.is_symlink() or not downloaded.is_file():
            raise m.Failure("Upstream download не является обычным файлом.")
        os.chmod(downloaded, 0o700)
        # Upstream asks for path, optionally asks to create it, then asks for
        # numeric firewall choice: 1=iptables, 2=nft. Its installer writes YAML.
        log = Path(defaults["LogFile"])
        create_log = "y\n" if not log.exists() else ""
        child_input = defaults["LogFile"] + "\n" + create_log + "1\n"
        runner.child(["bash", str(downloaded)], input_text=child_input, timeout=900)
        change.owned_files = change._snapshot_paths()
        _verify_result(paths, runner)
        change.service_started = True
        return change
    except BaseException as exc:
        try:
            change.owned_files = change._snapshot_paths()
            # A child may have started the service before returning failure.
            active = runner.run(["systemctl", "is-active", SERVICE], check=False, timeout=10)
            change.service_started = _stdout(active).strip() == "active" and _returncode(active) == 0
            change.rollback()
        except BaseException as rollback_error:
            raise m.Failure("tblocker: ошибка применения и отката; ручная проверка: " + str(backup)) from None
        if isinstance(exc, (KeyboardInterrupt, SystemExit)):
            raise
        raise m.Failure("tblocker: применение не подтверждено; собственные изменения отменены: " + str(backup)) from None
    finally:
        if temporary is not None:
            shutil.rmtree(temporary, ignore_errors=False)


__all__ = [
    "BLOCK_MODE",
    "CONFIG",
    "CommandRunner",
    "DEFAULT_UPSTREAM_INSTALLER_URL",
    "InstallPaths",
    "LOG_FILE",
    "SERVICE",
    "Transaction",
    "install",
    "preflight",
]
