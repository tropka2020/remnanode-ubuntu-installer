#!/usr/bin/env python3
"""Generate, validate and copy an owner's static website (Python 3.9+)."""
import argparse
import ctypes
import errno
import html
from html.parser import HTMLParser
import json
import os
from pathlib import Path
import re
import secrets
import shutil
import stat
import sys
import tempfile
from urllib.parse import unquote, urlsplit
import xml.etree.ElementTree as ET

MAX_FILES = 2000
MAX_BYTES = 50 * 1024 * 1024
MAX_CONTENT = 2 * 1024 * 1024
EXTENSIONS = {'.html', '.css', '.svg', '.png', '.jpg', '.jpeg', '.gif', '.webp',
              '.avif', '.ico', '.woff', '.woff2', '.ttf', '.otf', '.txt', '.pdf'}
BAD_ATTRIBUTES = (getattr(stat, 'FILE_ATTRIBUTE_REPARSE_POINT', 0x400) |
                  getattr(stat, 'FILE_ATTRIBUTE_HIDDEN', 2) |
                  getattr(stat, 'FILE_ATTRIBUTE_SYSTEM', 4))


class SiteError(Exception):
    """A safe, user-facing failure; messages never contain user content."""


def fail(message):
    raise SiteError(message)


def checked_stat(path, allow_hidden=False):
    info = path.lstat()
    forbidden = getattr(stat, 'FILE_ATTRIBUTE_REPARSE_POINT', 0x400) if allow_hidden else BAD_ATTRIBUTES
    if stat.S_ISLNK(info.st_mode) or getattr(info, 'st_file_attributes', 0) & forbidden:
        fail('Symbolic links, reparse points and hidden/system entries are not allowed.')
    return info


def check_ancestors(path):
    for part in reversed((path,) + tuple(path.parents)):
        # Hidden/system ancestors (e.g. Windows AppData) are not published.
        info = checked_stat(part, allow_hidden=True)
        if not stat.S_ISDIR(info.st_mode):
            fail('A path ancestor is not an ordinary directory.')


def absolute(path):
    # Do not resolve symlinks before checking them.
    return Path(os.path.abspath(os.fspath(path)))


def safe_name(name):
    reserved = {'CON', 'PRN', 'AUX', 'NUL'} | {p + str(i) for p in ('COM', 'LPT') for i in range(1, 10)}
    return (bool(name) and not name.startswith('.') and not name.endswith((' ', '.'))
            and not any(c in name for c in '<>:"/\\|?*')
            and not any(ord(c) < 32 or ord(c) == 127 for c in name)
            and name.split('.')[0].upper() not in reserved)


def inventory(source):
    source = absolute(source)
    check_ancestors(source)
    checked_stat(source)
    if source.name.startswith('.'):
        fail('A hidden source directory is not allowed.')
    files = {}
    total = 0
    entries = 0

    def visit(directory):
        nonlocal total, entries
        with os.scandir(directory) as iterator:
            for entry in iterator:
                entries += 1
                if entries > MAX_FILES:
                    fail('The site contains too many entries.')
                path = Path(entry.path)
                if not safe_name(entry.name):
                    fail('Hidden or unsafe names are not allowed.')
                info = checked_stat(path)
                if stat.S_ISDIR(info.st_mode):
                    visit(path)
                elif stat.S_ISREG(info.st_mode):
                    if info.st_nlink != 1:
                        fail('Hard-linked files are not allowed.')
                    if path.suffix.lower() not in EXTENSIONS:
                        fail('The site contains an unsupported file type.')
                    total += info.st_size
                    if total > MAX_BYTES:
                        fail('The site exceeds the size limit.')
                    files[path.relative_to(source).as_posix()] = info
                else:
                    fail('Only ordinary files and directories are allowed.')
    visit(source)
    if 'index.html' not in files:
        fail('The site must contain index.html.')
    return source, files


def read_regular(path, expected):
    """Recheck identity around reading; never intentionally follow a link."""
    check_ancestors(path.parent)
    before = checked_stat(path)
    if (before.st_dev, before.st_ino, before.st_size, before.st_mtime_ns) != (
            expected.st_dev, expected.st_ino, expected.st_size, expected.st_mtime_ns):
        fail('The source changed during the operation.')
    flags = os.O_RDONLY | getattr(os, 'O_BINARY', 0) | getattr(os, 'O_NOFOLLOW', 0)
    descriptor = os.open(path, flags)
    with os.fdopen(descriptor, 'rb') as stream:
        opened = os.fstat(stream.fileno())
        if (not stat.S_ISREG(opened.st_mode) or opened.st_nlink != 1 or
                (opened.st_dev, opened.st_ino) != (before.st_dev, before.st_ino)):
            fail('The source changed during the operation.')
        data = stream.read(MAX_BYTES + 1)
        after = os.fstat(stream.fileno())
    if len(data) != before.st_size or after.st_mtime_ns != before.st_mtime_ns:
        fail('The source changed during the operation.')
    checked_stat(path)
    check_ancestors(path.parent)
    return data


def check_url(value, current, files, external=False):
    value = value.strip()
    if not value:
        return
    if any(ord(c) < 32 or ord(c) == 127 for c in value) or '\\' in value:
        fail('An unsafe URL was found.')
    parsed = urlsplit(value)
    if parsed.scheme or parsed.netloc or value.startswith('//'):
        if (external and parsed.scheme.lower() == 'https' and parsed.hostname
                and not parsed.username and not parsed.password and not value.startswith('//')):
            return
        fail('External resources and unsafe URL schemes are not allowed.')
    decoded = unquote(parsed.path, errors='strict')
    if ('\\' in decoded or '%' in decoded or ':' in decoded or
            any(ord(c) < 32 or ord(c) == 127 for c in decoded)):
        fail('An unsafe local URL was found.')
    parts = decoded.split('/')
    if any(p == '..' or p.startswith('.') and p != '' for p in parts):
        fail('Traversal and hidden local URLs are not allowed.')
    if not decoded:
        target = current
    else:
        target = (Path(decoded.lstrip('/')) if decoded.startswith('/') else
                  Path(current).parent / decoded).as_posix()
        if decoded.endswith('/'):
            target = target.rstrip('/') + '/index.html'
        if target == '.':
            target = 'index.html'
        if target not in files and target.rstrip('/') + '/index.html' in files:
            target = target.rstrip('/') + '/index.html'
    if target not in files:
        fail('A local link or resource is missing.')


def check_css(text, current, files):
    # Refuse escapes instead of attempting partial CSS escape interpretation.
    if '\\' in text or '\x00' in text:
        fail('CSS escapes are not supported.')
    text = re.sub(r'/\*.*?\*/', '', text, flags=re.S)
    if '/*' in text:
        fail('Unterminated CSS comment.')
    if re.search(r'(?:expression\s*\(|-moz-binding\s*:|behavior\s*:|(?:image-set|image|src)\s*\()', text, re.I):
        fail('Active CSS is not allowed.')
    pattern = r'url\s*\(\s*(?:"([^"\n]*)"|\'([^\'\n]*)\'|([^\s\)\'\"]*))\s*\)'
    matches = list(re.finditer(pattern, text, re.I))
    if len(matches) != len(re.findall(r'url\s*\(', text, re.I)):
        fail('Malformed CSS URL.')
    for match in matches:
        check_url(next(v for v in match.groups() if v is not None), current, files)
    imports = re.sub(pattern, 'url()', text, flags=re.I)
    for match in re.finditer(r'@import\s+(?:"([^"]*)"|\'([^\']*)\'|url\(\))', imports, re.I):
        if match.group(1) is not None or match.group(2) is not None:
            check_url(match.group(1) if match.group(1) is not None else match.group(2), current, files)
    if len(re.findall(r'@import\b', imports, re.I)) != len(list(re.finditer(
            r'@import\s+(?:"[^"]*"|\'[^\']*\'|url\(\))', imports, re.I))):
        fail('Malformed CSS import.')


class PageParser(HTMLParser):
    ALLOWED = set(('html head title meta link style body header footer main nav section '
                   'article aside address h1 h2 h3 h4 h5 h6 p div span a area map img '
                   'picture source audio video track figure figcaption ul ol li dl dt dd '
                   'strong em b i u s small mark sub sup br hr pre code blockquote q cite '
                   'abbr time table caption colgroup col thead tbody tfoot tr th td '
                   'details summary wbr bdi bdo ruby rt rp').split())
    FORBIDDEN = {'script', 'form', 'iframe', 'frame', 'frameset', 'object', 'embed',
                 'base', 'applet', 'svg', 'math', 'template'}

    def __init__(self, current, files):
        super().__init__(convert_charrefs=True)
        self.current, self.files = current, files
        self.in_style = False
        self.styles = []

    def handle_starttag(self, tag, attrs):
        if tag not in self.ALLOWED or tag in self.FORBIDDEN:
            fail('Active or embedded HTML content is not allowed.')
        values = dict(attrs)
        if len(values) != len(attrs):
            fail('Duplicate HTML attributes are not allowed.')
        if tag == 'link' and not set((values.get('rel') or '').lower().split()).issubset(
                {'stylesheet', 'icon', 'alternate', 'canonical', 'license', 'author'}):
            fail('Unsupported resource link relation.')
        if tag == 'meta' and 'http-equiv' in values:
            fail('HTTP-equivalent metadata is not allowed.')
        for name, value in attrs:
            if name.startswith('on') or name in {'srcdoc', 'ping', 'action', 'formaction', 'manifest', 'codebase', 'archive', 'srcset'}:
                fail('Active HTML attributes are not allowed.')
            if name == 'style':
                check_css(value or '', self.current, self.files)
            if name in {'profile', 'longdesc', 'itemid', 'itemtype', 'vocab', 'resource', 'lowsrc', 'dynsrc', 'attributionsrc'}:
                fail('Unsupported URL-bearing attribute.')
            if name in {'href', 'src', 'poster', 'background', 'data', 'xlink:href', 'cite', 'usemap'}:
                check_url(value or '', self.current, self.files,
                          external=name == 'href' and tag in {'a', 'area'})
        if tag == 'style':
            self.in_style = True

    def handle_startendtag(self, tag, attrs):
        self.handle_starttag(tag, attrs)
        if tag == 'style':
            self.handle_endtag(tag)

    def handle_endtag(self, tag):
        if tag == 'style':
            check_css(''.join(self.styles), self.current, self.files)
            self.styles = []
            self.in_style = False

    def handle_data(self, data):
        if self.in_style:
            self.styles.append(data)

    def finish(self):
        self.close()
        if self.in_style:
            fail('Unterminated style element.')


def check_svg(text, current, files):
    if re.search(r'<!\s*(?:DOCTYPE|ENTITY)', text, re.I):
        fail('SVG document declarations are not allowed.')
    if re.search(r'<\?(?!xml(?:\s|\?>))', text, re.I):
        fail('SVG processing instructions are not allowed.')
    root = ET.fromstring(text)
    allowed = {'svg', 'g', 'path', 'rect', 'circle', 'ellipse', 'line', 'polyline',
               'polygon', 'title', 'desc', 'defs', 'linearGradient', 'radialGradient',
               'stop', 'clipPath', 'mask', 'text', 'tspan', 'use', 'image', 'style'}
    for node in root.iter():
        tag = node.tag.rsplit('}', 1)[-1]
        if tag not in allowed:
            fail('Active SVG content is not allowed.')
        if tag == 'style':
            check_css(node.text or '', current, files)
        for key, value in node.attrib.items():
            key = key.rsplit('}', 1)[-1]
            if key.lower().startswith('on') or key == 'base':
                fail('Active SVG attributes are not allowed.')
            if key == 'href':
                check_url(value, current, files)
            if key == 'style' or re.search(r'url\s*\(', value, re.I):
                check_css(value, current, files)


def validate(source):
    source, files = inventory(source)
    for name, info in files.items():
        data = read_regular(source / name, info)
        extension = Path(name).suffix.lower()
        if extension in {'.html', '.css', '.svg'}:
            text = data.decode('utf-8-sig')
            if '\x00' in text:
                fail('NUL characters are not allowed in text resources.')
            if extension == '.html':
                parser = PageParser(name, files)
                parser.feed(text)
                parser.finish()
            elif extension == '.css':
                check_css(text, name, files)
            else:
                check_svg(text, name, files)
    return source, files


def prepare_output(output, source=None):
    output = absolute(output)
    check_ancestors(output.parent)
    if os.path.lexists(output):
        fail('The output already exists; it will not be replaced.')
    if source is not None:
        source = absolute(source)
        if output == source or source in output.parents or output in source.parents:
            fail('Source and output must not overlap.')
    mode = output.parent.stat().st_mode
    if os.name != 'nt' and mode & (stat.S_IWGRP | stat.S_IWOTH):
        fail('The output parent must not be writable by other users.')
    if not safe_name(output.name):
        fail('The output name is unsafe.')
    return output


def rename_no_replace(source, output):
    if os.name == 'nt':
        os.rename(source, output)  # Windows never replaces an existing destination.
    elif sys.platform.startswith('linux'):
        libc = ctypes.CDLL(None, use_errno=True)
        operation = getattr(libc, 'renameat2', None)
        if operation is None:
            fail('Atomic no-replace publication is unavailable on this platform.')
        operation.argtypes = [ctypes.c_int, ctypes.c_char_p, ctypes.c_int,
                              ctypes.c_char_p, ctypes.c_uint]
        operation.restype = ctypes.c_int
        if operation(-100, os.fsencode(source), -100, os.fsencode(output), 1):
            code = ctypes.get_errno()
            if code == errno.EEXIST:
                fail('The output already exists; it will not be replaced.')
            fail('Atomic no-replace publication failed.')
    else:
        fail('Atomic no-replace publication requires Linux or Windows.')


def publish(output, builder, source=None):
    output = prepare_output(output, source)
    staging = Path(tempfile.mkdtemp(prefix='.site-staging-', dir=output.parent))
    try:
        builder(staging)
        # Validate under a non-hidden directory name: the staging root itself is private.
        validate(staging / 'public')
        public = staging / 'public'
        for directory, _, names in os.walk(public):
            os.chmod(directory, 0o755)
            for name in names:
                os.chmod(Path(directory) / name, 0o644)
        prepare_output(output, source)
        rename_no_replace(public, output)
    finally:
        shutil.rmtree(staging)


def load_content(path):
    path = Path(path)
    with path.open('rb') as stream:
        data = stream.read(MAX_CONTENT + 1)
    if len(data) > MAX_CONTENT:
        fail('The content file exceeds the size limit.')
    value = json.loads(data.decode('utf-8-sig'))
    if not isinstance(value, dict) or set(value) != {'title', 'description', 'about', 'articles'}:
        fail('Content must contain title, description, about and articles only.')
    for key in ('title', 'description', 'about'):
        if not isinstance(value[key], str) or not value[key].strip():
            fail('Content fields must be non-empty strings.')
    if not isinstance(value['articles'], list) or len(value['articles']) > 100:
        fail('Articles must be a list of at most 100 entries.')
    for article in value['articles']:
        if (not isinstance(article, dict) or set(article) != {'title', 'text'} or
                any(not isinstance(article[k], str) or not article[k].strip() for k in ('title', 'text'))):
            fail('Each article must contain non-empty title and text strings.')
    return value


def generate(content_file, output):
    content = load_content(content_file)
    esc = lambda text: html.escape(text, quote=True)
    palettes = [('#f7f3e9', '#202f35', '#176b64'), ('#f3f1fa', '#292238', '#6d498d'),
                ('#f2f5ed', '#273126', '#617326'), ('#fcf0e9', '#362923', '#a14c32')]
    background, ink, accent = secrets.choice(palettes)
    font = secrets.choice(['Georgia, serif', 'Verdana, sans-serif', '"Trebuchet MS", sans-serif'])
    layout = secrets.choice(['linear', 'split', 'framed'])
    radius = secrets.choice(['0', '0.7rem', '1.4rem'])
    spacing = secrets.choice(['1.3', '1.6', '1.9'])
    russian = bool(re.search(r'[\u0400-\u04ff]', content['title'] + content['about']))
    lang = 'ru' if russian else 'en'
    home, about, notes, read = (('Главная', 'О сайте', 'Заметки', 'Читать заметки') if russian
                                else ('Home', 'About', 'Notes', 'Read notes'))
    monogram = esc(content['title'].strip()[0].upper())
    geometry = secrets.choice([
        f'<circle cx="470" cy="110" r="65" fill="{background}"/><path d="M0 340 180 100 340 320 480 210 640 350V400H0Z" fill="{ink}"/><path d="M0 370 240 250 420 360 640 290V400H0Z" fill="{background}"/>',
        f'<circle cx="190" cy="200" r="140" fill="{background}"/><circle cx="380" cy="200" r="140" fill="{ink}"/><circle cx="475" cy="200" r="65" fill="{background}"/>',
        f'<path d="M70 330V70H210V330Z M250 330V140H390V330Z M430 330V210H570V330Z" fill="{background}"/><path d="M70 330 570 70" stroke="{ink}" stroke-width="18" fill="none"/>'
    ])
    css = f'''/* Local, self-contained owner website. */
:root {{ color-scheme: light; --paper: {background}; --ink: {ink}; --accent: {accent}; }}
* {{ box-sizing: border-box; }}
body {{ margin: 0; color: var(--ink); background: var(--paper); font-family: {font}; line-height: {spacing}; }}
header, main, footer {{ max-width: 70rem; margin: auto; padding: 1.5rem 5%; }}
nav {{ display: flex; gap: 1.5rem; flex-wrap: wrap; border-bottom: 2px solid var(--accent); padding-bottom: 1rem; }}
a {{ color: var(--accent); text-underline-offset: .2em; }}
h1 {{ font-size: clamp(2rem, 5vw, 4rem); line-height: 1.15; overflow-wrap: anywhere; }}
p, h2 {{ overflow-wrap: anywhere; }}
p {{ white-space: pre-wrap; }}
article {{ border-top: 1px solid var(--accent); padding: 1rem 0; }}
.illustration {{ display: block; width: 100%; height: auto; max-width: 28rem; border-radius: {radius}; }}
.hero {{ display: grid; gap: 2rem; align-items: center; }}
.split .hero {{ grid-template-columns: 3fr 2fr; }}
.framed main {{ border: 2px solid var(--accent); border-radius: {radius}; }}
.linear .illustration {{ max-width: 38rem; }}
footer {{ border-top: 1px solid var(--accent); margin-top: 2rem; }}
@media (max-width: 650px) {{ .split .hero {{ grid-template-columns: 1fr; }} }}
'''
    def page(title, body):
        return f'''<!doctype html>
<html lang="{lang}"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>{esc(title)} — {esc(content['title'])}</title><meta name="description" content="{esc(content['description'])}">
<link rel="stylesheet" href="style.css"><link rel="icon" href="favicon.svg" type="image/svg+xml"></head>
<body class="{layout}"><header><nav aria-label="{home}"><a href="index.html">{home}</a><a href="about.html">{about}</a><a href="notes.html">{notes}</a></nav></header>
<main>{body}</main><footer>{esc(content['title'])}</footer></body></html>
'''
    articles = ''.join(f'<article><h2>{esc(a["title"])}</h2><p>{esc(a["text"])}</p></article>' for a in content['articles'])
    pages = {
        'index.html': page(content['title'], f'<section class="hero"><div><h1>{esc(content["title"])}</h1><p>{esc(content["description"])}</p><a href="notes.html">{read}</a></div><img class="illustration" src="illustration.svg" alt="" width="640" height="400"></section>'),
        'about.html': page(about, f'<h1>{about}</h1><p>{esc(content["about"])}</p>'),
        'notes.html': page(notes, f'<h1>{notes}</h1>{articles}'),
        'style.css': css,
        'favicon.svg': f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64"><rect width="64" height="64" rx="12" fill="{accent}"/><text x="32" y="45" text-anchor="middle" font-family="sans-serif" font-size="40" fill="{background}">{monogram}</text></svg>',
        'illustration.svg': f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 640 400"><rect width="640" height="400" fill="{accent}"/>{geometry}</svg>'
    }
    def build(staging):
        public = staging / 'public'
        public.mkdir()
        for name, text in pages.items():
            (public / name).write_text(text, encoding='utf-8')
    publish(output, build)


def copy_directories(source, target):
    # Preserve empty directories too; do not use a traversal that follows links.
    with os.scandir(source) as entries:
        for entry in entries:
            path = Path(entry.path)
            info = checked_stat(path)
            if stat.S_ISDIR(info.st_mode):
                if entry.name.startswith('.'):
                    fail('Hidden directories are not allowed.')
                destination = target / entry.name
                destination.mkdir()
                copy_directories(path, destination)
            elif not stat.S_ISREG(info.st_mode):
                fail('The source changed during the operation.')


def copy_site(source, output):
    prepare_output(output, source)
    source, files = validate(source)
    def build(staging):
        public = staging / 'public'
        public.mkdir()
        copy_directories(source, public)
        for name, info in files.items():
            target = public / name
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(read_regular(source / name, info))
    publish(output, build, source)


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    commands = parser.add_subparsers(dest='command', required=True)
    command = commands.add_parser('generate', help='Generate from owner-supplied JSON')
    command.add_argument('--content', required=True)
    command.add_argument('--output', required=True)
    command = commands.add_parser('validate', help='Validate a static website')
    command.add_argument('--source', required=True)
    command = commands.add_parser('copy', help='Validate and copy without changing the source')
    command.add_argument('--source', required=True)
    command.add_argument('--output', required=True)
    args = parser.parse_args(argv)
    try:
        if args.command == 'generate':
            generate(args.content, args.output)
        elif args.command == 'validate':
            validate(args.source)
        else:
            copy_site(args.source, args.output)
    except SiteError as error:
        print('Error: ' + str(error), file=sys.stderr)
        return 1
    except (OSError, ValueError, RecursionError, ET.ParseError):
        print('Error: invalid input or unavailable filesystem operation.', file=sys.stderr)
        return 1
    print('OK: ' + args.command)
    return 0


if __name__ == '__main__':
    sys.exit(main())
