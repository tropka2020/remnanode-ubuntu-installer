"""Conservative online root expansion; callers hold manage.lock on Linux as root.

inspect_plan is read-only (including growpart -N). Only a direct ext4 partition
is supported. A filesystem >= 6 GiB is never changed. For smaller filesystems,
the partition must reach >= 15 GiB and the resulting ext4 must reach >= 14 GiB
(the difference allows filesystem overhead). No package installation, rollback,
partition-table restore, shrinking, reboot, or automatic retry is performed.
"""
import json
import os
from pathlib import Path
import re
import shutil
import stat
import sys

import manage as m

GIB = 1024 ** 3
MIN_ROOT_BYTES = 6 * GIB
TARGET_PARTITION_BYTES = 15 * GIB
MIN_RESULT_FS_BYTES = 14 * GIB
_READ_TIMEOUT = 30
_LSBLK_COLUMNS = 'NAME,KNAME,TYPE,SIZE,FSTYPE,PKNAME,MAJ:MIN,MOUNTPOINTS'
_CHANGE = re.compile(
    r'CHANGE: partition=([0-9]+) start=([0-9]+) '
    r'old: size=([0-9]+) end=([0-9]+) '
    r'new: size=([0-9]+) end=([0-9]+)')


def _fail(message):
    raise m.Failure('Расширение корня: ' + message)


def _integer(value, label, minimum=0):
    if type(value) is not int or value < minimum:
        _fail('некорректное целое поле ' + label + '.')
    return value


def _tools(*names):
    for name in names:
        if not shutil.which(name):
            _fail('нет необходимой команды ' + name + '; установка пакетов запрещена.')


def _json(args, key):
    text = m.run(args, capture=True, timeout=_READ_TIMEOUT)
    try:
        obj = json.loads(text)
    except (ValueError, TypeError) as exc:
        raise m.Failure('Расширение корня: команда вернула некорректный JSON.') from exc
    if not isinstance(obj, dict) or key not in obj:
        _fail('нет обязательных структурированных данных ' + key + '.')
    return obj[key]


def _fs_bytes():
    info = os.statvfs('/')
    return (_integer(info.f_blocks, 'f_blocks', 1) *
            _integer(info.f_frsize, 'f_frsize', 1))


def _major_minor(value):
    if not isinstance(value, str) or not re.fullmatch(r'[0-9]+:[0-9]+', value):
        _fail('некорректный MAJ:MIN.')
    return tuple(int(v) for v in value.split(':'))


def _device_stat(path):
    return os.stat(path)


def _read_partition_number(kname):
    text = (Path('/sys/class/block') / kname / 'partition').read_text().strip()
    if not re.fullmatch(r'[1-9][0-9]*', text):
        _fail('не удалось подтвердить номер раздела через sysfs.')
    return int(text)


def _read_kernel_geometry(kname):
    # sysfs start/size are always in 512-byte units, even on 4Kn disks.
    path = Path('/sys/class/block') / kname
    values = [(path / field).read_text().strip() for field in ('start', 'size')]
    if any(not re.fullmatch(r'[0-9]+', value) for value in values):
        _fail('некорректная геометрия ядра sysfs.')
    return tuple(int(value) * 512 for value in values)


def _block(path, major_minor):
    if not isinstance(path, str) or not path.startswith('/dev/'):
        _fail('источник не является устройством /dev.')
    info = _device_stat(path)
    if not stat.S_ISBLK(info.st_mode) or (
            os.major(info.st_rdev), os.minor(info.st_rdev)) != _major_minor(major_minor):
        _fail('тип или MAJ:MIN блочного устройства не совпадает.')
    return os.path.realpath(path)


def _kname(node):
    value = node.get('kname')
    if not isinstance(value, str):
        _fail('нет KNAME устройства.')
    name = Path(value).name
    if not re.fullmatch(r'[A-Za-z0-9_.!+-]+', name) or name in ('.', '..'):
        _fail('небезопасный KNAME устройства.')
    return name


def _sysfs(node):
    path = Path('/sys/class/block') / _kname(node)
    resolved = path.resolve(strict=True)
    # Any holder (dm, RAID, multipath, etc.) makes online mutation unsupported.
    if not (path / 'holders').is_dir() or any((path / 'holders').iterdir()):
        _fail('устройство имеет holders или sysfs недоступен.')
    slaves = path / 'slaves'
    if ((slaves.exists() and (not slaves.is_dir() or any(slaves.iterdir()))) or
            (not slaves.exists() and node.get('type') != 'part')):
        _fail('составные блочные устройства не поддерживаются.')
    return resolved


def _flatten(nodes, parent=None):
    if not isinstance(nodes, list):
        _fail('некорректное дерево lsblk.')
    result = []
    for node in nodes:
        if not isinstance(node, dict):
            _fail('некорректный узел lsblk.')
        result.append((node, parent))
        result.extend(_flatten(node.get('children', []), node))
    return result


def _discover(*, topology=False):
    """Read kernel and on-disk geometry; topology forces full final verification."""
    _tools('findmnt')
    mounts = _json(['findmnt', '-J', '--target', '/', '--output',
                    'SOURCE,FSTYPE,OPTIONS,MAJ:MIN,TARGET'], 'filesystems')
    if (not isinstance(mounts, list) or len(mounts) != 1 or
            not isinstance(mounts[0], dict)):
        _fail('неоднозначная корневая точка монтирования.')
    root = mounts[0]
    source, fstype, options = (root.get(k) for k in ('source', 'fstype', 'options'))
    if (root.get('target') != '/' or not isinstance(options, str) or
            'rw' not in options.split(',') or 'ro' in options.split(',')):
        _fail('ожидается настоящий доступный для записи mount target /.')
    if (not isinstance(source, str) or not source.startswith('/dev/') or
            not isinstance(fstype, str) or fstype in ('overlay', 'tmpfs', 'rootfs')):
        _fail('псевдо-корень или не блочный источник не поддерживается.')
    fs_bytes = _fs_bytes()
    plan = dict(version=1, status='unchanged', source=source, parent=None,
                number=None, fstype=fstype, fs_bytes=fs_bytes,
                partition_bytes=None, disk_bytes=None, target_partition_bytes=None,
                minimum_partition_bytes=TARGET_PARTITION_BYTES,
                minimum_fs_bytes=MIN_RESULT_FS_BYTES, identity=None,
                dry_run=None)
    if fs_bytes >= MIN_ROOT_BYTES and not topology:
        return plan
    if fstype != 'ext4':
        _fail('для корня меньше 6 GiB поддерживается только ext4.')
    _tools('lsblk', 'sfdisk', 'resize2fs')
    # PARTN is absent in some util-linux versions (including Ubuntu 24).
    # The kernel sysfs partition attribute is authoritative, not name suffixes.
    nodes = _flatten(_json(['lsblk', '--json', '--bytes', '--paths', '--output',
                           _LSBLK_COLUMNS], 'blockdevices'))
    source = _block(source, root.get('maj:min'))
    matches = [(n, p) for n, p in nodes if n.get('name') == source]
    if len(matches) != 1:
        _fail('источник отсутствует или неоднозначен в lsblk.')
    child, disk = matches[0]
    if (child.get('type') != 'part' or child.get('fstype') != 'ext4' or
            child.get('children') or disk is None or disk.get('type') != 'disk'):
        _fail('поддерживается только прямой раздел ext4 на одном диске.')
    parent = disk.get('name')
    if (_block(child.get('name'), child.get('maj:min')) != source or
            _major_minor(child.get('maj:min')) != _major_minor(root.get('maj:min')) or
            _block(parent, disk.get('maj:min')) != parent):
        _fail('идентичность корневого раздела или диска не подтверждена.')
    if sum(n.get('name') == parent for n, _ in nodes) != 1:
        _fail('неоднозначный родительский диск.')
    pkname = child.get('pkname')
    if not isinstance(pkname, str) or pkname not in (parent, _kname(disk)):
        _fail('PKNAME не совпадает с родителем lsblk.')
    child_sys, disk_sys = _sysfs(child), _sysfs(disk)
    if child_sys.parent != disk_sys or (disk_sys / 'partition').exists():
        _fail('родитель sysfs не совпадает с деревом lsblk.')
    number = _integer(_read_partition_number(_kname(child)), 'partition number', 1)
    if child.get('partn') is not None and (
            type(child['partn']) is not int or child['partn'] != number):
        _fail('номера раздела в lsblk и sysfs различаются.')
    mounts = child.get('mountpoints')
    if not isinstance(mounts, list) or '/' not in mounts:
        _fail('lsblk не подтверждает mountpoint /.')
    partition_bytes = _integer(child.get('size'), 'partition size', 1)
    disk_bytes = _integer(disk.get('size'), 'disk size', 1)
    if disk_bytes < TARGET_PARTITION_BYTES:
        _fail('родительский диск меньше 15 GiB; сначала увеличьте выделенный диск.')
    table = _json(['sfdisk', '--json', parent], 'partitiontable')
    if (not isinstance(table, dict) or table.get('label') not in ('dos', 'gpt') or
            table.get('unit') != 'sectors' or table.get('device') != parent):
        _fail('поддерживаются только таблицы dos/gpt с единицами sectors.')
    sector = _integer(table.get('sectorsize'), 'sectorsize', 512)
    if sector not in (512, 1024, 2048, 4096) or disk_bytes % sector:
        _fail('неподдерживаемый логический сектор или размер диска.')
    disk_sectors = disk_bytes // sector
    first = _integer(table.get('firstlba', 1), 'firstlba', 1)
    last = _integer(table.get('lastlba', disk_sectors - 1), 'lastlba', 1)
    if first > last or last >= disk_sectors:
        _fail('границы таблицы вне диска.')
    if table['label'] == 'gpt' and ('firstlba' not in table or 'lastlba' not in table):
        _fail('нет границ usable LBA таблицы GPT.')
    partitions = table.get('partitions')
    if not isinstance(partitions, list) or not partitions:
        _fail('нет списка разделов sfdisk.')
    geometry = []
    for part in partitions:
        if not isinstance(part, dict):
            _fail('некорректный раздел sfdisk.')
        node = part.get('node')
        start = _integer(part.get('start'), 'start', 1)
        size = _integer(part.get('size'), 'size', 1)
        if start < first or start + size - 1 > last:
            _fail('раздел выходит за usable LBA диска.')
        peers = [n for n, p in nodes if n.get('name') == node and p is disk]
        if len(peers) != 1 or peers[0].get('type') != 'part':
            _fail('таблица sfdisk не совпадает с прямыми разделами lsblk.')
        peer = peers[0]
        kernel_start, kernel_size = _read_kernel_geometry(_kname(peer))
        if (kernel_start != start * sector or kernel_size != size * sector or
                _integer(peer.get('size'), 'peer size', 1) != size * sector or
                _block(node, peer.get('maj:min')) != node):
            _fail('размер или идентичность раздела ядра не совпадает с таблицей.')
        # DOS extended/logical partitions are deliberately not supported.
        kind = str(part.get('type', '')).lower().removeprefix('0x')
        if table['label'] == 'dos' and kind in ('5', '05', 'f', '0f', '85'):
            _fail('расширенные/logical DOS-разделы не поддерживаются.')
        geometry.append(dict(node=node, start=start, size=size,
                             major_minor=peer.get('maj:min'),
                             type=part.get('type'), uuid=part.get('uuid')))
    geometry.sort(key=lambda item: item['start'])
    if len({p['node'] for p in geometry}) != len(geometry):
        _fail('дублирующиеся разделы в таблице.')
    if len(geometry) != len(disk.get('children', [])):
        _fail('список разделов ядра и таблицы различается.')
    for left, right in zip(geometry, geometry[1:]):
        if left['start'] + left['size'] > right['start']:
            _fail('разделы пересекаются.')
    own = [p for p in geometry if p['node'] == source]
    if len(own) != 1 or own[0] != geometry[-1]:
        _fail('корневой раздел не является физически последним.')
    start, size = own[0]['start'], own[0]['size']
    if size * sector != partition_bytes or fs_bytes > partition_bytes:
        _fail('размеры файловой системы, раздела и таблицы несовместимы.')
    if table['label'] == 'dos':
        if number > 4:
            _fail('logical DOS-разделы не поддерживаются.')
        last = min(last, 2 ** 32 - 1)
    available_bytes = (last + 1 - start) * sector
    if available_bytes < TARGET_PARTITION_BYTES:
        if (table['label'] == 'gpt' and
                (disk_sectors - start) * sector >= TARGET_PARTITION_BYTES):
            _fail('usable LBA GPT недостаточно, возможно backup GPT остался на старом '
                  'конце увеличенного диска. Нужна ручная диагностика вне установки; '
                  'автоматическое перемещение GPT не поддерживается.')
        _fail('после начала корневого раздела недостаточно места для 15 GiB.')
    identity = dict(source=source, mounted_source=root['source'], parent=parent,
                    number=number, fstype=fstype, options=options,
                    root_major_minor=root['maj:min'], disk_major_minor=disk['maj:min'],
                    child_sysfs=str(child_sys), disk_sysfs=str(disk_sys),
                    disk_bytes=disk_bytes, sector_size=sector,
                    label=table['label'], table_id=table.get('id'),
                    first_lba=first, last_lba=last, partitions=geometry,
                    table=table)
    plan.update(status=('expand-filesystem' if partition_bytes >= TARGET_PARTITION_BYTES
                        else 'expand-partition'), source=source, parent=parent,
                number=number, partition_bytes=partition_bytes, disk_bytes=disk_bytes,
                target_partition_bytes=partition_bytes, identity=identity,
                sector_size=sector, start_sector=start, size_sectors=size,
                end_sector=start + size - 1, usable_last_sector=last,
                available_partition_bytes=available_bytes)
    return plan


def _dry_run(plan):
    _tools('growpart')
    result = m.run(['growpart', '-N', plan['parent'], str(plan['number'])],
                   check=False, timeout=_READ_TIMEOUT)
    # Never treat NOCHANGE (including exit 0) as permission to resize a small
    # partition. Already-large partitions use the resize-only path instead.
    output = (result.stdout or '') + '\n' + (result.stderr or '')
    lines = [line.strip() for line in output.splitlines()
             if line.strip().startswith(('CHANGE:', 'CHANGED:', 'NOCHANGE:'))]
    match = _CHANGE.fullmatch(lines[0]) if len(lines) == 1 else None
    if result.returncode != 0 or match is None:
        _fail('growpart -N не подтвердил однозначное расширение (NOCHANGE не подходит).')
    number, start, old_size, old_end, size, end = map(int, match.groups())
    # cloud-utils releases use inclusive or exclusive printed end positions.
    # Require one consistent convention; validate physical bounds from size.
    end_offset = old_end - (start + old_size)
    if (number != plan['number'] or start != plan['start_sector'] or
            old_size != plan['size_sectors'] or end_offset not in (-1, 0) or
            size <= old_size or end != start + size + end_offset or
            start + size - 1 > plan['usable_last_sector'] or
            size * plan['sector_size'] < TARGET_PARTITION_BYTES):
        _fail('предложенная growpart геометрия небезопасна или не достигает 15 GiB.')
    return dict(number=number, start=start, old_size=old_size, old_end=old_end,
                new_size=size, new_end=end)


def _inspect_plan():
    plan = _discover()
    if plan['status'] == 'expand-partition':
        dry_run = _dry_run(plan)
        # Dry-run is read-only, but another process may have changed the disk.
        current = _discover()
        if current['identity'] != plan['identity'] or current['fs_bytes'] != plan['fs_bytes']:
            _fail('геометрия изменилась во время dry-run; получите новый план.')
        plan['dry_run'] = dry_run
        plan['target_partition_bytes'] = dry_run['new_size'] * plan['sector_size']
    return plan


def inspect_plan():
    """Return a JSON-compatible read-only plan; failures are manage.Failure."""
    try:
        return _inspect_plan()
    except (OSError, ValueError, TypeError, KeyError) as exc:
        raise m.Failure('Расширение корня: не удалось безопасно прочитать состояние диска.') from exc


def describe(plan):
    """Human summary; partition >=15 GiB, filesystem >=14 GiB after growth."""
    if plan['status'] == 'unchanged':
        return f"Корень {plan['fs_bytes'] / GIB:.2f} GiB >= 6 GiB: без изменений."
    action = ('расширить раздел до доступного конца и затем ext4' if
              plan['status'] == 'expand-partition' else 'расширить только ext4')
    return (f"Корень {plan['fs_bytes'] / GIB:.2f} GiB < 6 GiB: {action}; "
            f"{plan['source']} на {plan['parent']}, раздел {plan['number']}. "
            f"План: раздел {plan['target_partition_bytes'] / GIB:.2f} GiB "
            '(минимум 15 GiB), файловая система минимум 14 GiB с учётом overhead. '
            'Без уменьшения, отката таблицы и перезагрузки.')


def _sync_backup_parents(directory):
    """Persist mkdtemp and any newly created backup ancestor directory entries."""
    for path in [directory, *directory.parents]:
        fd = os.open(path, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)
        try:
            os.fsync(fd)
        finally:
            os.close(fd)


def _private_write(directory, name, text):
    """Create an immutable snapshot: exclusive creation, never update in place."""
    path = directory / name
    flags = os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW
    fd = os.open(path, flags, 0o600)
    with os.fdopen(fd, 'w', encoding='utf-8', newline='\n') as stream:
        os.fchmod(stream.fileno(), 0o600)
        info = os.fstat(stream.fileno())
        if info.st_uid != 0 or info.st_nlink != 1 or not stat.S_ISREG(info.st_mode):
            _fail('журнал не является приватным обычным файлом root.')
        stream.write(text)
        stream.flush()
        os.fsync(stream.fileno())
    fd = os.open(directory, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)
    try:
        os.fsync(fd)
    finally:
        os.close(fd)


def _record(directory, name, value):
    _private_write(directory, name, json.dumps(value, ensure_ascii=False, indent=2) + '\n')


def _same_plan(current, approved):
    if current != approved:
        _fail('план устарел или изменён; остановитесь и получите новый inspect_plan().')


def _verify_grown(before, after):
    """Allow only the approved root size increase, not any other table change."""
    expected = json.loads(json.dumps(before['identity']))
    size = before['target_partition_bytes'] // before['sector_size']
    actual_size = after.get('size_sectors')
    if type(actual_size) is not int or actual_size < size:
        _fail('ядро не подтвердило запланированный размер раздела; resize2fs запрещён.')
    if after['start_sector'] != before['start_sector']:
        _fail('начало корневого раздела изменилось; resize2fs запрещён.')
    for partition in expected['partitions']:
        if partition['node'] == before['source']:
            partition['size'] = actual_size
    for partition in expected['table']['partitions']:
        if partition['node'] == before['source']:
            partition['size'] = actual_size
    if after['identity'] != expected:
        _fail('после growpart изменились посторонние данные топологии; resize2fs запрещён.')


def apply(plan):
    """Apply an exact fresh plan. Caller must hold manage.lock throughout.

    Journals are append-only snapshots, root-owned mode 0600 in a private
    backup directory. A partial operation is never rolled back or retried.
    """
    if sys.platform != 'linux' or not hasattr(os, 'geteuid') or os.geteuid() != 0:
        _fail('apply разрешён только root на Linux.')
    directory = None
    try:
        # Reconstruct, including dry-run, rather than trusting caller fields.
        current = inspect_plan()
        _same_plan(current, plan)
        if current['status'] == 'unchanged':
            return dict(status='unchanged', source=current['source'],
                        fs_bytes=current['fs_bytes'], changed=False, journal=None)
        dump = m.run(['sfdisk', '--dump', current['parent']],
                     capture=True, timeout=_READ_TIMEOUT)
        if not isinstance(dump, str) or not dump.strip():
            _fail('не удалось получить резервную копию таблицы разделов.')
        directory = Path(m.backup_dir('disk-expand'))
        m.secure_path(directory, directory=True)
        info = directory.stat()
        if info.st_uid != 0 or stat.S_IMODE(info.st_mode) != 0o700:
            _fail('каталог журнала должен принадлежать root и иметь права 700.')
        _sync_backup_parents(directory)
        _private_write(directory, 'partition-table.sfdisk', dump)
        _record(directory, 'geometry.json', current)
        _record(directory, '00-intent.json', dict(
            status='prepared', plan=current,
            expected=['growpart', 'resize2fs'] if current['status'] == 'expand-partition'
            else ['resize2fs'],
            recovery='STOP. No rollback, shrink, table restore or reboot. Reinspect before retry.'))
        if current['status'] == 'expand-partition':
            _record(directory, '10-growpart-started.json', dict(status='may-be-partial'))
        # Last read-only check after dry-run AND durable journal, immediately
        # before the first mutation. Includes the complete partition table.
        fresh = _discover()
        baseline = dict(current, dry_run=None,
                        target_partition_bytes=current['partition_bytes'])
        _same_plan(fresh, baseline)
        if current['status'] == 'expand-partition':
            m.run(['growpart', current['parent'], str(current['number'])], timeout=120)
            grown = _discover()
            _verify_grown(current, grown)
            _record(directory, '20-partition-verified.json', grown)
        _record(directory, '30-resize2fs-started.json', dict(status='may-be-partial'))
        ready = _discover()
        _same_plan(ready, grown if current['status'] == 'expand-partition' else fresh)
        m.run(['resize2fs', current['source']], timeout=600)
        final = _discover(topology=True)
        if current['status'] == 'expand-partition':
            _verify_grown(current, final)
        elif final['identity'] != current['identity']:
            _fail('после resize2fs изменилась геометрия или идентичность корня.')
        final_fs_bytes = final['fs_bytes']
        if final_fs_bytes < MIN_RESULT_FS_BYTES:
            _fail('итоговая ext4 меньше 14 GiB; операция не подтверждена.')
        result = dict(status='expanded', action=current['status'], changed=True,
                      source=current['source'], parent=current['parent'],
                      number=current['number'], fs_bytes=final_fs_bytes,
                      partition_bytes=final['partition_bytes'],
                      journal=str(directory), minimum_fs_bytes=MIN_RESULT_FS_BYTES,
                      minimum_partition_bytes=TARGET_PARTITION_BYTES)
        _record(directory, '40-complete.json', result)
        return result
    except (m.Failure, OSError, ValueError, TypeError, KeyError, KeyboardInterrupt) as exc:
        # Never hide journal errors or command errors, and never run a fallback.
        location = str(directory) if directory is not None else 'не создан'
        detail = str(exc) if isinstance(exc, m.Failure) else 'ошибка ввода-вывода или прерывание'
        raise m.Failure('Расширение остановлено; состояние может быть частично изменено. '
                        'НЕ продолжайте установку/apt; без отката и автоматического повтора. '
                        'Нужен новый inspect_plan(). Журнал: ' + location + '. ' + detail) from exc
