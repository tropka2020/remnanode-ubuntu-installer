#!/usr/bin/env python3
"""Authenticated loopback composition registry; expose only behind an HTTPS proxy."""
import argparse
import contextlib
import hmac
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import json
import os
from pathlib import Path
import re
import secrets
import socket
import sqlite3
import stat
import sys
import threading
import uuid

from design_catalog import VERSION, all_compositions, composition_key, validate_manifest


class RegistryError(Exception):
    pass


class Exhausted(RegistryError):
    pass


def safe_path(path, *, directory=False):
    path = Path(os.path.abspath(path))
    uid = os.geteuid() if hasattr(os, 'geteuid') else None
    for part in [*reversed(path.parents), path]:
        if not os.path.lexists(part):
            continue
        info = part.lstat()
        if (stat.S_ISLNK(info.st_mode) or getattr(info, 'st_file_attributes', 0) & 0x400 or
                (stat.S_ISREG(info.st_mode) and info.st_nlink != 1)):
            raise RegistryError('Небезопасный путь реестра.')
        if os.name != 'nt':
            if info.st_uid not in (0, uid) or info.st_mode & 0o022:
                raise RegistryError('Путь реестра доступен для чужой записи.')
            if part == path and (info.st_uid != uid or info.st_mode & 0o077):
                raise RegistryError('Данные реестра должны принадлежать пользователю сервиса и иметь закрытые права.')
    if path.exists() and directory and not path.is_dir():
        raise RegistryError('Ожидается приватный каталог реестра.')
    if path.exists() and not directory and not path.is_file():
        raise RegistryError('Ожидается обычный файл реестра.')
    return path


def open_db(path):
    path = safe_path(path)
    if not path.exists():
        raise RegistryError('База не инициализирована.')
    # SQLite owns transient sidecars and may create/remove them between checks;
    # the database itself remains protected and SQLite handles their locking.
    connection = sqlite3.connect(path, timeout=15, isolation_level=None)
    connection.execute('PRAGMA busy_timeout=15000')
    return connection


def verify_db(connection):
    try:
        tables = {r[0] for r in connection.execute("SELECT name FROM sqlite_master WHERE type='table'")}
        if tables != {'metadata', 'reservations'}:
            raise RegistryError('Неизвестная схема базы реестра.')
        metadata = dict(connection.execute('SELECT key,value FROM metadata'))
        if metadata != {'version': VERSION, 'schema': '1'}:
            raise RegistryError('Версия реестра отличается; автоматического сброса нет.')
        for request, key, payload in connection.execute('SELECT request_id,composition_key,manifest FROM reservations'):
            manifest = validate_manifest(json.loads(payload))
            if manifest['request_id'] != request or composition_key(manifest['composition']) != key:
                raise RegistryError('Повреждена история резервирований.')
    except (sqlite3.Error, ValueError, TypeError) as exc:
        raise RegistryError('Повреждена база реестра; автоматическая переинициализация запрещена.') from None


def initialize(path):
    path = safe_path(path)
    parent = safe_path(path.parent, directory=True)
    if not parent.is_dir():
        raise RegistryError('Сначала создайте приватный каталог базы с правами 700.')
    if path.exists():
        with contextlib.closing(open_db(path)) as connection:
            verify_db(connection)
        return
    fd = os.open(path, os.O_CREAT | os.O_EXCL | os.O_WRONLY | getattr(os, 'O_NOFOLLOW', 0), 0o600)
    os.close(fd)
    try:
        with contextlib.closing(open_db(path)) as connection:
            connection.execute('BEGIN IMMEDIATE')
            connection.execute('CREATE TABLE metadata(key TEXT PRIMARY KEY,value TEXT NOT NULL)')
            connection.executemany('INSERT INTO metadata VALUES (?,?)', [('schema', '1'), ('version', VERSION)])
            connection.execute('CREATE TABLE reservations(request_id TEXT PRIMARY KEY,composition_key TEXT NOT NULL UNIQUE,manifest TEXT NOT NULL)')
            connection.execute('COMMIT')
    except sqlite3.Error:
        raise RegistryError('Инициализация базы не удалась; файл сохранён для диагностики.') from None


def reserve(path, request_id):
    try:
        if not isinstance(request_id, str) or str(uuid.UUID(request_id)) != request_id:
            raise ValueError()
    except (ValueError, TypeError, AttributeError):
        raise RegistryError('Некорректный request UUID.') from None
    try:
        with contextlib.closing(open_db(path)) as connection:
            connection.execute('BEGIN IMMEDIATE')
            try:
                verify_db(connection)
                row = connection.execute('SELECT manifest FROM reservations WHERE request_id=?', (request_id,)).fetchone()
                if row:
                    result = validate_manifest(json.loads(row[0]))
                else:
                    used = {row[0] for row in connection.execute('SELECT composition_key FROM reservations')}
                    available = [c for c in all_compositions() if composition_key(c) not in used]
                    if not available:
                        raise Exhausted('Все композиции этой версии заняты.')
                    result = {'schema': 1, 'version': VERSION, 'request_id': request_id,
                              'reservation_id': str(uuid.uuid4()), 'seed': secrets.token_hex(32),
                              'composition': secrets.choice(available)}
                    connection.execute('INSERT INTO reservations VALUES (?,?,?)',
                                       (request_id, composition_key(result['composition']), json.dumps(result, sort_keys=True)))
                connection.execute('COMMIT')
                return result
            except BaseException:
                connection.execute('ROLLBACK')
                raise
    except sqlite3.Error:
        raise RegistryError('База занята, повреждена или недоступна; повторите тот же request UUID.') from None


def read_token(path):
    path = safe_path(path)
    if not path.is_file() or path.stat().st_size > 512:
        raise RegistryError('Ожидается закрытый файл токена.')
    token = path.read_text(encoding='ascii').strip()
    if not re.fullmatch(r'[A-Za-z0-9_-]{32,256}', token):
        raise RegistryError('Токен должен содержать 32–256 URL-safe символов.')
    return token


class RegistryServer(ThreadingHTTPServer):
    daemon_threads = True
    block_on_close = True
    allow_reuse_address = False

    def __init__(self, address, database, token):
        if address[0] != '127.0.0.1':
            raise RegistryError('Разрешён только loopback bind 127.0.0.1.')
        self.database, self.token = database, token
        self.slots = threading.BoundedSemaphore(16)
        super().__init__(address, RegistryHandler)

    def process_request(self, request, client_address):
        if not self.slots.acquire(blocking=False):
            self.shutdown_request(request)
            return
        try:
            super().process_request(request, client_address)
        except BaseException:
            self.slots.release()
            raise

    def process_request_thread(self, request, client_address):
        try:
            super().process_request_thread(request, client_address)
        finally:
            self.slots.release()

    def handle_error(self, request, client_address):
        pass


class RegistryHandler(BaseHTTPRequestHandler):
    server_version = 'DesignRegistry'
    sys_version = ''
    protocol_version = 'HTTP/1.0'

    def setup(self):
        super().setup()
        self.connection.settimeout(10)

    def log_message(self, fmt, *args):
        pass

    def reply(self, status, data):
        payload = json.dumps(data, separators=(',', ':')).encode('utf-8')
        self.send_response(status)
        self.send_header('Content-Type', 'application/json; charset=utf-8')
        self.send_header('Cache-Control', 'no-store')
        self.send_header('Content-Length', str(len(payload)))
        self.end_headers()
        self.wfile.write(payload)

    def authenticated(self):
        values = self.headers.get_all('Authorization', [])
        expected = ('Bearer ' + self.server.token).encode('ascii')
        supplied = values[0].encode('utf-8') if len(values) == 1 else b''
        return hmac.compare_digest(supplied, expected)

    def do_GET(self):
        if not self.authenticated():
            self.reply(401, {'error': 'unauthorized'})
        elif self.path == '/health':
            self.reply(200, {'version': VERSION})
        else:
            self.reply(404, {'error': 'not_found'})

    def do_POST(self):
        lengths = self.headers.get_all('Content-Length', [])
        # Drain a bounded request body before rejecting auth/path/headers so HTTP/1.0
        # clients receive a complete response instead of a reset on some platforms.
        declared = int(lengths[0]) if len(lengths) == 1 and re.fullmatch(r'[0-9]{1,5}', lengths[0]) and int(lengths[0]) <= 8192 else 0
        try:
            raw = self.rfile.read(declared) if declared else b''
        except socket.timeout:
            self.reply(400, {'error': 'invalid_request'})
            return
        if not self.authenticated():
            self.reply(401, {'error': 'unauthorized'})
            return
        if self.path != '/v1/reserve':
            self.reply(404, {'error': 'not_found'})
            return
        
        if (len(lengths) != 1 or not re.fullmatch(r'[0-9]{1,5}', lengths[0]) or
                not 1 <= int(lengths[0]) <= 8192 or self.headers.get('Transfer-Encoding') is not None or
                self.headers.get_content_type() != 'application/json'):
            self.reply(400, {'error': 'invalid_request'})
            return
        try:
            if len(raw) != int(lengths[0]):
                raise ValueError()
            payload = json.loads(raw.decode('utf-8'))
            if not isinstance(payload, dict) or set(payload) != {'version', 'request_id'} or payload['version'] != VERSION:
                raise ValueError()
            result = reserve(self.server.database, payload['request_id'])
        except Exhausted:
            self.reply(409, {'error': 'exhausted'})
        except RegistryError:
            self.reply(503, {'error': 'registry_unavailable'})
        except (ValueError, TypeError, socket.timeout):
            self.reply(400, {'error': 'invalid_request'})
        else:
            self.reply(200, result)


def main():
    os.umask(0o077)
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--database', type=Path, required=True)
    p.add_argument('--token-file', type=Path, required=True)
    p.add_argument('--host', choices=['127.0.0.1'], default='127.0.0.1')
    p.add_argument('--port', type=int, default=8787)
    args = p.parse_args()
    if not 1 <= args.port <= 65535:
        raise RegistryError('Неверный порт.')
    token = read_token(args.token_file)
    initialize(args.database)
    with RegistryServer((args.host, args.port), args.database, token) as server:
        server.serve_forever()


if __name__ == '__main__':
    try:
        main()
    except (RegistryError, OSError, UnicodeError):
        print('Реестр не запущен: проверьте приватные пути, токен, базу и bind.', file=sys.stderr)
        sys.exit(1)
    except KeyboardInterrupt:
        pass
