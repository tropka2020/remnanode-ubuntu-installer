"""Small HTTPS-only client for the private composition registry."""
import json
import re
import ssl
import urllib.error
import urllib.parse
import urllib.request
import uuid

from design_catalog import VERSION, validate_manifest


class RegistryError(Exception):
    pass


def validate_registry_url(value):
    if not isinstance(value, str) or any(c.isspace() or ord(c) < 32 or ord(c) == 127 for c in value):
        raise ValueError('Invalid registry origin')
    url = urllib.parse.urlsplit(value)
    if (url.scheme != 'https' or not url.hostname or url.username is not None or url.password is not None or
            url.path not in ('', '/') or url.query or url.fragment or '\\' in value or '%' in value):
        raise ValueError('Registry must be an HTTPS origin without credentials or path')
    try:
        if url.port is not None and not 1 <= url.port <= 65535:
            raise ValueError('Invalid port')
    except ValueError as exc:
        raise ValueError('Invalid registry port') from exc
    return urllib.parse.urlunsplit(('https', url.netloc, '', '', ''))


class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        return None


def reserve_remote(url, token, request_id):
    try:
        origin = validate_registry_url(url)
        if (not isinstance(token, str) or not re.fullmatch(r'[A-Za-z0-9_-]{32,256}', token) or
                not isinstance(request_id, str) or str(uuid.UUID(request_id)) != request_id):
            raise ValueError('Invalid credentials or request')
        data = json.dumps({'version': VERSION, 'request_id': request_id}).encode('utf-8')
        request = urllib.request.Request(origin + '/v1/reserve', data=data, method='POST',
                  headers={'Authorization': 'Bearer ' + token, 'Content-Type': 'application/json', 'Accept': 'application/json'})
        opener = urllib.request.build_opener(urllib.request.ProxyHandler({}), NoRedirect(),
                  urllib.request.HTTPSHandler(context=ssl.create_default_context()))
        with opener.open(request, timeout=15) as response:
            if response.status != 200:
                raise ValueError('Unexpected response status')
            body = response.read(16385)
            if len(body) > 16384:
                raise ValueError('Response exceeds limit')
        result = validate_manifest(json.loads(body.decode('utf-8')))
        if result['request_id'] != request_id:
            raise ValueError('Mismatched response')
        return result
    except (ValueError, TypeError, OSError, urllib.error.URLError) as exc:
        raise RegistryError('Не удалось подтвердить резервирование: проверьте HTTPS, доступ и состояние реестра.') from None
