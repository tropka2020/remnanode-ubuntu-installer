#!/usr/bin/env python3
"""Самодостаточные редакционные сайты: растения, кофе и фотография (Python 3.9+)."""
import argparse
import html
import importlib.util
from pathlib import Path
import secrets
import sys
import xml.etree.ElementTree as ET

# Do not import Python's startup module named `site` by accident.
_SPEC = importlib.util.spec_from_file_location('themed_site_output', Path(__file__).resolve().with_name('site.py'))
site_tool = importlib.util.module_from_spec(_SPEC)
_SPEC.loader.exec_module(site_tool)
SiteError = site_tool.SiteError


# Evergreen editorial material, not invented people, businesses or testimonials.
CONTENT = {
    'plants': {
        'names': ('Листья у окна', 'Тихий зелёный угол', 'Побеги и свет'),
        'label': 'Комнатные растения',
        'intro': 'Наблюдать за ростом, понимать свет и не торопиться с лейкой. Практический журнал о зелени в обычной квартире.',
        'caption': 'Свет, пространство и время для роста',
        'about': 'Здесь собраны базовые приёмы ухода за комнатными растениями: от выбора места до пересадки. Вместо календаря обязательных процедур — наблюдение за конкретным растением и условиями в комнате.',
        'caution': 'Потребности разных видов отличаются. Уточняйте название растения и его безопасность для детей и животных; общие советы не заменяют рекомендации для конкретного вида.',
        'palettes': (('#f5f3e9', '#243b30', '#365f42', '#e5ead8', '#ced8bd'),
                     ('#faf6ef', '#303e32', '#52633b', '#eee9d8', '#d8ddc7')),
        'articles': (
            ('light', 'Место у окна: как оценить свет', 'Наблюдение',
             'Почему расстояние до стекла бывает важнее стороны света и как заметить нехватку освещения.', (
                 'Начните с наблюдения: в какое время прямое солнце попадает на выбранное место и как долго держится. Южное окно за деревом и открытое южное окно дают разные условия. Даже в одной комнате освещённость заметно падает по мере удаления от стекла; глаз приспосабливается к темноте лучше, чем растение.',
                 'Сверьтесь с требованиями конкретного вида. Для растения, привыкшего к рассеянному свету, летний полдень у стекла может оказаться слишком резким. Перемещайте горшок ближе к яркому окну постепенно, в течение нескольких дней, и при необходимости используйте лёгкую занавеску. Листья не должны касаться горячего или холодного стекла.',
                 'Вытянутые междоузлия и наклон к окну могут указывать на недостаток света, но не являются точным диагнозом. Сравните новый рост со старым и проверьте полив. Меняйте одно условие за раз и наблюдайте за новыми листьями: повреждённые участки старых листьев обычно не восстанавливаются.')),
            ('watering', 'Полив без расписания', 'Уход',
             'Проверяем субстрат и вес горшка, а не день недели.', (
                 'Перед поливом оцените влажность грунта не только на поверхности. Для многих обычных лиственных растений полезно дать верхнему слою подсохнуть, но глубина просушки зависит от вида и состава субстрата. Деревянная палочка и вес горшка помогают сравнивать состояние сегодня и после предыдущего полива; не протыкайте плотный ком с усилием.',
                 'Если растению уже нужна вода, медленно пролейте субстрат по поверхности до выхода воды из дренажных отверстий. Дайте ей стечь и опорожните поддон или кашпо. Горшок без отверстий делает контроль влаги сложнее; слой камней на дне не заменяет сток. У крупных тяжёлых горшков заранее продумайте безопасный способ слива.',
                 'Поникшие листья бывают и при пересушке, и при проблемах с корнями в мокром грунте. Не добавляйте воду автоматически: сначала проверьте влажность, температуру и состояние дренажа. Зимой при слабом свете грунт часто сохнет медленнее, поэтому летний интервал между поливами может не подойти.')),
            ('repotting', 'Пересадка: сначала корни, потом горшок', 'Практика',
             'Когда новая ёмкость действительно нужна и почему большой запас объёма не всегда полезен.', (
                 'Корни, показавшиеся из одного отверстия, ещё не повод срочно пересаживать растение. Оцените несколько признаков: ком быстро пересыхает, корни плотно оплели его стенки, рост замедлился при подходящих свете и питании. Здоровое растение обычно легче переносит плановую пересадку в период активного роста.',
                 'Подготовьте ёмкость с отверстиями, лишь немного шире корневого кома, и субстрат для своего вида. Слишком большой объём долго остаётся мокрым. Аккуратно выньте растение; не отмывайте и не распутывайте все корни без необходимости. Сохраните прежнюю глубину посадки, если для этого вида не рекомендовано иначе.',
                 'После пересадки поставьте горшок в подходящий свет без резкой смены условий. Режим первого полива зависит от растения: рекомендации для тропического лиственного вида нельзя автоматически переносить на суккуленты с повреждёнными корнями. Не спешите с удобрением, особенно если новый субстрат уже содержит питание.')),
            ('leaves', 'Чистые листья и спокойный осмотр', 'Наблюдение',
             'Простой способ заметить проблему до того, как она станет большой.', (
                 'Пыль можно снимать мягкой влажной тканью, придерживая лист снизу. Начните с одного листа и не трите восковой налёт. Для опушённых листьев часто лучше мягкая сухая кисть; способ очистки стоит уточнить для вида. Масло и средства для блеска не нужны: они могут оставлять плёнку и повреждать поверхность.',
                 'Заодно осмотрите нижнюю сторону листьев, черешки и молодой рост. Липкость, мелкая паутинка или неподвижные бугорки — повод отделить растение от остальных и внимательнее определить причину. Один жёлтый старый лист сам по себе не доказывает присутствие вредителей.',
                 'Сфотографируйте подозрительный участок и проверьте его через несколько дней. Не смешивайте домашние растворы и препараты наугад. Если обработка действительно нужна, используйте средство, разрешённое для комнатных растений и найденного вредителя, следуйте этикетке и учитывайте безопасность людей и животных.')),
            ('new-plant', 'Новое растение: мягкое знакомство с домом', 'Начало',
             'Небольшая пауза между покупкой и перестановкой всей коллекции.', (
                 'До покупки узнайте название вида и примерный размер взрослого растения. Сравните его требования со светом, температурой и местом в своей комнате. Компактный экземпляр подходящего вида обычно удобнее, чем крупное растение, которому постоянно не хватает пространства или освещения.',
                 'Дома осмотрите листья и субстрат. По возможности держите новичка отдельно от коллекции несколько недель и наблюдайте: часть вредителей заметна не сразу. Не ставьте горшок вплотную к батарее, под холодный поток воздуха или сразу на яркое солнце после тёмного магазина.',
                 'Запишите исходное состояние и дату первого полива в личный блокнот. Не объединяйте пересадку, подкормку и резкую смену освещения в один день без необходимости. Если растение выглядит здоровым, дайте ему привыкнуть; если есть признаки гнили или вредителей, сначала установите причину и действуйте адресно.')),
        ),
    },
    'coffee': {
        'names': ('Зерно и пауза', 'Утро с фильтром', 'Тетрадь о кофе'),
        'label': 'Кофе дома',
        'intro': 'Хорошая чашка начинается не с дорогого оборудования, а с понятного рецепта. Разбираемся во вкусе, воде и небольших ежедневных привычках.',
        'caption': 'Пропорции, тепло и небольшая пауза',
        'about': 'Это практическая тетрадь о домашнем кофе. Материалы помогают сравнивать рецепты и менять по одному параметру, не превращая личный вкус в обязательный стандарт.',
        'caution': 'Кофе содержит кофеин, а горячая вода может обжечь. Учитывайте свою чувствительность и рекомендации врача; при заваривании ставьте посуду на устойчивую поверхность.',
        'palettes': (('#f7f0e5', '#392b25', '#88452d', '#ece0cb', '#d9c6a6'),
                     ('#faf3ec', '#392c2b', '#844432', '#f0e1d7', '#e0c2ad')),
        'articles': (
            ('filter', 'Фильтр: рецепт, от которого удобно оттолкнуться', 'Заваривание',
             'Один базовый ориентир для воронки — с весами, таймером и без гонки за идеальной цифрой.', (
                 'Для первой пробы возьмите 15 граммов кофе и 250 граммов воды. Это отправная точка, а не универсальный рецепт. Установите бумажный фильтр в подходящую воронку, промойте его горячей водой и слейте воду перед завариванием. Используйте устойчивый сервер и берегите руки от пара.',
                 'Выберите средний помол. Равномерно смочите кофе примерно 40–50 граммами воды и подождите около 30 секунд. Затем добавляйте воду небольшими спокойными порциями, не позволяя уровню подниматься до края. Для многих воронок общее время около трёх минут удобно как начальный ориентир, но форма фильтра и зерно сильно влияют на результат.',
                 'Попробуйте напиток немного остывшим. Запишите дозу, массу воды, помол и впечатление. Если вкус не устраивает, в следующей чашке измените только один параметр. Не пытайтесь одновременно исправить помол, температуру и технику вливания: иначе трудно понять, что помогло.')),
            ('grind', 'Помол и вкус: маленькие шаги', 'Вкус',
             'Как сравнивать две чашки и не спутать крепость с экстракцией.', (
                 'Крепость описывает концентрацию напитка, а экстракция — сколько веществ перешло из кофе в воду. Более крепкая чашка не обязательно лучше заварена. Если вкус в целом приятен, но слишком насыщен, попробуйте добавить немного горячей воды уже в готовый напиток.',
                 'Для сравнения сохраняйте зерно, дозу и массу воды. Меняйте настройку жерновов на небольшой шаг. Более мелкий помол обычно увеличивает контакт с водой и замедляет пролив в фильтре, но слишком мелкие частицы могут забить бумагу и сделать течение неравномерным.',
                 'Резкая кислинка или сухая горечь не указывают на единственную ошибку: важны обжарка, вода и равномерность заваривания. Сделайте две последовательные пробы и сравните после остывания. Описывайте конкретные ощущения — сладость, плотность, сухость — вместо оценки «правильно» или «неправильно».')),
            ('water', 'Вода: незаметная часть рецепта', 'Основа',
             'Что проверить до покупки новой кофемолки.', (
                 'Вода составляет большую часть чашки, поэтому начните с простой проверки: нравится ли вам её вкус без кофе. Используйте питьевую воду без выраженного постороннего запаха. Бытовой фильтр может уменьшать запах хлора, но его возможности зависят от устройства и состояния картриджа.',
                 'Очень жёсткая вода способствует накипи, а состав минералов влияет на восприятие вкуса. Для сравнения достаточно заварить один рецепт на двух доступных видах питьевой воды. Не обязательно сразу покупать приборы или смешивать соли. Дистиллированная вода сама по себе редко удобна как универсальная основа для кофе.',
                 'Температуру тоже лучше держать постоянной во время сравнения. Для фильтра можно начать примерно с 92–96 °C, затем подбирать под зерно и вкус. Не используйте эти числа как требование для любой техники: у гейзерной кофеварки и других устройств есть собственные правила безопасной эксплуатации.')),
            ('storage', 'Хранение зерна без лишних ритуалов', 'Привычки',
             'Меньше воздуха, тепла и влаги; больше внимания к размеру покупки.', (
                 'Храните зерно в плотно закрытой непрозрачной упаковке или ёмкости, вдали от плиты и солнечного окна. Не пересыпайте его ежедневно ради красивой банки. Влажность и посторонние запахи нежелательны, поэтому холодильник для постоянно открываемого пакета обычно неудобен.',
                 'Покупайте объём, который успеете использовать, пока вкус вам нравится. Дата обжарки полезна для сравнения, но не задаёт единственного срока хорошего вкуса: многое зависит от зерна, обжарки и упаковки. Молотый кофе теряет аромат быстрее, поэтому молоть перед завариванием удобно, если есть такая возможность.',
                 'Если нужен длительный запас, можно разделить зерно на герметичные порции для морозильника. Дайте закрытой порции согреться перед открытием, чтобы уменьшить конденсацию, и не замораживайте её повторно без необходимости. Это дополнительный приём, а не обязательная часть домашнего приготовления.')),
            ('cleaning', 'Чистое оборудование — ясный вкус', 'Уход',
             'Короткая уборка после чашки и отдельное внимание к инструкции производителя.', (
                 'После заваривания удалите использованный кофе и промойте съёмные детали, если это допускает инструкция. Не оставляйте мокрую гущу в закрытой посуде. Дайте деталям высохнуть перед сборкой: это помогает избежать затхлого запаха.',
                 'Кофейные масла постепенно остаются на стенках, сетках и жерновах. Для посуды используйте подходящее моющее средство и тщательно смывайте его. Корпус электрической кофемолки нельзя погружать в воду; способ очистки жерновов уточняйте у производителя и отключайте прибор от сети перед обслуживанием.',
                 'Удаление масел и удаление накипи — разные процедуры. Не заливайте случайные кислоты в кофемашину и не смешивайте чистящие средства. Используйте совместимые составы и интервалы из инструкции; для оборудования под давлением особенно важно дождаться остывания и безопасно сбросить давление.')),
        ),
    },
    'photo': {
        'names': ('Свет между делом', 'Рамка и воздух', 'На уровне взгляда'),
        'label': 'Повседневная фотография',
        'intro': 'Замечать свет, оставлять в кадре главное и сохранять снимки. Небольшие упражнения для камеры, которая уже есть под рукой.',
        'caption': 'Линии, свет и пространство в кадре',
        'about': 'Здесь собраны упражнения по наблюдению и базовые приёмы работы со снимками. Для них подходит телефон или отдельная камера: важнее внимание к свету и границам кадра, чем список техники.',
        'caution': 'Снимайте с безопасного места, соблюдайте правила площадок и уважайте частную жизнь. Перед публикацией узнаваемых людей уточняйте согласие и применимые местные требования.',
        'palettes': (('#f0f2f1', '#202b35', '#365b73', '#e0e7e8', '#beced3'),
                     ('#f5f3ef', '#2e3038', '#51536e', '#e6e3ec', '#c9c6d6')),
        'articles': (
            ('window', 'Один предмет, одно окно', 'Свет',
             'Упражнение, которое помогает увидеть мягкость и направление света.', (
                 'Поставьте простой предмет на стол рядом с окном без прямого солнца. Выключите комнатные лампы, чтобы не смешивать источники разного цвета. Снимите предмет спереди, сбоку и со стороны тени, не меняя его положения. Сравните, где лучше читаются форма и фактура.',
                 'Затем отодвиньте предмет от окна и повторите кадр. Яркость уменьшится, а соотношение света и тени может измениться из-за отражений от стен. Если теневая сторона слишком тёмная, поставьте рядом белый лист картона вне кадра: он вернёт часть света без дополнительной лампы.',
                 'Не пытайтесь обязательно получить белый фон и ровную картинку. Выберите вариант, который передаёт нужное настроение. Сохраните несколько снимков вместе и подпишите положение предмета: собственное сравнение нагляднее абстрактного правила. Не оставляйте неустойчивые отражатели у открытого окна.')),
            ('frame', 'Края кадра важны не меньше центра', 'Композиция',
             'Пять секунд перед нажатием, чтобы убрать случайные отвлекающие детали.', (
                 'Выберите главный объект и сформулируйте, что именно хотите показать: силуэт, жест, цветовое пятно или связь с окружением. Перед съёмкой проведите взглядом по всем четырём краям кадра. Яркий обрезанный предмет у границы часто перетягивает внимание с того, ради чего вы снимаете.',
                 'Вместо немедленного увеличения попробуйте небольшой шаг в сторону или изменение высоты камеры, оставаясь в безопасной зоне. Так можно отделить объект от фона и избежать линии, которая случайно проходит через голову человека. Не выходите на дорогу и не подходите к краю высоты ради чистой композиции.',
                 'Сделайте один свободный кадр с окружением и один более плотный. Сравните, сколько пространства нужно истории. Правило третей можно использовать как подсказку, но центр и симметрия тоже работают. Главное — осознанное расположение, а не обязательное попадание в линии сетки.')),
            ('exposure', 'Сохранить светлые участки', 'Камера',
             'Как осторожно работать с экспозицией, когда окно или небо намного ярче остального.', (
                 'Камера не всегда удерживает детали и в ярком небе, и в глубокой тени одновременно. В сцене с сильным контрастом решите, что важнее для снимка. Если важны облака или светлая ткань, проверьте, не превратились ли они в сплошное белое пятно.',
                 'На телефоне коснитесь важной области и при необходимости немного уменьшите яркость ползунком экспозиции. На камере используйте экспокоррекцию в подходящем автоматическом режиме. Сделайте пробный кадр и посмотрите предупреждение пересветов или гистограмму, если они доступны. Блик на металле не всегда нуждается в деталях.',
                 'Сильное осветление тёмных участков при обработке может проявить шум. Иногда лучше сменить ракурс, дождаться облака или перенести съёмку на более мягкий свет. RAW даёт больше свободы обработки на совместимой камере, но не восстанавливает любую потерянную информацию и требует дополнительного места.')),
            ('selection', 'Отбор: оставить не всё, а главное', 'Практика',
             'Два прохода по серии вместо бесконечного сравнения почти одинаковых снимков.', (
                 'Сначала уберите явные технические дубли и случайные кадры, но не удаляйте единственную ценную сцену только из-за небольшого смаза. Работайте с копиями или пометками, если ещё не уверены в выборе. На маленьком экране резкость и мелкие детали оценивать сложнее.',
                 'Во втором проходе выберите снимки, которые отличаются по смыслу: общий план, деталь, действие. Из нескольких почти одинаковых кадров оставьте тот, где лучше жест, границы и свет. Сделайте короткую паузу перед окончательным выбором: сразу после съёмки память о событии иногда мешает оценить саму фотографию.',
                 'Начните обработку с умеренной коррекции яркости, баланса белого и кадрирования. Сравнивайте результат с исходником и проверяйте, не стали ли тени провальными, а цвета неестественными. Для документальной публикации не удаляйте значимые детали сцены и не выдавайте серьёзно изменённый снимок за неизменённый.')),
            ('archive', 'Архив, который можно найти и восстановить', 'Хранение',
             'Понятные папки, независимая копия и проверка восстановления.', (
                 'После съёмки перенесите оригиналы в папку с понятным названием: например, год, месяц и короткое описание события. Выберите один устойчивый порядок и придерживайтесь его. Обработанные версии удобно хранить отдельно, чтобы не перепутать их с исходниками.',
                 'Держите несколько копий на независимых носителях; одну желательно хранить отдельно от основного устройства. Синхронизация сама по себе не всегда является резервной копией: случайное удаление может распространиться на все устройства. Проверьте, есть ли история версий и как долго сохраняются удалённые файлы.',
                 'Периодически открывайте несколько файлов из резервной копии и пробуйте восстановить отдельную папку. Перед публикацией проверьте геометки и другие метаданные, особенно для домашних адресов и частных событий. Не удаляйте оригиналы с карты памяти, пока не убедились, что перенос и резервирование завершены.')),
        ),
    },
}

LAYOUTS = ('journal', 'grid', 'sidebar')
FONTS = {
    'journal': ('Georgia, "Times New Roman", serif', 'Georgia, "Times New Roman", serif'),
    'grid': ('"Trebuchet MS", Arial, sans-serif', '"Trebuchet MS", Arial, sans-serif'),
    'sidebar': ('Verdana, Arial, sans-serif', 'Georgia, "Times New Roman", serif'),
}


CSS = '''
* { box-sizing: border-box; }
html { color-scheme: light; }
body { margin: 0; background: var(--paper); color: var(--ink); font-family: var(--body-font); line-height: 1.75; }
a { color: var(--accent); text-underline-offset: .22em; }
a:hover { text-decoration-thickness: 2px; }
a:focus-visible { outline: 3px solid var(--accent); outline-offset: 5px; }
img { display: block; max-width: 100%; height: auto; }
figure { margin: 0; }
figcaption, .eyebrow, .meta, .brand-label, .footer-note { font-family: Arial, sans-serif; font-size: .78rem; letter-spacing: .06em; }
figcaption { margin-top: .7rem; letter-spacing: .02em; }
h1, h2, h3 { font-family: var(--heading-font); font-weight: 400; line-height: 1.14; margin: 0 0 1.1rem; }
h1 { font-size: clamp(2.6rem, 5.3vw, 4.8rem); letter-spacing: -.045em; }
h2 { font-size: clamp(1.6rem, 3vw, 2.5rem); letter-spacing: -.025em; }
h3 { font-size: 1.55rem; }
p { margin: 0 0 1.25rem; }
h1, h2, h3, p, a { overflow-wrap: anywhere; }
.eyebrow { text-transform: uppercase; color: var(--accent); margin-bottom: 1rem; font-weight: 700; }
.site-shell { max-width: 1240px; margin: auto; padding: 0 clamp(1.25rem, 5vw, 4rem); }
.site-header { padding: 1.8rem 0; border-bottom: 1px solid var(--line); display: flex; align-items: center; justify-content: space-between; gap: 2rem; }
.brand { max-width: 25rem; }
.brand a { font-family: var(--heading-font); font-size: 1.35rem; color: var(--ink); text-decoration: none; line-height: 1.2; display: block; }
.brand-label { display: block; margin-top: .4rem; }
nav { display: flex; flex-wrap: wrap; gap: .6rem 1.4rem; font-family: Arial, sans-serif; font-size: .88rem; }
nav a { text-decoration: none; padding: .25rem 0; }
nav a[aria-current="page"] { border-bottom: 2px solid var(--accent); }
main { min-width: 0; padding: 3.5rem 0 4rem; }
.hero { display: grid; grid-template-columns: 1.1fr 1fr; align-items: center; gap: clamp(2rem, 5vw, 4rem); margin-bottom: 4rem; }
.lede { font-size: 1.12rem; max-width: 42rem; }
.hero-art { background: var(--wash); border-radius: 48% 48% 2px 2px; overflow: hidden; }
.hero-art img { width: 100%; }
.text-link { display: inline-block; font-family: Arial, sans-serif; font-size: .9rem; font-weight: 700; margin-top: .5rem; }
.section-head { display: flex; align-items: baseline; justify-content: space-between; gap: 1rem; border-top: 1px solid var(--line); padding: 1.5rem 0 .8rem; }
.section-head p { font-family: Arial, sans-serif; font-size: .85rem; }
.cards { display: grid; grid-template-columns: repeat(2, minmax(0, 1fr)); gap: 2rem; }
.card { padding: 0 0 1.4rem; border-bottom: 1px solid var(--line); min-width: 0; }
.card-image { display: block; margin-bottom: 1.25rem; background: var(--wash); overflow: hidden; }
.card-image img { width: 100%; aspect-ratio: 2 / 1; object-fit: cover; }
.card h3 a { color: var(--ink); text-decoration: none; }
.card h3 a:hover { text-decoration: underline; }
.card .meta { color: var(--accent); margin-bottom: .6rem; }
.card p { font-size: .96rem; }
.card .text-link { margin-top: 0; }
.field-note { margin-top: 3rem; background: var(--wash); border-left: 3px solid var(--accent); padding: 1.5rem 2rem; }
.field-note h2 { font-size: 1.45rem; }
.field-note p { margin: 0; font-size: .94rem; }
.page-heading { max-width: 48rem; margin-bottom: 3rem; }
.prose { max-width: 43rem; margin: 0 auto; }
.prose h1 { font-size: clamp(2.25rem, 4.5vw, 3.8rem); }
.prose .article-cover { width: 100%; margin: 2rem 0; border-radius: 2px; }
.article-body { font-size: 1.07rem; }
.article-body p { margin-bottom: 1.6rem; }
.breadcrumb { font-family: Arial, sans-serif; font-size: .85rem; margin-bottom: 2rem; }
.related { border-top: 1px solid var(--line); padding-top: 1.5rem; margin-top: 2.5rem; }
.related h2 { font-size: 1.5rem; }
.related ul { padding-left: 1.2rem; }
.related li { margin-bottom: .8rem; }
.site-footer { border-top: 1px solid var(--line); padding: 2rem 0 2.5rem; display: flex; justify-content: space-between; gap: 2rem; }
.footer-title { font-family: var(--heading-font); font-size: 1.2rem; margin-bottom: .4rem; }
.footer-note { max-width: 24rem; letter-spacing: 0; margin-bottom: 0; }
.skip { position: absolute; left: -10000px; }
.skip:focus { left: 1rem; top: 1rem; padding: .8rem; background: var(--paper); z-index: 5; }
.journal .card:first-child { grid-column: 1 / -1; display: grid; grid-template-columns: 1fr 1fr; gap: 2rem; align-items: center; }
.journal .card:first-child .card-image { margin-bottom: 0; }
.journal .card:first-child h3 { font-size: 2rem; }
.grid .hero { grid-template-columns: 1fr; gap: 1.8rem; text-align: center; }
.grid .hero-copy { max-width: 49rem; margin: auto; }
.grid .lede { margin-left: auto; margin-right: auto; }
.grid .hero figure { max-width: 100%; }
.grid .hero-art { border-radius: 3px; }
.grid .hero-art img { max-height: 270px; object-fit: cover; }
.grid .cards { grid-template-columns: repeat(3, minmax(0, 1fr)); gap: 1.2rem; }
.grid .card { border: 1px solid var(--line); padding: .8rem; background: var(--wash); border-radius: 6px; }
.grid .card-copy { padding: .3rem .4rem .6rem; }
.grid h1, .grid h2, .grid h3 { font-weight: 700; }
.grid .card h3 { font-size: 1.35rem; }
.grid .card-image { border-radius: 3px; }
.sidebar .site-shell { display: grid; grid-template-columns: 210px minmax(0, 1fr); column-gap: clamp(2rem, 5vw, 4rem); }
.sidebar .site-header { display: block; grid-column: 1; grid-row: 1 / 3; align-self: start; position: sticky; top: 0; border: 0; padding-top: 3rem; }
.sidebar .brand { border-bottom: 1px solid var(--line); padding-bottom: 1.5rem; margin-bottom: 1.5rem; }
.sidebar .brand a { font-size: 1.7rem; }
.sidebar .site-header nav { flex-direction: column; align-items: flex-start; }
.sidebar main, .sidebar .site-footer { grid-column: 2; }
.sidebar .hero { grid-template-columns: 1fr; gap: 1.5rem; }
.sidebar .hero-copy { max-width: 42rem; }
.sidebar h1 { font-size: clamp(2.5rem, 4.8vw, 4.4rem); }
.sidebar .hero-art { border-radius: 0; }
.sidebar .hero-art img { max-height: 310px; object-fit: cover; }
.sidebar .cards { display: block; }
.sidebar .card { display: grid; grid-template-columns: 140px minmax(0, 1fr); gap: 1.5rem; padding: 1.5rem 0; }
.sidebar .card-image { margin: 0; }
.sidebar .card-image img { aspect-ratio: 1 / 1; }
.sidebar .card h3 { font-size: 1.7rem; }
.sidebar .site-footer { flex-direction: column; gap: 1rem; }
@media (max-width: 900px) {
  .grid .cards { grid-template-columns: repeat(2, minmax(0, 1fr)); }
  .sidebar .site-shell { grid-template-columns: 170px minmax(0, 1fr); column-gap: 2rem; }
  .sidebar .card { grid-template-columns: 100px minmax(0, 1fr); }
}
@media (max-width: 650px) {
  .site-header { align-items: flex-start; flex-direction: column; gap: 1rem; padding: 1.3rem 0; }
  main { padding-top: 2.4rem; }
  .hero, .journal .card:first-child { grid-template-columns: 1fr; gap: 1.5rem; }
  .hero { margin-bottom: 2.5rem; }
  .hero figure { max-width: 30rem; }
  .cards, .grid .cards { grid-template-columns: 1fr; }
  .section-head { display: block; }
  .site-footer { flex-direction: column; }
  .field-note { padding: 1.3rem; }
  .sidebar .site-shell { display: block; }
  .sidebar .site-header { position: static; padding-top: 1.3rem; border-bottom: 1px solid var(--line); }
  .sidebar .brand { border: 0; padding-bottom: 0; margin-bottom: 1rem; }
  .sidebar .site-header nav { flex-direction: row; }
  .sidebar .card { grid-template-columns: 90px minmax(0, 1fr); gap: 1rem; }
  .sidebar .card h3 { font-size: 1.4rem; }
}
@media (max-width: 380px) {
  .sidebar .card { grid-template-columns: 1fr; }
  .sidebar .card-image img { aspect-ratio: 2 / 1; }
}
'''


def esc(text):
    return html.escape(text, quote=True)


def illustration(theme, variant, palette):
    """Local drawings with theme-specific geometry, not downloaded artwork."""
    paper, ink, accent, wash, line = palette
    if theme == 'plants':
        drawings = (
            f'<path d="M235 280H405L385 370H255Z" fill="{accent}"/>'
            f'<path d="M320 286V95M320 215Q220 220 205 130Q300 120 320 215M320 170Q410 180 440 75Q335 75 320 170" fill="{line}" stroke="{ink}" stroke-width="3"/>',
            f'<path d="M170 340Q315 285 460 80M270 280Q175 280 180 195Q260 185 270 280M340 220Q335 120 405 110Q430 180 340 220M400 160Q450 195 510 155Q480 100 400 160" fill="{accent}" stroke="{ink}" stroke-width="3"/>',
            f'<rect x="175" y="290" width="290" height="65" rx="8" fill="{accent}"/>'
            f'<path d="M235 290V130M320 290V90M405 290V150" stroke="{ink}" stroke-width="5"/>'
            f'<ellipse cx="214" cy="160" rx="35" ry="58" fill="{line}"/><ellipse cx="341" cy="130" rx="35" ry="65" fill="{accent}"/><ellipse cx="425" cy="195" rx="35" ry="55" fill="{line}"/>',
        )
    elif theme == 'coffee':
        drawings = (
            f'<ellipse cx="310" cy="330" rx="170" ry="22" fill="{line}"/>'
            f'<path d="M425 165H470Q530 225 450 260H420" fill="none" stroke="{accent}" stroke-width="18"/>'
            f'<path d="M190 150H435L410 300Q310 345 215 300Z" fill="{accent}"/><ellipse cx="312" cy="150" rx="122" ry="24" fill="{ink}"/>'
            f'<path d="M270 105Q245 75 275 40M340 105Q315 75 345 40" fill="none" stroke="{line}" stroke-width="7"/>',
            f'<path d="M205 85H435L350 240H290Z" fill="{accent}"/><path d="M240 100L310 225M285 95L320 225M390 100L330 225" stroke="{paper}" stroke-width="4"/>'
            f'<rect x="230" y="250" width="180" height="90" rx="15" fill="{line}"/><path d="M320 242V265" stroke="{ink}" stroke-width="4"/>',
            f'<ellipse cx="255" cy="185" rx="75" ry="115" transform="rotate(-30 255 185)" fill="{accent}"/>'
            f'<path d="M225 90Q300 185 280 280" fill="none" stroke="{paper}" stroke-width="8"/>'
            f'<ellipse cx="415" cy="255" rx="60" ry="90" transform="rotate(35 415 255)" fill="{ink}"/>'
            f'<path d="M448 183Q385 250 390 328" fill="none" stroke="{paper}" stroke-width="7"/>',
        )
    else:
        drawings = (
            f'<rect x="120" y="90" width="400" height="245" rx="8" fill="{ink}"/>'
            f'<rect x="160" y="55" width="125" height="45" rx="8" fill="{accent}"/>'
            f'<circle cx="335" cy="212" r="93" fill="{line}"/><circle cx="335" cy="212" r="64" fill="{accent}"/><circle cx="335" cy="212" r="35" fill="{ink}"/>'
            f'<rect x="445" y="120" width="40" height="24" rx="3" fill="{paper}"/>',
            f'<rect x="115" y="55" width="410" height="300" fill="{ink}"/><rect x="135" y="75" width="370" height="245" fill="{line}"/>'
            f'<circle cx="410" cy="135" r="35" fill="{paper}"/><path d="M135 320V270L250 155L355 275L415 220L505 300V320Z" fill="{accent}"/>',
            f'<rect x="170" y="45" width="300" height="310" fill="{ink}"/><path d="M190 65H450V335H190Z" fill="{line}"/>'
            f'<path d="M190 65L450 335H190Z" fill="{accent}"/><path d="M320 65V335M190 195H450" stroke="{paper}" stroke-width="10"/>'
            f'<path d="M100 355H540" stroke="{ink}" stroke-width="4"/>',
        )
    return (f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 640 400">'
            f'<title>{esc(CONTENT[theme]["caption"])}</title>'
            f'<rect width="640" height="400" fill="{wash}"/>'
            f'<circle cx="540" cy="65" r="110" fill="{paper}"/>'
            f'{drawings[variant % len(drawings)]}</svg>')


def generate(theme, output, title=None):
    """Render and atomically publish a new site; never replace an existing path.

    The parent directory must exist. Links are site-root-relative, so serve the
    generated directory as the document root. The selected design lives in the
    HTML, CSS and SVG files; no runtime, network or private metadata is required.
    """
    if not isinstance(theme, str) or theme not in CONTENT:
        raise SiteError('Неизвестная тема: выберите plants, coffee или photo.')
    if title is not None:
        if (not isinstance(title, str) or not title.strip() or len(title) > 160
                or any(ord(c) < 32 or ord(c) == 127 for c in title)):
            raise SiteError('Название должно содержать от 1 до 160 символов без управляющих знаков.')
        title = title.strip()
    content = CONTENT[theme]
    title = title if title is not None else secrets.choice(content['names'])
    layout = secrets.choice(LAYOUTS)
    palette = secrets.choice(content['palettes'])
    variant = secrets.choice((0, 1, 2))
    paper, ink, accent, wash, line = palette
    body_font, heading_font = FONTS[layout]
    css = (f':root {{ --paper: {paper}; --ink: {ink}; --accent: {accent}; '
           f'--wash: {wash}; --line: {line}; --body-font: {body_font}; '
           f'--heading-font: {heading_font}; }}\n' + CSS)

    def nav(current, label):
        links = []
        for filename, text in (('index.html', 'Главная'), ('notes.html', 'Заметки'), ('about.html', 'О сайте')):
            active = ' aria-current="page"' if filename == current else ''
            links.append(f'<a href="/{filename}"{active}>{text}</a>')
        return f'<nav aria-label="{label}">{"".join(links)}</nav>'

    def page(page_title, body, current, description=None):
        return f'''<!doctype html>
<html lang="ru"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>{esc(page_title)} — {esc(title)}</title>
<meta name="description" content="{esc(description or content['intro'])}">
<link rel="stylesheet" href="/style.css"><link rel="icon" href="/favicon.svg" type="image/svg+xml">
</head><body class="{layout} theme-{theme}">
<a class="skip" href="#main">К содержанию</a><div class="site-shell">
<header class="site-header"><div class="brand"><a href="/index.html">{esc(title)}</a>
<span class="brand-label">{esc(content['label'])}</span></div>{nav(current, 'Основная навигация')}</header>
<main id="main">{body}</main>
<footer class="site-footer"><div><p class="footer-title">{esc(title)}</p>
<p class="footer-note">Практические заметки. Внимание к деталям вместо спешки.</p></div>
{nav(current, 'Навигация внизу страницы')}</footer></div></body></html>
'''

    def cards(articles):
        result = []
        for article in articles:
            slug, heading, category, summary, _ = article
            result.append(f'''<article class="card">
<a class="card-image" href="/articles/{slug}.html" aria-label="{esc(heading)}">
<img src="/illustrations/{slug}.svg" alt="" width="640" height="400" loading="lazy"></a>
<div class="card-copy"><p class="meta">{esc(category)}</p><h3><a href="/articles/{slug}.html">{esc(heading)}</a></h3>
<p>{esc(summary)}</p><a class="text-link" href="/articles/{slug}.html">Читать материал →</a></div></article>''')
        return '<div class="cards">' + ''.join(result) + '</div>'

    def caution():
        return f'<aside class="field-note"><h2>Важная оговорка</h2><p>{esc(content["caution"])}</p></aside>'

    articles = content['articles']
    hero = f'''<section class="hero" aria-labelledby="home-title"><div class="hero-copy">
<p class="eyebrow">Небольшой журнал · {esc(content['label'])}</p><h1 id="home-title">{esc(title)}</h1>
<p class="lede">{esc(content['intro'])}</p><a class="text-link" href="/notes.html">Открыть все заметки →</a></div>
<figure><div class="hero-art"><img src="/illustration.svg" alt="" width="640" height="400"></div>
<figcaption>{esc(content['caption'])}</figcaption></figure></section>'''
    pages = {
        'index.html': page('Главная', hero + '<section aria-labelledby="latest"><div class="section-head">'
                           '<h2 id="latest">С чего начать</h2><p>Пять материалов для практики</p></div>'
                           + cards(articles) + '</section>' + caution(), 'index.html'),
        'notes.html': page('Заметки', '<div class="page-heading"><p class="eyebrow">Тетрадь практики</p>'
                          '<h1>Заметки</h1><p class="lede">Выберите вопрос, который интересует вас сейчас. '
                          'Каждый материал — самостоятельная отправная точка для наблюдения и небольшой пробы.</p></div>'
                          + cards(articles) + caution(), 'notes.html'),
        'about.html': page('О сайте', '<article class="prose"><p class="eyebrow">О проекте</p><h1>О сайте</h1>'
                          f'<p class="lede">{esc(content["about"])}</p><h2>Как пользоваться материалами</h2>'
                          '<p>Начните с одного вопроса, попробуйте небольшой шаг и сравните результат. '
                          'Условия и личные предпочтения различаются, поэтому приведённые ориентиры не являются гарантией результата.</p>'
                          '<h2>Что здесь опубликовано</h2><p>Это общие справочные материалы, а не личные истории, '
                          'рекомендации конкретных товаров или индивидуальные консультации. '
                          'На сайте нет форм, аналитических скриптов и внешних загрузок.</p>'
                          '<p><a href="/notes.html">Перейти к подборке заметок →</a></p>' + caution() + '</article>', 'about.html'),
        'style.css': css,
        'illustration.svg': illustration(theme, variant, palette),
        'favicon.svg': (f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64">'
                        f'<title>{esc(title)}</title><rect width="64" height="64" rx="14" fill="{accent}"/>'
                        f'<text x="32" y="45" text-anchor="middle" font-family="serif" font-size="40" '
                        f'fill="{paper}">{esc(title[0].upper())}</text></svg>'),
    }
    for number, (slug, heading, category, summary, paragraphs) in enumerate(articles):
        related = [item for item in articles if item[0] != slug][:2]
        related_links = ''.join(f'<li><a href="/articles/{item[0]}.html">{esc(item[1])}</a></li>' for item in related)
        body = (f'<article class="prose"><p class="breadcrumb"><a href="/notes.html">Все заметки</a> / {esc(category)}</p>'
                f'<p class="eyebrow">{esc(category)}</p><h1>{esc(heading)}</h1><p class="lede">{esc(summary)}</p>'
                f'<img class="article-cover" src="/illustrations/{slug}.svg" alt="" width="640" height="400">'
                '<div class="article-body">' + ''.join(f'<p>{esc(p)}</p>' for p in paragraphs) + '</div>'
                '<aside class="related"><h2>Продолжить чтение</h2><ul>' + related_links + '</ul>'
                '<a class="text-link" href="/notes.html">Все материалы →</a></aside></article>')
        pages[f'articles/{slug}.html'] = page(heading, body, None, summary)
        pages[f'illustrations/{slug}.svg'] = illustration(theme, variant + number, palette)

    def build(staging):
        public = staging / 'public'
        public.mkdir()
        (public / 'articles').mkdir()
        (public / 'illustrations').mkdir()
        for name, text in pages.items():
            (public / name).write_text(text, encoding='utf-8')

    # publish validates the complete staging tree and performs atomic no-replace.
    site_tool.publish(output, build)


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--theme', choices=tuple(CONTENT), required=True, help='Тема сайта')
    parser.add_argument('--output', required=True, help='Новый каталог в существующем родительском каталоге')
    parser.add_argument('--title', help='Своё название, до 160 символов')
    args = parser.parse_args(argv)
    try:
        generate(args.theme, args.output, args.title)
    except SiteError as error:
        print('Ошибка: ' + str(error), file=sys.stderr)
        return 1
    except (OSError, ValueError, RecursionError, ET.ParseError):
        print('Ошибка: некорректные данные или недоступная операция с файлами.', file=sys.stderr)
        return 1
    print('Готово: статический сайт создан и проверен.')
    return 0


if __name__ == '__main__':
    sys.exit(main())
