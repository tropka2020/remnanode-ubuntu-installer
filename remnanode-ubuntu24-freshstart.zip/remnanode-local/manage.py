#!/usr/bin/env python3
"""Conservative local deployment tools for Remnawave and an owner-operated site."""
import argparse
import contextlib
import ipaddress
import json
import os
from pathlib import Path
import re
import shutil
import signal
import socket
import stat
import subprocess
import sys
import tempfile
import time

import progress

BASE = Path(__file__).resolve().parent
NODE = Path('/opt/remnanode')
WEB = Path('/opt/caddy')
BACKUPS = Path('/var/backups/remnanode-local')
IMAGE = re.compile(r'^[a-zA-Z0-9][a-zA-Z0-9./:_-]*@sha256:[a-f0-9]{64}$')
NODE_IMAGE = 'remnawave/node:latest'
DOMAIN = re.compile(r'^(?=.{1,253}$)(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z]{2,63}$')


class Failure(Exception):
    pass


def run(args, *, capture=False, combine_output=False, check=True, timeout=120, env=None):
    program = Path(str(args[0])).name
    try:
        with progress.command():
            result = subprocess.run([str(a) for a in args], stdout=subprocess.PIPE,
                                    stderr=subprocess.PIPE, text=True, encoding='utf-8', timeout=timeout, env=env)
    except (OSError, subprocess.TimeoutExpired) as exc:
        raise Failure('Команда недоступна или превысила таймаут: ' + program) from exc
    if check and result.returncode:
        # Commands can include secrets in diagnostics, so never echo their output.
        raise Failure('Команда завершилась ошибкой: ' + program +
                      '. Проверьте локальные журналы; вывод скрыт для защиты секретов.')
    if capture and combine_output:
        return (result.stdout or '') + (result.stderr or '')
    return result.stdout if capture else result


def check_domain(value):
    value = value.lower()
    if not DOMAIN.fullmatch(value):
        raise argparse.ArgumentTypeError('Ожидается DNS-имя без схемы, порта и пути.')
    return value


def check_ip(value):
    try:
        address = ipaddress.IPv4Address(value)
        if address.is_unspecified or address.is_multicast or address.is_loopback or int(address) == 0xffffffff:
            raise ipaddress.AddressValueError('Неподходящий адрес панели')
        return str(address)
    except ipaddress.AddressValueError as exc:
        raise argparse.ArgumentTypeError('Ожидается IPv4 без ведущих нулей.') from exc


def check_image(value):
    if not IMAGE.fullmatch(value):
        raise argparse.ArgumentTypeError('Укажите доверенный образ repository@sha256:<64 hex>.')
    return value


def check_node_image(value):
    if value != NODE_IMAGE and not IMAGE.fullmatch(value):
        raise argparse.ArgumentTypeError('Укажите remnawave/node:latest или доверенный образ repository@sha256:<64 hex>.')
    return value


def _yaml_scalar(value):
    # JSON double-quoted strings are valid YAML scalars and avoid PyYAML.
    quoted = json.dumps(str(value), ensure_ascii=False)
    # YAML treats NEL/Unicode line separators differently from JSON and rejects C1 controls.
    return ''.join(f'\\u{ord(char):04x}' if 0x7f <= ord(char) <= 0x9f or
                   ord(char) in (0x2028, 0x2029) else char for char in quoted)


def node_compose(secret, image=NODE_IMAGE):
    if not isinstance(secret, str) or not secret:
        raise ValueError('SECRET_KEY must be a non-empty string')
    check_node_image(image)
    escaped_secret = secret.replace('$', '$$')
    return '\n'.join([
        'services:',
        '  remnanode:',
        f'    image: {_yaml_scalar(image)}',
        '    container_name: remnanode',
        '    hostname: remnanode',
        '    network_mode: host',
        '    restart: always',
        '    cap_add:',
        '      - NET_ADMIN',
        '    ulimits:',
        '      nofile:',
        '        soft: 1048576',
        '        hard: 1048576',
        '    environment:',
        f'      - {_yaml_scalar("NODE_PORT=2222")}',
        f'      - {_yaml_scalar("SECRET_KEY=" + escaped_secret)}',
        '    volumes:',
        '      - /var/log/remnanode:/var/log/remnanode',
        ''
    ])


def secure_path(path, *, directory=None, allow_system_parent=False):
    path = Path(os.path.abspath(path))
    for part in [*reversed(path.parents), path]:
        if not part.exists() and not part.is_symlink():
            continue
        info = part.lstat()
        if stat.S_ISLNK(info.st_mode):
            raise Failure('Символические ссылки в системных путях запрещены: ' + str(part))
        trusted_log_parent = False
        if (allow_system_parent and path == Path(os.path.abspath('/var/log/remnanode')) and
                part == Path(os.path.abspath('/var/log')) and stat.S_ISDIR(info.st_mode) and
                info.st_uid == 0 and not info.st_mode & 0o002):
            import grp
            try:
                trusted_log_parent = info.st_gid == grp.getgrnam('syslog').gr_gid
            except KeyError:
                pass
        if info.st_uid != 0 or (info.st_mode & 0o022 and not trusted_log_parent):
            raise Failure('Путь должен принадлежать root и не допускать чужую запись: ' + str(part))
    if path.exists():
        info = path.stat()
        if directory is True and not stat.S_ISDIR(info.st_mode):
            raise Failure('Ожидается каталог: ' + str(path))
        if directory is False and (not stat.S_ISREG(info.st_mode) or info.st_nlink != 1):
            raise Failure('Ожидается обычный файл без hard links: ' + str(path))
    return path


def atomic_write(path, text, mode=0o600):
    path = Path(path)
    secure_path(path)
    fd, temporary = tempfile.mkstemp(prefix='.write-', dir=path.parent)
    try:
        with os.fdopen(fd, 'w', encoding='utf-8', newline='\n') as stream:
            stream.write(text)
            stream.flush()
            os.fsync(stream.fileno())
        os.chmod(temporary, mode)
        os.replace(temporary, path)
    finally:
        if os.path.exists(temporary):
            os.unlink(temporary)


def write_json(path, value):
    atomic_write(path, json.dumps(value, ensure_ascii=False, indent=2) + '\n')


def compose(directory, *args):
    return run(['docker', 'compose', '--project-directory', directory, '-f',
                directory / 'docker-compose.yml', *args], timeout=240)


def inspect(name):
    result = run(['docker', 'container', 'inspect', name], check=False)
    if result.returncode:
        names = run(['docker', 'container', 'ls', '--all', '--filter',
                     'name=^/' + name + '$', '--format', '{{.Names}}'], capture=True)
        if name not in names.splitlines():
            return None
        raise Failure('Docker не подтвердил состояние существующего контейнера: ' + name)
    try:
        data = json.loads(result.stdout)
        if (not isinstance(data, list) or len(data) != 1 or not isinstance(data[0], dict) or
                not isinstance(data[0].get('State'), dict) or
                not isinstance(data[0]['State'].get('Status'), str)):
            raise ValueError('Unknown container state')
        return data[0]
    except (ValueError, IndexError, KeyError, TypeError) as exc:
        raise Failure('Не удалось прочитать состояние контейнера.') from exc


def confirm_stopped(name):
    obj = inspect(name)
    if obj is not None and obj.get('State', {}).get('Status') not in ('exited', 'created', 'dead'):
        raise Failure('Остановка контейнера не подтверждена; каталоги и ограничения сохранены: ' + name)


def requirements():
    if sys.platform != 'linux' or os.geteuid() != 0:
        raise Failure('Развёртывание разрешено только от root на Linux; генератор работает отдельно.')
    secure_path(BASE, directory=True)
    for file in ('manage.py', 'site.py', 'install-remnanode.sh'):
        secure_path(BASE / file, directory=False)
    info = Path('/etc/os-release').read_text()
    if not re.search(r'^ID=(?:"?)(ubuntu|debian)(?:"?)$', info, re.M):
        raise Failure('Поддерживаются Ubuntu и Debian.')
    for command in ('docker', 'curl'):
        if not shutil.which(command):
            raise Failure('Сначала установите ' + command + ' из доверенного пакетного репозитория.')
    run(['docker', 'compose', 'version'])
    run(['docker', 'info'])


@contextlib.contextmanager
def lock():
    import fcntl
    path = Path('/run/remnanode-local.lock')
    secure_path(path)
    flags = os.O_CREAT | os.O_RDWR | os.O_NOFOLLOW
    fd = os.open(path, flags, 0o600)
    try:
        info = os.fstat(fd)
        if info.st_uid != 0 or info.st_nlink != 1 or not stat.S_ISREG(info.st_mode):
            raise Failure('Небезопасный lock-файл.')
        try:
            fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError as exc:
            raise Failure('Другой процесс уже выполняет установку.') from exc
        yield
    finally:
        os.close(fd)


def site_tool(*args):
    run([sys.executable, BASE / 'site.py', *args])


def read_secret(path):
    path = secure_path(path, directory=False)
    if not path.is_file() or path.stat().st_mode & 0o077:
        raise Failure('Файл секрета должен существовать и иметь права 600 или 400.')
    if path.stat().st_size > 16384:
        raise Failure('Слишком большой SECRET_KEY.')
    value = path.read_text(encoding='utf-8').rstrip('\n')
    if not value or any(c.isspace() or ord(c) < 32 or ord(c) == 127 for c in value):
        raise Failure('SECRET_KEY не должен быть пустым или содержать пробелы/управляющие символы.')
    return value


def assert_free(port, host='0.0.0.0'):
    with socket.socket() as listener:
        try:
            listener.bind((host, port))
        except OSError as exc:
            raise Failure('Порт занят или недоступен: ' + str(port)) from exc


def wait_container(name, port, timeout=60):
    deadline = time.monotonic() + timeout
    consecutive = 0
    while time.monotonic() < deadline:
        obj = inspect(name)
        state = (obj or {}).get('State', {})
        if state.get('Running') and not state.get('Restarting'):
            health = state.get('Health', {}).get('Status')
            try:
                with socket.create_connection(('127.0.0.1', port), timeout=2):
                    pass
                if health not in ('unhealthy', 'starting'):
                    consecutive += 1
                    if consecutive >= 3:
                        return
                else:
                    consecutive = 0
            except OSError:
                consecutive = 0
        else:
            consecutive = 0
        time.sleep(2)
    raise Failure('Сервис не подтвердил стабильный запуск и слушающий порт: ' + name)


def check_https(domain, port, expected=None):
    args = ['curl', '--fail', '--silent', '--show-error', '--noproxy', '*',
            '--connect-timeout', '5', '--max-time', '15',
            '--resolve', f'{domain}:{port}:127.0.0.1', '--write-out', '\n%{http_code}',
            f'https://{domain}:{port}/']
    # curl verifies both the certificate chain and hostname; never use --insecure.
    result = run(args, capture=True, timeout=20)
    body, separator, status = result.rpartition('\n')
    if not separator or status != '200':
        raise Failure('HTTPS не вернул ожидаемый статус 200; перенаправления не принимаются.')
    if expected is not None and body != expected:
        raise Failure('HTTPS вернул не тот index.html; содержимое не подтверждено.')


def wait_https(domain, port, expected, timeout=120):
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        try:
            check_https(domain, port, expected)
            return
        except Failure:
            time.sleep(3)
    raise Failure('HTTPS, сертификат или опубликованное содержимое не прошли проверку.')


def backup_dir(label):
    secure_path(BACKUPS, directory=True)
    BACKUPS.mkdir(mode=0o700, parents=True, exist_ok=True)
    os.chmod(BACKUPS, 0o700)
    return Path(tempfile.mkdtemp(prefix=label + '-', dir=BACKUPS))


def verify_firewall_order(status, panel):
    rows = []
    for line in status.splitlines():
        match = re.match(r'^\[\s*\d+\]\s+(.*)$', line.strip())
        if match:
            rows.append(' '.join(match.group(1).split('#', 1)[0].split()))
    ipv4 = [row for row in rows if '(v6)' not in row]
    ipv6 = [row for row in rows if '(v6)' in row]
    if (ipv4[:2] != ['2222/tcp ALLOW IN ' + panel, '2222/tcp DENY IN Anywhere'] or
            ipv6[:1] != ['2222/tcp (v6) DENY IN Anywhere (v6)']):
        raise Failure('UFW не подтвердил приоритет правил API (возможно, дубликат). Изменения отменяются.')


def configure_firewall(panel):
    if not shutil.which('ufw'):
        raise Failure('Требуется заранее настроенный активный UFW.')
    env = {**os.environ, 'LC_ALL': 'C', 'LANG': 'C'}
    status = run(['ufw', 'status'], capture=True, env=env)
    config = secure_path('/etc/default/ufw', directory=False).read_text()
    if 'Status: active' not in status or not re.search(r'^IPV6=yes$', config, re.M):
        raise Failure('Требуется активный UFW с IPV6=yes. SSH и исходную политику настройте заранее.')
    folder = backup_dir('ufw')
    for name in ('user.rules', 'user6.rules'):
        source = secure_path(Path('/etc/ufw') / name, directory=False)
        shutil.copy2(source, folder / name)
    try:
        # Prepending defeats old broad allows for this API without changing SSH policy.
        run(['ufw', 'insert', '1', 'deny', 'in', 'to', 'any', 'port', '2222', 'proto', 'tcp',
             'comment', 'remnanode-local-deny'])
        run(['ufw', 'insert', '1', 'allow', 'in', 'from', panel, 'to', 'any', 'port', '2222',
             'proto', 'tcp', 'comment', 'remnanode-local-panel'])
        run(['ufw', 'reload'])
        verified = run(['ufw', 'status', 'numbered'], capture=True, env=env)
        verify_firewall_order(verified, panel)
    except BaseException:
        restore_firewall(folder)
        raise
    return folder


def restore_firewall(folder):
    for name in ('user.rules', 'user6.rules'):
        secure_path(Path('/etc/ufw') / name, directory=False)
        shutil.copy2(folder / name, Path('/etc/ufw') / name)
    run(['ufw', 'reload'])


def install_node(args):
    if NODE.exists() or NODE.is_symlink() or inspect('remnanode'):
        raise Failure('Нода или /opt/remnanode уже существует. Автоматическая перезапись запрещена.')
    secret = read_secret(Path(args.secret_file))
    secure_path(NODE)
    assert_free(2222)
    run(['docker', 'pull', args.image], timeout=600)
    firewall_backup = configure_firewall(args.panel_ip)
    created = False
    try:
        NODE.mkdir(mode=0o700)
        created = True
        logdir = secure_path('/var/log/remnanode', directory=True, allow_system_parent=True)
        logdir.mkdir(mode=0o750, exist_ok=True)
        atomic_write(NODE / 'docker-compose.yml', node_compose(secret, args.image))
        compose(NODE, 'config', '--quiet')
        compose(NODE, 'up', '-d', '--no-build', '--pull', 'never')
        wait_container('remnanode', 2222)
        write_json(NODE / 'managed.json', {'version': 1, 'panel_ip': args.panel_ip, 'image': args.image})
    except BaseException:
        # Keep API restrictions if container shutdown fails; restoring old rules could expose it.
        if created:
            if inspect('remnanode'):
                compose(NODE, 'down')
                confirm_stopped('remnanode')
            failed = backup_dir('failed-node') / 'remnanode'
            NODE.rename(failed)
        restore_firewall(firewall_backup)
        raise
    print('Нода запущена; API ограничен UFW. Прикладную авторизацию проверьте из панели.')
    print('Резервная копия прежних правил UFW:', firewall_backup)
    print('Сайт и конфигурация REALITY этой командой не изменялись.')


def install_web(args):
    if WEB.exists() or WEB.is_symlink() or inspect('remnanode-web'):
        raise Failure('/opt/caddy или контейнер уже существует. Используйте publish-site для текущего сайта.')
    if Path('/opt/nginx-selfsteal').exists():
        raise Failure('Найдена существующая установка Nginx. Автоматическая замена запрещена.')
    secure_path(WEB)
    site_tool('validate', '--source', args.source)
    for port in (80, 443):
        assert_free(port)
    socket.getaddrinfo(args.domain, 443)
    run(['docker', 'pull', args.image], timeout=600)
    WEB.mkdir(mode=0o755)
    started = False
    try:
        site_tool('copy', '--source', args.source, '--output', WEB / 'html')
        atomic_write(WEB / 'Caddyfile',
                     '{\n    admin off\n}\n' + args.domain +
                     ' {\n    root * /var/www/html\n    encode gzip\n    file_server\n}\n')
        service = {'image': args.image, 'container_name': 'remnanode-web',
                   'restart': 'unless-stopped', 'network_mode': 'host',
                   'volumes': ['./Caddyfile:/etc/caddy/Caddyfile:ro', './html:/var/www/html:ro',
                               'caddy_data:/data', 'caddy_config:/config'],
                   'logging': {'driver': 'json-file', 'options': {'max-size': '10m', 'max-file': '3'}}}
        write_json(WEB / 'docker-compose.yml', {'services': {'caddy': service},
                   'volumes': {'caddy_data': {}, 'caddy_config': {}}})
        compose(WEB, 'config', '--quiet')
        compose(WEB, 'run', '--rm', '--no-deps', 'caddy', 'caddy', 'validate',
                '--config', '/etc/caddy/Caddyfile', '--adapter', 'caddyfile')
        started = True
        compose(WEB, 'up', '-d', '--no-build', '--pull', 'never')
        wait_https(args.domain, 443, (WEB / 'html/index.html').read_text(encoding='utf-8'))
        write_json(WEB / 'managed.json', {'version': 1, 'domain': args.domain, 'image': args.image})
    except BaseException:
        if started:
            compose(WEB, 'down')
            confirm_stopped('remnanode-web')
        WEB.rename(backup_dir('failed-web') / 'caddy')
        raise
    print('Обычный HTTPS-сайт установлен. Firewall, нода и REALITY не изменялись.')


def verify_caddy(container):
    secure_path(WEB, directory=True)
    obj = inspect(container)
    if not obj or not obj.get('State', {}).get('Running'):
        raise Failure('Нужен существующий работающий контейнер Caddy.')
    mounts = obj.get('Mounts', [])
    matched = [m for m in mounts if m.get('Destination') == '/var/www/html']
    if len(matched) != 1 or matched[0].get('Type') != 'bind' or matched[0].get('Source') != '/opt/caddy/html':
        raise Failure('Неизвестная схема: требуется bind /opt/caddy/html -> /var/www/html.')
    config_mount = [m for m in mounts if m.get('Destination') == '/etc/caddy/Caddyfile']
    if len(config_mount) != 1 or config_mount[0].get('Source') != '/opt/caddy/Caddyfile':
        raise Failure('Неизвестное расположение Caddyfile; публикация остановлена.')
    for name in ('Caddyfile', 'docker-compose.yml'):
        secure_path(WEB / name, directory=False)
    text = (WEB / 'Caddyfile').read_text()
    if not re.search(r'\broot\s+\*\s+/var/www/html\s*$', text, re.M):
        raise Failure('Caddyfile не подтверждает ожидаемый корень сайта.')
    if not inspect(container)['Config']['Image'].split('/')[-1].startswith('caddy'):
        raise Failure('Неизвестный образ контейнера; проверьте схему вручную.')
    return obj


def publish_site(args):
    verify_caddy(args.container)
    destination = secure_path(WEB / 'html', directory=True)
    if not destination.is_dir():
        raise Failure('Каталог существующего сайта не найден.')
    # Check that this domain/port already works before touching any published files.
    check_https(args.domain, args.port)
    site_tool('validate', '--source', args.source)
    backup = backup_dir('site')
    staging_parent = Path(tempfile.mkdtemp(prefix='.publish-', dir=WEB))
    stage = staging_parent / 'html'
    old = WEB / ('.previous-' + backup.name)
    switched = False
    stopped = False
    try:
        site_tool('copy', '--source', args.source, '--output', stage)
        # Copies stay root-only inside a private backup parent, including old template assets.
        shutil.copytree(destination, backup / 'html', symlinks=True)
        for name in ('Caddyfile', 'docker-compose.yml', '.env'):
            if (WEB / name).exists():
                secure_path(WEB / name, directory=False)
                shutil.copy2(WEB / name, backup / name)
        write_json(backup / 'restore.json', {'container': args.container, 'domain': args.domain,
                                           'port': args.port, 'target': str(destination)})
        stopped = True
        run(['docker', 'stop', '--time', '20', args.container], timeout=45)
        confirm_stopped(args.container)
        destination.rename(old)
        try:
            stage.rename(destination)
        except BaseException:
            old.rename(destination)
            raise
        switched = True
        run(['docker', 'start', args.container])
        wait_https(args.domain, args.port, (destination / 'index.html').read_text(encoding='utf-8'), timeout=60)
    except BaseException:
        if switched:
            # Do not rename a possibly live bind mount or delete either version on stop failure.
            run(['docker', 'stop', '--time', '20', args.container], check=False, timeout=45)
            confirm_stopped(args.container)
            destination.rename(staging_parent / 'failed-html')
            old.rename(destination)
        if stopped:
            run(['docker', 'start', args.container])
            check_https(args.domain, args.port)
        raise
    finally:
        # Only staging directories created in this invocation are removed.
        shutil.rmtree(staging_parent)
    shutil.rmtree(old)
    print('Сайт опубликован; Caddyfile, сертификаты и настройки ноды не изменены.')
    print('Резервная копия:', backup)
    print('Был краткий перерыв обслуживания на остановку/запуск Caddy.')


def parser():
    p = argparse.ArgumentParser(description=__doc__)
    commands = p.add_subparsers(dest='command', required=True)
    node = commands.add_parser('install-node', help='Только новая нода; существующую не перезаписывает')
    node.add_argument('--panel-ip', type=check_ip, required=True)
    node.add_argument('--secret-file', required=True)
    node.add_argument('--image', type=check_node_image, default=NODE_IMAGE)
    web = commands.add_parser('install-web', help='Новый обычный HTTPS-сайт, без изменения REALITY')
    web.add_argument('--domain', type=check_domain, required=True)
    web_content = web.add_mutually_exclusive_group(required=True)
    web_content.add_argument('--source', help='Подготовленный собственный статический сайт')
    web_content.add_argument('--content', help='JSON владельца: сгенерировать сайт при установке')
    web.add_argument('--image', type=check_image, required=True)
    publish = commands.add_parser('publish-site', help='Замена HTML в известном контейнере Caddy')
    publish.add_argument('--domain', type=check_domain, required=True)
    publish.add_argument('--port', type=int, default=443)
    publish_content = publish.add_mutually_exclusive_group(required=True)
    publish_content.add_argument('--source', help='Подготовленный собственный статический сайт')
    publish_content.add_argument('--content', help='JSON владельца: сгенерировать сайт при публикации')
    publish.add_argument('--container', choices=['caddy-selfsteal', 'remnanode-web'], default='caddy-selfsteal')
    for cmd in (node, web, publish):
        cmd.add_argument('--apply', action='store_true', help='Явно разрешить описанные изменения')
    return p


def main():
    os.umask(0o077)
    def interrupted(signum, frame):
        raise KeyboardInterrupt
    signal.signal(signal.SIGTERM, interrupted)
    args = parser().parse_args()
    if not args.apply:
        raise Failure('Изменения не выполнены. Прочтите README и добавьте --apply для выполнения.')
    if hasattr(args, 'port') and not 1 <= args.port <= 65535:
        raise Failure('Недопустимый порт HTTPS.')
    requirements()
    with lock():
        dispatch = {'install-node': install_node, 'install-web': install_web,
                    'publish-site': publish_site}[args.command]
        if getattr(args, 'content', None):
            secure_path('/opt', directory=True)
            with tempfile.TemporaryDirectory(prefix='remnanode-content-', dir='/opt') as temporary:
                args.source = str(Path(temporary) / 'public')
                site_tool('generate', '--content', args.content, '--output', args.source)
                dispatch(args)
        else:
            dispatch(args)


if __name__ == '__main__':
    try:
        main()
    except (Failure, OSError, UnicodeError) as error:
        print('ОШИБКА:', error, file=sys.stderr)
        sys.exit(1)
    except KeyboardInterrupt:
        print('Операция прервана. Проверьте состояние служб и резервные копии.', file=sys.stderr)
        sys.exit(130)
