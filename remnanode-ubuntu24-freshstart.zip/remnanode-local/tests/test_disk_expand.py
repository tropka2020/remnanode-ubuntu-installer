"""Synthetic disk geometry only. Never execute tools or touch real devices."""
import copy
from contextlib import ExitStack
import json
import os
from pathlib import Path
import stat
import subprocess
import sys
import tempfile
from types import SimpleNamespace
import unittest
from unittest.mock import patch

import disk_expand as d


class DiskTests(unittest.TestCase):
    def setUp(self):
        self.stack = ExitStack()
        self.addCleanup(self.stack.close)
        self.temp = self.stack.enter_context(tempfile.TemporaryDirectory())
        self.root = Path(self.temp)
        self.journal = self.root / 'backup'
        self.disk_sys = self.root / 'sys' / 'vda'
        self.disk_sys.mkdir(parents=True)
        self.child_sys = self.disk_sys / 'vda1'
        self.child_sys.mkdir()
        self.source, self.parent, self.kname, self.parent_kname = '/dev/vda1', '/dev/vda', 'vda1', 'vda'
        self.number = 1
        self.fs = 4 * d.GIB
        self.disk = 30 * d.GIB
        self.part = 4 * d.GIB
        self.start = 2048
        self.label = 'dos'
        self.fstype = 'ext4'
        self.options = 'rw,relatime'
        self.extra = []
        self.children_extra = []
        self.dry_offset = -1
        self.dry_override = None
        self.no_growth = False
        self.no_resize = False
        self.failure = None
        self.commands = []
        self.records = []
        self.patch(d.sys, 'platform', 'linux')
        self.patch(d.os, 'geteuid', lambda: 0, create=True)
        self.patch(d.shutil, 'which', lambda name: '/usr/bin/' + name)
        self.patch(d, '_fs_bytes', lambda: self.fs)
        self.patch(d, '_device_stat', self.device_stat)
        self.patch(d.os, 'major', lambda value: value >> 8, create=True)
        self.patch(d.os, 'minor', lambda value: value & 255, create=True)
        self.patch(d.os.path, 'realpath', lambda path, **kwargs: str(path))
        self.patch(d, '_sysfs', lambda node: self.child_sys if node['type'] == 'part' else self.disk_sys)
        self.patch(d, '_read_partition_number', lambda name: self.number)
        self.patch(d, '_read_kernel_geometry', lambda name: (self.start * 512, self.part))
        self.patch(d.m, 'run', self.command)
        self.patch(d.m, 'secure_path', lambda path, **kwargs: Path(path))
        self.patch(d.m, 'backup_dir', self.backup_dir)
        self.sync = self.patch(d, '_sync_backup_parents', lambda directory: None)
        self.patch(d, '_private_write', self.private_write)
        original_stat = Path.stat
        def test_stat(path, *args, **kwargs):
            result = original_stat(path, *args, **kwargs)
            if path == self.journal:
                fields = list(result)
                fields[0], fields[4] = stat.S_IFDIR | 0o700, 0
                return os.stat_result(fields)
            return result
        self.patch(Path, 'stat', test_stat)
        self.patch(subprocess, 'run', lambda *a, **k: self.fail('Real subprocess forbidden'))

    def patch(self, target, name, value, **kwargs):
        return self.stack.enter_context(patch.object(target, name, value, **kwargs))

    def device_stat(self, path):
        if path == self.source:
            return SimpleNamespace(st_mode=stat.S_IFBLK, st_rdev=(252 << 8) | 1)
        if path == self.parent:
            return SimpleNamespace(st_mode=stat.S_IFBLK, st_rdev=(252 << 8))
        self.fail('Unexpected device ' + str(path))

    def backup_dir(self, label):
        self.assertEqual(label, 'disk-expand')
        self.journal.mkdir()
        return self.journal

    def private_write(self, directory, name, text):
        self.assertEqual(directory, self.journal)
        self.records.append(name)
        with (directory / name).open('x', encoding='utf-8') as stream:
            stream.write(text)

    def table(self):
        table = {'label': self.label, 'device': self.parent, 'unit': 'sectors',
                 'sectorsize': 512, 'id': 'test-table', 'partitions': [
                     {'node': self.source, 'start': self.start, 'size': self.part // 512,
                      'type': '83' if self.label == 'dos' else 'linux', 'uuid': 'test-part'},
                     *copy.deepcopy(self.extra)]}
        if self.label == 'gpt':
            table.update(firstlba=34, lastlba=self.disk // 512 - 34)
        return table

    def block_tree(self):
        child = {'name': self.source, 'kname': self.kname, 'type': 'part', 'size': self.part,
                 'fstype': self.fstype, 'pkname': self.parent, 'maj:min': '252:1', 'mountpoints': ['/']}
        return {'blockdevices': [{'name': self.parent, 'kname': self.parent_kname,
                 'type': 'disk', 'size': self.disk, 'fstype': None, 'pkname': None,
                 'maj:min': '252:0', 'mountpoints': [None], 'children': [child, *self.children_extra]}]}

    def command(self, args, **kwargs):
        args = list(args)
        self.commands.append(args)
        self.assertTrue(0 < kwargs['timeout'] <= 600)
        if self.failure is not None:
            self.failure(args)
        if args[0] == 'findmnt':
            return json.dumps({'filesystems': [{'source': self.source, 'target': '/',
                    'fstype': self.fstype, 'options': self.options, 'maj:min': '252:1'}]})
        if args[0] == 'lsblk':
            self.assertNotIn('PARTN', args[-1])
            return json.dumps(self.block_tree())
        if args == ['sfdisk', '--json', self.parent]:
            return json.dumps({'partitiontable': self.table()})
        if args == ['sfdisk', '--dump', self.parent]:
            return 'label: ' + self.label + '\n' + self.source + ': start=2048\n'
        if args == ['growpart', '-N', self.parent, str(self.number)]:
            if self.dry_override is not None:
                return self.dry_override
            last = self.disk // 512 - (34 if self.label == 'gpt' else 1)
            size = last + 1 - self.start
            oldsize = self.part // 512
            return SimpleNamespace(returncode=0, stdout=(f'CHANGE: partition={self.number} start={self.start} '
                f'old: size={oldsize} end={self.start + oldsize + self.dry_offset} '
                f'new: size={size} end={self.start + size + self.dry_offset}\n'), stderr='')
        if args == ['growpart', self.parent, str(self.number)]:
            self.assertIn('00-intent.json', self.records)
            self.assertIn('10-growpart-started.json', self.records)
            if not self.no_growth:
                self.part = (self.disk // 512 - (34 if self.label == 'gpt' else 1) + 1 - self.start) * 512
            return SimpleNamespace(returncode=0, stdout='CHANGED', stderr='')
        if args == ['resize2fs', self.source]:
            self.assertIn('30-resize2fs-started.json', self.records)
            if not self.no_resize:
                self.fs = self.part - 128 * 1024 ** 2
            return SimpleNamespace(returncode=0, stdout='', stderr='')
        self.fail('Unexpected command: ' + repr(args))

    def mutations(self):
        return [a for a in self.commands if a[0] == 'resize2fs' or
                (a[0] == 'growpart' and '-N' not in a)]

    def test_exact_6_gib_is_read_only_unchanged(self):
        self.fs = 6 * d.GIB
        plan = d.inspect_plan()
        self.assertEqual(plan['status'], 'unchanged')
        self.assertEqual(len(self.commands), 1)
        result = d.apply(plan)
        self.assertFalse(result['changed'])
        self.assertFalse(self.journal.exists())
        self.assertEqual(self.mutations(), [])

    def test_dos_grow_and_filesystem_with_durable_journal_order(self):
        plan = d.inspect_plan()
        self.assertEqual(plan['status'], 'expand-partition')
        self.assertIn('15 GiB', d.describe(plan))
        self.assertFalse(self.journal.exists())
        result = d.apply(plan)
        self.assertEqual(result['status'], 'expanded')
        self.assertGreaterEqual(result['fs_bytes'], 14 * d.GIB)
        self.assertEqual(self.mutations(), [['growpart', self.parent, '1'], ['resize2fs', self.source]])
        self.assertEqual(self.records, ['partition-table.sfdisk', 'geometry.json', '00-intent.json',
                        '10-growpart-started.json', '20-partition-verified.json',
                        '30-resize2fs-started.json', '40-complete.json'])

    def test_nvme_gpt_uses_structured_parent_and_partition_number(self):
        self.source, self.parent = '/dev/nvme0n1p1', '/dev/nvme0n1'
        self.kname, self.parent_kname = 'nvme0n1p1', 'nvme0n1'
        self.label = 'gpt'
        result = d.apply(d.inspect_plan())
        self.assertEqual((result['source'], result['parent'], result['number']), (self.source, self.parent, 1))

    def test_exclusive_end_convention_is_supported(self):
        self.dry_offset = 0
        self.assertEqual(d.inspect_plan()['status'], 'expand-partition')

    def test_partition_already_large_resizes_only_filesystem(self):
        self.part = 29 * d.GIB
        plan = d.inspect_plan()
        self.assertEqual(plan['status'], 'expand-filesystem')
        d.apply(plan)
        self.assertEqual(self.mutations(), [['resize2fs', self.source]])
        self.assertFalse(any(a[0] == 'growpart' for a in self.commands))

    def test_insufficient_physical_disk_refused(self):
        self.disk = 14 * d.GIB
        with self.assertRaises(d.m.Failure): d.inspect_plan()
        self.assertEqual(self.mutations(), [])

    def test_insufficient_tail_refused(self):
        self.start = 20 * d.GIB // 512
        with self.assertRaises(d.m.Failure): d.inspect_plan()
        self.assertEqual(self.mutations(), [])

    def test_readonly_mount_and_unsupported_filesystem_refused(self):
        for options, filesystem in [('ro,relatime', 'ext4'), ('rw', 'xfs'), ('rw', 'overlay')]:
            self.options, self.fstype = options, filesystem
            with self.subTest(options=options, fs=filesystem), self.assertRaises(d.m.Failure):
                d.inspect_plan()
        self.assertEqual(self.mutations(), [])

    def test_nonblock_or_wrong_device_identity_refused(self):
        for mode, device in [(stat.S_IFREG, 252 << 8), (stat.S_IFBLK, (253 << 8) | 1)]:
            with self.subTest(mode=mode), patch.object(d, '_device_stat', return_value=SimpleNamespace(st_mode=mode, st_rdev=device)):
                with self.assertRaises(d.m.Failure): d.inspect_plan()
        self.assertEqual(self.mutations(), [])

    def test_missing_tool_refused_without_installation(self):
        with patch.object(d.shutil, 'which', side_effect=lambda n: None if n == 'growpart' else '/bin/' + n):
            with self.assertRaises(d.m.Failure): d.inspect_plan()
        self.assertEqual(self.mutations(), [])

    def test_kernel_start_mismatch_refused(self):
        with patch.object(d, '_read_kernel_geometry', return_value=(4096 * 512, self.part)):
            with self.assertRaises(d.m.Failure): d.inspect_plan()
        self.assertEqual(self.mutations(), [])

    def test_bool_and_malformed_geometry_refused(self):
        for value in [True, -1, '4096']:
            table = self.table()
            table['partitions'][0]['size'] = value
            original = self.command
            with self.subTest(value=value), patch.object(d.m, 'run', side_effect=lambda a, **kw: json.dumps({'partitiontable': table}) if a[:2] == ['sfdisk', '--json'] else original(a, **kw)):
                with self.assertRaises(d.m.Failure): d.inspect_plan()
        self.assertEqual(self.mutations(), [])

    def test_nochange_and_unbounded_dryrun_refused(self):
        for reply in [SimpleNamespace(returncode=1, stdout='NOCHANGE: partition=1', stderr=''),
                      SimpleNamespace(returncode=0, stdout='CHANGE: partition=1 start=1 old: size=1 end=1 new: size=999999999999 end=999999999999', stderr='')]:
            self.dry_override = reply
            with self.subTest(reply=reply.stdout), self.assertRaises(d.m.Failure): d.inspect_plan()
        self.assertEqual(self.mutations(), [])

    def test_plan_changed_after_confirmation_refused(self):
        plan = d.inspect_plan()
        self.start += 1
        with self.assertRaises(d.m.Failure): d.apply(plan)
        self.assertEqual(self.mutations(), [])
        self.assertFalse(self.journal.exists())

    def test_journal_fsync_failure_prevents_mutation(self):
        plan = d.inspect_plan()
        with patch.object(d, '_sync_backup_parents', side_effect=OSError('fsync failed')):
            with self.assertRaises(d.m.Failure): d.apply(plan)
        self.assertEqual(self.mutations(), [])

    def test_journal_write_failure_prevents_mutation(self):
        plan = d.inspect_plan()
        with patch.object(d, '_private_write', side_effect=OSError('disk full')):
            with self.assertRaises(d.m.Failure): d.apply(plan)
        self.assertEqual(self.mutations(), [])

    def test_grow_failure_stops_without_resize_or_reversal(self):
        plan = d.inspect_plan()
        self.failure = lambda args: (_ for _ in ()).throw(d.m.Failure('failed')) if args == ['growpart', self.parent, '1'] else None
        with self.assertRaises(d.m.Failure): d.apply(plan)
        self.assertEqual(self.mutations(), [['growpart', self.parent, '1']])
        self.assertTrue((self.journal / '00-intent.json').exists())

    def test_successful_grow_without_kernel_change_refused(self):
        plan = d.inspect_plan()
        self.no_growth = True
        with self.assertRaises(d.m.Failure): d.apply(plan)
        self.assertEqual(self.mutations(), [['growpart', self.parent, '1']])

    def test_resize_failure_preserves_journal_and_does_not_shrink(self):
        plan = d.inspect_plan()
        self.failure = lambda args: (_ for _ in ()).throw(d.m.Failure('failed')) if args[0] == 'resize2fs' else None
        with self.assertRaises(d.m.Failure): d.apply(plan)
        self.assertTrue((self.journal / '30-resize2fs-started.json').exists())
        self.assertEqual([a[0] for a in self.mutations()], ['growpart', 'resize2fs'])

    def test_resize_zero_exit_without_size_change_is_failure(self):
        self.no_resize = True
        with self.assertRaises(d.m.Failure): d.apply(d.inspect_plan())
        self.assertNotIn('40-complete.json', self.records)

    def test_interrupt_is_reported_as_partial_with_no_rollback(self):
        plan = d.inspect_plan()
        def interrupt(args):
            if args[0] == 'resize2fs': raise KeyboardInterrupt
        self.failure = interrupt
        with self.assertRaises(d.m.Failure): d.apply(plan)
        self.assertTrue(self.journal.exists())
        self.assertEqual([a[0] for a in self.mutations()], ['growpart', 'resize2fs'])

    def test_no_shrink_format_reboot_cleanup_or_unrelated_command(self):
        d.apply(d.inspect_plan())
        self.assertTrue(all(a[0] in ('findmnt', 'lsblk', 'sfdisk', 'growpart', 'resize2fs') for a in self.commands))
        self.assertEqual([a for a in self.commands if a[0] == 'resize2fs'], [['resize2fs', self.source]])

    def test_stale_gpt_boundaries_require_manual_diagnosis(self):
        self.label = 'gpt'
        table = self.table()
        table['lastlba'] = 5 * d.GIB // 512
        original = self.command
        with patch.object(d.m, 'run', side_effect=lambda a, **kw: json.dumps({'partitiontable': table}) if a[:2] == ['sfdisk', '--json'] else original(a, **kw)):
            with self.assertRaisesRegex(d.m.Failure, 'GPT'):
                d.inspect_plan()
        self.assertFalse(any(a[0] == 'growpart' for a in self.commands))

    def test_overlapping_or_nonlast_root_is_refused(self):
        original_device = self.device_stat
        for start in (3072, 10 * d.GIB // 512):
            self.extra = [{'node': '/dev/vda2', 'start': start, 'size': 1024, 'type': '83'}]
            self.children_extra = [{'name': '/dev/vda2', 'kname': 'vda2', 'type': 'part',
                                    'size': 1024 * 512, 'fstype': 'ext4', 'pkname': self.parent,
                                    'maj:min': '252:2', 'mountpoints': [None]}]
            def device(path):
                return SimpleNamespace(st_mode=stat.S_IFBLK, st_rdev=(252 << 8) | 2) if path == '/dev/vda2' else original_device(path)
            def geometry(name):
                return (start * 512, 1024 * 512) if name == 'vda2' else (self.start * 512, self.part)
            with self.subTest(start=start), patch.object(d, '_device_stat', side_effect=device), patch.object(d, '_read_kernel_geometry', side_effect=geometry):
                with self.assertRaises(d.m.Failure):
                    d.inspect_plan()
        self.assertEqual(self.mutations(), [])

    def test_retry_after_partial_growth_builds_fresh_resize_only_plan(self):
        plan = d.inspect_plan()
        def fail_resize(args):
            if args[0] == 'resize2fs': raise d.m.Failure('temporary failure')
        self.failure = fail_resize
        with self.assertRaises(d.m.Failure):
            d.apply(plan)
        self.failure = None
        self.commands.clear()
        fresh = d.inspect_plan()
        self.assertEqual(fresh['status'], 'expand-filesystem')
        self.journal = self.root / 'retry-backup'
        result = d.apply(fresh)
        self.assertEqual(result['status'], 'expanded')
        self.assertEqual(self.mutations(), [['resize2fs', self.source]])

    def test_apply_root_guard_precedes_any_command(self):
        with patch.object(d.sys, 'platform', 'win32'):
            with self.assertRaises(d.m.Failure): d.apply({})
        self.assertEqual(self.commands, [])
