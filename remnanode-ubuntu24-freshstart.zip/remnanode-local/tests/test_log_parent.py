from pathlib import Path
import stat
import sys
from types import SimpleNamespace
import unittest
from unittest.mock import patch
import manage


class LogParentTests(unittest.TestCase):
    def check(self, *, path='/var/log/remnanode', enabled=True, gid=104, uid=0, mode=0o775, child_mode=0o750):
        target = Path(path).absolute()
        parent = Path('/var/log').absolute()
        def lstat(value):
            if value == parent:
                return SimpleNamespace(st_uid=uid, st_gid=gid, st_mode=stat.S_IFDIR | mode, st_nlink=1)
            return SimpleNamespace(st_uid=0, st_gid=0, st_mode=stat.S_IFDIR | child_mode, st_nlink=1)
        fake_grp = SimpleNamespace(getgrnam=lambda name: SimpleNamespace(gr_gid=104))
        with patch.dict(sys.modules, {'grp': fake_grp}), \
                patch.object(Path, 'exists', return_value=True), \
                patch.object(Path, 'is_symlink', return_value=False), \
                patch.object(Path, 'lstat', new=lstat), patch.object(Path, 'stat', new=lstat):
            return manage.secure_path(target, directory=True, allow_system_parent=enabled)

    def test_root_syslog_775_allowed_only_for_exact_node_logs(self):
        self.assertEqual(self.check(), Path('/var/log/remnanode').absolute())
        for kwargs in ({'enabled': False}, {'path': '/var/log/other'}, {'gid': 999},
                       {'uid': 1000}, {'mode': 0o777}, {'child_mode': 0o775}):
            with self.subTest(kwargs=kwargs), self.assertRaises(manage.Failure):
                self.check(**kwargs)

    def test_existing_symlink_is_rejected_even_with_exception(self):
        with patch.object(Path, 'exists', return_value=True), \
                patch.object(Path, 'lstat', return_value=SimpleNamespace(st_mode=stat.S_IFLNK, st_uid=0)):
            with self.assertRaises(manage.Failure):
                manage.secure_path('/var/log/remnanode', allow_system_parent=True)
