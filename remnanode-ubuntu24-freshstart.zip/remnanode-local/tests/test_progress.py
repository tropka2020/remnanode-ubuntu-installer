"""Portable progress contracts: only local Python children, no network/system tools."""
import io
from pathlib import Path
from types import SimpleNamespace
import subprocess
import sys
import threading
import time
import unittest
from unittest.mock import MagicMock, Mock, patch

import manage
import progress


SECRET = 'PROGRESS_SECRET_NEVER_PRINT'


class ProgressTests(unittest.TestCase):
    def setUp(self):
        self.stdout = io.StringIO()
        self.stderr = io.StringIO()
        self.out_patch = patch('sys.stdout', self.stdout)
        self.err_patch = patch('sys.stderr', self.stderr)
        self.out_patch.start()
        self.err_patch.start()
        self.addCleanup(self.out_patch.stop)
        self.addCleanup(self.err_patch.stop)

    def assert_no_workers(self):
        self.assertFalse(any(worker.name == 'installer-progress'
                             for worker in threading.enumerate()))

    def assert_no_secrets(self):
        self.assertEqual(self.stdout.getvalue(), '')
        self.assertNotIn(SECRET, self.stderr.getvalue())

    def test_disabled_by_default_and_explicitly_disabled(self):
        with patch.object(progress.threading, 'Thread') as thread, \
                patch.object(progress.time, 'monotonic') as clock:
            for context in (progress.reporting(), progress.reporting(enabled=False)):
                with context, progress.stage(SECRET), progress.command():
                    pass
            with progress.stage(SECRET), progress.command():
                pass
            thread.assert_not_called()
            clock.assert_not_called()
        self.assertEqual(self.stderr.getvalue(), '')

    def test_stage_duration_nested_label_restoration_and_flush(self):
        stream = Mock()
        with patch.object(progress.time, 'monotonic', side_effect=[10, 11, 13.5, 17]), \
                progress.reporting(enabled=True, stream=stream):
            with progress.stage('Установка'):
                with progress.stage('Docker'):
                    pass
                self.assertEqual(progress._label.get(), 'Установка')
        writes = ''.join(call.args[0] for call in stream.write.call_args_list)
        self.assertEqual(writes, '[НАЧАЛО] Установка\n[НАЧАЛО] Docker\n'
                         '[ГОТОВО] Docker (2.5 с)\n[ГОТОВО] Установка (7.0 с)\n')
        self.assertEqual(stream.flush.call_count, 4)
        self.assertEqual(progress._label.get(), 'Внешняя команда')

    def test_stage_errors_preserve_exception_and_hide_its_text(self):
        for error in (ValueError(SECRET), KeyboardInterrupt(SECRET)):
            with self.subTest(error=type(error).__name__), \
                    patch.object(progress.time, 'monotonic', side_effect=[20, 23.25]):
                with self.assertRaises(type(error)) as caught:
                    with progress.reporting(enabled=True), progress.stage('Проверка'):
                        raise error
                self.assertIs(caught.exception, error)
        self.assertIn('[ОШИБКА] Проверка (3.2 с)', self.stderr.getvalue())
        self.assertNotIn('[ГОТОВО]', self.stderr.getvalue())
        self.assert_no_secrets()

    def test_local_sleep_heartbeat_captures_outputs_without_disclosure(self):
        args = [sys.executable, '-c',
                'import sys,time; time.sleep(1); print(sys.argv[1]); '
                'print(sys.argv[1], file=sys.stderr)', SECRET]
        with patch.object(progress.time, 'monotonic', side_effect=lambda: 100.0 + time.perf_counter()), \
                progress.reporting(enabled=True, interval=0.05), progress.stage('Загрузка образов'):
            result = manage.run(args, capture=True, combine_output=True)
        self.assertEqual(result, SECRET + '\n' + SECRET + '\n')
        self.assertRegex(self.stderr.getvalue(), r'\[ОЖИДАНИЕ\] Загрузка образов \(\d+\.\d с\)')
        self.assert_no_secrets()
        self.assert_no_workers()

    def test_timeout_stops_worker_and_reports_only_basename(self):
        args = [sys.executable, '-c', 'import time; time.sleep(1)', SECRET]
        with self.assertRaises(manage.Failure) as caught:
            with progress.reporting(enabled=True, interval=0.02), progress.stage('Проверка'):
                manage.run(args, timeout=0.2)
        self.assertIn(Path(sys.executable).name, str(caught.exception))
        self.assertIsInstance(caught.exception.__cause__, subprocess.TimeoutExpired)
        self.assertIn('[ОШИБКА] Проверка', self.stderr.getvalue())
        before = self.stderr.getvalue()
        time.sleep(0.06)
        self.assertEqual(self.stderr.getvalue(), before)
        self.assert_no_workers()
        self.assert_no_secrets()

    def test_errors_and_interrupts_stop_worker_without_disclosing_details(self):
        for error in (OSError(SECRET), subprocess.TimeoutExpired([SECRET], 1),
                      KeyboardInterrupt(SECRET)):
            expected = KeyboardInterrupt if isinstance(error, KeyboardInterrupt) else manage.Failure
            with self.subTest(error=type(error).__name__), \
                    patch.object(manage.subprocess, 'run', side_effect=error):
                with self.assertRaises(expected) as caught:
                    with progress.reporting(enabled=True, interval=0.01), progress.stage('Docker'):
                        manage.run(['/private/' + SECRET + '/docker', SECRET])
                if expected is manage.Failure:
                    self.assertNotIn(SECRET, str(caught.exception))
                self.assert_no_workers()
        self.assert_no_secrets()

    def test_interrupt_in_worker_start_stops_launched_thread(self):
        original_start = threading.Thread.start
        failure = KeyboardInterrupt(SECRET)

        def interrupted_start(worker):
            original_start(worker)
            raise failure

        with patch.object(progress.threading.Thread, 'start', new=interrupted_start):
            with self.assertRaises(KeyboardInterrupt) as caught:
                with progress.reporting(enabled=True, interval=0.01), progress.command():
                    self.fail('Interrupted worker start must not enter command body')
        self.assertIs(caught.exception, failure)
        self.assertFalse(progress._pending.get())
        self.assert_no_workers()
        before = self.stderr.getvalue()
        time.sleep(0.04)
        self.assertEqual(self.stderr.getvalue(), before)
        self.assert_no_secrets()

    def test_worker_start_failure_preserves_error_without_joining_unstarted_thread(self):
        failure = RuntimeError('worker unavailable')
        with patch.object(progress.threading.Thread, 'start', side_effect=failure):
            with self.assertRaises(RuntimeError) as caught:
                with progress.reporting(enabled=True), progress.command():
                    self.fail('Failed worker start must not enter command body')
        self.assertIs(caught.exception, failure)
        self.assertFalse(progress._pending.get())
        self.assert_no_workers()

    def test_run_call_and_capture_semantics_are_unchanged(self):
        args = ['/private/' + SECRET + '/docker', SECRET, Path('config.json')]
        env = {'TOKEN': SECRET}
        for enabled in (False, True):
            for capture, combine, expected in ((False, False, None),
                                                (True, False, SECRET),
                                                (True, True, SECRET + SECRET)):
                result = subprocess.CompletedProcess(args, 0, SECRET, SECRET)
                with self.subTest(enabled=enabled, capture=capture, combine=combine), \
                        patch.object(manage.subprocess, 'run', return_value=result) as run, \
                        progress.reporting(enabled=enabled):
                    returned = manage.run(args, capture=capture, combine_output=combine,
                                          timeout=42, env=env)
                self.assertEqual(returned, result if not capture else expected)
                run.assert_called_once_with([str(arg) for arg in args], stdout=subprocess.PIPE,
                                            stderr=subprocess.PIPE, text=True, encoding='utf-8',
                                            timeout=42, env=env)
        self.assert_no_secrets()
        self.assert_no_workers()

    def test_nonzero_and_check_false_keep_output_private(self):
        result = subprocess.CompletedProcess(['docker', SECRET], 7, SECRET, SECRET)
        with patch.object(manage.subprocess, 'run', return_value=result), \
                progress.reporting(enabled=True), progress.stage('Docker'):
            with self.assertRaises(manage.Failure) as caught:
                manage.run(['/private/' + SECRET + '/docker', SECRET])
            self.assertNotIn(SECRET, str(caught.exception))
            self.assertIs(manage.run(['docker', SECRET], check=False), result)
        self.assert_no_secrets()
        self.assert_no_workers()

    def test_no_heartbeat_for_prompts_or_after_reporting_context(self):
        with patch.object(progress.threading, 'Thread') as worker:
            with progress.reporting(enabled=True, interval=0.01), progress.stage('Настройки'):
                with patch('builtins.input', return_value=SECRET):
                    self.assertEqual(input('Настройки: '), SECRET)
                time.sleep(0.03)
            with progress.command():
                pass
            worker.assert_not_called()
        self.assertNotIn('[ОЖИДАНИЕ]', self.stderr.getvalue())
        self.assert_no_secrets()

    def test_nested_pending_wait_uses_one_worker(self):
        original = threading.Thread
        with patch.object(progress.threading, 'Thread', wraps=original) as worker, \
                patch.object(progress.time, 'monotonic', return_value=100) as clock, \
                progress.reporting(enabled=True, interval=0.01), progress.stage('HTTPS'):
            with progress.command():
                clock.return_value = 112.5
                with progress.command():
                    time.sleep(0.04)
            self.assertEqual(worker.call_count, 1)
        self.assertIn('[ОЖИДАНИЕ] HTTPS (12.5 с)', self.stderr.getvalue())
        self.assert_no_workers()

    def test_registry_heartbeat_starts_after_token_prompt_and_hides_url(self):
        import design_state
        settings = SimpleNamespace(source=None, domain='node.example', theme='plants', title='')
        private = MagicMock()
        private.exists.return_value = True
        private.stat.return_value = SimpleNamespace(st_mode=0o700)
        pending, manifest = Mock(), Mock()
        pending.exists.return_value = manifest.exists.return_value = False

        def password(prompt):
            self.assert_no_workers()
            return SECRET

        def reserve(url, token, request_id):
            self.assertEqual((url, token), ('https://' + SECRET + '.example', SECRET))
            time.sleep(0.04)
            return {'request_id': request_id, 'composition': {'direction': 'editorial'}}

        registry = SimpleNamespace(validate_registry_url=lambda url: url,
                                   reserve_remote=reserve, RegistryError=RuntimeError)
        with patch.object(design_state, 'STATE', private), \
                patch.object(design_state, 'private_file', side_effect=[pending, manifest]), \
                patch.object(design_state.m, 'secure_path'), \
                patch.object(design_state.m, 'write_json'), \
                patch.object(design_state, 'validate_manifest', side_effect=lambda value: value), \
                patch('builtins.input', return_value='https://' + SECRET + '.example'), \
                patch.object(design_state.getpass, 'getpass', side_effect=password), \
                patch.dict(sys.modules, {'registry_client': registry}), \
                progress.reporting(enabled=True, interval=0.01):
            self.assertIs(design_state.prepare_design(settings), manifest)
        self.assertIn('[ОЖИДАНИЕ] Резервирование дизайна', self.stderr.getvalue())
        self.assertNotIn(SECRET, self.stdout.getvalue() + self.stderr.getvalue())
        self.assert_no_workers()

    def test_broken_stream_does_not_mask_work_or_errors(self):
        for error in (BrokenPipeError(), UnicodeEncodeError('ascii', 'я', 0, 1, 'unsupported'),
                      ValueError('closed stream')):
            stream = Mock()
            stream.write.side_effect = error
            with self.subTest(error=type(error).__name__), \
                    progress.reporting(enabled=True, stream=stream, interval=0.01):
                with progress.stage('Проверка'), progress.command():
                    time.sleep(0.03)
                failure = RuntimeError(SECRET)
                with self.assertRaises(RuntimeError) as caught:
                    with progress.stage('Проверка'):
                        raise failure
                self.assertIs(caught.exception, failure)
            self.assert_no_workers()


if __name__ == '__main__':
    unittest.main()
