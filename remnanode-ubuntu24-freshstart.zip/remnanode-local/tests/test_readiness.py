import importlib.util
from pathlib import Path
import unittest
from unittest.mock import MagicMock, patch

spec = importlib.util.spec_from_file_location('readiness_manage', Path(__file__).parents[1] / 'manage.py')
manage = importlib.util.module_from_spec(spec)
spec.loader.exec_module(manage)


def state(health='healthy', running=True):
    return {'State': {'Running': running, 'Restarting': False, 'Health': {'Status': health}}}


class ReadinessTests(unittest.TestCase):
    def test_requires_three_consecutive_healthy_observations(self):
        states = [state(), state(), state('unhealthy'), state(), state(), state()]
        with patch.object(manage, 'inspect', side_effect=states) as inspection, \
                patch.object(manage.time, 'sleep'), \
                patch.object(manage.socket, 'create_connection', return_value=MagicMock()):
            manage.wait_container('test', 2222, timeout=60)
        self.assertEqual(inspection.call_count, 6)

    def test_stopped_state_resets_readiness(self):
        states = [state(), state(), state(running=False), state(), state(), state()]
        with patch.object(manage, 'inspect', side_effect=states) as inspection, \
                patch.object(manage.time, 'sleep'), \
                patch.object(manage.socket, 'create_connection', return_value=MagicMock()):
            manage.wait_container('test', 2222, timeout=60)
        self.assertEqual(inspection.call_count, 6)

    def test_timeout_does_not_report_success(self):
        with patch.object(manage.time, 'monotonic', side_effect=[0, 1, 61]), \
                patch.object(manage.time, 'sleep'), \
                patch.object(manage, 'inspect', return_value=state(running=False)):
            with self.assertRaises(manage.Failure):
                manage.wait_container('test', 2222, timeout=60)
