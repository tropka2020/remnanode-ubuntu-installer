"""Safe client-contract tests; no external network, only mocked openers."""
import io
import json
import socket
import ssl
import unittest
from unittest.mock import Mock, patch
import urllib.error
import urllib.request
import uuid

import registry_client as client
from design_catalog import VERSION


REQUEST_ID = "00000000-0000-4000-8000-000000000001"
TOKEN = "T" * 32
MANIFEST = {
    "schema": 1, "version": VERSION, "request_id": REQUEST_ID,
    "reservation_id": "00000000-0000-4000-8000-000000000002", "seed": "a" * 64,
    "composition": {"version": VERSION, "direction": "editorial", "hero": "feature",
                    "listing": "cards", "article": "column"},
}


class Response:
    def __init__(self, body, status=200):
        self.body = body
        self.status = status

    def __enter__(self):
        return self

    def __exit__(self, *args):
        return False

    def read(self, amount=-1):
        return self.body if amount < 0 else self.body[:amount]


class RegistryClientTests(unittest.TestCase):
    def setUp(self):
        for name in ('socket', 'create_connection', 'getaddrinfo'):
            guard = patch.object(socket, name, side_effect=AssertionError('External network forbidden'))
            guard.start()
            self.addCleanup(guard.stop)

    def test_validate_registry_url_accepts_only_canonical_https_origin(self):
        accepted = {
            "https://registry.example": "https://registry.example",
            "https://registry.example/": "https://registry.example",
            "https://registry.example:443": "https://registry.example:443",
            "https://127.0.0.1:18443": "https://127.0.0.1:18443",
            "https://[::1]:18443": "https://[::1]:18443",
        }
        for value, expected in accepted.items():
            with self.subTest(value=value):
                self.assertEqual(client.validate_registry_url(value), expected)

    def test_validate_registry_url_rejects_bad_schemes_credentials_paths_and_delimiters(self):
        bad = (
            None, 42, "", "http://registry.example", "ftp://registry.example",
            "https://", "https:///path", "https://registry.example/path",
            "https://registry.example?x=1", "https://registry.example#x",
            "https://user@registry.example", "https://user:pass@registry.example",
            "https://registry.example:0", "https://registry.example:65536",
            "https://registry.example:bad", "https://registry.example%2f",
            "https://registry.example\\evil", " https://registry.example",
            "https://registry.example\n", "https://registry.example:443/path",
        )
        for value in bad:
            with self.subTest(value=repr(value)), self.assertRaises(ValueError):
                client.validate_registry_url(value)

    def test_reserve_remote_posts_auth_json_and_validates_response(self):
        opener = Mock()
        opener.open.return_value = Response(json.dumps(MANIFEST).encode())
        with patch.object(client.urllib.request, "build_opener", return_value=opener), \
                patch.object(client.ssl, "create_default_context", return_value="TLS_CONTEXT") as tls:
            result = client.reserve_remote("https://registry.example/", TOKEN, REQUEST_ID)
        self.assertEqual(result, MANIFEST)
        tls.assert_called_once_with()
        opener.open.assert_called_once()
        request = opener.open.call_args.args[0]
        self.assertEqual(request.full_url, "https://registry.example/v1/reserve")
        self.assertEqual(request.method, "POST")
        self.assertEqual(request.get_header("Authorization"), "Bearer " + TOKEN)
        self.assertEqual(request.get_header("Content-type"), "application/json")
        self.assertEqual(request.get_header("Accept"), "application/json")
        self.assertEqual(opener.open.call_args.kwargs, {'timeout': 15})
        self.assertEqual(json.loads(request.data), {"version": VERSION, "request_id": REQUEST_ID})

    def test_reserve_remote_builds_no_proxy_no_redirect_default_tls_opener(self):
        opener = Mock()
        opener.open.return_value = Response(json.dumps(MANIFEST).encode())
        context = ssl.create_default_context()
        self.assertTrue(context.check_hostname)
        self.assertEqual(context.verify_mode, ssl.CERT_REQUIRED)
        with patch.object(client.urllib.request, "build_opener", return_value=opener) as build, \
                patch.object(client.ssl, "create_default_context", return_value=context) as tls:
            client.reserve_remote("https://registry.example", TOKEN, REQUEST_ID)
        tls.assert_called_once_with()
        args = build.call_args.args
        self.assertEqual(len(args), 3)
        self.assertIsInstance(args[0], urllib.request.ProxyHandler)
        self.assertEqual(args[0].proxies, {})
        self.assertIsInstance(args[1], client.NoRedirect)
        self.assertIsInstance(args[2], urllib.request.HTTPSHandler)
        self.assertIs(args[2]._context, context)
        self.assertTrue(context.check_hostname)
        self.assertEqual(context.verify_mode, ssl.CERT_REQUIRED)
        for code in (301, 302, 303, 307, 308):
            with self.subTest(code=code):
                self.assertIsNone(args[1].redirect_request(None, None, code, 'redirect', {},
                                                          'https://other.example/reserve'))

    def test_reserve_remote_rejects_bad_credentials_and_request_without_opener(self):
        with patch.object(client.urllib.request, "build_opener") as build:
            for token, request_id in (("short", REQUEST_ID), ("x" * 257, REQUEST_ID),
                                      (TOKEN + "!", REQUEST_ID), (TOKEN, "not-uuid"),
                                      (TOKEN, str(uuid.uuid4()).upper()), (TOKEN, None)):
                with self.subTest(token=token, request_id=request_id), self.assertRaises(client.RegistryError):
                    client.reserve_remote("https://registry.example", token, request_id)
        build.assert_not_called()

    def test_reserve_remote_translates_url_network_status_redirect_and_json_errors(self):
        with patch.object(client.urllib.request, "build_opener") as build:
            for url in ("http://registry.example", "https://registry.example/path"):
                with self.subTest(url=url), self.assertRaises(client.RegistryError):
                    client.reserve_remote(url, TOKEN, REQUEST_ID)
            opener = Mock()
            build.return_value = opener
            for response in (Response(b"{}", 201), Response(b"not-json", 200)):
                opener.open.return_value = response
                with self.subTest(response=response), self.assertRaises(client.RegistryError):
                    client.reserve_remote("https://registry.example", TOKEN, REQUEST_ID)
            opener.open.side_effect = urllib.error.HTTPError(
                "https://registry.example/v1/reserve", 302, "redirect", {}, io.BytesIO())
            with self.assertRaises(client.RegistryError):
                client.reserve_remote("https://registry.example", TOKEN, REQUEST_ID)
            opener.open.side_effect = urllib.error.URLError("offline")
            with self.assertRaises(client.RegistryError):
                client.reserve_remote("https://registry.example", TOKEN, REQUEST_ID)

    def test_reserve_remote_rejects_oversized_body_before_json(self):
        opener = Mock()
        # Valid JSON with trailing whitespace: without the size check this would
        # be accepted, so rejection cannot accidentally be a JSON parse failure.
        oversized = json.dumps(MANIFEST).encode().ljust(16385, b' ')
        response = Response(oversized)
        response.read = Mock(wraps=response.read)
        opener.open.return_value = response
        with patch.object(client.urllib.request, "build_opener", return_value=opener):
            with self.assertRaises(client.RegistryError):
                client.reserve_remote("https://registry.example", TOKEN, REQUEST_ID)
        response.read.assert_called_once_with(16385)
        self.assertEqual(json.loads(oversized), MANIFEST)

    def test_response_at_exact_size_limit_is_accepted(self):
        opener = Mock()
        body = json.dumps(MANIFEST).encode().ljust(16384, b' ')
        opener.open.return_value = Response(body)
        with patch.object(client.urllib.request, "build_opener", return_value=opener):
            self.assertEqual(client.reserve_remote('https://registry.example', TOKEN, REQUEST_ID), MANIFEST)

    def test_reserve_remote_rejects_response_request_id_uuid_seed_and_manifest_schema(self):
        cases = []
        wrong_id = dict(MANIFEST, request_id=str(uuid.uuid4()))
        cases.append(wrong_id)
        bad_uuid = dict(MANIFEST, request_id="not-uuid")
        cases.append(bad_uuid)
        for seed in ('not-a-seed', 'a' * 63, 'a' * 65, 'A' * 64, None):
            cases.append(dict(MANIFEST, seed=seed))
        for reservation_id in ('not-uuid', None, '00000000-0000-4000-8000-00000000000Z'):
            cases.append(dict(MANIFEST, reservation_id=reservation_id))
        cases.extend((None, {}, {"request_id": REQUEST_ID}, dict(MANIFEST, version='future'),
                      dict(MANIFEST, schema=True)))
        for payload in cases:
            with self.subTest(payload=payload):
                opener = Mock()
                opener.open.return_value = Response(json.dumps(payload).encode())
                with patch.object(client.urllib.request, "build_opener", return_value=opener), \
                        self.assertRaises(client.RegistryError):
                    client.reserve_remote("https://registry.example", TOKEN, REQUEST_ID)

    def test_registry_error_does_not_expose_token_or_remote_error_details(self):
        marker = "SECRET_TOKEN_SHOULD_NOT_LEAK"
        opener = Mock()
        opener.open.side_effect = OSError(marker)
        with patch.object(client.urllib.request, "build_opener", return_value=opener):
            with self.assertRaises(client.RegistryError) as caught:
                client.reserve_remote("https://registry.example", "A" * 32, REQUEST_ID)
        self.assertNotIn(marker, str(caught.exception))
        self.assertNotIn(marker, repr(caught.exception))


if __name__ == "__main__":
    unittest.main()
