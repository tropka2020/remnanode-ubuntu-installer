"""Portable selfsteal contracts: mocks/tempdirs only, no Docker or network.

Run: python -B -m unittest discover -s tests -p test_selfsteal.py -v
Linux ownership, real TLS/ACME and Docker are deliberately not integration-tested.
"""
from contextlib import ExitStack, nullcontext
from copy import deepcopy
from datetime import datetime, timedelta, timezone
import importlib.util
import io
import json
import os
from pathlib import Path
import shlex
import socket
import ssl
import subprocess
import sys
import tempfile
import unittest
from unittest.mock import MagicMock, call, patch


PROJECT = Path(__file__).resolve().parents[1]


def load_module(name, filename):
    spec = importlib.util.spec_from_file_location(name, PROJECT / filename)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


# Isolate manage globals from other suites and never import bootstrap.
m = load_module("selfsteal_test_manage", "manage.py")
with patch.dict(sys.modules, {"manage": m}):
    manager = load_module("selfsteal_under_test", "selfsteal.py")
    installer = load_module("selfsteal_test_installer", "installer.py")

IMAGE = "caddy@sha256:" + "b" * 64
DOMAIN = "node.example.com"
NOW = datetime(2026, 10, 21, 12, 0, 0, tzinfo=timezone.utc)


class IsolatedCase(unittest.TestCase):
    def setUp(self):
        self.stack = ExitStack()
        self.addCleanup(self.stack.close)
        self.root = Path(self.stack.enter_context(
            tempfile.TemporaryDirectory(prefix="test-selfsteal-")))
        self.stdout = self.stack.enter_context(patch("sys.stdout", new_callable=io.StringIO))
        self.stderr = self.stack.enter_context(patch("sys.stderr", new_callable=io.StringIO))
        for target, name in ((subprocess, "run"), (subprocess, "Popen"),
                             (os, "system"), (socket, "socket"),
                             (socket, "getaddrinfo"), (socket, "create_connection")):
            self.patch(target, name, side_effect=AssertionError("External command/network forbidden"))
        self.web = self.root / "caddy"
        self.web.mkdir()
        (self.web / "logs").mkdir()
        self.metadata_path = self.web / "managed.json"
        self.caddyfile = self.web / "Caddyfile"
        self.access = self.web / "logs" / "access.log"
        for name, value in (("WEB", self.web), ("METADATA", self.metadata_path),
                            ("CADDYFILE", self.caddyfile), ("ACCESS_LOG", self.access)):
            self.patch(manager, name, new=value)
        self.patch(m, "WEB", new=self.web)
        self.patch(manager, "require_root")
        self.private = self.root / 'private' / 'premium-manifest.json'
        self.patch(manager, "PRIVATE_MANIFEST", new=self.private)
        self.metadata = {"version": 2, "purpose": "local-backend", "domain": DOMAIN,
                         "https_port": 9443, "image": IMAGE}
        self.write_metadata()
        self.caddyfile.write_text(
            "{\n admin off\n https_port 9443\n}\nhttps://node.example.com {\n"
            " bind 127.0.0.1\n root * /var/www/html\n file_server\n}\n", encoding="utf-8")
        self.container = {
            "Name": "/remnanode-web", "Config": {"Image": IMAGE},
            "State": {"Status": "running", "Running": True,
                      "StartedAt": "2026-10-20T12:00:00Z"},
            "RestartCount": 3,
            "Mounts": [
                {"Source": "/opt/caddy/Caddyfile", "Destination": "/etc/caddy/Caddyfile",
                 "Type": "bind", "RW": False},
                {"Source": "/opt/caddy/html", "Destination": "/var/www/html",
                 "Type": "bind", "RW": False},
                {"Source": "/opt/caddy/logs", "Destination": "/var/log/caddy",
                 "Type": "bind", "RW": True},
                {"Name": "caddy_caddy_data", "Destination": "/data", "Type": "volume"},
                {"Name": "caddy_caddy_config", "Destination": "/config", "Type": "volume"},
            ],
        }
        self.secure = self.patch(m, "secure_path", side_effect=self.safe_path)
        self.inspect = self.patch(m, "inspect", return_value=self.container)
        self.run = self.patch(m, "run", side_effect=AssertionError("Unexpected system command"))
        self.compose = self.patch(m, "compose", side_effect=AssertionError("Unexpected Compose command"))
        self.lock = self.patch(m, "lock", side_effect=lambda: nullcontext())
        self.stopped = self.patch(m, "confirm_stopped")
        # A missing write mock must never reach application or system files.
        original_open, original_mkdir = Path.open, Path.mkdir

        def safe_open(path, mode="r", *args, **kwargs):
            if any(flag in mode for flag in "wax+"):
                self.safe_path(path)
            return original_open(path, mode, *args, **kwargs)

        def safe_mkdir(path, *args, **kwargs):
            self.safe_path(path)
            return original_mkdir(path, *args, **kwargs)

        self.patch(Path, "open", new=safe_open)
        self.patch(Path, "mkdir", new=safe_mkdir)

    def patch(self, target, name, **kwargs):
        return self.stack.enter_context(patch.object(target, name, **kwargs))

    def safe_path(self, path, **kwargs):
        path = Path(path).absolute()
        if not path.is_relative_to(self.root):
            raise AssertionError("Non-test system path forbidden: " + str(path))
        return path

    def write_metadata(self, data=None):
        self.metadata_path.write_text(json.dumps(self.metadata if data is None else data), encoding="utf-8")

    def assert_no_mutations(self):
        self.run.assert_not_called()
        self.compose.assert_not_called()
        self.lock.assert_not_called()


class InstallationTests(IsolatedCase):
    def test_current_backend_is_accepted_without_mutation(self):
        self.assertEqual(manager.validate_installation(), self.metadata)
        self.inspect.assert_called_once_with("remnanode-web")
        self.assert_no_mutations()

    def test_rejects_legacy_or_unknown_metadata(self):
        variants = [{}, {"version": 1}, [], None]
        for field, value in (("version", 1), ("purpose", "selfsteal"),
                             ("https_port", 443), ("https_port", "9443"),
                             ("domain", "https://node.example.com"), ("domain", 123)):
            data = dict(self.metadata)
            data[field] = value
            variants.append(data)
        for data in variants:
            with self.subTest(data=data):
                self.metadata_path.write_text(json.dumps(data), encoding="utf-8")
                with self.assertRaises(manager.SelfstealError):
                    manager.validate_installation()
        self.assert_no_mutations()

    def test_corrupt_or_missing_metadata_is_rejected(self):
        self.metadata_path.write_text("{broken", encoding="utf-8")
        with self.assertRaises(manager.SelfstealError):
            manager.validate_installation()
        self.metadata_path.unlink()
        with self.assertRaises(manager.SelfstealError):
            manager.validate_installation()
        self.assert_no_mutations()

    def test_missing_container_or_foreign_image_is_rejected(self):
        for image in (None, "nginx:latest", "caddy:2", "caddy@sha256:" + "z" * 64):
            with self.subTest(image=image):
                obj = deepcopy(self.container)
                obj["Config"]["Image"] = image
                self.inspect.return_value = obj
                with self.assertRaises(manager.SelfstealError):
                    manager.validate_installation()
        self.inspect.return_value = None
        with self.assertRaises(manager.SelfstealError):
            manager.validate_installation()
        self.assert_no_mutations()

    def test_container_image_must_match_metadata(self):
        self.container["Config"]["Image"] = "caddy@sha256:" + "a" * 64
        with self.assertRaises(manager.SelfstealError):
            manager.validate_installation()
        self.assert_no_mutations()

    def test_metadata_requires_valid_pinned_image(self):
        for value in (None, "caddy:latest", "nginx@sha256:" + "b" * 64):
            with self.subTest(image=value):
                self.metadata["image"] = value
                self.write_metadata()
                with self.assertRaises(manager.SelfstealError):
                    manager.validate_installation()
        self.assert_no_mutations()

    def test_foreign_or_missing_mounts_are_rejected(self):
        for mutate in ("missing", "legacy-source", "wrong-destination", "volume-instead-of-bind"):
            with self.subTest(mutate=mutate):
                obj = deepcopy(self.container)
                if mutate == "missing":
                    obj["Mounts"] = []
                elif mutate == "legacy-source":
                    obj["Mounts"][0]["Source"] = "/opt/nginx-selfsteal/Caddyfile"
                elif mutate == "wrong-destination":
                    obj["Mounts"][1]["Destination"] = "/usr/share/nginx/html"
                else:
                    obj["Mounts"][0]["Type"] = "volume"
                self.inspect.return_value = obj
                with self.assertRaises(manager.SelfstealError):
                    manager.validate_installation()
        self.assert_no_mutations()

    def test_foreign_caddyfile_is_rejected(self):
        self.caddyfile.write_text("https://foreign.example {\n file_server\n}\n", encoding="utf-8")
        with self.assertRaises(manager.SelfstealError):
            manager.validate_installation()
        self.assert_no_mutations()

    def test_docker_unavailable_is_failure_not_absence_or_success(self):
        self.inspect.side_effect = m.Failure("Docker unavailable")
        self.assertEqual(manager.main(["status"]), 1)
        self.assertIn("Docker unavailable", self.stderr.getvalue())
        self.assert_no_mutations()


class ServiceTests(IsolatedCase):
    def test_start_stop_restart_only_target_web_under_lock(self):
        for action in ("start", "stop", "restart"):
            with self.subTest(action=action):
                self.run.reset_mock(side_effect=True)
                self.lock.reset_mock()
                self.stopped.reset_mock()
                entered = []

                class Locked:
                    def __enter__(inner):
                        entered.append(True)

                    def __exit__(inner, *args):
                        entered.pop()

                self.lock.side_effect = Locked

                def command(argv, **kwargs):
                    self.assertTrue(entered, "Service mutation must hold the shared lock")
                    self.assertEqual(argv, ["docker", action, "remnanode-web"])
                    self.assertNotIn("remnanode", argv)

                self.run.side_effect = command
                manager.service_action(action, confirm=True)
                self.run.assert_called_once_with(["docker", action, "remnanode-web"], timeout=60)
                self.lock.assert_called_once_with()
                if action == "stop":
                    self.stopped.assert_called_once_with("remnanode-web")
                else:
                    self.stopped.assert_not_called()
        self.compose.assert_not_called()

    def test_stop_and_restart_require_explicit_confirmation(self):
        for action in ("stop", "restart"):
            with self.subTest(action=action), self.assertRaises(manager.SelfstealError):
                manager.service_action(action)
        self.assert_no_mutations()

    def test_unknown_action_never_runs_command(self):
        with self.assertRaises(manager.SelfstealError):
            manager.service_action("remove", confirm=True)
        self.assert_no_mutations()

    def test_invalid_installation_prevents_confirmed_stop(self):
        self.metadata["purpose"] = "legacy"
        self.write_metadata()
        with self.assertRaises(manager.SelfstealError):
            manager.service_action("stop", confirm=True)
        self.assert_no_mutations()

    def test_start_failure_and_not_running_state_are_not_success(self):
        self.run.side_effect = m.Failure("Docker failed")
        with self.assertRaises(m.Failure):
            manager.service_action("start")
        self.run.side_effect = None
        self.container["State"] = {"Status": "exited", "Running": False}
        with self.assertRaises(manager.SelfstealError):
            manager.service_action("start")

    def test_stop_requires_confirmed_container_stop(self):
        self.run.side_effect = None
        self.stopped.side_effect = m.Failure("still running")
        with self.assertRaises(m.Failure):
            manager.service_action("stop", confirm=True)
        self.assertNotIn("Caddy выключен", self.stdout.getvalue())


class WrapperTests(unittest.TestCase):
    def test_installer_delegates_to_standalone_runtime(self):
        import command_runtime
        with patch.object(command_runtime, 'install_runtime') as install:
            installer.install_selfsteal_command()
        install.assert_called_once_with(installer.m.BASE)


class CertificateTests(IsolatedCase):
    def setUp(self):
        super().setUp()

        class FrozenDatetime(datetime):
            @classmethod
            def now(cls, tz=None):
                return NOW.astimezone(tz) if tz is not None else NOW.replace(tzinfo=None)

        self.patch(manager, "datetime", new=FrozenDatetime)
        self.raw = MagicMock(name="raw_socket")
        self.connect = self.patch(socket, "create_connection", return_value=self.raw)
        self.tls = MagicMock(name="tls_socket")
        self.context = MagicMock(name="verified_context")
        self.context.wrap_socket.return_value.__enter__.return_value = self.tls
        self.factory = self.patch(ssl, "create_default_context", return_value=self.context)
        self.unverified = self.patch(ssl, "_create_unverified_context",
                                     side_effect=AssertionError("TLS verification must not be disabled"))
        self.tls.getpeercert.return_value = {"notAfter": "Nov  1 00:00:00 2026 GMT"}

    def test_certificate_uses_local_backend_sni_and_verified_tls(self):
        status = manager.certificate_status()
        self.connect.assert_called_once_with(("127.0.0.1", 9443), timeout=8)
        self.factory.assert_called_once_with()
        self.context.wrap_socket.assert_called_once_with(
            self.raw.__enter__.return_value, server_hostname=DOMAIN)
        self.unverified.assert_not_called()
        self.assertTrue(status["verified"])
        self.assertEqual(status["domain"], DOMAIN)
        self.assertEqual(status["expires_at"], datetime(2026, 11, 1, tzinfo=timezone.utc))
        self.assertEqual(status["expires_at"].utcoffset(), timedelta(0))
        self.assertEqual(status["days_left"], 10)
        self.assert_no_mutations()

    def test_days_are_full_utc_days_at_boundaries(self):
        for offset, expected in ((0, 0), (86399, 0), (86400, 1), (172799, 1)):
            with self.subTest(offset=offset):
                expires = NOW + timedelta(seconds=offset)
                self.tls.getpeercert.return_value = {
                    "notAfter": expires.strftime("%b %d %H:%M:%S %Y GMT")}
                self.assertEqual(manager.certificate_status()["days_left"], expected)

    def test_expired_untrusted_or_wrong_hostname_is_never_reported_verified(self):
        for reason in ("certificate has expired", "self-signed certificate", "Hostname mismatch"):
            with self.subTest(reason=reason):
                self.context.wrap_socket.side_effect = ssl.SSLCertVerificationError(1, reason)
                with self.assertRaises(manager.SelfstealError):
                    manager.certificate_status()
                self.unverified.assert_not_called()
        self.assert_no_mutations()

    def test_stopped_backend_connection_refused_is_failure(self):
        self.container["State"] = {"Status": "exited", "Running": False}
        self.connect.side_effect = ConnectionRefusedError("backend stopped")
        with self.assertRaises(manager.SelfstealError):
            manager.certificate_status()
        self.assert_no_mutations()

    def test_missing_certificate_or_expiry_is_failure(self):
        for cert in ({}, {"subject": ()}):
            with self.subTest(cert=cert):
                self.tls.getpeercert.return_value = cert
                with self.assertRaises(manager.SelfstealError):
                    manager.certificate_status()


class LogTests(IsolatedCase):
    def test_visits_returns_requested_tail_without_service_mutation(self):
        self.access.write_text("first\nsecond\nthird\n", encoding="utf-8")
        self.assertEqual(manager.show_logs("visits", 2), "second\nthird\n")
        self.assert_no_mutations()

    def test_large_log_reads_at_most_configured_byte_bound(self):
        data = b"OLD_SENTINEL\n" + b"x" * (manager.MAX_LOG_BYTES * 3) + b"\nlast\n"
        reads = []

        class BoundedStream(io.BytesIO):
            def read(inner, size=-1):
                reads.append(size)
                self.assertGreaterEqual(size, 0, "Unbounded log reads are forbidden")
                self.assertLessEqual(size, manager.MAX_LOG_BYTES)
                return super().read(size)

        self.access.write_bytes(data)
        original_open = Path.open

        def open_log(path, *args, **kwargs):
            if path == self.access:
                return BoundedStream(data)
            return original_open(path, *args, **kwargs)

        self.patch(Path, "open", new=open_log)
        text = manager.show_logs("visits", 1000)
        self.assertTrue(reads)
        self.assertNotIn("OLD_SENTINEL", text)
        self.assertTrue(text.endswith("last\n"))
        self.assertLessEqual(len(text.encode("utf-8")), manager.MAX_LOG_BYTES + 1)
        self.assert_no_mutations()

    def test_missing_and_empty_access_log_are_safe(self):
        self.assertTrue(manager.show_logs("visits", 1))
        self.access.write_bytes(b"")
        self.assertEqual(manager.show_logs("visits", 1), "")
        self.assert_no_mutations()

    def test_access_log_terminal_controls_are_escaped(self):
        self.access.write_text("request /\x1b[2J\x00\x07\x9b31m END\n", encoding="utf-8")
        text = manager.show_logs("visits", 1)
        self.assertNotRegex(text, r"[\x00-\x08\x0b-\x1f\x7f-\x9f]")
        self.assertIn("END", text)
        self.assert_no_mutations()

    def test_error_logs_are_bounded_and_only_read_web(self):
        self.run.side_effect = None
        self.run.return_value = "ACME test\n"
        self.assertEqual(manager.show_logs("errors", 17), "ACME test\n")
        self.run.assert_called_once_with(
            ["docker", "logs", "--tail", "17", "--timestamps", "remnanode-web"],
            capture=True, combine_output=True, timeout=30)
        self.lock.assert_not_called()
        self.compose.assert_not_called()

    def test_error_log_terminal_controls_are_escaped(self):
        self.run.side_effect = None
        self.run.return_value = "ACME \x1b]0;injected\x07\x00 END\n"
        text = manager.show_logs("errors", 1)
        self.assertNotRegex(text, r"[\x00-\x08\x0b-\x1f\x7f-\x9f]")
        self.assertIn("END", text)

    def test_invalid_line_limits_or_kind_never_run_docker(self):
        for lines in (-1, 0, 1001):
            with self.subTest(lines=lines), self.assertRaises(manager.SelfstealError):
                manager.show_logs("visits", lines)
        with self.assertRaises(manager.SelfstealError):
            manager.show_logs("unknown", 100)
        self.assert_no_mutations()

    def test_line_limit_endpoints_are_accepted(self):
        self.access.write_text("a\nb\n", encoding="utf-8")
        self.assertEqual(manager.show_logs("visits", 1), "b\n")
        self.assertEqual(manager.show_logs("visits", 1000), "a\nb\n")


class CommandAndMenuTests(IsolatedCase):
    def test_empty_argv_and_explicit_menu_dispatch_without_lock(self):
        menu = self.patch(manager, "menu")
        for argv in ([], ["menu"]):
            with self.subTest(argv=argv):
                self.assertEqual(manager.main(argv), 0)
        self.assertEqual(menu.call_count, 2)
        self.assert_no_mutations()

    def test_cli_dispatches_service_and_log_arguments(self):
        service = self.patch(manager, "service_action")
        logs = self.patch(manager, "show_logs", return_value="TEST_LOG")
        self.assertEqual(manager.main(["restart", "--confirm"]), 0)
        service.assert_called_once_with("restart", confirm=True)
        self.assertEqual(manager.main(["logs", "--kind", "errors", "--lines", "25"]), 0)
        logs.assert_called_once_with("errors", 25)
        self.assertIn("TEST_LOG", self.stdout.getvalue())
        self.assert_no_mutations()

    def test_cli_unconfirmed_stop_is_nonzero_and_no_mutation(self):
        self.assertEqual(manager.main(["stop"]), 1)
        self.assertTrue(self.stderr.getvalue())
        self.assert_no_mutations()

    def test_invalid_cli_input_is_rejected(self):
        for argv in (["delete"], ["logs", "--kind", "other"], ["logs", "--lines", "abc"]):
            with self.subTest(argv=argv), self.assertRaises(SystemExit) as caught:
                manager.main(argv)
            self.assertEqual(caught.exception.code, 2)
        self.assert_no_mutations()

    def test_menu_exit_does_not_validate_or_change_installation(self):
        self.stack.enter_context(patch("builtins.input", return_value="0"))
        manager.menu()
        self.inspect.assert_not_called()
        self.assert_no_mutations()

    def test_menu_start_status_and_log_dispatch(self):
        status = self.patch(manager, "print_status")
        service = self.patch(manager, "service_action")
        logs = self.patch(manager, "show_logs", return_value="sample")
        self.stack.enter_context(patch("builtins.input", side_effect=["1", "2", "6", "7", "0"]))
        manager.menu()
        status.assert_called_once_with()
        service.assert_called_once_with("start")
        self.assertEqual(logs.call_args_list, [call("visits"), call("errors")])
        self.assert_no_mutations()

    def test_menu_stop_restart_cannot_bypass_confirmation(self):
        service = self.patch(manager, "service_action")
        self.stack.enter_context(patch("builtins.input", side_effect=["3", "", "4", "no", "0"]))
        manager.menu()
        service.assert_not_called()
        self.assert_no_mutations()

    def test_menu_confirmed_stop_restart_warns_about_backend(self):
        service = self.patch(manager, "service_action")
        inputs = self.stack.enter_context(patch(
            "builtins.input", side_effect=["3", "ПОДТВЕРЖДАЮ", "4", "ПОДТВЕРЖДАЮ", "0"]))
        manager.menu()
        self.assertEqual(service.call_args_list,
                         [call("stop", confirm=True), call("restart", confirm=True)])
        prompts = " ".join(str(item) for item in inputs.call_args_list)
        self.assertIn("backend", prompts)
        self.assert_no_mutations()

    def test_renew_check_never_claims_forced_issue_or_mutates(self):
        cert = self.patch(manager, "certificate_status", return_value={"days_left": 30})
        self.assertEqual(manager.main(["renew-check"]), 0)
        cert.assert_called_once_with()
        self.assertIn("автомат", self.stdout.getvalue().lower())
        self.assert_no_mutations()

    def test_menu_acme_declined_restart_does_not_mutate(self):
        self.patch(manager, "certificate_status", return_value={"days_left": 30})
        service = self.patch(manager, "service_action")
        self.stack.enter_context(patch("builtins.input", side_effect=["5", "n", "0"]))
        manager.menu()
        service.assert_not_called()
        self.assert_no_mutations()


class TemplateTests(IsolatedCase):
    def setUp(self):
        super().setUp()
        self.html = self.web / 'html'
        self.html.mkdir()
        (self.html / 'index.html').write_bytes(b'OLD INDEX')
        (self.html / 'old.css').write_bytes(b'old css')
        self.backup = self.root / 'backups' / 'change'
        self.backup.parent.mkdir()
        self.patch(m, 'backup_dir', side_effect=self.make_backup)
        self.https = self.patch(m, 'check_https')
        self.real_wait_https = m.wait_https
        self.wait_https = self.patch(m, 'wait_https',
                                     side_effect=lambda domain, port, expected, timeout: self.https(domain, port, expected))
        self.manifest = {'schema': 1, 'version': 'premium-v1',
                         'template': 'north', 'seed': 'a' * 64}
        self.expected = {'index.html': b'NEW INDEX', 'style.css': b'new css'}
        self.premium = MagicMock()
        self.premium.SiteError = type('FakeSiteError', (Exception,), {})
        self.premium.new_manifest.side_effect = lambda template: dict(self.manifest, template=template)
        self.premium.validate_manifest.side_effect = lambda data: data
        self.premium.expected_files.return_value = self.expected
        self.premium.generate.side_effect = self.generate
        self.premium.copy_generated.side_effect = self.copy_generated
        self.patch(manager, '_premium', return_value=self.premium)
        self.patch(manager, '_manifest_bytes', side_effect=self.read_manifest)
        self.run.side_effect = None

    def make_backup(self, label):
        self.assertEqual(label, 'premium-site')
        self.backup.mkdir(mode=0o700)
        return self.backup

    def read_manifest(self):
        return self.private.read_bytes() if self.private.exists() else None

    def generate(self, manifest, output):
        self.assertFalse(output.exists())
        output.mkdir()
        for name, content in self.expected.items():
            (output / name).write_bytes(content)

    def copy_generated(self, source, output, manifest):
        import shutil
        shutil.copytree(source, output)

    def save_old_manifest(self):
        self.private.parent.mkdir(mode=0o700)
        self.private.write_bytes(b'{"template":"still","legacy":false}\n')
        return self.private.read_bytes()

    def test_switch_legacy_install_generates_validates_before_stop_and_commits_after_https(self):
        events = []
        self.https.side_effect = lambda domain, port, expected: events.append(('https', expected))
        def run(argv, **kwargs):
            events.append(tuple(argv))
            self.assertEqual(argv[-1], 'remnanode-web')
            if argv[1] == 'stop':
                self.assertTrue(self.premium.copy_generated.called)
                self.assertFalse(self.private.exists())
                self.assertEqual((self.backup / 'html' / 'index.html').read_bytes(), b'OLD INDEX')
            else:
                self.assertEqual((self.html / 'index.html').read_bytes(), b'NEW INDEX')
                self.assertFalse(self.private.exists())
        self.run.side_effect = run
        manager.switch_template('1', confirm=True)
        self.assertEqual((self.html / 'index.html').read_bytes(), b'NEW INDEX')
        self.assertFalse((self.html / 'old.css').exists())
        self.assertEqual(json.loads(self.private.read_bytes()), self.manifest)
        self.assertEqual(events[0], ('https', 'OLD INDEX'))
        self.assertEqual(events[-1], ('https', 'NEW INDEX'))
        self.stopped.assert_called_once_with('remnanode-web')
        self.lock.assert_called_once_with()
        self.compose.assert_not_called()
        self.assertFalse(list(self.web.glob('.premium-*')))

    def test_new_https_retries_transient_unavailability_after_start(self):
        self.wait_https.side_effect = self.real_wait_https
        self.https.side_effect = [None, m.Failure('Caddy starting'), None]
        sleep = self.patch(m.time, 'sleep')
        manager.switch_template('1', confirm=True)
        self.wait_https.assert_called_once_with(DOMAIN, 9443, 'NEW INDEX', timeout=60)
        self.assertEqual(self.https.call_args_list,
                         [call(DOMAIN, 9443, 'OLD INDEX'),
                          call(DOMAIN, 9443, 'NEW INDEX'),
                          call(DOMAIN, 9443, 'NEW INDEX')])
        sleep.assert_called_once_with(3)
        self.assertEqual(json.loads(self.private.read_bytes()), self.manifest)
        self.assertEqual([c.args[0][1] for c in self.run.call_args_list], ['stop', 'start'])

    def test_restored_https_retries_transient_unavailability_after_rollback_start(self):
        self.wait_https.side_effect = self.real_wait_https
        self.https.side_effect = [None, m.Failure('Caddy starting'), None,
                                 m.Failure('old Caddy starting'), None]
        sleep = self.patch(m.time, 'sleep')
        original = manager._atomic_bytes
        def atomic(path, data):
            if path == self.private:
                raise OSError('manifest commit failed')
            return original(path, data)
        self.patch(manager, '_atomic_bytes', side_effect=atomic)
        with self.assertRaises(OSError):
            manager.switch_template('1', confirm=True)
        self.assertEqual(self.wait_https.call_args_list,
                         [call(DOMAIN, 9443, 'NEW INDEX', timeout=60),
                          call(DOMAIN, 9443, 'OLD INDEX', timeout=60)])
        self.assertEqual(sleep.call_args_list, [call(3), call(3)])
        self.assertEqual((self.html / 'index.html').read_bytes(), b'OLD INDEX')
        self.assertFalse(self.private.exists())
        self.assertFalse(list(self.web.glob('.premium-*')))

    def test_requires_root_and_confirmation(self):
        with self.assertRaises(manager.SelfstealError):
            manager.switch_template('1')
        self.assert_no_mutations()
        manager.require_root.side_effect = manager.SelfstealError('root required')
        with self.assertRaises(manager.SelfstealError):
            manager.switch_template('1', confirm=True)
        self.assert_no_mutations()

    def test_unknown_installation_or_failed_old_https_never_stops(self):
        self.metadata['version'] = 99
        self.write_metadata()
        with self.assertRaises(manager.SelfstealError):
            manager.switch_template('1', confirm=True)
        self.run.assert_not_called()
        self.metadata['version'] = 2
        self.write_metadata()
        self.https.side_effect = m.Failure('certificate invalid')
        with self.assertRaises(m.Failure):
            manager.switch_template('1', confirm=True)
        self.run.assert_not_called()
        self.premium.generate.assert_not_called()

    def test_generation_or_exact_validation_failure_never_stops(self):
        self.premium.generate.side_effect = ValueError('bad asset')
        with self.assertRaises(ValueError):
            manager.switch_template('2', confirm=True)
        self.run.assert_not_called()
        self.assertEqual((self.html / 'index.html').read_bytes(), b'OLD INDEX')

    def test_generator_site_error_is_reported_without_traceback_or_stop(self):
        self.premium.generate.side_effect = self.premium.SiteError('bad asset')
        self.assertEqual(manager.main(['template', '--template1', '--confirm']), 1)
        self.assertIn('bad asset', self.stderr.getvalue())
        self.run.assert_not_called()

    def test_tampered_generated_bytes_refused_before_stop(self):
        def tamper(source, output, manifest):
            self.copy_generated(source, output, manifest)
            (output / 'index.html').write_bytes(b'tampered')
        self.premium.copy_generated.side_effect = tamper
        with self.assertRaises(manager.SelfstealError):
            manager.switch_template('1', confirm=True)
        self.run.assert_not_called()

    def test_readiness_failure_restores_site_and_unchanged_private_manifest(self):
        before = self.save_old_manifest()
        def https(domain, port, expected):
            if expected == 'NEW INDEX':
                raise m.Failure('not ready')
        self.https.side_effect = https
        with self.assertRaises(m.Failure):
            manager.switch_template('1', confirm=True)
        self.assertEqual((self.html / 'index.html').read_bytes(), b'OLD INDEX')
        self.assertEqual(self.private.read_bytes(), before)
        self.assertEqual([c.args[0][1] for c in self.run.call_args_list],
                         ['stop', 'start', 'stop', 'start'])
        self.assertEqual(self.stopped.call_count, 2)
        self.assertEqual((self.backup / 'premium-manifest.json').read_bytes(), before)

    def test_manifest_commit_failure_restores_old_site_and_exact_state(self):
        before = self.save_old_manifest()
        original = manager._atomic_bytes
        failed = []
        def atomic(path, data):
            if path == self.private and not failed:
                failed.append(True)
                # Simulate a write that fails after replacement, not only before it.
                original(path, data)
                raise OSError('commit failure')
            original(path, data)
        self.patch(manager, '_atomic_bytes', side_effect=atomic)
        with self.assertRaises(OSError):
            manager.switch_template('1', confirm=True)
        self.assertEqual((self.html / 'index.html').read_bytes(), b'OLD INDEX')
        self.assertEqual(self.private.read_bytes(), before)

    def test_failed_commit_on_legacy_restores_absent_manifest(self):
        original = manager._atomic_bytes
        def atomic(path, data):
            original(path, data)
            if path == self.private:
                raise OSError('commit failure')
        self.patch(manager, '_atomic_bytes', side_effect=atomic)
        with self.assertRaises(OSError):
            manager.switch_template('3', confirm=True)
        self.assertFalse(self.private.exists())
        self.assertEqual((self.html / 'index.html').read_bytes(), b'OLD INDEX')

    def test_publication_rename_failure_restores_old_tree_before_start(self):
        original = Path.rename
        def rename(path, target):
            if path.name == 'html' and path.parent.name.startswith('.premium-'):
                raise OSError('publication rename failure')
            return original(path, target)
        self.patch(Path, 'rename', new=rename)
        with self.assertRaises(OSError):
            manager.switch_template('1', confirm=True)
        self.assertEqual((self.html / 'index.html').read_bytes(), b'OLD INDEX')
        self.assertFalse(self.private.exists())
        self.assertEqual([c.args[0][1] for c in self.run.call_args_list], ['stop', 'start'])

    def test_failed_publication_and_restore_rename_preserves_old_tree(self):
        original = Path.rename
        def rename(path, target):
            if path.parent.name.startswith('.premium-'):
                raise OSError('rename failure')
            return original(path, target)
        self.patch(Path, 'rename', new=rename)
        with self.assertRaises(manager.SelfstealError):
            manager.switch_template('1', confirm=True)
        workspace, = self.web.glob('.premium-*')
        self.assertEqual((workspace / 'previous-html' / 'index.html').read_bytes(), b'OLD INDEX')
        self.assertTrue((self.backup / 'html').exists())

    def test_uncertain_initial_stop_preserves_all_trees(self):
        self.stopped.side_effect = m.Failure('still running')
        with self.assertRaises(manager.SelfstealError):
            manager.switch_template('1', confirm=True)
        self.assertEqual((self.html / 'index.html').read_bytes(), b'OLD INDEX')
        workspaces = list(self.web.glob('.premium-*'))
        self.assertEqual(len(workspaces), 1)
        self.assertEqual((workspaces[0] / 'html' / 'index.html').read_bytes(), b'NEW INDEX')
        self.assertTrue((self.backup / 'html').exists())
        self.assertFalse(self.private.exists())
        self.assertEqual([c.args[0][1] for c in self.run.call_args_list], ['stop'])

    def test_uncertain_rollback_stop_never_deletes_live_or_old_tree(self):
        self.stopped.side_effect = [None, m.Failure('still running')]
        self.https.side_effect = [None, m.Failure('not ready')]
        with self.assertRaises(manager.SelfstealError):
            manager.switch_template('1', confirm=True)
        self.assertEqual((self.html / 'index.html').read_bytes(), b'NEW INDEX')
        workspace, = self.web.glob('.premium-*')
        self.assertEqual((workspace / 'previous-html' / 'index.html').read_bytes(), b'OLD INDEX')
        self.assertTrue((self.backup / 'html').exists())

    def test_cli_flags_and_menu_dispatch(self):
        switch = self.patch(manager, 'switch_template')
        for number in ('1', '2', '3'):
            self.assertEqual(manager.main(['template', '--template' + number, '--confirm']), 0)
            switch.assert_called_with(number, confirm=True)
        self.stack.enter_context(patch('builtins.input', side_effect=['8', '2', 'ПОДТВЕРЖДАЮ', '0']))
        manager.menu()
        switch.assert_called_with('2', confirm=True)
        self.assertIn('Сменить шаблон сайта', self.stdout.getvalue())
        self.assertIn('legacy', self.stdout.getvalue())

    def test_install_command_validates_existing_install_and_never_changes_services(self):
        import command_runtime
        install = self.patch(command_runtime, 'install_runtime')
        check = self.patch(command_runtime, 'check_conflict')
        manager.install_command()
        check.assert_called_once_with(m.BASE)
        install.assert_called_once_with(m.BASE)
        self.run.assert_not_called()
        self.compose.assert_not_called()


class ExtraValidationTests(IsolatedCase):
    def test_mount_readonly_logs_and_volumes_must_match(self):
        for index, field, value in ((0, 'RW', True), (1, 'RW', True),
                                    (2, 'Source', '/foreign/logs'),
                                    (3, 'Name', 'foreign_data'), (4, 'RW', False)):
            original = deepcopy(self.container)
            self.container['Mounts'][index][field] = value
            with self.subTest(index=index, field=field), self.assertRaises(manager.SelfstealError):
                manager.validate_installation()
            self.container.clear()
            self.container.update(original)
        self.assert_no_mutations()

    def test_missing_manifest_reports_legacy_without_loading_premium(self):
        premium = self.patch(manager, '_premium', side_effect=AssertionError('must remain lazy'))
        self.assertEqual(manager.current_template(), 'legacy')
        premium.assert_not_called()

    def test_root_denial_blocks_service(self):
        manager.require_root.side_effect = manager.SelfstealError('root required')
        with self.assertRaises(manager.SelfstealError):
            manager.service_action('start')
        self.assert_no_mutations()


if __name__ == "__main__":
    unittest.main()
