"""Portable host-feature contracts. No server commands, network or system writes.

Run: python -B -m unittest discover -s tests -p test_host_features.py -v
Linux ownership/service behavior is mocked, not integration-tested on Windows.
"""
from contextlib import ExitStack
import importlib.util
import json
import os
from pathlib import Path
import socket
import subprocess
import sys
import tempfile
from types import SimpleNamespace
import unittest
from unittest.mock import patch

PROJECT = Path(__file__).resolve().parents[1]


def load(name, filename):
    spec = importlib.util.spec_from_file_location(name, PROJECT / filename)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


m = load('host_features_test_manage', 'manage.py')
with patch.dict(sys.modules, {'manage': m}):
    host = load('host_features_under_test', 'host_features.py')


class HostCase(unittest.TestCase):
    def setUp(self):
        self.stack = ExitStack()
        self.addCleanup(self.stack.close)
        self.root = Path(self.stack.enter_context(tempfile.TemporaryDirectory(prefix='host-features-')))
        self.patch(host, 'ROOT', new=self.root)
        self.patch(host.sys, 'platform', new='linux')
        self.patch(host.os, 'geteuid', return_value=0, create=True)
        self.stack.enter_context(patch.dict(os.environ, {'SSH_CONNECTION': '192.0.2.10 55555 192.0.2.20 2200'}))
        for target, name in ((subprocess, 'run'), (subprocess, 'Popen'),
                             (os, 'system'), (socket, 'socket'),
                             (socket, 'create_connection'), (socket, 'getaddrinfo')):
            self.patch(target, name, side_effect=AssertionError('Real external calls forbidden'))
        self.secure = self.patch(m, 'secure_path', side_effect=self.safe_path)
        self.patch(m, 'backup_dir', side_effect=self.backup)
        original_open, original_mkdir, original_unlink = Path.open, Path.mkdir, Path.unlink

        def safe_open(path, mode='r', *args, **kwargs):
            if any(flag in mode for flag in 'wax+'):
                self.safe_path(path)
            return original_open(path, mode, *args, **kwargs)

        def safe_mkdir(path, *args, **kwargs):
            self.safe_path(path)
            return original_mkdir(path, *args, **kwargs)

        def safe_unlink(path, *args, **kwargs):
            self.safe_path(path)
            return original_unlink(path, *args, **kwargs)

        self.patch(Path, 'open', new=safe_open)
        self.patch(Path, 'mkdir', new=safe_mkdir)
        self.patch(Path, 'unlink', new=safe_unlink)
        self.disk = self.patch(host, '_disk_snapshot', return_value=[
            {'path': '/', 'free_bytes': 4 * host.GIB, 'free_inodes': 20000}])
        self.cc = 'cubic'
        self.qdisc = 'fq_codel'
        self.actual = [{'kind': 'noqueue', 'dev': 'lo'}, {'kind': 'fq_codel', 'dev': 'eth0'}]
        self.module = '/lib/modules/test/tcp_bbr.ko'
        self.installed = False
        self.active = 'unknown'
        self.enabled = 'not-found'
        self.calls = []
        self.failure = None
        self.run = self.patch(m, 'run', side_effect=self.command)

    def patch(self, target, name, **kwargs):
        return self.stack.enter_context(patch.object(target, name, **kwargs))

    def safe_path(self, path, **kwargs):
        path = Path(path).absolute()
        if not path.is_relative_to(self.root):
            raise AssertionError('Non-test path forbidden: ' + str(path))
        if path.is_symlink():
            raise m.Failure('Unsafe symlink')
        return path

    def backup(self, label):
        path = self.root / 'backups' / (label + '-' + str(len(list((self.root / 'backups').glob('*')))))
        path.mkdir(parents=True)
        return path

    def write(self, name, text):
        path = host._path(name)
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(text, encoding='utf-8')
        return path

    def command(self, args, **kwargs):
        args = [str(arg) for arg in args]
        self.calls.append(args)
        self.assertGreater(kwargs.get('timeout', 0), 0)
        self.assertLessEqual(kwargs['timeout'], 900)
        if self.failure is not None:
            self.failure(args)
        if args[:2] == ['sysctl', '-n']:
            return {host.CC: self.cc, host.QDISC: self.qdisc,
                    'net.ipv4.tcp_available_congestion_control': 'cubic bbr'}[args[2]]
        if args[:2] == ['sysctl', '-w']:
            self.assertEqual(args[2].split('=')[0], host.CC)
            self.cc = args[2].split('=')[1]
            return SimpleNamespace(returncode=0, stdout='')
        if args == ['tc', '-j', 'qdisc', 'show']:
            return json.dumps(self.actual)
        if args == ['modinfo', '-F', 'filename', 'tcp_bbr']:
            return self.module
        if args == ['modprobe', 'tcp_bbr']:
            return SimpleNamespace(returncode=0, stdout='')
        if args == ['uname', '-r']:
            return 'test-kernel'
        if args == ['nproc']:
            return '2'
        if args == ['systemd-detect-virt']:
            return 'kvm'
        if args == ['free', '-b']:
            return 'Mem: 2000000000 500000000 1500000000'
        if args[:1] == ['dpkg-query']:
            self.assertEqual(args[-1], 'fail2ban')
            return SimpleNamespace(returncode=0 if self.installed else 1,
                                   stdout='install ok installed' if self.installed else '')
        if args == ['systemctl', 'is-active', 'fail2ban']:
            return SimpleNamespace(returncode={'active': 0, 'inactive': 3, 'unknown': 4,
                                               'failed': 3}[self.active], stdout=self.active)
        if args == ['systemctl', 'is-enabled', 'fail2ban']:
            return SimpleNamespace(returncode=0 if self.enabled == 'enabled' else 1, stdout=self.enabled)
        if args[:2] == ['apt-get', 'update']:
            self.assertTrue(host._path(host.POLICY_FILE).is_file())
            return SimpleNamespace(returncode=0, stdout='')
        if args[:2] == ['apt-get', 'install']:
            self.assertTrue(host._path(host.POLICY_FILE).is_file())
            self.installed = True
            self.active = 'inactive'
            self.enabled = 'disabled'
            self.write('/etc/fail2ban/action.d/nftables-multiport.conf', '[Definition]\n')
            return SimpleNamespace(returncode=0, stdout='')
        if args == ['fail2ban-client', '-t']:
            self.assertTrue(host._path(host.JAIL_FILE).is_file())
            self.assertFalse(host._path(host.POLICY_FILE).exists())
            return SimpleNamespace(returncode=0, stdout='OK')
        if args == ['systemctl', 'enable', '--now', 'fail2ban']:
            self.active, self.enabled = 'active', 'enabled'
            return SimpleNamespace(returncode=0, stdout='')
        if args == ['fail2ban-client', 'status', 'sshd']:
            return SimpleNamespace(returncode=0, stdout='Status for the jail: sshd')
        if args == ['systemctl', 'stop', 'fail2ban']:
            self.active = 'inactive'
            return SimpleNamespace(returncode=0, stdout='')
        if args == ['systemctl', 'disable', 'fail2ban']:
            self.enabled = 'disabled'
            return SimpleNamespace(returncode=0, stdout='')
        raise AssertionError('Unexpected external command: ' + repr(args))

    def fail_on(self, expected):
        def fail(args):
            if args == expected:
                raise m.Failure('SECRET_DIAGNOSTIC')
        self.failure = fail

    def assert_no_writes(self):
        self.assertEqual(list(self.root.iterdir()), [])


class CapacityTests(HostCase):
    def test_default_is_2_gib_and_threshold_is_inclusive(self):
        self.disk.return_value[0].update(free_bytes=2 * host.GIB, free_inodes=10000)
        self.assertEqual(host.preflight_capacity(), self.disk.return_value)
        self.run.assert_not_called()
        self.assert_no_writes()

    def test_low_space_or_inodes_warn_without_blocking_or_cleanup(self):
        for field, value in (('free_bytes', 0), ('free_bytes', host.GIB - 1),
                             ('free_bytes', 2 * host.GIB - 1), ('free_inodes', 9999)):
            with self.subTest(field=field, value=value):
                self.disk.return_value = [{'path': '/var/lib/docker', 'free_bytes': 4 * host.GIB,
                                           'free_inodes': 20000, field: value}]
                with patch('builtins.print') as output:
                    self.assertEqual(host.preflight_capacity(), self.disk.return_value)
                self.assertTrue(output.called)
                self.assertIn('ПРЕДУПРЕЖДЕНИЕ', output.call_args.args[0])
        self.run.assert_not_called()
        self.assert_no_writes()

    def test_cannot_disable_capacity_floor(self):
        for value in (0, host.GIB - 1, True, 'invalid'):
            with self.subTest(value=value), self.assertRaises(m.Failure):
                host.preflight_capacity(value)
        self.disk.assert_not_called()

    def test_optional_floor_and_unknown_unlimited_inodes(self):
        self.disk.return_value[0].update(free_bytes=host.GIB, free_inodes=None)
        self.assertTrue(host.preflight_capacity(host.GIB))

    def test_observation_failure_is_controlled(self):
        self.disk.side_effect = OSError('disk unavailable')
        with self.assertRaises(m.Failure):
            host.preflight_capacity()
        self.assert_no_writes()

    def test_snapshot_checks_ancestor_of_each_download_path(self):
        self.write('/var/lib/docker/keep', 'keep')
        self.disk.side_effect = None
        with patch.object(host.shutil, 'disk_usage', return_value=SimpleNamespace(free=3 * host.GIB, total=5 * host.GIB)) as usage:
            with patch.object(host.os, 'statvfs', create=True,
                              return_value=SimpleNamespace(f_favail=12345, f_files=100000)):
                snapshot = self.disk_snapshot_original()
        self.assertEqual([item['path'] for item in snapshot],
                         ['/', '/var/lib/docker', '/var/cache/apt/archives', '/opt'])
        self.assertEqual(snapshot[0]['free_inodes'], 12345)
        self.assertEqual(usage.call_count, 4)

    @staticmethod
    def disk_snapshot_original():
        # A fresh isolated module retains the real function, with the same temp ROOT.
        with patch.dict(sys.modules, {'manage': m}):
            real = load('host_features_disk_test', 'host_features.py')
        real.ROOT = host.ROOT
        return real._disk_snapshot()


class InspectionTests(HostCase):
    def test_read_only_bounded_commands(self):
        data = host.inspect_performance()
        self.assertEqual(data['congestion_control'], 'cubic')
        self.assertEqual(data['default_qdisc'], 'fq_codel')
        self.assertEqual(data['qdiscs'], self.actual)
        self.assertEqual(data['disk'], self.disk.return_value)
        self.assertEqual(data['errors'], [])
        self.assertEqual(data['cpu_count'], '2')
        self.assertEqual(data['virtualization'], 'kvm')
        self.assertIn('2000000000', data['memory'])
        self.assertEqual(len(self.calls), 9)
        self.assertTrue(all(entry.kwargs['timeout'] <= 10 for entry in self.run.call_args_list))
        self.assert_no_writes()

    def test_unavailable_observations_do_not_trigger_changes(self):
        self.run.side_effect = m.Failure('SECRET_DIAGNOSTIC')
        data = host.inspect_performance()
        self.assertEqual(len(data['errors']), 9)
        self.assertNotIn('SECRET_DIAGNOSTIC', json.dumps(data))
        self.assert_no_writes()


class BBRTests(HostCase):
    def test_apply_only_cc_preserves_qdisc_and_leaves_module_loaded_on_rollback(self):
        change = host.configure_bbr()
        self.assertIn('включён и проверен', change.status)
        self.assertEqual(self.cc, 'bbr')
        self.assertEqual(host._path(host.MODULE_FILE).read_text(), host.MODULE_TEXT)
        self.assertEqual(host._path(host.SYSCTL_FILE).read_text(), host.SYSCTL_TEXT)
        self.assertTrue((change.backup / 'rollback.py').is_file())
        state = json.loads((change.backup / 'state.json').read_text())
        self.assertEqual(state['old_cc'], 'cubic')
        self.assertEqual(len(state['files']), 2)
        self.assertEqual([args for args in self.calls if args[:2] == ['sysctl', '-w']],
                         [['sysctl', '-w', host.CC + '=bbr']])
        change.rollback()
        self.assertEqual(self.cc, 'cubic')
        self.assertFalse(host._path(host.MODULE_FILE).exists())
        self.assertFalse(host._path(host.SYSCTL_FILE).exists())
        self.assertFalse(any(args[:1] == ['tc'] and 'show' not in args for args in self.calls))
        self.assertFalse(any(args[:2] == ['modprobe', '-r'] for args in self.calls))
        count = len(self.calls)
        change.rollback()
        self.assertEqual(len(self.calls), count)

    def test_both_supported_qdiscs_preserved(self):
        self.qdisc = 'fq'
        self.actual = [{'kind': 'mq'}, {'kind': 'fq'}]
        self.assertIn('включён', host.configure_bbr().status)
        self.assertEqual(self.qdisc, 'fq')

    def test_unknown_qdisc_current_or_module_skips_without_writes(self):
        for field, value in (('qdisc', 'pfifo_fast'), ('actual', [{'kind': 'cake'}]),
                             ('actual', []), ('actual', {}), ('module', ''), ('cc', 'bad value')):
            with self.subTest(field=field):
                old = getattr(self, field)
                setattr(self, field, value)
                change = host.configure_bbr()
                self.assertIn('пропущен', change.status)
                change.rollback()
                self.assert_no_writes()
                setattr(self, field, old)
        self.assertFalse(any(args[:2] == ['sysctl', '-w'] for args in self.calls))

    def test_read_failure_is_skip_not_error(self):
        self.fail_on(['modinfo', '-F', 'filename', 'tcp_bbr'])
        self.assertIn('пропущен', host.configure_bbr().status)
        self.assert_no_writes()

    def test_existing_external_config_is_respected(self):
        for name, text in (('/etc/sysctl.d/tuning.conf', host.CC + '=cubic\n'),
                           ('/etc/sysctl.d/tuning.conf', host.QDISC + '=fq\n'),
                           ('/etc/sysctl.d/tuning.conf', 'net/ipv4/tcp_congestion_control=cubic\n'),
                           ('/etc/modules-load.d/external.conf', 'tcp_bbr\n'),
                           (host.SYSCTL_FILE, 'external owner\n')):
            with self.subTest(name=name, text=text):
                path = self.write(name, text)
                self.assertIn('пропущен', host.configure_bbr().status)
                self.assertEqual(path.read_text(), text)
                path.unlink()
        self.assertFalse(any(args[:1] == ['modprobe'] for args in self.calls))

    def test_already_enabled_external_does_not_add_persistence(self):
        self.cc = 'bbr'
        change = host.configure_bbr()
        self.assertIn('извне', change.status)
        change.rollback()
        self.assert_no_writes()

    def test_idempotent_second_call_cannot_rollback_first_calls_changes(self):
        first = host.configure_bbr()
        count = len([args for args in self.calls if args[:2] == ['sysctl', '-w']])
        second = host.configure_bbr()
        self.assertIn('уже включён', second.status)
        second.rollback()
        self.assertEqual(self.cc, 'bbr')
        self.assertTrue(host._path(host.SYSCTL_FILE).exists())
        self.assertEqual(len([args for args in self.calls if args[:2] == ['sysctl', '-w']]), count)
        first.rollback()

    def test_runtime_rollback_failure_is_reported_and_keeps_journal(self):
        change = host.configure_bbr()
        self.fail_on(['sysctl', '-w', host.CC + '=cubic'])
        with self.assertRaises(m.Failure):
            change.rollback()
        state = json.loads((change.backup / 'state.json').read_text())
        self.assertTrue(state['cc_changed'])
        self.assertTrue(host._path(host.SYSCTL_FILE).exists())
        self.failure = None
        change.rollback()
        self.assertEqual(self.cc, 'cubic')

    def test_exclusive_file_creation_failure_restores_earlier_own_file(self):
        original = host.FeatureChange._new_file

        def write(change, path, text, mode=0o644):
            if path == host._path(host.SYSCTL_FILE):
                self.write(host.SYSCTL_FILE, 'concurrent owner')
            return original(change, path, text, mode)
        with patch.object(host.FeatureChange, '_new_file', new=write):
            with self.assertRaises(m.Failure):
                host.configure_bbr()
        self.assertFalse(host._path(host.MODULE_FILE).exists())
        self.assertEqual(host._path(host.SYSCTL_FILE).read_text(), 'concurrent owner')
        self.assertFalse(any(args[:2] == ['sysctl', '-w'] for args in self.calls))

    def test_failed_apply_rolls_back_files_and_safe_message(self):
        self.fail_on(['sysctl', '-w', host.CC + '=bbr'])
        with self.assertRaises(m.Failure) as caught:
            host.configure_bbr()
        self.assertNotIn('SECRET_DIAGNOSTIC', str(caught.exception))
        self.assertFalse(host._path(host.MODULE_FILE).exists())
        self.assertFalse(host._path(host.SYSCTL_FILE).exists())
        self.assertEqual(self.cc, 'cubic')

    def test_failed_verification_restores_runtime_value(self):
        original = self.command
        reads = 0

        def command(args, **kwargs):
            nonlocal reads
            if args == ['sysctl', '-n', host.CC]:
                reads += 1
                if reads == 2:
                    raise m.Failure('verification failed')
            return original(args, **kwargs)
        self.run.side_effect = command
        with self.assertRaises(m.Failure):
            host.configure_bbr()
        self.assertEqual(self.cc, 'cubic')
        self.assertFalse(host._path(host.SYSCTL_FILE).exists())

    def test_modprobe_failure_has_no_sysctl_write(self):
        self.fail_on(['modprobe', 'tcp_bbr'])
        with self.assertRaises(m.Failure):
            host.configure_bbr()
        self.assertFalse(any(args[:2] == ['sysctl', '-w'] for args in self.calls))

    def test_rollback_preserves_concurrent_file_and_runtime_changes(self):
        change = host.configure_bbr()
        path = self.write(host.SYSCTL_FILE, 'concurrent config\n')
        self.cc = 'reno'
        change.rollback()
        self.assertEqual(path.read_text(), 'concurrent config\n')
        self.assertEqual(self.cc, 'reno')
        self.assertFalse(host._path(host.MODULE_FILE).exists())

    def test_rollback_preserves_preexisting_own_exact_targets(self):
        module = self.write(host.MODULE_FILE, host.MODULE_TEXT)
        config = self.write(host.SYSCTL_FILE, host.SYSCTL_TEXT)
        change = host.configure_bbr()
        change.rollback()
        self.assertEqual(module.read_text(), host.MODULE_TEXT)
        self.assertEqual(config.read_text(), host.SYSCTL_TEXT)

    def test_root_required_before_commands(self):
        self.patch(host.os, 'geteuid', return_value=1000)
        with self.assertRaises(m.Failure):
            host.configure_bbr()
        self.run.assert_not_called()


class Fail2banTests(HostCase):
    def ensure(self):
        return host.ensure_fail2ban([2200, 22, 2200])

    def test_new_install_validates_before_enable_with_exact_client_and_ports(self):
        change = self.ensure()
        self.assertIn('включён и проверен', change.status)
        jail = host._path(host.JAIL_FILE).read_text()
        for text in ('backend = systemd', 'port = 22,2200', 'banaction = nftables-multiport',
                     'maxretry = 5', 'findtime = 10m', 'bantime = 1h',
                     'ignoreip = 127.0.0.1/8 ::1 192.0.2.10'):
            self.assertIn(text, jail)
        self.assertNotIn('192.0.2.0', jail)
        self.assertLess(self.calls.index(['fail2ban-client', '-t']),
                        self.calls.index(['systemctl', 'enable', '--now', 'fail2ban']))
        self.assertLess(self.calls.index(['systemctl', 'enable', '--now', 'fail2ban']),
                        self.calls.index(['fail2ban-client', 'status', 'sshd']))
        apt = next(entry for entry in self.run.call_args_list if entry.args[0][:2] == ['apt-get', 'install'])
        for package in ('fail2ban', 'python3-systemd', 'nftables'):
            self.assertIn(package, apt.args[0])
        self.assertEqual(apt.kwargs['env']['DEBIAN_FRONTEND'], 'noninteractive')
        self.assertIn('Dpkg::Options::=--force-confold', apt.args[0])
        self.assertFalse(host._path(host.POLICY_FILE).exists())
        self.assertTrue(self.disk.called)
        change.rollback()
        self.assertFalse(host._path(host.JAIL_FILE).exists())
        self.assertEqual(self.active, 'inactive')
        self.assertEqual(self.enabled, 'disabled')
        self.assertTrue(self.installed)
        self.assertFalse(any('remove' in args or 'purge' in args for args in self.calls))
        self.assertFalse(any(args[0] in ('ufw', 'sshd', 'nft') for args in self.calls))

    def test_existing_installed_active_external_is_never_touched(self):
        self.installed, self.active = True, 'active'
        path = self.write(host.JAIL_FILE, 'external config')
        change = self.ensure()
        self.assertIn('уже установлен', change.status)
        change.rollback()
        self.assertEqual(path.read_text(), 'external config')
        self.assertEqual(len(self.calls), 1)

    def test_existing_unknown_or_enabled_service_skipped(self):
        for active, enabled in (('active', 'enabled'), ('failed', 'disabled'),
                                ('inactive', 'enabled'), ('unknown', 'masked')):
            with self.subTest(active=active, enabled=enabled):
                self.active, self.enabled = active, enabled
                self.assertIn('пропущен', self.ensure().status)
                self.assert_no_writes()
        self.assertFalse(any(args[0] == 'apt-get' for args in self.calls))

    def test_external_config_and_policy_are_not_overwritten(self):
        for name in (host.JAIL_FILE, '/etc/fail2ban/jail.local', host.POLICY_FILE):
            with self.subTest(name=name):
                path = self.write(name, 'external')
                self.assertIn('пропущен', self.ensure().status)
                self.assertEqual(path.read_text(), 'external')
                path.unlink()
        self.assertFalse(any(args[0] == 'apt-get' for args in self.calls))

    def test_insufficient_capacity_warns_but_does_not_prevent_apt(self):
        self.disk.return_value[0]['free_bytes'] = 1
        with patch('builtins.print') as output:
            result = self.ensure()
        self.assertIn('включён', result.status)
        self.assertTrue(any(args[0] == 'apt-get' for args in self.calls))
        self.assertTrue(any('ПРЕДУПРЕЖДЕНИЕ' in str(entry) for entry in output.call_args_list))

    def test_apt_failure_removes_only_temporary_policy(self):
        self.fail_on(['apt-get', 'update'])
        with self.assertRaises(m.Failure) as caught:
            self.ensure()
        self.assertNotIn('SECRET_DIAGNOSTIC', str(caught.exception))
        self.assertFalse(host._path(host.POLICY_FILE).exists())
        self.assertFalse(host._path(host.JAIL_FILE).exists())
        self.assertFalse(any(args[:2] == ['systemctl', 'stop'] for args in self.calls))

    def test_partial_apt_failure_disables_only_newly_enabled_unit(self):
        def enable_and_fail(args):
            if args[:2] == ['apt-get', 'install']:
                self.installed, self.active, self.enabled = True, 'inactive', 'enabled'
                raise m.Failure('apt partially failed')
        self.failure = enable_and_fail
        with self.assertRaises(m.Failure):
            self.ensure()
        self.assertEqual(self.enabled, 'disabled')
        self.assertTrue(self.installed)
        self.assertFalse(host._path(host.POLICY_FILE).exists())
        self.assertFalse(any(args[:2] == ['systemctl', 'stop'] for args in self.calls))

    def test_config_validation_failure_removes_jail_without_starting_or_stopping(self):
        self.fail_on(['fail2ban-client', '-t'])
        with self.assertRaises(m.Failure):
            self.ensure()
        self.assertFalse(host._path(host.JAIL_FILE).exists())
        self.assertFalse(host._path(host.POLICY_FILE).exists())
        self.assertFalse(any(args[:2] in (['systemctl', 'enable'], ['systemctl', 'stop']) for args in self.calls))
        self.assertTrue(self.installed)

    def test_enable_failure_stops_only_originally_inactive_service(self):
        self.fail_on(['systemctl', 'enable', '--now', 'fail2ban'])
        with self.assertRaises(m.Failure):
            self.ensure()
        self.assertIn(['systemctl', 'stop', 'fail2ban'], self.calls)
        self.assertIn(['systemctl', 'disable', 'fail2ban'], self.calls)
        self.assertFalse(host._path(host.JAIL_FILE).exists())

    def test_failed_stop_retains_config_for_manual_recovery(self):
        change = self.ensure()
        self.fail_on(['systemctl', 'stop', 'fail2ban'])
        with self.assertRaises(m.Failure):
            change.rollback()
        self.assertTrue(host._path(host.JAIL_FILE).exists())
        self.assertTrue(json.loads((change.backup / 'state.json').read_text())['service_started'])
        self.failure = None
        change.rollback()
        self.assertFalse(host._path(host.JAIL_FILE).exists())

    def test_failed_apply_and_rollback_reports_private_recovery_path(self):
        def fail(args):
            if args in (['fail2ban-client', 'status', 'sshd'], ['systemctl', 'stop', 'fail2ban']):
                raise m.Failure('SECRET_DIAGNOSTIC')
        self.failure = fail
        with self.assertRaises(m.Failure) as caught:
            self.ensure()
        self.assertIn('ручная проверка', str(caught.exception))
        self.assertIn(str(self.root / 'backups'), str(caught.exception))
        self.assertNotIn('SECRET_DIAGNOSTIC', str(caught.exception))
        self.assertTrue(host._path(host.JAIL_FILE).exists())
        self.assertEqual(self.active, 'active')

    def test_missing_supported_action_does_not_start_service(self):
        original = self.command

        def command(args, **kwargs):
            result = original(args, **kwargs)
            if args[:2] == ['apt-get', 'install']:
                host._path('/etc/fail2ban/action.d/nftables-multiport.conf').unlink()
            return result
        self.run.side_effect = command
        with self.assertRaises(m.Failure):
            self.ensure()
        self.assertFalse(host._path(host.POLICY_FILE).exists())
        self.assertFalse(host._path(host.JAIL_FILE).exists())
        self.assertFalse(any(args[:2] == ['systemctl', 'enable'] for args in self.calls))

    def test_status_failure_stops_own_service_retains_packages(self):
        self.fail_on(['fail2ban-client', 'status', 'sshd'])
        with self.assertRaises(m.Failure):
            self.ensure()
        self.assertEqual(self.active, 'inactive')
        self.assertEqual(self.enabled, 'disabled')
        self.assertTrue(self.installed)
        self.assertFalse(host._path(host.JAIL_FILE).exists())

    def test_concurrent_jail_edit_does_not_stop_service_or_delete_file(self):
        change = self.ensure()
        path = self.write(host.JAIL_FILE, 'external edit')
        before = len(self.calls)
        with self.assertRaises(m.Failure):
            change.rollback()
        self.assertEqual(path.read_text(), 'external edit')
        self.assertEqual(len(self.calls), before)
        self.assertEqual(self.active, 'active')

    def test_concurrent_policy_edit_is_preserved_on_failure(self):
        def edit_and_fail(args):
            if args == ['apt-get', 'update']:
                self.write(host.POLICY_FILE, 'external edit')
                raise m.Failure('apt failed')
        self.failure = edit_and_fail
        with self.assertRaises(m.Failure):
            self.ensure()
        self.assertEqual(host._path(host.POLICY_FILE).read_text(), 'external edit')

    def test_invalid_ports_or_ssh_connection_fail_before_commands(self):
        for ports in ([], [0], [65536], [True], ['22']):
            with self.subTest(ports=ports), self.assertRaises(m.Failure):
                host.ensure_fail2ban(ports)
        for value in ('bad', '192.0.2.10 10 192.0.2.20 2222',
                      '192.0.2.10\nmalicious 10 192.0.2.20 22'):
            with self.subTest(value=value), patch.dict(os.environ, {'SSH_CONNECTION': value}):
                with self.assertRaises(m.Failure):
                    self.ensure()
        self.run.assert_not_called()
        self.assert_no_writes()

    def test_ipv6_client_is_exact_address_and_local_invocation_is_supported(self):
        with patch.dict(os.environ, {'SSH_CONNECTION': '2001:db8::10 55555 2001:db8::20 22'}):
            text = host._jail_text([22])
        self.assertIn('ignoreip = 127.0.0.1/8 ::1 2001:db8::10\n', text)
        with patch.dict(os.environ, {'SSH_CONNECTION': ''}):
            self.assertIn('ignoreip = 127.0.0.1/8 ::1\n', host._jail_text([22]))

    def test_keyboard_interrupt_also_rolls_back_policy(self):
        def interrupt(args):
            if args == ['apt-get', 'update']:
                raise KeyboardInterrupt()
        self.failure = interrupt
        with self.assertRaises(KeyboardInterrupt):
            self.ensure()
        self.assertFalse(host._path(host.POLICY_FILE).exists())


if __name__ == '__main__':
    unittest.main()
