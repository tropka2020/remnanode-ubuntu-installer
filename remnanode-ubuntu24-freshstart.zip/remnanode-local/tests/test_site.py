import contextlib
import ctypes
import importlib.util
import io
import json
import os
from pathlib import Path
import stat
import tempfile
import unittest
from unittest import mock

# Import by path because Python's built-in site module has the same name.
SPEC = importlib.util.spec_from_file_location('owner_site', Path(__file__).resolve().parents[1] / 'site.py')
site = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(site)


class SiteTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        os.chmod(self.root, 0o700)
        self.content = self.root / 'content.json'
        self.content.write_text(json.dumps({
            'title': 'Owner <&" title', 'description': 'Real description',
            'about': 'Actual owner material',
            'articles': [{'title': 'A real note', 'text': 'Actual note\nSecond line'}]
        }), encoding='utf-8')

    def source(self, html='<a href="https://example.org/">Public link</a>'):
        source = self.root / 'source'
        source.mkdir()
        (source / 'index.html').write_text(html, encoding='utf-8')
        return source

    def reject_html(self, text):
        source = self.root / 'source'
        source.mkdir(exist_ok=True)
        (source / 'index.html').write_text(text, encoding='utf-8')
        with self.assertRaises(site.SiteError):
            site.validate(source)

    def test_generate_variants_and_escape(self):
        outputs = []
        illustrations = []
        for number in range(3):
            with mock.patch.object(site.secrets, 'choice', side_effect=lambda items: items[number % len(items)]):
                output = self.root / ('published' + str(number))
                site.generate(self.content, output)
            site.validate(output)
            self.assertEqual(set(p.name for p in output.iterdir()), {
                'index.html', 'about.html', 'notes.html', 'style.css',
                'favicon.svg', 'illustration.svg'})
            index = (output / 'index.html').read_text(encoding='utf-8')
            self.assertIn('Owner &lt;&amp;&quot; title', index)
            self.assertIn('Actual owner material', (output / 'about.html').read_text())
            self.assertIn('Actual note', (output / 'notes.html').read_text())
            outputs.append((output / 'style.css').read_text())
            illustrations.append((output / 'illustration.svg').read_text())
            self.assertIn('>O</text>', (output / 'favicon.svg').read_text())
            self.assertIn('lang="en"', index)
            self.assertIn('>Home</a>', index)
            if os.name != 'nt':
                self.assertEqual(stat.S_IMODE(output.stat().st_mode), 0o755)
                for file in output.iterdir():
                    self.assertEqual(stat.S_IMODE(file.stat().st_mode), 0o644)
        self.assertEqual(len(set(outputs)), 3)
        self.assertEqual(len(set(illustrations)), 3)
        self.assertEqual(illustrations[0].count('<circle'), 1)
        self.assertEqual(illustrations[1].count('<circle'), 3)
        self.assertEqual(illustrations[2].count('<circle'), 0)
        self.assertFalse(list(self.root.glob('.site-staging-*')))

    def test_russian_interface_and_escaped_monogram(self):
        content = json.loads(self.content.read_text(encoding='utf-8'))
        content['title'] = '<Мои материалы>'
        content['about'] = 'Настоящее описание владельца'
        self.content.write_text(json.dumps(content), encoding='utf-8')
        output = self.root / 'published'
        site.generate(self.content, output)
        site.validate(output)
        index = (output / 'index.html').read_text(encoding='utf-8')
        self.assertIn('lang="ru"', index)
        for label in ('Главная', 'О сайте', 'Заметки', 'Читать заметки'):
            self.assertIn(label, index)
        self.assertIn('>&lt;</text>', (output / 'favicon.svg').read_text(encoding='utf-8'))
        self.assertIn('<h1>О сайте</h1>', (output / 'about.html').read_text(encoding='utf-8'))
        self.assertIn('<h1>Заметки</h1>', (output / 'notes.html').read_text(encoding='utf-8'))

    def test_owner_strings_do_not_become_markup(self):
        payload = '<script>alert("x")</script><img src="https://secret.invalid/"> & \' "'
        self.content.write_text(json.dumps({
            'title': payload, 'description': payload, 'about': payload,
            'articles': [{'title': payload, 'text': payload}]
        }), encoding='utf-8')
        output = self.root / 'published'
        site.generate(self.content, output)
        site.validate(output)
        for name in ('index.html', 'about.html', 'notes.html'):
            text = (output / name).read_text(encoding='utf-8')
            self.assertNotIn('<script>', text)
            self.assertNotIn('<img src="https:', text)
            self.assertIn('&lt;script&gt;', text)

    def test_existing_output_is_unchanged(self):
        output = self.root / 'published'
        output.mkdir()
        marker = output / 'keep.txt'
        marker.write_text('keep')
        with self.assertRaises(site.SiteError):
            site.generate(self.content, output)
        self.assertEqual(marker.read_text(), 'keep')
        self.assertEqual(list(output.iterdir()), [marker])
        with self.assertRaises((site.SiteError, OSError)):
            site.rename_no_replace(self.source(), output)
        self.assertTrue(marker.exists())

    def test_existing_empty_directory_is_not_replaced(self):
        source = self.source()
        output = self.root / 'published'
        output.mkdir()
        with self.assertRaises((site.SiteError, OSError)):
            site.rename_no_replace(source, output)
        self.assertTrue(source.exists())
        self.assertEqual(list(output.iterdir()), [])

    def test_staging_is_removed_on_failure(self):
        output = self.root / 'published'
        def broken(staging):
            (staging / 'public').mkdir()
            (staging / 'public' / 'index.html').write_text('<script></script>')
        with self.assertRaises(site.SiteError):
            site.publish(output, broken)
        self.assertFalse(output.exists())
        self.assertFalse(list(self.root.glob('.site-staging-*')))

    def test_missing_index(self):
        source = self.root / 'source'
        source.mkdir()
        (source / 'about.html').write_text('About')
        with self.assertRaises(site.SiteError):
            site.validate(source)

    def test_unsafe_html_and_links(self):
        cases = [
            '<a href="javascript:alert(1)">x</a>',
            '<a href="java&#x09;script:alert(1)">x</a>',
            '<a href="file:///private">x</a>',
            '<a href="//example.org/">x</a>',
            '<a href="../private.txt">x</a>',
            '<a href="%2e%2e/private.txt">x</a>',
            '<a href="%252e%252e/private.txt">x</a>',
            '<a href="%5cprivate">x</a>',
            '<a href="missing.html">x</a>',
            '<img src="https://example.org/image.png">',
            '<link rel="stylesheet" href="https://example.org/style.css">',
            '<form></form>', '<iframe></iframe>', '<script></script>',
            '<img onerror="alert(1)">', '<meta http-equiv="refresh" content="1">',
            '<base href="https://example.org/">', '<img srcset="a.png 1x">',
            '<svg><script/></svg>', '<object data="index.html"></object>'
        ]
        for text in cases:
            with self.subTest(text=text):
                self.reject_html(text)

    def test_local_references(self):
        source = self.source('<a href="/notes/">Notes</a><a href="#one">Here</a><link rel="stylesheet" href="style.css">')
        (source / 'notes').mkdir()
        (source / 'notes' / 'index.html').write_text('<a href="/index.html">Home</a>')
        (source / 'style.css').write_text('@import "other.css"; body { background: url("picture.svg"); }')
        (source / 'other.css').write_text('p { color: red; }')
        (source / 'picture.svg').write_text('<svg xmlns="http://www.w3.org/2000/svg"><rect id="r"/><use href="#r"/></svg>')
        site.validate(source)

    def test_css_urls_and_imports(self):
        source = self.source()
        cases = ['@import "https://example.org/style.css";',
                 '@import url(//example.org/style.css);',
                 'a {background: url(../secret.png)}',
                 'a {background: url(missing.png)}',
                 'a {background: u\\72l(https://example.org/)}',
                 'a {background: url("file:///a")}',
                 '@import "missing.css";',
                 'a {background: URL(https://example.org/)}',
                 'a {width: expression(alert(1))}']
        for text in cases:
            with self.subTest(text=text):
                (source / 'style.css').write_text(text)
                with self.assertRaises(site.SiteError):
                    site.validate(source)
        (source / 'style.css').unlink()
        self.reject_html('<style>body {background: url(https://example.org/)}</style>')
        self.reject_html('<p style="background:url(missing.png)">x</p>')

    def test_svg_is_not_an_active_document(self):
        source = self.source()
        cases = ['<svg><script/></svg>', '<svg onload="x"/>',
                 '<svg><image href="https://example.org/a.png"/></svg>',
                 '<!DOCTYPE svg [<!ENTITY x "secret">]><svg/>',
                 '<svg><rect style="fill:url(https://example.org/)"/></svg>']
        for text in cases:
            with self.subTest(text=text):
                (source / 'picture.svg').write_text(text)
                with self.assertRaises(site.SiteError):
                    site.validate(source)

    def test_svg_rejects_stylesheet_processing_instructions(self):
        source = self.source()
        instruction = '<?xml-stylesheet type="text/css" href="https://external.example/style.css"?>'
        cases = [
            instruction + '<svg xmlns="http://www.w3.org/2000/svg"/>',
            '<svg xmlns="http://www.w3.org/2000/svg">' + instruction + '</svg>',
        ]
        for text in cases:
            with self.subTest(text=text):
                (source / 'picture.svg').write_text(text, encoding='utf-8')
                with self.assertRaises(site.SiteError):
                    site.validate(source)

    def test_svg_accepts_xml_declaration(self):
        source = self.source()
        (source / 'picture.svg').write_text(
            '<?xml version="1.0"?><svg xmlns="http://www.w3.org/2000/svg"/>',
            encoding='utf-8')
        site.validate(source)

    def test_dotfiles_and_disallowed_extensions(self):
        source = self.source()
        for name in ('.env', '.private.txt', 'program.js', 'binary.exe'):
            with self.subTest(name=name):
                path = source / name
                path.write_text('private')
                with self.assertRaises(site.SiteError):
                    site.validate(source)
                path.unlink()
        (source / '.private').mkdir()
        with self.assertRaises(site.SiteError):
            site.validate(source)

    def test_symlink(self):
        source = self.source()
        target = self.root / 'outside.txt'
        target.write_text('private')
        try:
            (source / 'linked.txt').symlink_to(target)
        except OSError as error:
            self.skipTest('Symlinks unavailable: ' + type(error).__name__)
        with self.assertRaises(site.SiteError):
            site.validate(source)
        (source / 'linked.txt').unlink()
        link = self.root / 'linked-source'
        link.symlink_to(source, target_is_directory=True)
        with self.assertRaises(site.SiteError):
            site.validate(link)
        with self.assertRaises(site.SiteError):
            site.copy_site(source, link / 'new')

    def test_hardlink(self):
        source = self.source()
        target = self.root / 'outside.txt'
        target.write_text('private')
        try:
            os.link(target, source / 'linked.txt')
        except OSError as error:
            self.skipTest('Hard links unavailable: ' + type(error).__name__)
        with self.assertRaises(site.SiteError):
            site.validate(source)

    @unittest.skipUnless(os.name == 'nt', 'Windows file attributes')
    def test_windows_hidden_and_reparse_attributes(self):
        source = self.source()
        path = source / 'private.txt'
        path.write_text('private')
        kernel = ctypes.WinDLL('kernel32', use_last_error=True)
        setter = kernel.SetFileAttributesW
        setter.argtypes = [ctypes.c_wchar_p, ctypes.c_uint32]
        setter.restype = ctypes.c_int
        self.assertTrue(setter(str(path), 2))
        try:
            with self.assertRaises(site.SiteError):
                site.validate(source)
        finally:
            setter(str(path), 0x80)
        fake = mock.Mock(st_mode=stat.S_IFREG | 0o644, st_file_attributes=0x400)
        with mock.patch.object(Path, 'lstat', return_value=fake):
            with self.assertRaises(site.SiteError):
                site.checked_stat(path)

    def test_limits(self):
        source = self.source()
        with mock.patch.object(site, 'MAX_FILES', 0):
            with self.assertRaises(site.SiteError):
                site.validate(source)
        with mock.patch.object(site, 'MAX_BYTES', 1):
            with self.assertRaises(site.SiteError):
                site.validate(source)

    def test_copy_preserves_source(self):
        source = self.source('<a href="notes/note.html">Note</a>')
        (source / 'notes').mkdir()
        (source / 'empty').mkdir()
        (source / 'notes' / 'note.html').write_text('Real note')
        before = {p.relative_to(source): (p.read_bytes(), p.stat().st_mtime_ns, p.stat().st_mode)
                  for p in source.rglob('*') if p.is_file()}
        output = self.root / 'copy'
        site.copy_site(source, output)
        self.assertTrue((output / 'empty').is_dir())
        site.validate(output)
        after = {p.relative_to(source): (p.read_bytes(), p.stat().st_mtime_ns, p.stat().st_mode)
                 for p in source.rglob('*') if p.is_file()}
        self.assertEqual(before, after)
        self.assertEqual({p.relative_to(output): p.read_bytes() for p in output.rglob('*') if p.is_file()},
                         {name: data[0] for name, data in before.items()})
        with self.assertRaises(site.SiteError):
            site.copy_site(source, source / 'child')
        with self.assertRaises(site.SiteError):
            site.copy_site(source, source)

    def test_cli_error_has_no_content_or_traceback(self):
        self.content.write_text('{secret invalid JSON')
        stderr = io.StringIO()
        with contextlib.redirect_stderr(stderr):
            result = site.main(['generate', '--content', str(self.content), '--output', str(self.root / 'out')])
        self.assertEqual(result, 1)
        self.assertNotIn('secret', stderr.getvalue())
        self.assertNotIn('Traceback', stderr.getvalue())

    def test_cli_commands(self):
        with contextlib.redirect_stdout(io.StringIO()):
            output = self.root / 'out'
            self.assertEqual(site.main(['generate', '--content', str(self.content), '--output', str(output)]), 0)
            self.assertEqual(site.main(['validate', '--source', str(output)]), 0)
            self.assertEqual(site.main(['copy', '--source', str(output), '--output', str(self.root / 'copied')]), 0)


if __name__ == '__main__':
    unittest.main()
