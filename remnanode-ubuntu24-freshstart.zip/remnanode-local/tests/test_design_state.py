"""Private design-state contracts; Windows-safe, no services or network.

Run: python -B -m unittest discover -s tests -p test_design_state.py -v
POSIX permissions and secure_path refusal are simulated, not integration-tested.
"""
from contextlib import ExitStack
import importlib.util
import io
import json
import os
from pathlib import Path
import socket
import stat
import subprocess
import sys
import tempfile
from types import SimpleNamespace
import unittest
from unittest.mock import Mock, patch
import uuid


PROJECT = Path(__file__).resolve().parents[1]


def load_module(name, filename):
    spec = importlib.util.spec_from_file_location(name, PROJECT / filename)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


m = load_module("design_state_test_manage", "manage.py")
with patch.dict(sys.modules, {"manage": m}):
    state = load_module("design_state_under_test", "design_state.py")


class RegistryError(Exception):
    pass


class DesignStateTests(unittest.TestCase):
    def setUp(self):
        self.stack = ExitStack()
        self.addCleanup(self.stack.close)
        self.root = Path(self.stack.enter_context(tempfile.TemporaryDirectory(prefix="test-design-state-")))
        self.private = self.root / "private"
        self.pending = self.private / "request.json"
        self.manifest = self.private / "site-manifest.json"
        self.settings = SimpleNamespace(source=None, domain="node.example.com", theme="plants", title="Тест")
        self.stdout = self.patch(sys, "stdout", new_callable=io.StringIO)
        self.stderr = self.patch(sys, "stderr", new_callable=io.StringIO)
        for target, name in ((subprocess, "run"), (subprocess, "Popen"), (os, "system"),
                             (socket, "socket"), (socket, "getaddrinfo"), (socket, "create_connection")):
            self.patch(target, name, side_effect=AssertionError("External command/network forbidden"))
        self.patch(state, "STATE", new=self.private)
        self.rejected = set()
        self.permissions = {}
        self.secure = self.patch(m, "secure_path", side_effect=self.safe_path)
        self.prompt = self.patch(__import__("builtins"), "input", return_value="https://registry.example")
        self.token = "TEST_REGISTRY_TOKEN_NEVER_SAVE"
        self.password = self.patch(state.getpass, "getpass", return_value=self.token)
        self.validate = Mock(side_effect=lambda url: url)
        self.reserve = Mock(side_effect=lambda url, token, request_id: self.valid_manifest(request_id))
        self.stack.enter_context(patch.dict(sys.modules, {"registry_client": SimpleNamespace(
            validate_registry_url=self.validate, reserve_remote=self.reserve, RegistryError=RegistryError)}))
        original_stat, original_open, original_mkdir = Path.stat, Path.open, Path.mkdir

        def portable_stat(path, *args, **kwargs):
            info = original_stat(path, *args, **kwargs)
            if Path(path).is_relative_to(self.root):
                mode = self.permissions.get(Path(path), 0o700 if stat.S_ISDIR(info.st_mode) else 0o600)
                return os.stat_result((stat.S_IFMT(info.st_mode) | mode, *tuple(info)[1:]))
            return info

        def safe_open(path, mode="r", *args, **kwargs):
            if any(flag in mode for flag in "wax+"):
                self.assert_test_path(path)
            return original_open(path, mode, *args, **kwargs)

        def safe_mkdir(path, *args, **kwargs):
            self.assert_test_path(path)
            return original_mkdir(path, *args, **kwargs)

        self.mkdir_modes = []
        original_safe_mkdir = safe_mkdir

        def record_mkdir(path, *args, **kwargs):
            self.mkdir_modes.append((Path(path), kwargs.get("mode", args[0] if args else 0o777)))
            return original_safe_mkdir(path, *args, **kwargs)

        original_chmod = os.chmod

        def safe_chmod(path, mode, *args, **kwargs):
            self.assert_test_path(path)
            return original_chmod(path, mode, *args, **kwargs)

        self.chmod = self.patch(os, "chmod", side_effect=safe_chmod)
        self.patch(Path, "stat", new=portable_stat)
        self.patch(Path, "open", new=safe_open)
        self.patch(Path, "mkdir", new=record_mkdir)

    def patch(self, target, name, **kwargs):
        return self.stack.enter_context(patch.object(target, name, **kwargs))

    def assert_test_path(self, path):
        path = Path(path).absolute()
        if not path.is_relative_to(self.root):
            raise AssertionError("Non-test path forbidden: " + str(path))
        return path

    def safe_path(self, path, **kwargs):
        path = self.assert_test_path(path)
        if path in self.rejected:
            raise m.Failure("Simulated secure_path refusal: symlink/untrusted path")
        return path

    def valid_manifest(self, request_id):
        return {"schema": 1, "version": "studio-v1", "request_id": request_id,
                "reservation_id": "00000000-0000-4000-8000-000000000002", "seed": "a" * 64,
                "composition": {"version": "studio-v1", "direction": "editorial",
                                "hero": "feature", "listing": "cards", "article": "column"}}

    def read(self, path):
        return json.loads(path.read_text(encoding="utf-8"))

    def pending_request(self, mode="registry", **changes):
        self.private.mkdir(exist_ok=True)
        request = {"identity": state.fingerprint(self.settings),
                   "request_id": "00000000-0000-4000-8000-000000000001",
                   "registry_url": "https://registry.example" if mode == "registry" else None,
                   "mode": mode}
        request.update(changes)
        m.write_json(self.pending, request)
        return request

    def assert_no_secrets(self):
        self.assertNotIn(self.token, self.stdout.getvalue() + self.stderr.getvalue())
        for path in self.root.rglob("*"):
            if path.is_file():
                self.assertNotIn(self.token, path.read_text(encoding="utf-8"))
        self.assertFalse((self.root / "public").exists())

    def test_new_registry_request_is_persisted_before_reservation_and_manifest_private(self):
        def reserve(url, token, request_id):
            request = self.read(self.pending)
            self.assertEqual(request["request_id"], request_id)
            self.assertFalse(self.manifest.exists())
            self.assertEqual((url, token), ("https://registry.example", self.token))
            return self.valid_manifest(request_id)
        self.reserve.side_effect = reserve
        self.assertEqual(state.prepare_design(self.settings), self.manifest)
        request = self.read(self.pending)
        self.assertEqual(set(request), {"identity", "request_id", "registry_url", "mode"})
        self.assertEqual(request["mode"], "registry")
        self.assertEqual(str(uuid.UUID(request["request_id"])), request["request_id"])
        self.assertEqual(self.read(self.manifest), self.valid_manifest(request["request_id"]))
        self.secure.assert_any_call(self.private, directory=True)
        self.secure.assert_any_call(self.pending, directory=False)
        self.secure.assert_any_call(self.manifest, directory=False)
        self.assertIn((self.private, 0o700), self.mkdir_modes)
        self.assertEqual(len(self.chmod.call_args_list), 2)
        self.assertTrue(all(entry.args[1] == 0o600 for entry in self.chmod.call_args_list))
        self.assert_no_secrets()

    def test_explicit_offline_creates_valid_manifest_and_warns_without_registry_or_token(self):
        self.prompt.return_value = "АВТОНОМНО"
        self.assertEqual(state.prepare_design(self.settings), self.manifest)
        request = self.read(self.pending)
        self.assertEqual((request["mode"], request["registry_url"]), ("offline", None))
        manifest = state.validate_manifest(self.read(self.manifest))
        self.assertEqual(manifest["request_id"], request["request_id"])
        self.validate.assert_not_called()
        self.reserve.assert_not_called()
        self.password.assert_not_called()
        self.assertIn("НЕ", self.stdout.getvalue())
        self.assert_no_secrets()

    def test_network_failure_keeps_pending_uuid_and_retry_does_not_prompt_mode_again(self):
        self.reserve.side_effect = RegistryError("network unavailable")
        with self.assertRaises(m.Failure):
            state.prepare_design(self.settings)
        original = self.pending.read_bytes()
        request = self.read(self.pending)
        self.assertFalse(self.manifest.exists())
        self.reserve.side_effect = lambda url, token, request_id: self.valid_manifest(request_id)
        self.assertEqual(state.prepare_design(self.settings), self.manifest)
        self.assertEqual(self.pending.read_bytes(), original)
        self.assertEqual([entry.args[2] for entry in self.reserve.call_args_list],
                         [request["request_id"], request["request_id"]])
        self.prompt.assert_called_once()
        self.assert_no_secrets()

    def test_saved_manifest_reused_unchanged_without_prompt_token_or_reservation(self):
        request = self.pending_request()
        m.write_json(self.manifest, self.valid_manifest(request["request_id"]))
        before = (self.pending.read_bytes(), self.manifest.read_bytes())
        self.assertEqual(state.prepare_design(self.settings), self.manifest)
        self.assertEqual((self.pending.read_bytes(), self.manifest.read_bytes()), before)
        for mock in (self.prompt, self.password, self.reserve):
            mock.assert_not_called()

    def test_saved_offline_manifest_reuses_seed_and_composition_without_random_redraw(self):
        self.prompt.return_value = "АВТОНОМНО"
        state.prepare_design(self.settings)
        before = self.manifest.read_bytes()
        self.prompt.reset_mock()
        with patch.object(state.secrets, "choice", side_effect=AssertionError("Unexpected redraw")), \
                patch.object(state.secrets, "token_hex", side_effect=AssertionError("Unexpected seed")):
            self.assertEqual(state.prepare_design(self.settings), self.manifest)
        self.assertEqual(self.manifest.read_bytes(), before)
        for mock in (self.prompt, self.password, self.reserve):
            mock.assert_not_called()

    def test_offline_request_with_registry_url_is_corrupt_not_a_mode_change(self):
        self.pending_request(mode="offline", registry_url="https://registry.example")
        before = self.pending.read_bytes()
        with self.assertRaises(m.Failure):
            state.prepare_design(self.settings)
        self.assertEqual(self.pending.read_bytes(), before)
        self.assertFalse(self.manifest.exists())
        for mock in (self.prompt, self.password, self.reserve):
            mock.assert_not_called()

    def test_blank_invalid_or_implicit_offline_mode_never_silently_falls_back(self):
        for value in ("", "offline", "автономно", "http://registry.example"):
            with self.subTest(value=value):
                self.prompt.return_value = value
                self.validate.side_effect = ValueError("invalid URL")
                with self.assertRaises(m.Failure):
                    state.prepare_design(self.settings)
                self.assertFalse(self.pending.exists())
                self.assertFalse(self.manifest.exists())
        self.reserve.assert_not_called()
        self.password.assert_not_called()

    def test_changed_domain_theme_or_title_refuses_existing_identity_without_overwrite(self):
        self.pending_request()
        before = self.pending.read_bytes()
        for name, value in (("domain", "other.example"), ("theme", "coffee"), ("title", "Other")):
            with self.subTest(field=name):
                original = getattr(self.settings, name)
                setattr(self.settings, name, value)
                with self.assertRaises(m.Failure):
                    state.prepare_design(self.settings)
                setattr(self.settings, name, original)
                self.assertEqual(self.pending.read_bytes(), before)
        self.reserve.assert_not_called()
        self.prompt.assert_not_called()

    def test_corrupt_request_json_schema_uuid_and_mode_refused_untouched(self):
        request = self.pending_request()
        payloads = ["{bad", "null", "[]", "{}", "x" * 32769]
        for changes in ({"request_id": "not-a-uuid"}, {"request_id": None},
                        {"mode": "automatic"}, {"token": self.token}):
            payloads.append(json.dumps(dict(request, **changes)))
        for payload in payloads:
            with self.subTest(payload=payload[:80]):
                self.pending.write_text(payload, encoding="utf-8")
                with self.assertRaises(m.Failure):
                    state.prepare_design(self.settings)
                self.assertEqual(self.pending.read_text(encoding="utf-8"), payload)
                self.assertFalse(self.manifest.exists())
        self.reserve.assert_not_called()
        self.prompt.assert_not_called()

    def test_corrupt_or_mismatched_saved_manifest_never_rereserved(self):
        request = self.pending_request()
        payloads = ["not json", "null", "{}", "x" * 32769,
                    json.dumps(self.valid_manifest(str(uuid.uuid4())))]
        bad_seed = self.valid_manifest(request["request_id"])
        bad_seed["seed"] = "bad"
        payloads.append(json.dumps(bad_seed))
        for payload in payloads:
            with self.subTest(payload=payload[:80]):
                self.manifest.write_text(payload, encoding="utf-8")
                with self.assertRaises(m.Failure):
                    state.prepare_design(self.settings)
                self.assertEqual(self.manifest.read_text(encoding="utf-8"), payload)
        self.reserve.assert_not_called()
        self.password.assert_not_called()

    def test_unclosed_directory_request_and_manifest_permissions_are_refused(self):
        request = self.pending_request()
        m.write_json(self.manifest, self.valid_manifest(request["request_id"]))
        for path, mode in ((self.private, 0o755), (self.pending, 0o644), (self.manifest, 0o640)):
            with self.subTest(path=path):
                self.permissions[path] = mode
                with self.assertRaises(m.Failure):
                    state.prepare_design(self.settings)
                self.permissions.clear()
        self.reserve.assert_not_called()
        self.password.assert_not_called()

    def test_secure_path_symlink_refusal_propagates_before_read_or_reserve(self):
        for path in (self.private, self.pending, self.manifest):
            with self.subTest(path=path):
                self.rejected.add(path)
                with self.assertRaisesRegex(m.Failure, "secure_path refusal"):
                    state.prepare_design(self.settings)
                self.rejected.clear()
        self.reserve.assert_not_called()
        self.prompt.assert_not_called()
        self.password.assert_not_called()

    def test_registry_failure_does_not_persist_manifest_or_token_or_choose_offline(self):
        self.reserve.side_effect = RegistryError("reservation denied")
        with self.assertRaises(m.Failure):
            state.prepare_design(self.settings)
        self.assertEqual(self.read(self.pending)["mode"], "registry")
        self.assertFalse(self.manifest.exists())
        self.assert_no_secrets()

    def test_mismatched_registry_reply_stops_without_manifest(self):
        self.reserve.side_effect = lambda *args: self.valid_manifest(str(uuid.uuid4()))
        with self.assertRaises(m.Failure):
            state.prepare_design(self.settings)
        self.assertTrue(self.pending.exists())
        self.assertFalse(self.manifest.exists())

    def test_malformed_registry_reply_is_controlled_failure_not_traceback(self):
        for payload in (None, {}, {"composition": None}):
            with self.subTest(payload=payload):
                self.reserve.side_effect = None
                self.reserve.return_value = payload
                with self.assertRaises(m.Failure):
                    state.prepare_design(self.settings)
                self.assertFalse(self.manifest.exists())

    def test_invalid_remote_composition_is_not_printed_before_validation(self):
        def invalid_reply(url, token, request_id):
            manifest = self.valid_manifest(request_id)
            manifest["composition"]["direction"] = token
            return manifest
        self.reserve.side_effect = invalid_reply
        with self.assertRaises(m.Failure):
            state.prepare_design(self.settings)
        self.assertFalse(self.manifest.exists())
        self.assert_no_secrets()

    def test_saved_registry_mode_requires_valid_url_before_token_or_network(self):
        for value in (None, "", "http://registry.example"):
            with self.subTest(url=value):
                self.manifest.unlink(missing_ok=True)
                self.password.reset_mock()
                self.reserve.reset_mock()
                self.pending_request(registry_url=value)
                self.validate.side_effect = ValueError("invalid persisted registry URL")
                with self.assertRaises(m.Failure):
                    state.prepare_design(self.settings)
                self.assertFalse(self.manifest.exists())
                self.password.assert_not_called()
                self.reserve.assert_not_called()

    def test_own_source_skips_all_private_state_prompts_and_network(self):
        self.settings.source = str(self.root / "own-site")
        self.assertIsNone(state.prepare_design(self.settings))
        self.assertEqual(list(self.root.iterdir()), [])
        for mock in (self.secure, self.prompt, self.password, self.validate, self.reserve):
            mock.assert_not_called()


if __name__ == "__main__":
    unittest.main()
