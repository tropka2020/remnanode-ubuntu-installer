"""Portable tests: no Linux requirements, network, Docker, UFW or system writes.

Run from any directory with:
    python -m unittest discover -s "Z:/zcode/vpn node install/tests" -p test_manage.py -v
"""
import argparse
from contextlib import ExitStack
import importlib.util
import io
import json
from pathlib import Path
import stat
import subprocess
import tempfile
from types import SimpleNamespace
import unittest
from unittest.mock import MagicMock, Mock, call, patch


PROJECT = Path(__file__).resolve().parents[1]
SPEC = importlib.util.spec_from_file_location("manage_under_test", PROJECT / "manage.py")
manage = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(manage)
IMAGE = "example/remnanode@sha256:" + "a" * 64
NODE_IMAGE = "remnawave/node:latest"


class IsolatedTestCase(unittest.TestCase):
    def setUp(self):
        self.stack = ExitStack()
        self.addCleanup(self.stack.close)
        # A missed mock must fail the test, never invoke an external command.
        self.stack.enter_context(patch.object(
            subprocess, "run", side_effect=AssertionError("External commands are forbidden")))
        for name in ("socket", "create_connection", "getaddrinfo"):
            self.stack.enter_context(patch.object(
                manage.socket, name, side_effect=AssertionError("Network access is forbidden")))
        self.temp = self.stack.enter_context(tempfile.TemporaryDirectory(prefix="test-manage-"))
        self.root = Path(self.temp)

    def mock(self, name, **kwargs):
        return self.stack.enter_context(patch.object(manage, name, **kwargs))


class ValidationTests(unittest.TestCase):
    def test_ip_accepts_unicast_panel_addresses(self):
        for value in ("1.0.0.1", "10.0.0.1", "192.0.2.1", "223.255.255.254"):
            with self.subTest(value=value):
                self.assertEqual(manage.check_ip(value), value)

    def test_ip_rejects_noncanonical_or_invalid_input(self):
        for value in ("", "1.2.3", "256.0.0.1", "01.2.3.4", "::1", "1.2.3.4/32",
                      " 1.2.3.4", "1.2.3.4:80", "localhost", "0.0.0.0", "127.0.0.1",
                      "127.255.255.255", "224.0.0.1", "239.255.255.255", "255.255.255.255"):
            with self.subTest(value=value), self.assertRaises(argparse.ArgumentTypeError):
                manage.check_ip(value)

    def test_domain_normalizes_case_and_accepts_boundaries(self):
        longest = ".".join(("a" * 63, "b" * 63, "c" * 63, "d" * 61))
        self.assertEqual(len(longest), 253)
        for value in ("Example.COM", "a-b.example", "a.example", longest):
            with self.subTest(value=value):
                self.assertEqual(manage.check_domain(value), value.lower())

    def test_domain_rejects_invalid_names(self):
        for value in ("", "localhost", "https://example.com", "example.com:443",
                      "example.com/path", "example.com.", "-a.example", "a-.example",
                      "a_b.example", "a..example", "example.c", "127.0.0.1",
                      "a" * 64 + ".com", "a." + "b" * 64,
                      ".".join(("a" * 63,) * 4)):
            with self.subTest(value=value), self.assertRaises(argparse.ArgumentTypeError):
                manage.check_domain(value)

    def test_image_accepts_pinned_digest(self):
        for value in (IMAGE, "registry.example:5000/team/node:v1@sha256:" + "0" * 64):
            with self.subTest(value=value):
                self.assertEqual(manage.check_image(value), value)

    def test_image_rejects_unpinned_and_invalid_digest(self):
        for value in ("", "node:latest", "node@sha256:" + "a" * 63,
                      "node@sha256:" + "a" * 65, "node@sha256:" + "A" * 64,
                      "node@sha256:" + "g" * 64, " " + IMAGE, IMAGE + "\n"):
            with self.subTest(value=value), self.assertRaises(argparse.ArgumentTypeError):
                manage.check_image(value)


class NodeComposeTests(IsolatedTestCase):
    def test_exact_official_yaml_contract(self):
        self.assertEqual(manage.node_compose('secret'), '''services:
  remnanode:
    image: "remnawave/node:latest"
    container_name: remnanode
    hostname: remnanode
    network_mode: host
    restart: always
    cap_add:
      - NET_ADMIN
    ulimits:
      nofile:
        soft: 1048576
        hard: 1048576
    environment:
      - "NODE_PORT=2222"
      - "SECRET_KEY=secret"
    volumes:
      - /var/log/remnanode:/var/log/remnanode
''')

    def test_secret_scalars_roundtrip_without_yaml_injection_or_compose_interpolation(self):
        # Decode only the JSON-quoted scalar, not a home-grown YAML parser.
        for secret in ('a$HOME${TOKEN}$$end', 'a\\"#:[{}],!&*|>\\\\b',
                       'value=other', 'secret\nservices:\n  injected: yes',
                       'ключ😀', 'a\u0085b\u009fc\u2028d\u2029e'):
            with self.subTest(secret=repr(secret)):
                text = manage.node_compose(secret)
                scalar = next(line.removeprefix('      - ') for line in text.splitlines()
                              if line.startswith('      - "SECRET_KEY='))
                self.assertEqual(json.loads(scalar).removeprefix('SECRET_KEY=').replace('$$', '$'),
                                 secret)
                self.assertEqual(len(text.splitlines()), 18)
        self.assertNotIn('\u0085', manage.node_compose('a\u0085b'))

    def test_default_latest_and_legacy_digest_cli(self):
        base = ['install-node', '--panel-ip', '192.0.2.1', '--secret-file', 'mock-secret']
        self.assertEqual(manage.parser().parse_args(base).image, NODE_IMAGE)
        for image in (NODE_IMAGE, IMAGE):
            self.assertEqual(manage.parser().parse_args(base + ['--image', image]).image, image)
            self.assertIn('    image: ' + json.dumps(image), manage.node_compose('secret', image))

    def test_image_input_rejects_other_tags_and_injection(self):
        for image in ('node:latest', 'remnawave/node:other', '--privileged',
                      'remnawave/node:latest;id', NODE_IMAGE + '\n', IMAGE + '&&id'):
            with self.subTest(image=image), self.assertRaises(argparse.ArgumentTypeError):
                manage.check_node_image(image)
            with self.subTest(image=image), self.assertRaises(argparse.ArgumentTypeError):
                manage.node_compose('secret', image)


class InspectTests(IsolatedTestCase):
    def setUp(self):
        super().setUp()
        self.run = self.mock("run")
        self.name = "remnanode"
        self.lookup = ["docker", "container", "ls", "--all", "--filter",
                       "name=^/remnanode$", "--format", "{{.Names}}"]

    def test_inspect_success_returns_container_without_fallback(self):
        obj = {"Name": "/remnanode", "State": {"Status": "running"}}
        self.run.return_value = SimpleNamespace(returncode=0, stdout=json.dumps([obj]))
        self.assertEqual(manage.inspect(self.name), obj)
        self.run.assert_called_once_with(["docker", "container", "inspect", self.name], check=False)

    def test_inspect_absent_requires_successful_exact_name_lookup(self):
        for names in ("", "remnanode-other\n", "other-remnanode\n"):
            with self.subTest(names=names):
                self.run.reset_mock()
                self.run.side_effect = [SimpleNamespace(returncode=1), names]
                self.assertIsNone(manage.inspect(self.name))
                self.assertEqual(self.run.call_args_list, [
                    call(["docker", "container", "inspect", self.name], check=False),
                    call(self.lookup, capture=True)])

    def test_inspect_error_for_existing_container_is_not_absence(self):
        self.run.side_effect = [SimpleNamespace(returncode=1), "remnanode\n"]
        with self.assertRaises(manage.Failure):
            manage.inspect(self.name)
        self.assertEqual(self.run.call_args_list[-1], call(self.lookup, capture=True))

    def test_inspect_daemon_failure_propagates_instead_of_returning_none(self):
        failure = manage.Failure("daemon unavailable")
        self.run.side_effect = [SimpleNamespace(returncode=1), failure]
        with self.assertRaises(manage.Failure) as caught:
            manage.inspect(self.name)
        self.assertIs(caught.exception, failure)
        self.assertEqual(self.run.call_args_list[-1], call(self.lookup, capture=True))

    def test_inspect_command_unavailable_propagates(self):
        self.run.side_effect = manage.Failure("docker unavailable")
        with self.assertRaisesRegex(manage.Failure, "docker unavailable"):
            manage.inspect(self.name)
        self.assertEqual(self.run.call_count, 1)

    def test_inspect_invalid_json_is_failure(self):
        for text in ("not json", "[]", "null"):
            with self.subTest(text=text):
                self.run.return_value = SimpleNamespace(returncode=0, stdout=text)
                with self.assertRaises(manage.Failure):
                    manage.inspect(self.name)

    def test_inspect_unknown_json_structure_is_failure(self):
        for text in ("{}", "[{}]", "[null]", "[42]"):
            with self.subTest(text=text):
                self.run.return_value = SimpleNamespace(returncode=0, stdout=text)
                with self.assertRaises(manage.Failure):
                    manage.inspect(self.name)


class ConfirmStoppedTests(IsolatedTestCase):
    def setUp(self):
        super().setUp()
        self.inspect = self.mock("inspect")

    def test_absent_or_explicit_stopped_status_is_accepted(self):
        for obj in (None, {"State": {"Status": "exited"}},
                    {"State": {"Status": "created"}}, {"State": {"Status": "dead"}}):
            with self.subTest(obj=obj):
                self.inspect.reset_mock()
                self.inspect.return_value = obj
                manage.confirm_stopped("caddy-selfsteal")
                self.inspect.assert_called_once_with("caddy-selfsteal")

    def test_running_and_unknown_status_are_rejected(self):
        for state in ({"Status": "running"}, {"Status": "paused"}, {"Status": "restarting"},
                      {"Status": "removing"}, {"Status": "unknown"}, {"Running": False},
                      {"Status": None}, {}):
            with self.subTest(state=state):
                self.inspect.return_value = {"State": state}
                with self.assertRaises(manage.Failure):
                    manage.confirm_stopped("caddy-selfsteal")

    def test_empty_inspection_is_not_confirmed_absence(self):
        self.inspect.return_value = {}
        with self.assertRaises(manage.Failure):
            manage.confirm_stopped("caddy-selfsteal")

    def test_daemon_failure_propagates(self):
        failure = manage.Failure("daemon unavailable")
        self.inspect.side_effect = failure
        with self.assertRaises(manage.Failure) as caught:
            manage.confirm_stopped("remnanode")
        self.assertIs(caught.exception, failure)


class FirewallTests(IsolatedTestCase):
    PANEL = "192.0.2.1"
    ALLOW = "2222/tcp ALLOW IN 192.0.2.1"
    DENY = "2222/tcp DENY IN Anywhere"
    DENY6 = "2222/tcp (v6) DENY IN Anywhere (v6)"

    @staticmethod
    def status(*rows):
        return "Status: active\n\nTo Action From\n-- ------ ----\n" + "\n".join(
            "[ %d] %s" % (index, row) for index, row in enumerate(rows, 1))

    def bad_statuses(self):
        return [
            "", "Status: active\n",
            self.status(self.DENY, self.ALLOW, self.DENY6),
            self.status("2222/tcp ALLOW IN Anywhere", self.ALLOW, self.DENY, self.DENY6),
            self.status("22/tcp ALLOW IN Anywhere", self.ALLOW, self.DENY, self.DENY6),
            self.status(self.ALLOW, self.ALLOW, self.DENY, self.DENY6),
            self.status(self.ALLOW, "2222/tcp ALLOW IN Anywhere", self.DENY, self.DENY6),
            self.status(self.ALLOW, self.DENY),
            self.status(self.ALLOW, self.DENY, "2222/tcp (v6) ALLOW IN Anywhere (v6)", self.DENY6),
            self.status("2222/tcp ALLOW IN 192.0.2.2", self.DENY, self.DENY6),
        ]

    def test_firewall_order_accepts_verified_prefixes_and_comments(self):
        status = self.status(self.ALLOW + " # remnanode-local-panel", self.DENY,
                             "22/tcp ALLOW IN Anywhere", self.DENY6,
                             "22/tcp (v6) ALLOW IN Anywhere (v6)")
        manage.verify_firewall_order(status, self.PANEL)
        manage.verify_firewall_order(status.replace(" ALLOW IN ", "   ALLOW    IN    "), self.PANEL)

    def test_firewall_order_rejects_missing_duplicate_and_wrong_order_rules(self):
        for status in self.bad_statuses():
            with self.subTest(status=status), self.assertRaises(manage.Failure):
                manage.verify_firewall_order(status, self.PANEL)

    def configure_fixture(self, status):
        folder = self.root / "backup"
        folder.mkdir(exist_ok=True)
        self.stack.enter_context(patch.object(manage.shutil, "which", return_value="mock-ufw"))
        secure = self.mock("secure_path")
        secure.return_value.read_text.return_value = "IPV6=yes\n"
        copies = self.stack.enter_context(patch.object(manage.shutil, "copy2"))
        self.mock("backup_dir", return_value=folder)
        restore = self.mock("restore_firewall")
        run = self.mock("run", side_effect=["Status: active\n", None, None, None, status])
        return folder, run, restore, copies

    def test_configure_firewall_verifies_after_reload_and_keeps_backup(self):
        folder, run, restore, copies = self.configure_fixture(
            self.status(self.ALLOW, self.DENY, self.DENY6))
        self.assertEqual(manage.configure_firewall(self.PANEL), folder)
        restore.assert_not_called()
        self.assertEqual(copies.call_count, 2)
        self.assertEqual([entry.args[0] for entry in run.call_args_list], [
            ["ufw", "status"],
            ["ufw", "insert", "1", "deny", "in", "to", "any", "port", "2222", "proto", "tcp",
             "comment", "remnanode-local-deny"],
            ["ufw", "insert", "1", "allow", "in", "from", self.PANEL, "to", "any", "port", "2222",
             "proto", "tcp", "comment", "remnanode-local-panel"],
            ["ufw", "reload"], ["ufw", "status", "numbered"]])
        self.assertTrue(run.call_args.kwargs["capture"])
        self.assertEqual(run.call_args.kwargs["env"]["LC_ALL"], "C")

    def test_configure_firewall_restores_backup_on_duplicate_wrong_order(self):
        folder, run, restore, copies = self.configure_fixture("")
        for status in self.bad_statuses():
            with self.subTest(status=status):
                restore.reset_mock()
                run.side_effect = ["Status: active\n", None, None, None, status]
                with self.assertRaises(manage.Failure):
                    manage.configure_firewall(self.PANEL)
                restore.assert_called_once_with(folder)

    def test_configure_firewall_restores_if_numbered_status_fails(self):
        folder, run, restore, copies = self.configure_fixture("")
        run.side_effect = ["Status: active\n", None, None, None, manage.Failure("status failed")]
        with self.assertRaisesRegex(manage.Failure, "status failed"):
            manage.configure_firewall(self.PANEL)
        restore.assert_called_once_with(folder)


class SecretTests(IsolatedTestCase):
    def secret_path(self, value="secret", mode=0o600, size=None, is_file=True):
        # Windows ACLs/chmod do not represent Linux permission bits reliably.
        path = MagicMock(spec=Path)
        path.is_file.return_value = is_file
        path.stat.return_value = SimpleNamespace(
            st_mode=stat.S_IFREG | mode,
            st_size=len(value.encode("utf-8")) if size is None else size)
        path.read_text.return_value = value
        secure = self.mock("secure_path", return_value=path)
        return path, secure

    def test_secret_accepts_private_modes_and_trailing_newline(self):
        for mode in (0o400, 0o600):
            with self.subTest(mode=mode):
                with patch.object(manage, "secure_path") as secure:
                    path = MagicMock(spec=Path)
                    path.is_file.return_value = True
                    path.stat.return_value = SimpleNamespace(st_mode=stat.S_IFREG | mode, st_size=14)
                    path.read_text.return_value = "s$e'c\\ret\"\n"
                    secure.return_value = path
                    self.assertEqual(manage.read_secret("secret-file"), "s$e'c\\ret\"")
                    secure.assert_called_once_with("secret-file", directory=False)
                    path.read_text.assert_called_once_with(encoding="utf-8")

    def test_secret_rejects_public_permissions_before_read(self):
        for mode in (0o604, 0o640, 0o666):
            with self.subTest(mode=mode), patch.object(manage, "secure_path") as secure:
                path = MagicMock(spec=Path)
                path.is_file.return_value = True
                path.stat.return_value = SimpleNamespace(st_mode=stat.S_IFREG | mode)
                secure.return_value = path
                with self.assertRaises(manage.Failure):
                    manage.read_secret("secret-file")
                path.read_text.assert_not_called()

    def test_secret_rejects_missing_file(self):
        path, _ = self.secret_path(is_file=False)
        with self.assertRaises(manage.Failure):
            manage.read_secret("missing")
        path.read_text.assert_not_called()

    def test_secret_size_limit(self):
        path, _ = self.secret_path("x" * 16384)
        self.assertEqual(len(manage.read_secret("secret-file")), 16384)
        path.stat.return_value.st_size = 16385
        path.read_text.reset_mock()
        with self.assertRaises(manage.Failure):
            manage.read_secret("secret-file")
        path.read_text.assert_not_called()

    def test_secret_rejects_empty_whitespace_and_control_characters(self):
        path, _ = self.secret_path()
        for value in ("", "\n", "a b", "a\tb", "a\nb", "a\rb", "a\x00b", "a\x1fb",
                      "a\x7fb", "a\u00a0b"):
            with self.subTest(value=repr(value)):
                path.read_text.return_value = value
                with self.assertRaises(manage.Failure):
                    manage.read_secret("secret-file")

    def test_secure_path_failure_prevents_read(self):
        self.mock("secure_path", side_effect=manage.Failure("unsafe secret"))
        with self.assertRaisesRegex(manage.Failure, "unsafe secret"):
            manage.read_secret(self.root / "secret")


class AtomicWriteTests(IsolatedTestCase):
    def setUp(self):
        super().setUp()
        self.secure = self.mock("secure_path", side_effect=Path)
        self.target = self.root / "config.json"

    def test_create_and_replace_utf8_with_lf_and_no_temporary_files(self):
        for value in ("first\n", "секрет $value\nnext\n"):
            manage.atomic_write(self.target, value)
            self.assertEqual(self.target.read_bytes(), value.encode("utf-8"))
            self.assertEqual(list(self.root.iterdir()), [self.target])
        self.assertEqual(self.secure.call_args_list, [call(self.target), call(self.target)])

    def test_node_compose_write_requests_private_mode_before_atomic_replace(self):
        events = Mock()
        with patch.object(manage.os, 'chmod') as chmod, patch.object(
                manage.os, 'replace', wraps=manage.os.replace) as replace:
            events.attach_mock(chmod, 'chmod')
            events.attach_mock(replace, 'replace')
            manage.atomic_write(self.target, manage.node_compose('secret'))
        self.assertEqual(events.mock_calls[0].args[1], 0o600)
        self.assertEqual(events.mock_calls[0].args[0], events.mock_calls[1].args[0])
        self.assertEqual(events.mock_calls[1].args[1], self.target)

    def test_replace_failure_preserves_old_file_and_removes_temporary_file(self):
        self.target.write_text("old", encoding="utf-8")
        with patch.object(manage.os, "replace", side_effect=OSError("replace failed")):
            with self.assertRaisesRegex(OSError, "replace failed"):
                manage.atomic_write(self.target, "new")
        self.assertEqual(self.target.read_text(encoding="utf-8"), "old")
        self.assertEqual(list(self.root.iterdir()), [self.target])

    def test_fsync_failure_preserves_old_file_and_removes_temporary_file(self):
        self.target.write_text("old", encoding="utf-8")
        with patch.object(manage.os, "fsync", side_effect=OSError("fsync failed")):
            with self.assertRaisesRegex(OSError, "fsync failed"):
                manage.atomic_write(self.target, "new")
        self.assertEqual(self.target.read_text(encoding="utf-8"), "old")
        self.assertEqual(list(self.root.iterdir()), [self.target])

    def test_unsafe_path_creates_nothing(self):
        self.secure.side_effect = manage.Failure("unsafe path")
        with self.assertRaisesRegex(manage.Failure, "unsafe path"):
            manage.atomic_write(self.target, "new")
        self.assertEqual(list(self.root.iterdir()), [])


class DeploymentTests(IsolatedTestCase):
    def setUp(self):
        super().setUp()
        self.node = self.root / "node"
        self.web = self.root / "web"
        self.log = self.root / "log"
        self.mock("NODE", new=self.node)
        self.mock("WEB", new=self.web)
        self.secure = self.mock("secure_path", side_effect=self.safe_path)
        self.run = self.mock("run")
        self.compose = self.mock("compose")
        self.inspect = self.mock("inspect", return_value=None)
        self.read_secret = self.mock("read_secret", return_value="secret")
        self.free = self.mock("assert_free")
        self.configure = self.mock("configure_firewall", return_value=self.root / "ufw-backup")
        self.restore = self.mock("restore_firewall")
        self.wait = self.mock("wait_container")
        self.backup = self.mock("backup_dir", side_effect=self.make_backup)
        self.verify = self.mock("verify_caddy")
        self.https = self.mock("check_https")
        self.wait_https = self.mock("wait_https")
        self.site = self.mock("site_tool", side_effect=self.site_action)
        self.stack.enter_context(patch("sys.stdout", new_callable=io.StringIO))
        self.node_args = SimpleNamespace(panel_ip="192.0.2.1", secret_file="mock-secret", image=IMAGE)
        self.publish_args = SimpleNamespace(domain="example.com", port=443, source="mock-source",
                                            container="caddy-selfsteal")

    def safe_path(self, path, **kwargs):
        if str(path) == "/var/log/remnanode":
            return self.log
        path = Path(path)
        # Never pass an unexpected system path through to real filesystem code.
        if not path.is_relative_to(self.root):
            raise AssertionError("Unexpected non-test path: " + str(path))
        return path

    def make_backup(self, label):
        folder = self.root / "backups" / (label + "-" + str(self.backup.call_count))
        folder.mkdir(parents=True)
        return folder

    def site_action(self, *args):
        if args[0] == "copy":
            destination = Path(args[args.index("--output") + 1])
            destination.mkdir(parents=True)
            (destination / "index.html").write_text("new page\n", encoding="utf-8")

    def existing_site(self):
        (self.web / "html").mkdir(parents=True)
        (self.web / "html/index.html").write_text("old page\n", encoding="utf-8")
        (self.web / "html/old.css").write_text("old css", encoding="utf-8")
        for name in ("Caddyfile", "docker-compose.yml", ".env"):
            (self.web / name).write_text("original " + name, encoding="utf-8")

    def assert_old_site_restored(self):
        self.assertEqual((self.web / "html/index.html").read_text(encoding="utf-8"), "old page\n")
        self.assertTrue((self.web / "html/old.css").is_file())
        self.assertFalse(list(self.web.glob(".publish-*")))
        self.assertFalse(list(self.web.glob(".previous-*")))
        for name in ("Caddyfile", "docker-compose.yml", ".env"):
            self.assertEqual((self.web / name).read_text(encoding="utf-8"), "original " + name)

    def test_node_secret_escaping_in_actual_yaml_compose_file(self):
        secret = "abc$HOME${TOKEN}$$end'\\\""
        self.read_secret.return_value = secret
        self.node_args.image = NODE_IMAGE
        manage.install_node(self.node_args)
        text = (self.node / "docker-compose.yml").read_text(encoding="utf-8")
        self.assertIn('image: "remnawave/node:latest"', text)
        self.assertIn('      - "NODE_PORT=2222"', text)
        self.assertIn('      - "SECRET_KEY=abc$$HOME$${TOKEN}$$$$end\'\\\\\\\""', text)
        self.assertIn("restart: always", text)
        self.assertIn("      - NET_ADMIN", text)
        self.assertIn("soft: 1048576", text)
        self.assertIn("      - /var/log/remnanode:/var/log/remnanode", text)
        self.assertNotIn("logging:", text)
        self.assertTrue((self.node / "managed.json").is_file())

        self.compose.assert_has_calls([
            call(self.node, "config", "--quiet"),
            call(self.node, "up", "-d", "--no-build", "--pull", "never")])
        self.wait.assert_called_once_with("remnanode", 2222)
        self.restore.assert_not_called()

    def test_existing_node_directory_is_refused_without_side_effects(self):
        self.node.mkdir()
        marker = self.node / "keep"
        marker.write_text("untouched", encoding="utf-8")
        with self.assertRaises(manage.Failure):
            manage.install_node(self.node_args)
        self.assertEqual(marker.read_text(encoding="utf-8"), "untouched")
        self.inspect.assert_not_called()
        self.read_secret.assert_not_called()
        self.run.assert_not_called()
        self.configure.assert_not_called()

    def test_existing_node_container_is_refused(self):
        self.inspect.return_value = {"State": {"Running": True}}
        with self.assertRaises(manage.Failure):
            manage.install_node(self.node_args)
        self.assertFalse(self.node.exists())
        self.read_secret.assert_not_called()
        self.run.assert_not_called()

    def test_existing_web_directory_or_container_is_refused(self):
        args = SimpleNamespace(domain="example.com", source="mock-source", image=IMAGE)
        for directory in (True, False):
            with self.subTest(directory=directory):
                if directory:
                    self.web.mkdir()
                else:
                    self.web.rmdir()
                    self.inspect.return_value = {"State": {"Running": True}}
                with self.assertRaises(manage.Failure):
                    manage.install_web(args)
        self.site.assert_not_called()
        self.run.assert_not_called()

    def test_node_pull_failure_does_not_change_firewall_or_create_node(self):
        self.run.side_effect = manage.Failure("pull failed")
        with self.assertRaisesRegex(manage.Failure, "pull failed"):
            manage.install_node(self.node_args)
        self.configure.assert_not_called()
        self.restore.assert_not_called()
        self.assertFalse(self.node.exists())

    def test_node_compose_failure_restores_firewall_and_archives_failed_install(self):
        self.compose.side_effect = manage.Failure("config failed")
        with self.assertRaisesRegex(manage.Failure, "config failed"):
            manage.install_node(self.node_args)
        self.restore.assert_called_once_with(self.root / "ufw-backup")
        self.assertFalse(self.node.exists())
        failed = list((self.root / "backups").glob("failed-node-*/remnanode"))
        self.assertEqual(len(failed), 1)
        self.assertTrue((failed[0] / "docker-compose.yml").is_file())
        self.wait.assert_not_called()

    def test_node_start_failure_stops_partial_container_and_rolls_back(self):
        self.inspect.side_effect = [None, {"State": {"Running": False}},
                                    {"State": {"Status": "exited", "Running": False}}]

        def fail_up(directory, *args):
            if args[0] == "up":
                raise manage.Failure("docker up failed")

        self.compose.side_effect = fail_up
        with self.assertRaisesRegex(manage.Failure, "docker up failed"):
            manage.install_node(self.node_args)
        self.compose.assert_has_calls([
            call(self.node, "config", "--quiet"),
            call(self.node, "up", "-d", "--no-build", "--pull", "never"),
            call(self.node, "down")])
        self.restore.assert_called_once_with(self.root / "ufw-backup")
        self.assertFalse(self.node.exists())

    def test_node_health_failure_rolls_back(self):
        self.inspect.side_effect = [None, {"State": {"Running": True}}, None]
        self.wait.side_effect = manage.Failure("health failed")
        with self.assertRaisesRegex(manage.Failure, "health failed"):
            manage.install_node(self.node_args)
        self.compose.assert_any_call(self.node, "down")
        self.restore.assert_called_once_with(self.root / "ufw-backup")
        self.assertFalse(self.node.exists())
        self.assertEqual(len(list((self.root / "backups").glob("failed-node-*/remnanode"))), 1)

    def test_node_rollback_down_failure_keeps_restrictive_firewall(self):
        self.inspect.side_effect = [None, {"State": {"Running": True}}, None]
        self.wait.side_effect = manage.Failure("health failed")

        def fail_down(directory, *args):
            if args[0] == "down":
                raise manage.Failure("docker down failed")

        self.compose.side_effect = fail_down
        with self.assertRaises(manage.Failure):
            manage.install_node(self.node_args)
        # The container may still run: keep restrictive rules rather than expose its API.
        self.restore.assert_not_called()
        self.assertTrue((self.node / "docker-compose.yml").is_file())
        self.backup.assert_not_called()

    def test_node_interrupt_rolls_back_before_propagating(self):
        self.inspect.side_effect = [None, {"State": {"Running": True}}, None]
        interrupted = KeyboardInterrupt()
        self.wait.side_effect = interrupted
        with self.assertRaises(KeyboardInterrupt) as caught:
            manage.install_node(self.node_args)
        self.assertIs(caught.exception, interrupted)
        self.compose.assert_any_call(self.node, "down")
        self.restore.assert_called_once_with(self.root / "ufw-backup")
        self.assertFalse(self.node.exists())
        self.assertEqual(len(list((self.root / "backups").glob("failed-node-*/remnanode"))), 1)

    def test_publish_interrupt_during_stop_restarts_unchanged_old_site(self):
        self.existing_site()
        interrupted = KeyboardInterrupt()
        self.run.side_effect = [interrupted, None]
        with self.assertRaises(KeyboardInterrupt) as caught:
            manage.publish_site(self.publish_args)
        self.assertIs(caught.exception, interrupted)
        self.assert_old_site_restored()
        self.assertEqual(self.run.call_args_list, [
            call(["docker", "stop", "--time", "20", "caddy-selfsteal"], timeout=45),
            call(["docker", "start", "caddy-selfsteal"])])
        self.assertEqual(self.https.call_args_list, [call("example.com", 443), call("example.com", 443)])

    def test_publish_interrupt_after_switch_restores_old_site(self):
        self.existing_site()
        interrupted = KeyboardInterrupt()
        self.wait_https.side_effect = interrupted
        with self.assertRaises(KeyboardInterrupt) as caught:
            manage.publish_site(self.publish_args)
        self.assertIs(caught.exception, interrupted)
        self.assert_old_site_restored()
        self.assertEqual(self.run.call_args_list[-2:], [
            call(["docker", "stop", "--time", "20", "caddy-selfsteal"], check=False, timeout=45),
            call(["docker", "start", "caddy-selfsteal"])])
        self.assertEqual(self.https.call_args_list, [call("example.com", 443), call("example.com", 443)])

    def test_node_daemon_failure_during_rollback_keeps_firewall_and_node(self):
        self.inspect.side_effect = [None, manage.Failure("daemon unavailable")]
        self.wait.side_effect = manage.Failure("health failed")
        with self.assertRaisesRegex(manage.Failure, "daemon unavailable"):
            manage.install_node(self.node_args)
        self.restore.assert_not_called()
        self.backup.assert_not_called()
        self.assertTrue((self.node / "docker-compose.yml").is_file())
        self.assertNotIn(call(self.node, "down"), self.compose.call_args_list)

    def test_node_unconfirmed_shutdown_keeps_firewall_and_node(self):
        for confirmation in ({"State": {"Status": "running"}}, manage.Failure("daemon unavailable")):
            with self.subTest(confirmation=confirmation):
                self.inspect.side_effect = [None, {"State": {"Status": "running"}}, confirmation]
                self.wait.side_effect = manage.Failure("health failed")
                self.compose.reset_mock()
                with self.assertRaises(manage.Failure):
                    manage.install_node(self.node_args)
                self.compose.assert_any_call(self.node, "down")
                self.restore.assert_not_called()
                self.backup.assert_not_called()
                self.assertTrue((self.node / "docker-compose.yml").is_file())
                # Remove only this test's retained node so the next subcase can install.
                manage.shutil.rmtree(self.node)

    def test_publish_first_stop_running_does_not_rename_live_html(self):
        self.existing_site()
        self.inspect.return_value = {"State": {"Status": "running"}}
        with patch.object(Path, "rename", autospec=True) as rename:
            with self.assertRaises(manage.Failure):
                manage.publish_site(self.publish_args)
            rename.assert_not_called()
        self.assert_old_site_restored()
        self.assertEqual(self.run.call_args_list, [
            call(["docker", "stop", "--time", "20", "caddy-selfsteal"], timeout=45),
            call(["docker", "start", "caddy-selfsteal"])])
        self.wait_https.assert_not_called()

    def test_publish_rollback_unconfirmed_stop_preserves_live_and_previous_html(self):
        self.existing_site()
        cases = (
            (manage.Failure("rollback stop failed"), None),
            (SimpleNamespace(returncode=1), {"State": {"Status": "running"}}),
            (None, {"State": {"Status": "running"}}),
            (None, manage.Failure("daemon unavailable")),
        )
        for stop_result, confirmation in cases:
            with self.subTest(stop_result=stop_result, confirmation=confirmation):
                self.run.reset_mock()
                self.run.side_effect = [None, None, stop_result]
                self.inspect.reset_mock()
                self.inspect.side_effect = [{"State": {"Status": "exited"}}, confirmation]
                self.wait_https.side_effect = manage.Failure("new HTTPS failed")
                original_rename = Path.rename
                original_rmtree = manage.shutil.rmtree
                renames = []
                removals = []

                def record_rename(path, target):
                    renames.append((path, Path(target)))
                    return original_rename(path, target)

                def record_removal(path, *args, **kwargs):
                    removals.append(Path(path))
                    return original_rmtree(path, *args, **kwargs)

                with patch.object(Path, "rename", new=record_rename), patch.object(
                        manage.shutil, "rmtree", side_effect=record_removal):
                    with self.assertRaises(manage.Failure):
                        manage.publish_site(self.publish_args)
                previous = list(self.web.glob(".previous-*"))
                self.assertEqual(len(previous), 1)
                self.assertEqual((self.web / "html/index.html").read_text(encoding="utf-8"), "new page\n")
                self.assertEqual((previous[0] / "index.html").read_text(encoding="utf-8"), "old page\n")
                self.assertEqual((previous[0] / "old.css").read_text(encoding="utf-8"), "old css")
                # Only the forward switch is allowed; no rollback rename on a live mount.
                self.assertEqual(len(renames), 2)
                self.assertEqual(renames[0], (self.web / "html", previous[0]))
                self.assertEqual(renames[1][1], self.web / "html")
                self.assertEqual(len(removals), 1)
                self.assertTrue(removals[0].name.startswith(".publish-"))
                self.assertFalse(list(self.web.glob(".publish-*")))
                self.assertEqual(self.run.call_args_list, [
                    call(["docker", "stop", "--time", "20", "caddy-selfsteal"], timeout=45),
                    call(["docker", "start", "caddy-selfsteal"]),
                    call(["docker", "stop", "--time", "20", "caddy-selfsteal"], check=False, timeout=45)])
                expected_inspections = 1 if isinstance(stop_result, Exception) else 2
                self.assertEqual(self.inspect.call_args_list,
                                 [call("caddy-selfsteal")] * expected_inspections)
                # Reset only isolated fixtures, outside the recorded production call.
                original_rmtree(self.web / "html")
                previous[0].rename(self.web / "html")

    def test_publish_success_checks_initial_https_before_mutation(self):
        self.existing_site()
        events = Mock()
        for name, child in (("verify", self.verify), ("https", self.https),
                            ("site", self.site), ("run", self.run), ("wait", self.wait_https)):
            events.attach_mock(child, name)
        manage.publish_site(self.publish_args)
        self.assertEqual(events.mock_calls[:3], [
            call.verify("caddy-selfsteal"), call.https("example.com", 443),
            call.site("validate", "--source", "mock-source")])
        self.run.assert_has_calls([
            call(["docker", "stop", "--time", "20", "caddy-selfsteal"], timeout=45),
            call(["docker", "start", "caddy-selfsteal"])])
        self.wait_https.assert_called_once_with("example.com", 443, "new page\n", timeout=60)
        self.assertEqual((self.web / "html/index.html").read_text(encoding="utf-8"), "new page\n")
        self.assertFalse((self.web / "html/old.css").exists())
        backup = next((self.root / "backups").glob("site-*"))
        self.assertEqual((backup / "html/index.html").read_text(encoding="utf-8"), "old page\n")
        metadata = json.loads((backup / "restore.json").read_text(encoding="utf-8"))
        self.assertEqual(metadata["target"], str(self.web / "html"))
        for name in ("Caddyfile", "docker-compose.yml", ".env"):
            self.assertEqual((backup / name).read_bytes(), (self.web / name).read_bytes())
        self.assertFalse(list(self.web.glob(".publish-*")))
        self.assertFalse(list(self.web.glob(".previous-*")))

    def test_publish_initial_https_failure_does_not_touch_files_or_stop_docker(self):
        self.existing_site()
        self.https.side_effect = manage.Failure("initial HTTPS failed")
        with self.assertRaisesRegex(manage.Failure, "initial HTTPS failed"):
            manage.publish_site(self.publish_args)
        self.assert_old_site_restored()
        self.site.assert_not_called()
        self.backup.assert_not_called()
        self.run.assert_not_called()

    def test_publish_copy_failure_preserves_old_site_and_cleans_stage(self):
        self.existing_site()

        def fail_copy(*args):
            if args[0] == "copy":
                raise manage.Failure("copy failed")

        self.site.side_effect = fail_copy
        with self.assertRaisesRegex(manage.Failure, "copy failed"):
            manage.publish_site(self.publish_args)
        self.assert_old_site_restored()
        self.run.assert_not_called()

    def test_publish_stop_failure_preserves_old_site(self):
        self.existing_site()
        # A stop command can fail after Docker already stopped the container.
        self.run.side_effect = [manage.Failure("stop failed"), None]
        with self.assertRaisesRegex(manage.Failure, "stop failed"):
            manage.publish_site(self.publish_args)
        self.assert_old_site_restored()
        self.assertEqual(self.run.call_args_list, [
            call(["docker", "stop", "--time", "20", "caddy-selfsteal"], timeout=45),
            call(["docker", "start", "caddy-selfsteal"])])
        self.assertEqual(self.https.call_count, 2)

    def test_publish_docker_start_failure_restores_files_and_restarts_old_site(self):
        self.existing_site()
        self.run.side_effect = [None, manage.Failure("start failed"), None, None]
        with self.assertRaisesRegex(manage.Failure, "start failed"):
            manage.publish_site(self.publish_args)
        self.assert_old_site_restored()
        self.assertEqual(self.run.call_args_list, [
            call(["docker", "stop", "--time", "20", "caddy-selfsteal"], timeout=45),
            call(["docker", "start", "caddy-selfsteal"]),
            call(["docker", "stop", "--time", "20", "caddy-selfsteal"], check=False, timeout=45),
            call(["docker", "start", "caddy-selfsteal"])])
        self.assertEqual(self.https.call_args_list, [call("example.com", 443), call("example.com", 443)])
        self.wait_https.assert_not_called()

    def test_publish_new_https_failure_restores_old_site(self):
        self.existing_site()
        self.wait_https.side_effect = manage.Failure("new HTTPS failed")
        with self.assertRaisesRegex(manage.Failure, "new HTTPS failed"):
            manage.publish_site(self.publish_args)
        self.assert_old_site_restored()
        self.assertEqual(self.https.call_count, 2)
        self.assertEqual(self.run.call_args_list[-1], call(["docker", "start", "caddy-selfsteal"]))

    def test_publish_stage_rename_failure_restores_old_site(self):
        self.existing_site()
        original = Path.rename

        def fail_stage(path, destination):
            if path.name == "html" and path.parent.name.startswith(".publish-"):
                raise OSError("stage rename failed")
            return original(path, destination)

        with patch.object(Path, "rename", new=fail_stage):
            with self.assertRaisesRegex(OSError, "stage rename failed"):
                manage.publish_site(self.publish_args)
        self.assert_old_site_restored()
        self.assertEqual(self.run.call_args_list[-1], call(["docker", "start", "caddy-selfsteal"]))

    def test_publish_backup_failure_cleans_staging_directory(self):
        self.existing_site()
        self.backup.side_effect = manage.Failure("backup unavailable")
        with self.assertRaisesRegex(manage.Failure, "backup unavailable"):
            manage.publish_site(self.publish_args)
        self.run.assert_not_called()
        self.assert_old_site_restored()


class HttpsTests(IsolatedTestCase):
    def setUp(self):
        super().setUp()
        self.original_run = manage.run
        self.run = self.mock("run")

    def test_https_requests_root_with_certificate_checks_without_redirect_following(self):
        self.run.return_value = "body\n200"
        manage.check_https("example.com", 8443, "body")
        self.run.assert_called_once_with([
            "curl", "--fail", "--silent", "--show-error", "--noproxy", "*",
            "--connect-timeout", "5", "--max-time", "15", "--resolve",
            "example.com:8443:127.0.0.1", "--write-out", "\n%{http_code}",
            "https://example.com:8443/"], capture=True, timeout=20)
        args = self.run.call_args.args[0]
        for forbidden in ("-k", "--insecure", "-L", "--location", "--location-trusted"):
            self.assertNotIn(forbidden, args)

    def test_https_compares_exact_utf8_body_including_trailing_newlines(self):
        for body in ("", "сайт", "сайт\n", "сайт\n\n", "first\nsecond\n", "200\n"):
            with self.subTest(body=body):
                self.run.return_value = body + "\n200"
                manage.check_https("example.com", 443, body)

    def test_https_rejects_redirect_and_non200_even_without_expected_body(self):
        for status in ("308", "301", "302", "204", "404", "500"):
            for expected in (None, "body"):
                with self.subTest(status=status, expected=expected):
                    self.run.return_value = "body\n" + status
                    with self.assertRaises(manage.Failure):
                        manage.check_https("example.com", 443, expected)

    def test_https_rejects_missing_or_malformed_status(self):
        for result in ("body", "200", "body\n", "body\n200\n", "body\n0200", "body\n 200"):
            with self.subTest(result=result):
                self.run.return_value = result
                with self.assertRaises(manage.Failure):
                    manage.check_https("example.com", 443)

    def test_https_rejects_wrong_body_and_newline_differences(self):
        for body, expected in (("wrong", "right"), ("сайт", "сайт\n"),
                               ("сайт\n", "сайт"), ("сайт\n\n", "сайт\n")):
            with self.subTest(body=body, expected=expected):
                self.run.return_value = body + "\n200"
                with self.assertRaises(manage.Failure):
                    manage.check_https("example.com", 443, expected)

    def test_https_propagates_curl_failure(self):
        failure = manage.Failure("curl certificate failure")
        self.run.side_effect = failure
        with self.assertRaises(manage.Failure) as caught:
            manage.check_https("example.com", 443)
        self.assertIs(caught.exception, failure)

    def test_run_explicitly_decodes_curl_output_as_utf8(self):
        result = SimpleNamespace(returncode=0, stdout="сайт\n\n200", stderr="")
        with patch.object(manage.subprocess, "run", return_value=result) as subprocess_run:
            self.assertEqual(self.original_run(["curl", "mock-url"], capture=True), result.stdout)
        subprocess_run.assert_called_once_with(["curl", "mock-url"], stdout=subprocess.PIPE,
                                               stderr=subprocess.PIPE, text=True, encoding="utf-8",
                                               timeout=120, env=None)


class InstallWebTests(IsolatedTestCase):
    def setUp(self):
        super().setUp()
        self.web = self.root / "caddy"
        self.mock("WEB", new=self.web)
        self.args = SimpleNamespace(domain="example.com", source="mock-source", image=IMAGE)
        self.nginx_exists = False
        original_exists = Path.exists

        def controlled_exists(path):
            if path == Path("/opt/nginx-selfsteal"):
                return self.nginx_exists
            if not path.is_relative_to(self.root):
                raise AssertionError("Unexpected non-test existence check: " + str(path))
            return original_exists(path)

        self.stack.enter_context(patch.object(Path, "exists", new=controlled_exists))
        self.secure = self.mock("secure_path", side_effect=self.safe_path)
        self.inspect = self.mock("inspect", return_value=None)
        self.run = self.mock("run")
        self.compose = self.mock("compose")
        self.site = self.mock("site_tool", side_effect=self.copy_site)
        self.free = self.mock("assert_free")
        self.dns = self.stack.enter_context(patch.object(manage.socket, "getaddrinfo", return_value=[]))
        self.https = self.mock("wait_https")
        self.backup = self.mock("backup_dir", side_effect=self.make_backup)
        self.firewall = self.mock("configure_firewall")
        self.restore = self.mock("restore_firewall")
        self.stack.enter_context(patch("sys.stdout", new_callable=io.StringIO))
        self.config_call = call(self.web, "config", "--quiet")
        self.validate_call = call(self.web, "run", "--rm", "--no-deps", "caddy", "caddy", "validate",
                                  "--config", "/etc/caddy/Caddyfile", "--adapter", "caddyfile")
        self.up_call = call(self.web, "up", "-d", "--no-build", "--pull", "never")
        self.down_call = call(self.web, "down")

    def safe_path(self, path, **kwargs):
        path = Path(path)
        if not path.is_relative_to(self.root):
            raise AssertionError("Unexpected system path: " + str(path))
        return path

    def copy_site(self, *args):
        if args[0] == "copy":
            output = Path(args[args.index("--output") + 1])
            self.safe_path(output)
            output.mkdir()
            (output / "index.html").write_text("новый сайт\n", encoding="utf-8")

    def make_backup(self, label):
        self.assertEqual(label, "failed-web")
        folder = self.root / (label + "-backup")
        folder.mkdir()
        return folder

    def assert_preflight_did_not_install(self):
        self.assertFalse(self.web.exists())
        self.compose.assert_not_called()
        self.backup.assert_not_called()
        self.https.assert_not_called()
        self.firewall.assert_not_called()
        self.restore.assert_not_called()

    def assert_failed_install_archived(self):
        self.assertFalse(self.web.exists())
        self.backup.assert_called_once_with("failed-web")
        archived = self.root / "failed-web-backup/caddy"
        self.assertTrue(archived.is_dir())
        self.assertFalse((archived / "managed.json").exists())
        expected_inspections = 2 if self.down_call in self.compose.call_args_list else 1
        self.assertEqual(self.inspect.call_args_list, [call("remnanode-web")] * expected_inspections)
        self.firewall.assert_not_called()
        self.restore.assert_not_called()
        return archived

    def test_fresh_install_writes_config_and_verifies_exact_https_before_metadata(self):
        events = Mock()
        for name, child in (("site", self.site), ("free", self.free), ("dns", self.dns),
                            ("run", self.run), ("compose", self.compose), ("https", self.https)):
            events.attach_mock(child, name)

        def https_before_metadata(*args):
            self.assertFalse((self.web / "managed.json").exists())

        self.https.side_effect = https_before_metadata
        manage.install_web(self.args)
        self.assertEqual(events.mock_calls, [
            call.site("validate", "--source", "mock-source"), call.free(80), call.free(443),
            call.dns("example.com", 443), call.run(["docker", "pull", IMAGE], timeout=600),
            call.site("copy", "--source", "mock-source", "--output", self.web / "html"),
            call.compose(*self.config_call.args), call.compose(*self.validate_call.args),
            call.compose(*self.up_call.args), call.https("example.com", 443, "новый сайт\n")])
        self.assertEqual((self.web / "Caddyfile").read_text(encoding="utf-8"),
                         "{\n    admin off\n}\nexample.com {\n    root * /var/www/html\n"
                         "    encode gzip\n    file_server\n}\n")
        compose = json.loads((self.web / "docker-compose.yml").read_text(encoding="utf-8"))
        service = compose["services"]["caddy"]
        self.assertEqual(service["image"], IMAGE)
        self.assertEqual(service["container_name"], "remnanode-web")
        self.assertEqual(service["network_mode"], "host")
        self.assertEqual(service["volumes"], ["./Caddyfile:/etc/caddy/Caddyfile:ro",
                         "./html:/var/www/html:ro", "caddy_data:/data", "caddy_config:/config"])
        self.assertEqual(compose["volumes"], {"caddy_data": {}, "caddy_config": {}})
        self.assertEqual(json.loads((self.web / "managed.json").read_text(encoding="utf-8")),
                         {"version": 1, "domain": "example.com", "image": IMAGE})
        self.backup.assert_not_called()
        self.firewall.assert_not_called()
        self.restore.assert_not_called()

    def test_existing_nginx_is_refused_before_validation_dns_and_pull(self):
        self.nginx_exists = True
        with self.assertRaises(manage.Failure):
            manage.install_web(self.args)
        self.assert_preflight_did_not_install()
        self.site.assert_not_called()
        self.free.assert_not_called()
        self.dns.assert_not_called()
        self.run.assert_not_called()

    def test_source_validation_failure_has_no_install_side_effects(self):
        self.site.side_effect = manage.Failure("invalid source")
        with self.assertRaisesRegex(manage.Failure, "invalid source"):
            manage.install_web(self.args)
        self.assert_preflight_did_not_install()
        self.free.assert_not_called()
        self.dns.assert_not_called()
        self.run.assert_not_called()

    def test_occupied_port_does_not_pull_or_create_web(self):
        self.free.side_effect = [None, manage.Failure("443 occupied")]
        with self.assertRaisesRegex(manage.Failure, "443 occupied"):
            manage.install_web(self.args)
        self.assertEqual(self.free.call_args_list, [call(80), call(443)])
        self.assert_preflight_did_not_install()
        self.dns.assert_not_called()
        self.run.assert_not_called()

    def test_dns_failure_does_not_pull_or_create_web(self):
        self.dns.side_effect = manage.socket.gaierror("DNS failed")
        with self.assertRaises(manage.socket.gaierror):
            manage.install_web(self.args)
        self.assert_preflight_did_not_install()
        self.run.assert_not_called()

    def test_pull_failure_does_not_create_web(self):
        self.run.side_effect = manage.Failure("pull failed")
        with self.assertRaisesRegex(manage.Failure, "pull failed"):
            manage.install_web(self.args)
        self.assert_preflight_did_not_install()
        self.site.assert_called_once_with("validate", "--source", "mock-source")

    def test_copy_failure_archives_partial_install_without_docker_down(self):
        def fail_copy(*args):
            if args[0] == "copy":
                raise manage.Failure("copy failed")

        self.site.side_effect = fail_copy
        with self.assertRaisesRegex(manage.Failure, "copy failed"):
            manage.install_web(self.args)
        self.assert_failed_install_archived()
        self.compose.assert_not_called()
        self.https.assert_not_called()

    def test_compose_config_failure_archives_without_starting(self):
        self.compose.side_effect = manage.Failure("config failed")
        with self.assertRaisesRegex(manage.Failure, "config failed"):
            manage.install_web(self.args)
        archived = self.assert_failed_install_archived()
        self.assertTrue((archived / "docker-compose.yml").is_file())
        self.assertEqual(self.compose.call_args_list, [self.config_call])
        self.https.assert_not_called()

    def test_caddy_validate_failure_archives_without_starting(self):
        self.compose.side_effect = [None, manage.Failure("caddy validate failed")]
        with self.assertRaisesRegex(manage.Failure, "caddy validate failed"):
            manage.install_web(self.args)
        self.assert_failed_install_archived()
        self.assertEqual(self.compose.call_args_list, [self.config_call, self.validate_call])
        self.https.assert_not_called()

    def test_docker_up_failure_runs_down_then_archives(self):
        self.compose.side_effect = [None, None, manage.Failure("up failed"), None]
        with self.assertRaisesRegex(manage.Failure, "up failed"):
            manage.install_web(self.args)
        self.assert_failed_install_archived()
        self.assertEqual(self.compose.call_args_list,
                         [self.config_call, self.validate_call, self.up_call, self.down_call])
        self.https.assert_not_called()

    def test_https_failure_runs_down_then_archives(self):
        self.https.side_effect = manage.Failure("HTTPS failed")
        with self.assertRaisesRegex(manage.Failure, "HTTPS failed"):
            manage.install_web(self.args)
        self.assert_failed_install_archived()
        self.assertEqual(self.compose.call_args_list,
                         [self.config_call, self.validate_call, self.up_call, self.down_call])
        self.https.assert_called_once_with("example.com", 443, "новый сайт\n")

    def test_metadata_write_failure_runs_down_then_archives(self):
        original_write = manage.write_json

        def fail_metadata(path, value):
            if path.name == "managed.json":
                raise OSError("metadata write failed")
            original_write(path, value)

        self.mock("write_json", side_effect=fail_metadata)
        with self.assertRaisesRegex(OSError, "metadata write failed"):
            manage.install_web(self.args)
        self.assert_failed_install_archived()
        self.assertEqual(self.compose.call_args_list[-1], self.down_call)
        self.https.assert_called_once()

    def test_interrupt_runs_down_then_archives_and_propagates(self):
        interrupted = KeyboardInterrupt()
        self.https.side_effect = interrupted
        with self.assertRaises(KeyboardInterrupt) as caught:
            manage.install_web(self.args)
        self.assertIs(caught.exception, interrupted)
        self.assert_failed_install_archived()
        self.assertEqual(self.compose.call_args_list[-1], self.down_call)

    def test_down_failure_preserves_config_and_html_in_place(self):
        self.https.side_effect = manage.Failure("HTTPS failed")
        self.compose.side_effect = [None, None, None, manage.Failure("down failed")]
        with self.assertRaisesRegex(manage.Failure, "down failed"):
            manage.install_web(self.args)
        self.backup.assert_not_called()
        self.assertEqual((self.web / "html/index.html").read_text(encoding="utf-8"), "новый сайт\n")
        self.assertTrue((self.web / "Caddyfile").is_file())
        self.assertTrue((self.web / "docker-compose.yml").is_file())
        self.assertFalse((self.web / "managed.json").exists())

    def test_unconfirmed_stop_preserves_possibly_live_bind_mount(self):
        self.https.side_effect = manage.Failure("HTTPS failed")
        # The first inspection permits a fresh install; Docker down returning zero
        # alone is not sufficient proof that bind-mounted paths can be renamed.
        self.inspect.side_effect = [None, {"State": {"Status": "running", "Running": True}}]
        with self.assertRaises(manage.Failure):
            manage.install_web(self.args)
        self.assertEqual(self.compose.call_args_list[-1], self.down_call)
        self.assertEqual(self.inspect.call_args_list,
                         [call("remnanode-web"), call("remnanode-web")])
        self.backup.assert_not_called()
        self.assertEqual((self.web / "html/index.html").read_text(encoding="utf-8"), "новый сайт\n")
        self.assertTrue((self.web / "Caddyfile").is_file())
        self.assertTrue((self.web / "docker-compose.yml").is_file())


class LockTests(IsolatedTestCase):
    def setUp(self):
        super().setUp()
        # fcntl and O_NOFOLLOW are not available on Windows. Only their contract
        # is simulated; this is not a test of actual Linux filesystem locking.
        self.fcntl = SimpleNamespace(LOCK_EX=2, LOCK_NB=4, flock=Mock())
        self.stack.enter_context(patch.dict("sys.modules", {"fcntl": self.fcntl}))
        self.stack.enter_context(patch.object(manage.os, "O_NOFOLLOW", 0x20000, create=True))
        self.secure = self.mock("secure_path")
        self.open = self.stack.enter_context(patch.object(manage.os, "open", return_value=123))
        self.fstat = self.stack.enter_context(patch.object(
            manage.os, "fstat", return_value=SimpleNamespace(
                st_uid=0, st_nlink=1, st_mode=stat.S_IFREG | 0o600)))
        self.close = self.stack.enter_context(patch.object(manage.os, "close"))

    def test_lock_uses_run_path_secure_open_and_nonblocking_exclusive_flock(self):
        events = Mock()
        for name, child in (("secure", self.secure), ("open", self.open),
                            ("fstat", self.fstat), ("flock", self.fcntl.flock),
                            ("close", self.close)):
            events.attach_mock(child, name)
        with manage.lock():
            self.close.assert_not_called()
        self.assertEqual(events.mock_calls, [
            call.secure(Path("/run/remnanode-local.lock")),
            call.open(Path("/run/remnanode-local.lock"),
                      manage.os.O_CREAT | manage.os.O_RDWR | manage.os.O_NOFOLLOW, 0o600),
            call.fstat(123), call.flock(123, self.fcntl.LOCK_EX | self.fcntl.LOCK_NB),
            call.close(123)])

    def test_lock_busy_fails_and_closes_descriptor_without_entering_body(self):
        self.fcntl.flock.side_effect = BlockingIOError("already locked")
        with self.assertRaisesRegex(manage.Failure, "Другой процесс"):
            with manage.lock():
                self.fail("Busy lock must not permit deployment")
        self.close.assert_called_once_with(123)

    def test_lock_rejects_unsafe_metadata_and_closes_descriptor(self):
        for uid, links, mode in ((1000, 1, stat.S_IFREG), (0, 2, stat.S_IFREG),
                                 (0, 1, stat.S_IFDIR)):
            with self.subTest(uid=uid, links=links, mode=mode):
                self.close.reset_mock()
                self.fstat.return_value = SimpleNamespace(st_uid=uid, st_nlink=links, st_mode=mode)
                with self.assertRaisesRegex(manage.Failure, "Небезопасный lock"):
                    with manage.lock():
                        self.fail("Unsafe lock must not permit deployment")
                self.close.assert_called_once_with(123)
        self.fcntl.flock.assert_not_called()

    def test_lock_closes_descriptor_when_body_is_interrupted(self):
        interrupted = KeyboardInterrupt()
        with self.assertRaises(KeyboardInterrupt) as caught:
            with manage.lock():
                raise interrupted
        self.assertIs(caught.exception, interrupted)
        self.close.assert_called_once_with(123)

    def test_unsafe_lock_path_is_rejected_before_open(self):
        self.secure.side_effect = manage.Failure("unsafe lock path")
        with self.assertRaisesRegex(manage.Failure, "unsafe lock path"):
            with manage.lock():
                self.fail("Unsafe path must not permit deployment")
        self.open.assert_not_called()
        self.close.assert_not_called()


class MainSafetyTests(IsolatedTestCase):
    def test_sigterm_handler_raises_keyboard_interrupt_and_releases_lock(self):
        requirements = self.mock("requirements")
        lock = self.mock("lock")
        handler = self.mock("install_node")
        signal = self.stack.enter_context(patch.object(manage.signal, "signal"))

        def terminate_during_install(args):
            signal.assert_called_once()
            signum, callback = signal.call_args.args
            self.assertEqual(signum, manage.signal.SIGTERM)
            callback(signum, None)
            self.fail("SIGTERM must interrupt deployment")

        handler.side_effect = terminate_during_install
        argv = ["manage.py", "install-node", "--panel-ip", "192.0.2.1",
                "--secret-file", "mock-secret", "--image", IMAGE, "--apply"]
        with patch.object(manage.os, "umask"), patch("sys.argv", argv):
            with self.assertRaises(KeyboardInterrupt):
                manage.main()
        requirements.assert_called_once_with()
        lock.return_value.__enter__.assert_called_once_with()
        self.assertIs(lock.return_value.__exit__.call_args.args[0], KeyboardInterrupt)
        handler.assert_called_once()

    def test_no_apply_fails_before_requirements_lock_or_dispatch(self):
        commands = [
            ["install-node", "--panel-ip", "192.0.2.1", "--secret-file", "mock-secret", "--image", IMAGE],
            ["install-web", "--domain", "example.com", "--source", "mock-source", "--image", IMAGE],
            ["publish-site", "--domain", "example.com", "--source", "mock-source"],
        ]
        requirements = self.mock("requirements")
        self.stack.enter_context(patch.object(manage.signal, "signal"))
        lock = self.mock("lock")
        handlers = [self.mock(name) for name in ("install_node", "install_web", "publish_site")]
        with patch.object(manage.os, "umask"):
            for argv in commands:
                with self.subTest(command=argv[0]), patch("sys.argv", ["manage.py", *argv]):
                    with self.assertRaisesRegex(manage.Failure, "--apply"):
                        manage.main()
        requirements.assert_not_called()
        lock.assert_not_called()
        for handler in handlers:
            handler.assert_not_called()

    def test_invalid_https_port_fails_before_requirements(self):
        requirements = self.mock("requirements")
        self.stack.enter_context(patch.object(manage.signal, "signal"))
        lock = self.mock("lock")
        with patch.object(manage.os, "umask"):
            for port in ("0", "-1", "65536"):
                argv = ["manage.py", "publish-site", "--domain", "example.com",
                        "--source", "mock-source", "--port", port, "--apply"]
                with self.subTest(port=port), patch("sys.argv", argv):
                    with self.assertRaises(manage.Failure):
                        manage.main()
        requirements.assert_not_called()
        lock.assert_not_called()


if __name__ == "__main__":
    unittest.main()
