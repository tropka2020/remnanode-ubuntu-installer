import contextlib
from html.parser import HTMLParser
import importlib.util
import io
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest
from unittest import mock
from urllib.parse import unquote, urlsplit
import xml.etree.ElementTree as ET


MODULE_PATH = Path(__file__).resolve().parents[1] / 'themed_site.py'
SPEC = importlib.util.spec_from_file_location('themed_site_under_test', MODULE_PATH)
themed_site = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(themed_site)


class Document(HTMLParser):
    def __init__(self, text):
        super().__init__(convert_charrefs=True)
        self.tags = []
        self.ids = set()
        self.links = []
        self.h1_count = 0
        self.feed(text)
        self.close()

    def handle_starttag(self, tag, attributes):
        attrs = dict(attributes)
        self.tags.append((tag, attrs))
        if 'id' in attrs:
            self.ids.add(attrs['id'])
        if tag == 'h1':
            self.h1_count += 1
        for key in ('href', 'src'):
            if key in attrs:
                self.links.append(attrs[key])


class ThemedSiteTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        os.chmod(self.root, 0o700)

    def generate(self, theme='plants', layout='journal', name='published', title=None, variant=0):
        def choose(items):
            if items is themed_site.LAYOUTS:
                return layout
            if items == (0, 1, 2):
                return variant
            return items[0]
        output = self.root / name
        with mock.patch.object(themed_site.secrets, 'choice', side_effect=choose):
            themed_site.generate(theme, output, title)
        return output

    def test_three_themes_and_three_materially_different_layouts_validate(self):
        styles = {}
        theme_illustrations = set()
        for theme in ('plants', 'coffee', 'photo'):
            for layout in themed_site.LAYOUTS:
                with self.subTest(theme=theme, layout=layout):
                    output = self.generate(theme, layout, name=theme + '-' + layout)
                    _, files = themed_site.site_tool.validate(output)
                    self.assertEqual(len(files), 16)
                    self.assertTrue({'index.html', 'notes.html', 'about.html', 'style.css',
                                     'favicon.svg', 'illustration.svg'}.issubset(files))
                    index = (output / 'index.html').read_text(encoding='utf-8')
                    self.assertIn(f'class="{layout} theme-{theme}"', index)
                    self.assertIn('lang="ru"', index)
                    for label in ('Главная', 'Заметки', 'О сайте'):
                        self.assertIn(label, index)
                    articles = list((output / 'articles').glob('*.html'))
                    self.assertEqual(len(articles), 5)
                    for article in articles:
                        text = article.read_text(encoding='utf-8')
                        body = text.split('<div class="article-body">')[1].split('</div>')[0]
                        self.assertEqual(body.count('<p>'), 3)
                        self.assertGreater(len(body), 700)
                        self.assertNotIn('lorem', text.lower())
                        self.assertNotIn('<time', text)
                    styles[theme, layout] = (output / 'style.css').read_text(encoding='utf-8')
                    theme_illustrations.add((output / 'illustration.svg').read_text(encoding='utf-8'))
        self.assertEqual(len(theme_illustrations), 3)
        self.assertEqual(len({styles['plants', layout] for layout in themed_site.LAYOUTS}), 3)
        css = styles['plants', 'journal']
        # Structural changes, not just a different colour or border radius.
        self.assertIn('.journal .card:first-child { grid-column: 1 / -1;', css)
        self.assertIn('.grid .cards { grid-template-columns: repeat(3,', css)
        self.assertIn('.sidebar .site-shell { display: grid;', css)
        self.assertIn('height: auto', css)
        self.assertIn('@media (max-width: 650px)', css)

    def test_all_links_resources_and_fragments_exist_without_network(self):
        for theme in themed_site.CONTENT:
            with self.subTest(theme=theme):
                output = self.generate(theme, name=theme)
                documents = {p.relative_to(output).as_posix(): Document(p.read_text(encoding='utf-8'))
                             for p in output.rglob('*.html')}
                for name, document in documents.items():
                    self.assertEqual(document.h1_count, 1, name)
                    self.assertEqual(sum(tag == 'main' for tag, _ in document.tags), 1)
                    self.assertEqual(sum(tag == 'nav' for tag, _ in document.tags), 2)
                    self.assertFalse(any(tag in {'script', 'iframe', 'form', 'style'} for tag, _ in document.tags))
                    for value in document.links:
                        url = urlsplit(value)
                        self.assertFalse(url.scheme or url.netloc, (name, value))
                        target = unquote(url.path).lstrip('/') if url.path else name
                        self.assertTrue((output / target).is_file(), (name, value))
                        if url.fragment:
                            self.assertIn(url.fragment, documents[target].ids)
                    for tag, attrs in document.tags:
                        if tag == 'img':
                            self.assertIn('alt', attrs)
                            self.assertEqual(attrs['width'], '640')
                            self.assertEqual(attrs['height'], '400')
                notes = (output / 'notes.html').read_text(encoding='utf-8')
                for article in (output / 'articles').glob('*.html'):
                    self.assertIn('/articles/' + article.name, notes)

    def test_title_escaping_in_every_page_and_favicon(self):
        title = '<script>"Кадр" & \'свет\'</script>'
        output = self.generate(title=title)
        themed_site.site_tool.validate(output)
        for path in output.rglob('*.html'):
            text = path.read_text(encoding='utf-8')
            self.assertIn(themed_site.esc(title), text)
            self.assertNotIn('<script>', text)
            self.assertNotIn('<script>', [tag for tag, _ in Document(text).tags])
        favicon = ET.fromstring((output / 'favicon.svg').read_text(encoding='utf-8'))
        ns = {'s': 'http://www.w3.org/2000/svg'}
        self.assertEqual(favicon.find('s:title', ns).text, title)
        self.assertEqual(favicon.find('s:text', ns).text, '<')

    def test_defaults_and_saved_design_and_geometry_variants(self):
        for theme, content in themed_site.CONTENT.items():
            self.assertTrue(all(len(name.split()) >= 2 for name in content['names']))
            self.assertEqual(len(content['names']), len(set(content['names'])))
            illustrations = set()
            for variant in range(3):
                output = self.generate(theme, 'grid', f'{theme}-{variant}', variant=variant)
                self.assertIn(content['names'][0], (output / 'index.html').read_text(encoding='utf-8'))
                illustrations.add((output / 'illustration.svg').read_bytes())
                # No private state or runtime is needed to preserve this design.
                snapshot = {p.relative_to(output): p.read_bytes() for p in output.rglob('*') if p.is_file()}
                themed_site.site_tool.validate(output)
                self.assertEqual(snapshot, {p.relative_to(output): p.read_bytes()
                                            for p in output.rglob('*') if p.is_file()})
                self.assertFalse(list(output.rglob('*.json')))
            self.assertEqual(len(illustrations), 3)
        output = self.generate(title='  Тёплый подоконник  ')
        self.assertIn('>Т</text>', (output / 'favicon.svg').read_text(encoding='utf-8'))
        self.assertIn('>Тёплый подоконник</a>', (output / 'index.html').read_text(encoding='utf-8'))

    def test_existing_output_directory_empty_directory_and_file_are_refused(self):
        for kind in ('directory', 'empty', 'file'):
            with self.subTest(kind=kind):
                output = self.root / kind
                if kind == 'file':
                    output.write_text('keep', encoding='utf-8')
                else:
                    output.mkdir()
                    if kind == 'directory':
                        (output / 'keep.txt').write_text('keep', encoding='utf-8')
                with self.assertRaises(themed_site.SiteError):
                    themed_site.generate('coffee', output)
                if kind == 'empty':
                    self.assertEqual(list(output.iterdir()), [])
                else:
                    marker = output if kind == 'file' else output / 'keep.txt'
                    self.assertEqual(marker.read_text(encoding='utf-8'), 'keep')
        self.assertFalse(list(self.root.glob('.site-staging-*')))

    def test_no_replace_if_destination_appears_during_publication(self):
        output = self.root / 'race'
        original = themed_site.site_tool.rename_no_replace

        def race(source, destination):
            destination.mkdir()
            (destination / 'keep.txt').write_text('keep', encoding='utf-8')
            return original(source, destination)

        with mock.patch.object(themed_site.site_tool, 'rename_no_replace', side_effect=race):
            with self.assertRaises((themed_site.SiteError, OSError)):
                themed_site.generate('plants', output)
        self.assertEqual((output / 'keep.txt').read_text(encoding='utf-8'), 'keep')
        self.assertFalse(list(self.root.glob('.site-staging-*')))

    def test_publish_reuses_validator_and_rejects_invalid_staging(self):
        validate = themed_site.site_tool.validate
        with mock.patch.object(themed_site.site_tool, 'validate', wraps=validate) as checked:
            self.generate()
        self.assertEqual(checked.call_count, 1)
        self.assertEqual(checked.call_args.args[0].name, 'public')
        with mock.patch.object(themed_site, 'illustration', return_value='<svg><script/></svg>'):
            with self.assertRaises(themed_site.SiteError):
                themed_site.generate('plants', self.root / 'invalid')
        self.assertFalse((self.root / 'invalid').exists())
        self.assertFalse(list(self.root.glob('.site-staging-*')))

    def test_invalid_inputs_do_not_publish(self):
        for theme in ('unknown', '', None, [], 1):
            with self.subTest(theme=theme), self.assertRaises(themed_site.SiteError):
                themed_site.generate(theme, self.root / 'bad-theme')
        for title in ('', '   ', '\x00title', 'line\nbreak', 'a' * 161, 123):
            with self.subTest(title=title), self.assertRaises(themed_site.SiteError):
                themed_site.generate('photo', self.root / 'bad-title', title)
        with self.assertRaises((themed_site.SiteError, OSError)):
            themed_site.generate('photo', self.root / 'missing' / 'output')
        self.assertEqual(list(self.root.iterdir()), [])

    def test_cli_contract_success_and_safe_errors(self):
        output = self.root / 'cli'
        result = subprocess.run([sys.executable, str(MODULE_PATH), '--theme', 'photo',
                                 '--output', str(output), '--title', 'Свет у окна'],
                                capture_output=True, encoding='utf-8')
        self.assertEqual(result.returncode, 0, result.stderr)
        themed_site.site_tool.validate(output)
        self.assertIn('Свет у окна', (output / 'index.html').read_text(encoding='utf-8'))
        result = subprocess.run([sys.executable, str(MODULE_PATH), '--theme', 'coffee',
                                 '--output', str(output)], capture_output=True, encoding='utf-8')
        self.assertEqual(result.returncode, 1)
        self.assertNotIn('Traceback', result.stderr)
        with contextlib.redirect_stderr(io.StringIO()) as errors:
            self.assertEqual(themed_site.main(['--theme', 'plants', '--output', str(self.root / 'bad'),
                                              '--title', '']), 1)
        self.assertIn('Ошибка:', errors.getvalue())
        with contextlib.redirect_stderr(io.StringIO()), self.assertRaises(SystemExit) as error:
            themed_site.main(['--theme', 'other', '--output', str(self.root / 'bad')])
        self.assertEqual(error.exception.code, 2)


if __name__ == '__main__':
    unittest.main()
