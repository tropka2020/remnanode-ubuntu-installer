import contextlib
import copy
from html.parser import HTMLParser
import io
import itertools
import json
import os
from pathlib import Path
import random
import shutil
import subprocess
import sys
import tempfile
import unittest
from unittest import mock
from urllib.parse import unquote, urlsplit
import xml.etree.ElementTree as ET

# unittest discovery and direct invocation both work without installing packages.
ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))
import design_catalog
import studio_site


class Document(HTMLParser):
    def __init__(self, text):
        super().__init__(convert_charrefs=True)
        self.tags = []
        self.ids = set()
        self.links = []
        self.feed(text)
        self.close()

    def handle_starttag(self, tag, attrs):
        attrs = dict(attrs)
        self.tags.append((tag, attrs))
        if 'id' in attrs:
            self.ids.add(attrs['id'])
        for key in ('href', 'src'):
            if key in attrs:
                self.links.append(attrs[key])

    def classes(self, name):
        return [(tag, attrs) for tag, attrs in self.tags if name in attrs.get('class', '').split()]


def manifest(direction='editorial', hero='feature', listing='cards', article='column', seed='1' * 64):
    return {'schema': 1, 'version': design_catalog.VERSION,
            'request_id': '11111111-1111-4111-8111-111111111111',
            'reservation_id': '22222222-2222-4222-8222-222222222222', 'seed': seed,
            'composition': {'version': design_catalog.VERSION, 'direction': direction,
                            'hero': hero, 'listing': listing, 'article': article}}


def snapshot(output):
    return {p.relative_to(output).as_posix(): p.read_bytes() for p in output.rglob('*') if p.is_file()}


class StudioSiteTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        os.chmod(self.root, 0o700)

    def generate(self, theme='plants', name='published', title=None, value=None):
        output = self.root / name
        studio_site.generate(theme, output, title, manifest=value or manifest())
        return output

    def assert_links(self, output):
        documents = {p.relative_to(output).as_posix(): Document(p.read_text(encoding='utf-8'))
                     for p in output.rglob('*.html')}
        for name, document in documents.items():
            self.assertEqual(sum(t == 'h1' for t, _ in document.tags), 1, name)
            self.assertEqual(sum(t == 'main' for t, _ in document.tags), 1, name)
            self.assertFalse(any(t in {'script', 'iframe', 'form', 'style'} for t, _ in document.tags))
            self.assertTrue(any(t == 'meta' and a.get('name') == 'viewport' for t, a in document.tags))
            for value in document.links:
                parsed = urlsplit(value)
                self.assertFalse(parsed.scheme or parsed.netloc, (name, value))
                self.assertTrue(not parsed.path or parsed.path.startswith('/'), (name, value))
                target = unquote(parsed.path).lstrip('/') if parsed.path else name
                self.assertTrue((output / target).is_file(), (name, value))
                if parsed.fragment:
                    self.assertIn(parsed.fragment, documents[target].ids, (name, value))
            for tag, attrs in document.tags:
                if tag == 'img':
                    self.assertIn('alt', attrs)
                    self.assertEqual(attrs['width'], '960')
                    self.assertEqual(attrs['height'], '720')
        return documents

    def test_all_144_compositions_validate_with_real_content_and_axis_structure(self):
        shells = set()
        for direction, hero, listing, article in itertools.product(
                design_catalog.DIRECTIONS, design_catalog.HEROES, design_catalog.LISTINGS, design_catalog.ARTICLES):
            with self.subTest(direction=direction, hero=hero, listing=listing, article=article):
                value = manifest(direction, hero, listing, article)
                output = self.generate(value=value)
                _, files = studio_site.site_tool.validate(output)
                self.assertEqual(len(files), 19)
                docs = self.assert_links(output)
                index = docs['index.html']
                self.assertEqual(len(index.classes('hero-' + hero)), 1)
                self.assertEqual(len(index.classes('list-' + listing)), 1)
                if hero == 'type':
                    self.assertEqual(len(index.classes('type-specimen')), 1)
                    self.assertNotIn('/illustration.svg', index.links)
                    self.assertFalse(any('/plate-' in s for s in index.links))
                elif hero == 'mosaic':
                    self.assertEqual(len(index.classes('art-mosaic')), 1)
                    self.assertEqual(sum('/plate-' in s for s in index.links), 3)
                    plate_geometry = {ET.tostring(ET.fromstring((output / f'illustrations/plate-{i}.svg').read_text(encoding='utf-8')))
                                      for i in range(3)}
                    self.assertEqual(len(plate_geometry), 3)
                else:
                    self.assertIn('/illustration.svg', index.links)
                    self.assertFalse(any('/plate-' in s for s in index.links))
                if listing == 'rows':
                    self.assertEqual(len(index.classes('row-entry')), 5)
                    self.assertEqual(index.classes('list-rows')[0][0], 'ol')
                elif listing == 'featured':
                    self.assertEqual(len(index.classes('lead-entry')), 1)
                    self.assertEqual(len(index.classes('small-entry')), 4)
                else:
                    self.assertEqual(len(index.classes('card-entry')), 5)
                for slug, heading, category, summary, paragraphs in studio_site.CONTENT['plants']['articles']:
                    name = f'articles/{slug}.html'
                    text = (output / name).read_text(encoding='utf-8')
                    for paragraph in paragraphs:
                        self.assertIn(studio_site.esc(paragraph), text)
                    self.assertIn(studio_site.esc(heading), text)
                    self.assertEqual(len(docs[name].classes('reading-' + article)), 1)
                    if article == 'split':
                        self.assertEqual(len(docs[name].classes('reading-guide')), 1)
                        self.assertEqual(sum('#part-' in s for s in docs[name].links), 3)
                    else:
                        self.assertEqual(len(docs[name].classes('reading-guide')), 0)
                    self.assertNotIn('<time', text)
                if hero == 'feature' and listing == 'cards' and article == 'column':
                    # DOM signatures differ after colour/typography is removed.
                    shells.add(tuple((tag, attrs.get('class', '')) for tag, attrs in index.tags))
                shutil.rmtree(output)
        self.assertEqual(len(shells), 8)
        self.assertFalse(list(self.root.glob('.site-staging-*')))

    def test_all_three_subjects_have_original_local_svg_and_complete_evergreen_articles(self):
        hero_images = set()
        for theme in studio_site.CONTENT:
            with self.subTest(theme=theme):
                output = self.generate(theme, name=theme, value=manifest('nocturne', 'mosaic', 'rows', 'split'))
                studio_site.site_tool.validate(output)
                self.assert_links(output)
                self.assertEqual(len(list((output / 'articles').glob('*.html'))), 5)
                hero_images.add((output / 'illustration.svg').read_bytes())
                for svg in output.rglob('*.svg'):
                    root = ET.fromstring(svg.read_bytes())
                    self.assertTrue(root.tag.endswith('svg'))
                    self.assertFalse(any(n.tag.endswith('script') for n in root.iter()))
                for slug, heading, _, summary, paragraphs in studio_site.CONTENT[theme]['articles']:
                    text = (output / f'articles/{slug}.html').read_text(encoding='utf-8')
                    for paragraph in paragraphs:
                        self.assertIn(studio_site.esc(paragraph), text)
                    self.assertIn(studio_site.esc(summary), text)
                    self.assertGreater(sum(len(p) for p in paragraphs), 700)
        self.assertEqual(len(hero_images), 3)

    def test_equal_manifest_produces_byte_exact_tree_without_global_randomness(self):
        value = manifest('gallery', 'mosaic', 'featured', 'split')
        original = copy.deepcopy(value)
        state = random.getstate()
        # Reusing themed_site's secrets.choice would make reproducibility fail.
        with mock.patch.object(studio_site.themed_site.secrets, 'choice', side_effect=AssertionError('global secrets')):
            first = self.generate(name='first', value=value)
            second = self.generate(name='second', value=value)
        self.assertEqual(snapshot(first), snapshot(second))
        self.assertEqual(random.getstate(), state)
        self.assertEqual(value, original)

    def test_seed_changes_visible_geometry_not_hidden_identifiers(self):
        for theme in studio_site.CONTENT:
            first = self.generate(theme, name=theme + '-a', title='Наблюдение', value=manifest(seed='a' * 64))
            second = self.generate(theme, name=theme + '-b', title='Наблюдение', value=manifest(seed='b' * 64))
            self.assertEqual((first / 'index.html').read_bytes(), (second / 'index.html').read_bytes())
            a = ET.fromstring((first / 'illustration.svg').read_bytes())
            b = ET.fromstring((second / 'illustration.svg').read_bytes())
            # Geometric element attributes—not comments, desc, title or data-*—vary.
            geometry = lambda root: [(n.tag, tuple(sorted(n.attrib.items()))) for n in root.iter()
                                     if n.tag.rsplit('}', 1)[-1] in {'path', 'circle', 'ellipse', 'g'}]
            self.assertNotEqual(geometry(a), geometry(b))
            for root in (a, b):
                self.assertFalse(any(k.startswith('data-') for n in root.iter() for k in n.attrib))

    def test_private_identifiers_do_not_influence_or_leak_into_public_tree(self):
        value = manifest('poster', 'type', 'rows', 'split', seed='deadbeef' * 8)
        first = self.generate(value=value)
        second_value = copy.deepcopy(value)
        second_value['request_id'] = '33333333-3333-4333-8333-333333333333'
        second_value['reservation_id'] = '44444444-4444-4444-8444-444444444444'
        second = self.generate(name='other-identifiers', value=second_value)
        self.assertEqual(snapshot(first), snapshot(second))
        self.assertFalse(list(first.rglob('*.json')))
        for path, raw in snapshot(first).items():
            text = raw.decode('utf-8')
            for private in (value['seed'], value['request_id'], value['reservation_id'], 'request_id',
                            'reservation_id', 'seed', 'manifest', 'token', design_catalog.VERSION):
                self.assertNotIn(private, text, path)
        self.assertEqual(set(p.suffix for p in first.rglob('*') if p.is_file()), {'.html', '.css', '.svg'})

    def test_title_escaping_everywhere_and_trimmed_initial(self):
        title = '<script>"Лист" & \'свет\'</script>'
        output = self.generate(title=title)
        for path in output.rglob('*.html'):
            text = path.read_text(encoding='utf-8')
            self.assertIn(studio_site.esc(title), text)
            self.assertNotIn('<script>', text)
            self.assertNotIn('script', [t for t, _ in Document(text).tags])
        favicon = ET.fromstring((output / 'favicon.svg').read_bytes())
        ns = {'s': 'http://www.w3.org/2000/svg'}
        self.assertEqual(favicon.find('s:title', ns).text, title)
        self.assertEqual(favicon.find('s:text', ns).text, '<')
        trimmed = self.generate(name='trimmed', title='  Тёплый свет  ')
        self.assertIn('>Тёплый свет</a>', (trimmed / 'index.html').read_text(encoding='utf-8'))
        self.assertIn('>Т</text>', (trimmed / 'favicon.svg').read_text(encoding='utf-8'))

    def test_mobile_390_css_safety_focus_and_independent_direction_rules(self):
        direction_rules = set()
        for direction in design_catalog.DIRECTIONS:
            output = self.generate(name=direction, value=manifest(direction))
            css = (output / 'style.css').read_text(encoding='utf-8')
            self.assertIn('height: auto;', css)
            self.assertIn('min-width: 0;', css)
            self.assertIn('@media (max-width: 700px)', css)
            self.assertIn('grid-template-columns: minmax(0, 1fr)', css)
            self.assertIn(':focus-visible', css)
            self.assertNotIn('@import', css)
            self.assertNotIn('url(', css)
            self.assertNotIn('overflow-x: hidden', css)
            self.assertNotIn('min-width: 390', css)
            self.assertIn('position: static;', css)
            rules = studio_site.DIRECTION_CSS[direction]
            self.assertGreater(len(rules), 1000)
            direction_rules.add(rules)
        self.assertEqual(len(direction_rules), 8)
        # Structural assertions are not a substitute for a rendered viewport test.
        self.assertIn('.reference-shell { display: block;', studio_site.MOBILE_CSS)
        self.assertIn('.directory-index { columns: 2;', studio_site.MOBILE_CSS)
        self.assertIn('.night-stage .art-mosaic figure:first-child { grid-column: 1 / -1;', studio_site.MOBILE_CSS)

    def test_text_palettes_have_wcag_aa_contrast_on_both_reading_surfaces(self):
        def luminance(color):
            channels = [int(color[i:i + 2], 16) / 255 for i in (1, 3, 5)]
            linear = [v / 12.92 if v <= .04045 else ((v + .055) / 1.055) ** 2.4 for v in channels]
            return sum(weight * channel for weight, channel in zip((.2126, .7152, .0722), linear))

        for direction, (paper, ink, accent, wash, _) in studio_site.PALETTES.items():
            for foreground, background in itertools.product((ink, accent), (paper, wash)):
                with self.subTest(direction=direction, foreground=foreground, background=background):
                    light, dark = sorted((luminance(foreground), luminance(background)), reverse=True)
                    self.assertGreaterEqual((light + .05) / (dark + .05), 4.5)

    def test_existing_destinations_are_never_replaced(self):
        for kind in ('file', 'empty', 'directory'):
            output = self.root / kind
            if kind == 'file':
                output.write_bytes(b'keep')
            else:
                output.mkdir()
                if kind == 'directory':
                    (output / 'keep.txt').write_bytes(b'keep')
            before = output.read_bytes() if output.is_file() else snapshot(output)
            with self.subTest(kind=kind), self.assertRaises(studio_site.SiteError):
                studio_site.generate('coffee', output, manifest=manifest())
            self.assertEqual(output.read_bytes() if output.is_file() else snapshot(output), before)
        self.assertFalse(list(self.root.glob('.site-staging-*')))

    def test_publication_race_does_not_replace_and_staging_is_cleaned(self):
        output = self.root / 'raced'
        rename = studio_site.site_tool.rename_no_replace

        def race(source, destination):
            destination.mkdir()
            (destination / 'keep.txt').write_bytes(b'keep')
            return rename(source, destination)

        with mock.patch.object(studio_site.site_tool, 'rename_no_replace', side_effect=race):
            with self.assertRaises((studio_site.SiteError, OSError)):
                studio_site.generate('plants', output, manifest=manifest())
        self.assertEqual((output / 'keep.txt').read_bytes(), b'keep')
        self.assertFalse(list(self.root.glob('.site-staging-*')))

    def test_validation_failure_is_atomic_and_uses_existing_publish_validator(self):
        validate = studio_site.site_tool.validate
        with mock.patch.object(studio_site.site_tool, 'validate', wraps=validate) as checked:
            self.generate()
        self.assertEqual(checked.call_count, 1)
        with mock.patch.object(studio_site, 'illustration', return_value='<svg><script/></svg>'):
            with self.assertRaises(studio_site.SiteError):
                studio_site.generate('plants', self.root / 'bad', manifest=manifest())
        self.assertFalse((self.root / 'bad').exists())
        self.assertFalse(list(self.root.glob('.site-staging-*')))

    def test_invalid_input_never_creates_output(self):
        for theme in (None, [], 1, '', 'unknown'):
            with self.subTest(theme=theme), self.assertRaises(studio_site.SiteError):
                studio_site.generate(theme, self.root / 'bad', manifest=manifest())
        for title in ('', ' ', 'a' * 161, '\x00secret', 'line\nbreak', 123):
            with self.subTest(title=title), self.assertRaises(studio_site.SiteError):
                studio_site.generate('plants', self.root / 'bad', title, manifest=manifest())
        invalid = [None, {}, [], {'seed': 'private-value'}]
        for key, value in (('seed', 'not-a-seed'), ('request_id', 'not-a-uuid'),
                           ('version', 'unsupported'), ('schema', True), ('composition', None)):
            item = manifest()
            item[key] = value
            invalid.append(item)
        item = manifest()
        item['composition']['hero'] = 'unsupported'
        invalid.append(item)
        for item in invalid:
            with self.subTest(manifest=item), self.assertRaises(ValueError):
                studio_site.generate('plants', self.root / 'bad', manifest=item)
        with self.assertRaises(TypeError):
            studio_site.generate('plants', self.root / 'missing-manifest')
        with self.assertRaises((studio_site.SiteError, OSError)):
            studio_site.generate('plants', self.root / 'missing' / 'output', manifest=manifest())
        self.assertEqual(list(self.root.iterdir()), [])

    def test_generate_does_not_modify_sources_or_private_manifest(self):
        sources = [ROOT / 'studio_site.py', ROOT / 'themed_site.py', ROOT / 'site.py', ROOT / 'design_catalog.py']
        before = {p: p.read_bytes() for p in sources}
        private = self.root / 'private.json'
        private.write_text(json.dumps(manifest()), encoding='utf-8')
        private_bytes = private.read_bytes()
        self.generate(value=json.loads(private_bytes))
        self.assertEqual({p: p.read_bytes() for p in sources}, before)
        self.assertEqual(private.read_bytes(), private_bytes)

    def test_cli_requires_manifest_and_returns_safe_errors(self):
        private = self.root / 'private.json'
        private.write_text(json.dumps(manifest('almanac', 'mosaic', 'featured', 'split')), encoding='utf-8')
        output = self.root / 'cli'
        args = [sys.executable, str(ROOT / 'studio_site.py'), '--theme', 'coffee', '--output', str(output),
                '--title', 'Зерно у окна', '--manifest', str(private)]
        result = subprocess.run(args, capture_output=True, encoding='utf-8')
        self.assertEqual(result.returncode, 0, result.stderr)
        studio_site.site_tool.validate(output)
        self.assertIn('Зерно у окна', (output / 'index.html').read_text(encoding='utf-8'))
        repeated = subprocess.run(args, capture_output=True, encoding='utf-8')
        self.assertEqual(repeated.returncode, 1)
        self.assertNotIn('Traceback', repeated.stderr)
        secret = 'PRIVATE_TOKEN_DO_NOT_ECHO'
        private.write_text('{"private": "' + secret + '"}', encoding='utf-8')
        with contextlib.redirect_stderr(io.StringIO()) as errors:
            result = studio_site.main(['--theme', 'plants', '--output', str(self.root / 'bad'), '--manifest', str(private)])
        self.assertEqual(result, 1)
        self.assertNotIn(secret, errors.getvalue())
        self.assertNotIn(str(private), errors.getvalue())
        self.assertNotIn('Traceback', errors.getvalue())
        self.assertFalse((self.root / 'bad').exists())
        private.write_text('x' * 65537, encoding='utf-8')
        with contextlib.redirect_stderr(io.StringIO()):
            self.assertEqual(studio_site.main(['--theme', 'plants', '--output', str(self.root / 'big'), '--manifest', str(private)]), 1)
        self.assertFalse((self.root / 'big').exists())
        with contextlib.redirect_stderr(io.StringIO()), self.assertRaises(SystemExit) as missing:
            studio_site.main(['--theme', 'plants', '--output', str(self.root / 'no-manifest')])
        self.assertEqual(missing.exception.code, 2)


if __name__ == '__main__':
    unittest.main()
