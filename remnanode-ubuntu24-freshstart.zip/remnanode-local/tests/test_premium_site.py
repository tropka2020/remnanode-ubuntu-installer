import copy
import ctypes
from html.parser import HTMLParser
import os
from pathlib import Path, PurePosixPath
import re
import tempfile
import unittest
from unittest import mock
from urllib.parse import unquote, urljoin, urlsplit

import premium_site as premium


def _jpeg_dimensions(data):
    """Read SOF dimensions without an optional image-processing dependency."""
    if data[:2] != b'\xff\xd8':
        raise ValueError('Not JPEG')
    position = 2
    while position < len(data):
        if data[position] != 0xff:
            raise ValueError('Invalid JPEG marker')
        while data[position] == 0xff:
            position += 1
        marker = data[position]
        position += 1
        length = int.from_bytes(data[position:position + 2], 'big')
        if marker in (0xc0, 0xc1, 0xc2):
            return (int.from_bytes(data[position + 5:position + 7], 'big'),
                    int.from_bytes(data[position + 3:position + 5], 'big'))
        position += length
    raise ValueError('Missing JPEG frame')


class Document(HTMLParser):
    def __init__(self, data):
        super().__init__(convert_charrefs=True)
        self.links = []
        self.ids = set()
        self.tags = []
        self.text = []
        self.feed(data.decode('utf-8'))
        self.close()

    def handle_starttag(self, tag, attrs):
        attrs = dict(attrs)
        self.tags.append((tag, attrs))
        if 'id' in attrs:
            if attrs['id'] in self.ids:
                raise AssertionError('duplicate id: ' + attrs['id'])
            self.ids.add(attrs['id'])
        for key in ('href', 'src'):
            if key in attrs:
                self.links.append((tag, key, attrs[key]))

    def handle_data(self, value):
        self.text.append(value)


class PremiumSiteTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        os.chmod(self.root, 0o700)

    def manifest(self, template='north', number=0):
        return {'schema': 1, 'version': 'premium-v1', 'template': template,
                'seed': f'{number:064x}'}

    def generated(self, template='north'):
        manifest = self.manifest(template)
        source = self.root / 'source'
        premium.generate(manifest, source)
        return manifest, source

    def assert_rejected(self, source, manifest):
        output = self.root / 'rejected'
        with self.assertRaises((premium.SiteError, OSError, ValueError)):
            premium.copy_generated(source, output, manifest)
        self.assertFalse(output.exists())
        self.assertFalse(list(self.root.glob('.premium-staging-*')))

    def test_manifest_exact_schema_and_defensive_copy(self):
        for template in premium.TEMPLATES:
            manifest = premium.new_manifest(template)
            self.assertEqual(set(manifest), {'schema', 'version', 'template', 'seed'})
            self.assertEqual(manifest['schema'], 1)
            self.assertEqual(manifest['version'], 'premium-v1')
            self.assertEqual(manifest['template'], template)
            self.assertRegex(manifest['seed'], r'^[0-9a-f]{64}$')
            self.assertEqual(premium.validate_manifest(manifest), manifest)
            self.assertIsNot(premium.validate_manifest(manifest), manifest)
            self.assertNotEqual(premium.new_manifest(template)['seed'], manifest['seed'])
        invalid = [None, [], {}, dict(self.manifest(), title='User title'),
                   dict(self.manifest(), schema=True), dict(self.manifest(), schema=1.0),
                   dict(self.manifest(), version='premium-v2'),
                   dict(self.manifest(), template='NORTH'), dict(self.manifest(), template=[])]
        for seed in ('0' * 63, '0' * 65, 'A' * 64, 'g' * 64, '../x', '0' * 63 + '\n', 42):
            invalid.append(dict(self.manifest(), seed=seed))
        for value in invalid:
            with self.subTest(value=value):
                with self.assertRaises(ValueError):
                    premium.validate_manifest(value)
        for value in ('invalid', None, [], '<script>'):
            with self.assertRaises(ValueError):
                premium.new_manifest(value)

    def test_all_families_deterministic_offline_five_real_articles(self):
        for template in premium.TEMPLATES:
            with self.subTest(template=template):
                manifest = self.manifest(template)
                original = copy.deepcopy(manifest)
                files = premium.expected_files(manifest)
                self.assertEqual(files, premium.expected_files(manifest))
                self.assertEqual(manifest, original)
                self.assertTrue(all(type(k) is str and type(v) is bytes for k, v in files.items()))
                self.assertLess(sum(map(len, files.values())), 30 * 1024 * 1024)
                articles = {name for name in files if name.startswith('article-') and name.endswith('.html')}
                self.assertEqual(len(articles), 5)
                pages = {name: Document(data) for name, data in files.items() if name.endswith('.html')}
                self.assertEqual(len(pages), 8)
                self.assertEqual(set(pages), articles | {'index.html', 'notes.html', 'about.html'})
                for name in ('index.html', 'notes.html'):
                    hrefs = {url for _, key, url in pages[name].links if key == 'href'}
                    self.assertTrue(articles.issubset(hrefs), (name, articles - hrefs))
                for name, document in pages.items():
                    self.assertEqual(sum(tag == 'h1' for tag, _ in document.tags), 1, name)
                    self.assertTrue(any(tag == 'main' for tag, _ in document.tags))
                    self.assertTrue(any(tag == 'details' and attrs.get('class') == 'menu'
                                        for tag, attrs in document.tags))
                    self.assertTrue(any(tag == 'summary' for tag, _ in document.tags))
                    self.assertFalse(any('hidden' in attrs for _, attrs in document.tags))
                    self.assertNotIn('#article/', files[name].decode())
                    self.assertNotIn('@@', files[name].decode())
                    self.assertNotIn('design-preview', files[name].decode())
                    scripts = [attrs for tag, attrs in document.tags if tag == 'script']
                    self.assertEqual(scripts, [{'src': 'assets/enhance.js', 'defer': None}])
                    for tag, key, url in document.links:
                        parsed = urlsplit(url)
                        self.assertFalse(parsed.scheme or parsed.netloc, (name, url))
                        target = unquote(parsed.path) or name
                        self.assertIn(target, set(files), (name, url))
                        if parsed.fragment and target.endswith('.html'):
                            self.assertIn(parsed.fragment, pages[target].ids, (name, url))
                    if name in articles:
                        self.assertGreater(len(''.join(document.text)), 1500)
                        self.assertGreaterEqual(sum(tag == 'h2' for tag, _ in document.tags), 4)
                        self.assertTrue(any(url in articles - {name} for _, _, url in document.links))
                for name, data in files.items():
                    if name.endswith('.css'):
                        for url in re.findall(r'url\([\s\'"]*([^\)\'"\s]+)', data.decode()):
                            parsed = urlsplit(url)
                            self.assertFalse(parsed.scheme or parsed.netloc)
                            target = (PurePosixPath(name).parent / unquote(parsed.path)).as_posix()
                            self.assertIn(target, set(files), (name, url))
                self.assertNotIn('manifest.json', files)
                self.assertNotIn(manifest['seed'], b''.join(files.values()).decode('latin-1'))

    def test_background_variable_urls_resolve_from_consumers_under_subpath(self):
        base = 'https://example.invalid/nested/publication/'
        url_pattern = r'url\([\s\'\"]*([^\)\'\"\s]+)'
        for template in premium.TEMPLATES:
            for number in range(6):
                with self.subTest(template=template, seed=number):
                    files = premium.expected_files(self.manifest(template, number))
                    self.assertNotIn('variant.css', files)
                    variables = dict(re.findall(
                        r'(--(?:hero|pause)-image):([^;}]+)',
                        files['assets/variant.css'].decode()))
                    self.assertEqual(set(variables), {'--hero-image', '--pause-image'})
                    for name, data in files.items():
                        if not name.endswith('.css'):
                            continue
                        css = data.decode()
                        for variable in re.findall(r'var\((--(?:hero|pause)-image)\)', css):
                            urls = re.findall(url_pattern, variables[variable])
                            self.assertEqual(len(urls), 1)
                            url = urls[0]
                            self.assertFalse(url.startswith(('/', 'assets/')))
                            consumer_url = urljoin(base, name)
                            resolved = urljoin(consumer_url, url)
                            self.assertTrue(resolved.startswith(base))
                            target = unquote(resolved[len(base):])
                            self.assertIn(target, set(files), (name, variable, resolved))
                            self.assertTrue(files[target].startswith(b'\xff\xd8'))
                    for name, data in files.items():
                        if name.endswith('.html'):
                            self.assertIn(('link', 'href', 'assets/variant.css'), Document(data).links)

    def test_curated_variants_change_palette_composition_crop_order_and_title(self):
        for template in premium.TEMPLATES:
            files = [premium.expected_files(self.manifest(template, n)) for n in range(12)]
            self.assertGreater(len({f['assets/variant.css'] for f in files}), 3)
            self.assertGreater(len({re.search(rb'layout-([01])', f['index.html']).group(1)
                                    for f in files}), 1)
            self.assertGreater(len({tuple(re.findall(rb'href="(article-[^"]+)"', f['notes.html']))
                                    for f in files}), 3)
            self.assertGreater(len({re.search(rb'<title>(.*?)</title>', f['index.html']).group(1)
                                    for f in files}), 1)
        variants = [premium.expected_files(self.manifest('north', n))['assets/variant.css'] for n in range(12)]
        self.assertGreater(len({re.search(rb'--hero-image:([^;]+)', v).group(1) for v in variants}), 1)

    def test_automatic_title_is_escaped_and_user_title_is_not_an_input(self):
        original = premium.THEMES['still']['names']
        try:
            premium.THEMES['still']['names'] = ('ROOM & <LIGHT> "QUIET"',)
            files = premium.expected_files(self.manifest('still'))
        finally:
            premium.THEMES['still']['names'] = original
        for name, data in files.items():
            if name.endswith('.html'):
                self.assertIn(b'ROOM &amp; &lt;LIGHT&gt; &quot;QUIET&quot;', data)
                self.assertNotIn(b'<LIGHT>', data)
        with self.assertRaises(ValueError):
            premium.expected_files(dict(self.manifest(), title='arbitrary'))

    def test_no_js_readability_reduced_motion_and_trusted_script(self):
        files = premium.expected_files(self.manifest())
        css = files['assets/premium.css'].decode()
        script = files['assets/enhance.js'].decode()
        self.assertIn('prefers-reduced-motion:reduce', css)
        self.assertIn('animation:none!important', css)
        self.assertIn('transition:none!important', css)
        self.assertIn('prefers-reduced-motion: reduce', script)
        self.assertIn('!media.matches', script)
        self.assertNotIn('innerHTML', script)
        self.assertNotRegex(script, r'\b(fetch|XMLHttpRequest|WebSocket|eval)\s*\(')
        self.assertNotIn("classList.add('js')", script)
        self.assertIn('.menu summary', css)
        self.assertIn('details', files['index.html'].decode())
        self.assertNotIn('display:none', files['index.html'].decode())

    def test_assets_are_fully_enumerated_licensed_and_true_type(self):
        self.assertEqual(set(premium.ASSET_FILES), {p.name for p in premium.ASSET_ROOT.iterdir()})
        self.assertEqual(len(premium.ASSET_FILES), len(set(premium.ASSET_FILES)))
        files = premium.expected_files(self.manifest('still'))
        for name in ('Manrope.ttf', 'CormorantGaramond.ttf', 'CormorantGaramond-Italic.ttf'):
            self.assertEqual(files['assets/' + name][:4], b'\0\1\0\0')
        self.assertNotIn('woff2', files['assets/fonts.css'].decode())
        for name in ('Manrope-OFL.txt', 'CormorantGaramond-OFL.txt'):
            self.assertIn(b'SIL OPEN FONT LICENSE Version 1.1', files['assets/' + name])
        sources = files['assets/ASSET-SOURCES.txt'].decode()
        self.assertEqual(sources.count('https://images.unsplash.com/photo-'), 7)
        self.assertIn('UNVERIFIED', sources)
        self.assertIn('HTTP 401', sources)
        self.assertIn('798 x 997', sources)
        self.assertIn('кадрирована', files['about.html'].decode())
        self.assertNotIn('В интерьерной фотографии есть настенные изображения', files['about.html'].decode())
        self.assertEqual(_jpeg_dimensions(files['assets/interior.jpg']), (798, 997))

    def test_generate_and_copy_exact_bytes_for_three_families(self):
        for template in premium.TEMPLATES:
            manifest = self.manifest(template)
            source, output = self.root / template, self.root / (template + '-copy')
            expected = premium.expected_files(manifest)
            self.assertEqual(premium.generate(manifest, source), source)
            self.assertEqual(premium.copy_generated(source, output, manifest), output)
            for tree in (source, output):
                actual = {p.relative_to(tree).as_posix(): p.read_bytes()
                          for p in tree.rglob('*') if p.is_file()}
                self.assertEqual(actual, expected)
                if os.name != 'nt':
                    self.assertEqual(tree.stat().st_mode & 0o777, 0o755)
                    self.assertTrue(all(p.stat().st_mode & 0o777 == 0o644
                                        for p in tree.rglob('*') if p.is_file()))
        self.assertFalse(list(self.root.glob('.premium-staging-*')))

    def test_trusted_js_tampering_same_length_is_rejected(self):
        manifest, source = self.generated()
        script = source / 'assets/enhance.js'
        data = script.read_bytes()
        script.write_bytes(data.replace(b'use strict', b'bad strict'))
        self.assertEqual(script.stat().st_size, len(data))
        self.assert_rejected(source, manifest)

    def test_arbitrary_script_marker_hidden_extra_and_empty_directory_rejected(self):
        manifest, source = self.generated()
        for extra in ('assets/other.js', 'trusted.sha256', 'premium-manifest.json', '.hidden'):
            with self.subTest(extra=extra):
                path = source / extra
                path.write_bytes(b'not authority')
                self.assert_rejected(source, manifest)
                path.unlink()
        empty = source / 'empty'
        empty.mkdir()
        self.assert_rejected(source, manifest)
        empty.rmdir()
        (source / 'notes.html').unlink()
        self.assert_rejected(source, manifest)

    def test_html_photo_and_manifest_tampering_rejected(self):
        manifest, source = self.generated()
        for name in ('index.html', 'assets/forest.jpg', 'assets/fonts.css'):
            path = source / name
            data = path.read_bytes()
            path.write_bytes(bytes([data[0] ^ 1]) + data[1:])
            self.assert_rejected(source, manifest)
            path.write_bytes(data)
        self.assert_rejected(source, self.manifest(number=1))
        self.assert_rejected(source, self.manifest('still'))

    def test_no_overwrite_and_no_overlapping_paths(self):
        manifest, source = self.generated()
        output = self.root / 'output'
        output.mkdir()
        (output / 'sentinel').write_bytes(b'keep')
        for operation in (lambda: premium.generate(manifest, output),
                          lambda: premium.copy_generated(source, output, manifest),
                          lambda: premium.copy_generated(source, source, manifest),
                          lambda: premium.copy_generated(source, source / 'child', manifest)):
            with self.assertRaises(premium.SiteError):
                operation()
        self.assertEqual((output / 'sentinel').read_bytes(), b'keep')
        self.assertFalse((source / 'child').exists())

    def test_publish_uses_atomic_no_replace_and_cleans_on_failure(self):
        manifest = self.manifest()
        output = self.root / 'output'
        original = premium.site_tool.rename_no_replace
        with mock.patch.object(premium.site_tool, 'rename_no_replace', wraps=original) as rename:
            premium.generate(manifest, output)
            rename.assert_called_once()
        failed = self.root / 'failed'
        with mock.patch.object(premium.site_tool, 'rename_no_replace', side_effect=OSError('unavailable')):
            with self.assertRaises(OSError):
                premium.generate(manifest, failed)
        self.assertFalse(failed.exists())
        self.assertFalse(list(self.root.glob('.premium-staging-*')))

    def test_output_race_never_replaces_destination(self):
        manifest = self.manifest()
        output = self.root / 'raced'
        original = premium.site_tool.rename_no_replace

        def race(source, target):
            target.mkdir()
            (target / 'sentinel').write_bytes(b'concurrent owner')
            original(source, target)

        with mock.patch.object(premium.site_tool, 'rename_no_replace', side_effect=race):
            with self.assertRaises((premium.SiteError, OSError)):
                premium.generate(manifest, output)
        self.assertEqual((output / 'sentinel').read_bytes(), b'concurrent owner')
        self.assertFalse((output / 'index.html').exists())
        self.assertFalse(list(self.root.glob('.premium-staging-*')))

    def test_symlinks_files_directories_and_ancestors_rejected(self):
        manifest, source = self.generated()
        original = source / 'notes.html'
        outside = self.root / 'outside.html'
        original.rename(outside)
        try:
            original.symlink_to(outside)
        except OSError as error:
            outside.rename(original)
            self.skipTest('Symlink creation unavailable: ' + str(error))
        self.assert_rejected(source, manifest)
        original.unlink()
        outside.rename(original)
        linked = self.root / 'linked'
        linked.symlink_to(source, target_is_directory=True)
        self.assert_rejected(linked, manifest)
        with self.assertRaises(premium.SiteError):
            premium.generate(manifest, linked / 'nested')

    def test_hardlinks_rejected(self):
        manifest, source = self.generated()
        outside = self.root / 'hardlink.html'
        try:
            os.link(source / 'notes.html', outside)
        except OSError as error:
            self.skipTest('Hard-link creation unavailable: ' + str(error))
        self.assert_rejected(source, manifest)

    @unittest.skipUnless(os.name == 'nt', 'Windows file attributes')
    def test_hidden_expected_asset_and_source_directory_rejected(self):
        manifest, source = self.generated()
        kernel = ctypes.WinDLL('kernel32', use_last_error=True)
        setter = kernel.SetFileAttributesW
        setter.argtypes = [ctypes.c_wchar_p, ctypes.c_uint32]
        setter.restype = ctypes.c_int
        for path in (source / 'assets/enhance.js', source / 'assets', source):
            with self.subTest(path=path.name):
                self.assertTrue(setter(str(path), 2))
                try:
                    self.assert_rejected(source, manifest)
                finally:
                    self.assertTrue(setter(str(path), 0x80))

    def test_private_runtime_has_no_preview_dependency(self):
        runtime = self.root / 'runtime'
        runtime.mkdir()
        assets = runtime / 'premium_assets'
        assets.mkdir()
        module_path = runtime / 'premium_site.py'
        module_path.write_bytes(Path(premium.__file__).read_bytes())
        (runtime / 'site.py').write_bytes(Path(premium.site_tool.__file__).read_bytes())
        for name in premium.ASSET_FILES:
            (assets / name).write_bytes((premium.ASSET_ROOT / name).read_bytes())
        import importlib.util
        spec = importlib.util.spec_from_file_location('isolated_premium', module_path)
        isolated = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(isolated)
        self.assertFalse((runtime / 'design-preview').exists())
        for template in premium.TEMPLATES:
            manifest = self.manifest(template)
            self.assertEqual(isolated.expected_files(manifest), premium.expected_files(manifest))

    def test_source_entry_added_during_read_is_rejected(self):
        manifest, source = self.generated()
        original = premium.site_tool.read_regular
        inserted = False

        def changed(path, expected):
            nonlocal inserted
            data = original(path, expected)
            if Path(path).parent == source and not inserted:
                inserted = True
                (source / 'surprise.txt').write_bytes(b'extra')
            return data

        with mock.patch.object(premium.site_tool, 'read_regular', side_effect=changed):
            self.assert_rejected(source, manifest)
        self.assertTrue(inserted)

    def test_legacy_validator_still_rejects_javascript(self):
        _, source = self.generated()
        with self.assertRaises(premium.SiteError):
            premium.site_tool.validate(source)


if __name__ == '__main__':
    unittest.main()
