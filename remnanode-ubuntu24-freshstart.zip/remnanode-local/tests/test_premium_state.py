from contextlib import ExitStack
import io
import json
import os
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

import manage
import premium_state


class PremiumStateTests(unittest.TestCase):
    def setUp(self):
        self.stack = ExitStack()
        self.addCleanup(self.stack.close)
        self.tmp = self.stack.enter_context(tempfile.TemporaryDirectory())
        self.root = Path(self.tmp)
        self.directory = self.root / 'private'
        self.manifest = self.directory / 'premium-manifest.json'
        self.stack.enter_context(patch.object(premium_state, 'DIRECTORY', self.directory))
        self.stack.enter_context(patch.object(premium_state, 'MANIFEST', self.manifest))
        self.stack.enter_context(patch.object(manage, 'secure_path', side_effect=lambda p, **kw: Path(p)))
        original_stat = Path.stat
        def private_stat(path, *args, **kwargs):
            result = original_stat(path, *args, **kwargs)
            if path == self.directory or path == self.manifest:
                values = list(result)
                values[0] &= ~0o077
                return os.stat_result(values)
            return result
        self.stack.enter_context(patch.object(Path, 'stat', new=private_stat))
        self.stack.enter_context(patch('sys.stdout', new_callable=io.StringIO))
        self.stack.enter_context(patch('builtins.input', side_effect=AssertionError('No prompts expected')))

    def test_new_offline_has_no_questions_and_replays_exactly(self):
        path = premium_state.prepare('north')
        first = path.read_bytes()
        self.assertEqual(json.loads(first)['template'], 'north')
        self.assertEqual(premium_state.prepare('north').read_bytes(), first)
        self.assertFalse((self.directory / 'request.json').exists())

    def test_different_template_requires_explicit_switch(self):
        premium_state.prepare('still')
        old = self.manifest.read_bytes()
        with self.assertRaises(manage.Failure):
            premium_state.prepare('ritual')
        self.assertEqual(self.manifest.read_bytes(), old)

    def test_legacy_state_is_not_changed(self):
        self.directory.mkdir()
        os.chmod(self.directory, 0o700)
        legacy = self.directory / 'site-manifest.json'
        legacy.write_text('legacy-do-not-change', encoding='utf-8')
        premium_state.prepare('ritual')
        self.assertEqual(legacy.read_text(), 'legacy-do-not-change')

    def test_corrupt_manifest_is_not_replaced(self):
        self.directory.mkdir()
        os.chmod(self.directory, 0o700)
        self.manifest.write_text('{broken', encoding='utf-8')
        os.chmod(self.manifest, 0o600)
        with self.assertRaises(manage.Failure):
            premium_state.prepare('north')
        self.assertEqual(self.manifest.read_text(), '{broken')
