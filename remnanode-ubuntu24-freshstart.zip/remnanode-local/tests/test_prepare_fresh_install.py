from contextlib import ExitStack
from pathlib import Path
from types import SimpleNamespace
import tempfile
import unittest
from unittest.mock import patch

import prepare_fresh_install as f


class FreshStartTests(unittest.TestCase):
    def setUp(self):
        self.stack = ExitStack()
        self.addCleanup(self.stack.close)
        self.tmp = self.stack.enter_context(tempfile.TemporaryDirectory())
        self.root = Path(self.tmp)
        self.node = self.root / 'node'
        self.node.mkdir()
        self.marker = self.node / 'compose.yml'
        self.marker.write_text('sensitive-not-to-print')
        self.stack.enter_context(patch.object(f, 'PATHS', (str(self.node),)))
        self.stack.enter_context(patch.object(f, 'safe', side_effect=lambda p, **kw: Path(p)))
        self.stack.enter_context(patch.object(f.shutil, 'which', return_value='/usr/bin/docker'))
        self.run = self.stack.enter_context(patch.object(f, 'command', side_effect=self.command))
        self.containers = ''
        self.timers = ''
        self.state = 'unknown'
        self.audit = ''
        self.original_lexists = f.os.path.lexists
        self.stack.enter_context(patch.object(f.os.path, 'lexists', side_effect=self.lexists))

    def lexists(self, path):
        if str(path) in ('/usr/sbin/policy-rc.d', '/usr/local/bin/selfsteal', '/usr/local/lib/remnanode-manager'):
            return False
        return self.original_lexists(path)

    def command(self, args, allowed=(0,)):
        if args[:3] == ['docker', 'ps', '-aq']:
            return SimpleNamespace(stdout=self.containers)
        if args[:2] == ['systemctl', 'list-units']:
            return SimpleNamespace(stdout=self.timers)
        if args[:2] == ['systemctl', 'is-active']:
            return SimpleNamespace(stdout=self.state)
        if args == ['dpkg', '--audit']:
            return SimpleNamespace(stdout=self.audit)
        self.fail('Unexpected command ' + repr(args))

    def test_readonly_precheck_returns_known_paths_without_deleting(self):
        self.assertEqual(f.checks(), [self.node])
        self.assertTrue(self.marker.exists())
        for entry in self.run.call_args_list:
            self.assertNotIn('rm', entry.args[0])
            self.assertNotIn('prune', entry.args[0])

    def test_existing_containers_prevent_reset(self):
        self.containers = 'abc123'
        with self.assertRaisesRegex(RuntimeError, 'контейнеры'):
            f.checks()
        self.assertTrue(self.marker.exists())

    def test_running_recovery_timer_prevents_reset(self):
        self.timers = 'remnanode-ufw-rollback-123.timer active'
        with self.assertRaisesRegex(RuntimeError, 'таймер'):
            f.checks()

    def test_active_fail2ban_not_stopped(self):
        self.state = 'active'
        with self.assertRaisesRegex(RuntimeError, 'Fail2ban'):
            f.checks()
        self.assertTrue(all('stop' not in entry.args[0] for entry in self.run.call_args_list))

    def test_dpkg_audit_requires_manual_recovery(self):
        self.audit = 'package not configured'
        with self.assertRaisesRegex(RuntimeError, 'dpkg'):
            f.checks()
