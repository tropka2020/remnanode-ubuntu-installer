import contextlib
import importlib.util
import io
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

spec = importlib.util.spec_from_file_location('content_manage', Path(__file__).parents[1] / 'manage.py')
manage = importlib.util.module_from_spec(spec)
spec.loader.exec_module(manage)
IMAGE = 'caddy@sha256:' + 'a' * 64


class ContentCommandTests(unittest.TestCase):
    def test_content_and_source_are_mutually_exclusive(self):
        with contextlib.redirect_stderr(io.StringIO()):
            for command in ('install-web', 'publish-site'):
                args = [command, '--domain', 'example.org', '--source', 'site', '--content', 'owner.json']
                if command == 'install-web':
                    args += ['--image', IMAGE]
                with self.subTest(command=command), self.assertRaises(SystemExit):
                    manage.parser().parse_args(args)

    def test_generate_before_dispatch_and_clean_staging(self):
        for command, target in (('install-web', 'install_web'), ('publish-site', 'publish_site')):
            with self.subTest(command=command), tempfile.TemporaryDirectory() as parent:
                args = [command, '--domain', 'example.org', '--content', 'owner.json', '--apply']
                if command == 'install-web':
                    args += ['--image', IMAGE]
                real_temporary = tempfile.TemporaryDirectory
                seen = []
                def temporary(**kwargs):
                    self.assertEqual(kwargs['dir'], '/opt')
                    return real_temporary(prefix=kwargs['prefix'], dir=parent)
                def generate(*values):
                    self.assertEqual(values[:3], ('generate', '--content', 'owner.json'))
                    output = Path(values[-1])
                    output.mkdir()
                    (output / 'index.html').write_text('owner page', encoding='utf-8')
                    seen.append(output)
                def dispatch(config):
                    self.assertTrue(Path(config.source).is_dir())
                    self.assertEqual(Path(config.source), seen[0])
                with patch.object(manage.os, 'umask'), patch.object(manage.signal, 'signal'), \
                        patch.object(manage, 'requirements'), patch.object(manage, 'lock'), \
                        patch.object(manage, 'secure_path'), \
                        patch.object(manage.tempfile, 'TemporaryDirectory', side_effect=temporary), \
                        patch.object(manage, 'site_tool', side_effect=generate), \
                        patch.object(manage, target, side_effect=dispatch), \
                        patch('sys.argv', ['manage.py', *args]):
                    manage.main()
                self.assertFalse(seen[0].parent.exists())

    def test_failed_generation_never_dispatches(self):
        with tempfile.TemporaryDirectory() as parent:
            real_temporary = tempfile.TemporaryDirectory
            def temporary(**kwargs):
                return real_temporary(prefix=kwargs['prefix'], dir=parent)
            with patch.object(manage.os, 'umask'), patch.object(manage.signal, 'signal'), \
                    patch.object(manage, 'requirements'), patch.object(manage, 'lock'), \
                    patch.object(manage, 'secure_path'), \
                    patch.object(manage.tempfile, 'TemporaryDirectory', side_effect=temporary), \
                    patch.object(manage, 'site_tool', side_effect=manage.Failure('bad content')), \
                    patch.object(manage, 'publish_site') as dispatch, \
                    patch('sys.argv', ['manage.py', 'publish-site', '--domain', 'example.org',
                                       '--content', 'bad.json', '--apply']):
                with self.assertRaises(manage.Failure):
                    manage.main()
                dispatch.assert_not_called()
            self.assertEqual(list(Path(parent).iterdir()), [])
