"""Safe design registry tests: temporary SQLite and loopback-only HTTP."""
import contextlib
import http.client
import json
from pathlib import Path
import tempfile
import threading
from concurrent.futures import ThreadPoolExecutor
import unittest
import uuid

import design_catalog as catalog
import design_registry as registry


TOKEN = "R" * 40


class RegistryCoreTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory(prefix="design-registry-test-")
        self.root = Path(self.tmp.name)
        self.root.chmod(0o700)
        self.db = self.root / "designs.sqlite3"

    def tearDown(self):
        self.tmp.cleanup()

    def test_catalog_has_144_structural_compositions(self):
        values = catalog.all_compositions()
        self.assertEqual(len(values), 144)
        self.assertEqual(len({catalog.composition_key(v) for v in values}), 144)

    def test_initialize_reserve_and_idempotency(self):
        registry.initialize(self.db)
        request = str(uuid.uuid4())
        first = registry.reserve(self.db, request)
        again = registry.reserve(self.db, request)
        other = registry.reserve(self.db, str(uuid.uuid4()))
        self.assertEqual(first, again)
        self.assertNotEqual(first['composition'], other['composition'])
        catalog.validate_manifest(first)

    def test_twenty_concurrent_distinct_requests_have_no_duplicate_compositions(self):
        registry.initialize(self.db)
        requests = [str(uuid.uuid4()) for _ in range(20)]
        ready = threading.Barrier(20, timeout=10)

        def reserve_together(request):
            ready.wait()
            return registry.reserve(self.db, request)

        with ThreadPoolExecutor(max_workers=20) as pool:
            manifests = list(pool.map(reserve_together, requests))
        self.assertEqual(len({catalog.composition_key(m['composition']) for m in manifests}), 20)
        self.assertEqual(len({m['reservation_id'] for m in manifests}), 20)
        with contextlib.closing(registry.open_db(self.db)) as connection:
            self.assertEqual(connection.execute('SELECT COUNT(*) FROM reservations').fetchone()[0], 20)
        self.assertEqual({m['request_id'] for m in manifests}, set(requests))

    def test_same_uuid_concurrency_returns_one_identical_result(self):
        registry.initialize(self.db)
        request = str(uuid.uuid4())
        ready = threading.Barrier(20, timeout=10)

        def reserve_together(_):
            ready.wait()
            return registry.reserve(self.db, request)

        with ThreadPoolExecutor(max_workers=20) as pool:
            manifests = list(pool.map(reserve_together, range(20)))
        self.assertEqual(len({json.dumps(m, sort_keys=True) for m in manifests}), 1)
        self.assertEqual(manifests[0], registry.reserve(self.db, request))

    def test_exhaustion_after_all_144_compositions_never_reuses_one(self):
        registry.initialize(self.db)
        with ThreadPoolExecutor(max_workers=16) as pool:
            manifests = list(pool.map(lambda _: registry.reserve(self.db, str(uuid.uuid4())), range(144)))
        self.assertEqual(len({catalog.composition_key(m['composition']) for m in manifests}), 144)
        for _ in range(2):
            with self.assertRaises(registry.Exhausted):
                registry.reserve(self.db, str(uuid.uuid4()))
        registry.initialize(self.db)
        self.assertEqual(registry.reserve(self.db, manifests[0]['request_id']), manifests[0])
        with contextlib.closing(registry.open_db(self.db)) as connection:
            self.assertEqual(connection.execute('SELECT COUNT(*) FROM reservations').fetchone()[0], 144)

    def test_existing_unknown_database_is_not_reset(self):
        self.db.write_text('not sqlite', encoding='utf-8')
        with self.assertRaises(registry.RegistryError):
            registry.initialize(self.db)
        self.assertEqual(self.db.read_text(encoding='utf-8'), 'not sqlite')

    def test_corrupt_manifest_history_is_rejected(self):
        registry.initialize(self.db)
        with contextlib.closing(registry.open_db(self.db)) as connection:
            connection.execute('UPDATE metadata SET value=? WHERE key=?', ('other', 'version'))
        with self.assertRaises(registry.RegistryError):
            registry.reserve(self.db, str(uuid.uuid4()))

    def test_corrupt_schema_and_row_are_refused_without_reinitialization(self):
        registry.initialize(self.db)
        with contextlib.closing(registry.open_db(self.db)) as connection:
            connection.execute('DROP TABLE reservations')
        with self.assertRaises(registry.RegistryError):
            registry.initialize(self.db)
        with contextlib.closing(registry.open_db(self.db)) as connection:
            tables = {row[0] for row in connection.execute("SELECT name FROM sqlite_master WHERE type='table'")}
        self.assertNotIn('reservations', tables)

    def test_corrupt_manifest_payload_is_rejected(self):
        registry.initialize(self.db)
        request = str(uuid.uuid4())
        registry.reserve(self.db, request)
        with contextlib.closing(registry.open_db(self.db)) as connection:
            connection.execute('UPDATE reservations SET manifest=? WHERE request_id=?', ('{}', request))
        with self.assertRaises(registry.RegistryError):
            registry.reserve(self.db, request)

    def test_manifest_request_and_composition_history_mismatch_are_refused(self):
        registry.initialize(self.db)
        request = str(uuid.uuid4())
        original = registry.reserve(self.db, request)
        for field, value in (('request_id', str(uuid.uuid4())), ('seed', 'bad')):
            with self.subTest(field=field):
                payload = dict(original, **{field: value})
                with contextlib.closing(registry.open_db(self.db)) as connection:
                    connection.execute('UPDATE reservations SET manifest=? WHERE request_id=?',
                                       (json.dumps(payload), request))
                with self.assertRaises(registry.RegistryError):
                    registry.reserve(self.db, str(uuid.uuid4()))
        with contextlib.closing(registry.open_db(self.db)) as connection:
            connection.execute('UPDATE reservations SET manifest=?, composition_key=? WHERE request_id=?',
                               (json.dumps(original), 'wrong-key', request))
        with self.assertRaises(registry.RegistryError):
            registry.reserve(self.db, request)

    def test_invalid_request_is_rejected(self):
        registry.initialize(self.db)
        for value in ('not-uuid', '', None, str(uuid.uuid4()).upper()):
            with self.subTest(value=value), self.assertRaises(registry.RegistryError):
                registry.reserve(self.db, value)


class LoopbackHTTPTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory(prefix="design-registry-http-")
        self.root = Path(self.tmp.name)
        self.root.chmod(0o700)
        self.db = self.root / "designs.sqlite3"
        registry.initialize(self.db)
        self.server = registry.RegistryServer(('127.0.0.1', 0), self.db, TOKEN)
        self.thread = threading.Thread(target=self.server.serve_forever, daemon=True)
        self.thread.start()
        self.host, self.port = self.server.server_address

    def tearDown(self):
        self.server.shutdown()
        self.server.server_close()
        self.thread.join(timeout=5)
        self.tmp.cleanup()

    def request(self, method, path, body=None, headers=None):
        connection = http.client.HTTPConnection(self.host, self.port, timeout=5)
        connection.request(method, path, body=body, headers=headers or {})
        response = connection.getresponse()
        payload = response.read()
        status = response.status
        connection.close()
        return status, json.loads(payload)

    def post(self, token=TOKEN, path='/v1/reserve', payload=None, extra=None):
        payload = payload or {'version': catalog.VERSION, 'request_id': str(uuid.uuid4())}
        body = json.dumps(payload).encode()
        headers = {'Authorization': 'Bearer ' + token, 'Content-Type': 'application/json',
                   'Content-Length': str(len(body))}
        if extra:
            headers.update(extra)
        return self.request('POST', path, body, headers)

    def test_health_and_authenticated_reserve_post_actual_loopback(self):
        status, data = self.request('GET', '/health', headers={'Authorization': 'Bearer ' + TOKEN})
        self.assertEqual((status, data), (200, {'version': catalog.VERSION}))
        request_id = str(uuid.uuid4())
        payload = {'version': catalog.VERSION, 'request_id': request_id}
        status, data = self.post(payload=payload)
        self.assertEqual(status, 200)
        self.assertEqual(data['version'], catalog.VERSION)
        self.assertEqual(data['request_id'], request_id)
        catalog.validate_manifest(data)
        self.assertEqual(self.post(payload=payload), (200, data))

    def test_authentication_and_route_are_enforced(self):
        for headers in ({}, {'Authorization': 'Bearer wrong'}):
            with self.subTest(headers=headers):
                status, data = self.request('GET', '/health', headers=headers)
                self.assertEqual((status, data['error']), (401, 'unauthorized'))
        status, data = self.post(path='/other')
        self.assertEqual((status, data['error']), (404, 'not_found'))

    def test_duplicate_authorization_headers_are_rejected(self):
        with contextlib.closing(http.client.HTTPConnection(self.host, self.port, timeout=5)) as connection:
            connection.putrequest('GET', '/health')
            connection.putheader('Authorization', 'Bearer ' + TOKEN)
            connection.putheader('Authorization', 'Bearer ' + TOKEN)
            connection.endheaders()
            response = connection.getresponse()
            self.assertEqual(response.status, 401)
            self.assertEqual(json.loads(response.read()), {'error': 'unauthorized'})

    def test_post_requires_auth_before_reservation(self):
        status, data = self.post(token='wrong')
        self.assertEqual((status, data), (401, {'error': 'unauthorized'}))
        with contextlib.closing(registry.open_db(self.db)) as connection:
            self.assertEqual(connection.execute('SELECT COUNT(*) FROM reservations').fetchone()[0], 0)

    def test_post_rejects_bad_content_length_transfer_encoding_and_payload(self):
        cases = [
            ({'Content-Length': '0'}, b''),
            ({'Content-Length': 'abc'}, b'{}'),
            ({'Content-Length': '1', 'Transfer-Encoding': 'chunked'}, b'{}'),
            ({'Content-Length': '2', 'Content-Type': 'text/plain'}, b'{}'),
            ({'Content-Length': '2', 'Content-Type': 'application/json'}, b'{}'),
        ]
        for extra, body in cases:
            with self.subTest(extra=extra):
                headers = {'Authorization': 'Bearer ' + TOKEN, 'Content-Type': 'application/json'}
                headers.update(extra)
                status, data = self.request('POST', '/v1/reserve', body, headers)
                self.assertEqual((status, data['error']), (400, 'invalid_request'))

    def test_loopback_bind_is_mandatory(self):
        with self.assertRaises(registry.RegistryError):
            registry.RegistryServer(('0.0.0.0', 0), self.db, TOKEN)

    def test_exhaustion_is_http_409_and_does_not_auto_reuse(self):
        # Keep this HTTP-path check sequential; the server intentionally caps
        # active handlers at 16 and rejects excess sockets without a response.
        responses = [self.post() for _ in range(144)]
        self.assertEqual(sum(status == 200 for status, _ in responses), 144)
        status, data = self.post()
        self.assertEqual((status, data), (409, {'error': 'exhausted'}))


if __name__ == '__main__':
    unittest.main()
