"""Runtime installation contracts: temporary files only; no system commands."""
from contextlib import ExitStack
import importlib.util
import os
from pathlib import Path
import shlex
import stat
import sys
import tempfile
import unittest
from unittest.mock import patch

PROJECT = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location('runtime_under_test', PROJECT / 'command_runtime.py')
runtime = importlib.util.module_from_spec(spec)
spec.loader.exec_module(runtime)


class RuntimeTests(unittest.TestCase):
    def setUp(self):
        self.stack = ExitStack()
        self.addCleanup(self.stack.close)
        self.root = Path(self.stack.enter_context(tempfile.TemporaryDirectory()))
        self.source = self.root / 'download with spaces'
        self.source.mkdir()
        (self.source / 'premium_assets').mkdir()
        self.target = self.root / 'lib with spaces' / 'remnanode-manager'
        self.wrapper = self.root / 'bin' / 'selfsteal'
        self.wrapper.parent.mkdir()
        for name, value in (('RUNTIME', self.target), ('WRAPPER', self.wrapper)):
            self.stack.enter_context(patch.object(runtime, name, value))
        self.root_guard = self.stack.enter_context(patch.object(runtime, 'require_root'))
        self.secure = self.stack.enter_context(patch.object(runtime.m, 'secure_path', side_effect=self.safe))
        for name in runtime.MODULES:
            (self.source / name).write_bytes(('module ' + name).encode())
        (self.source / 'premium_site.py').write_text('ASSET_FILES = ' + repr(runtime.ASSET_FILES))
        for name in runtime.ASSET_FILES:
            (self.source / 'premium_assets' / name).write_bytes(('asset ' + name).encode())

    def safe(self, path, *, directory=None):
        path = Path(path)
        self.assertTrue(path.absolute().is_relative_to(self.root))
        if path.is_symlink():
            raise runtime.m.Failure('symlink')
        if path.exists() and directory is not None and path.is_dir() != directory:
            raise runtime.m.Failure('wrong type')
        return path

    def test_exact_allowlist_and_source_independent_wrapper(self):
        for name in ('registry.key', 'private.md', 'old.zip', 'design_state.py'):
            (self.source / name).write_text('must not copy')
        (self.source / 'premium_assets' / 'untrusted.tmp').write_text('must not copy')
        runtime.install_runtime(self.source)
        actual = {p.relative_to(self.target).as_posix() for p in self.target.rglob('*') if p.is_file()}
        expected = set(runtime.MODULES) | {'.managed-runtime'} | {
            'premium_assets/' + name for name in runtime.ASSET_FILES}
        self.assertEqual(actual, expected)
        text = self.wrapper.read_text()
        self.assertIn(shlex.quote(str(self.target / 'selfsteal.py')), text)
        self.assertNotIn(str(self.source), text)
        self.assertIn('"$@"', text)
        self.assertIn(runtime.MARKER, text)
        self.root_guard.assert_called_once_with()

    def test_uses_only_generator_explicit_export_not_directory_glob(self):
        (self.source / 'premium_site.py').write_text("ASSET_FILES = ('new-trusted.css',)\n")
        (self.source / 'premium_assets' / 'new-trusted.css').write_bytes(b'trusted')
        runtime.install_runtime(self.source)
        self.assertEqual([p.name for p in (self.target / 'premium_assets').iterdir()], ['new-trusted.css'])

    def test_unsafe_asset_export_rejected_before_runtime_changes(self):
        (self.source / 'premium_site.py').write_text("ASSET_FILES = ('../registry.key',)\n")
        with self.assertRaises(runtime.m.Failure):
            runtime.install_runtime(self.source)
        self.assertFalse(self.target.exists())
        self.assertFalse(self.wrapper.exists())

    def test_real_runtime_imports_and_generates_without_original_download(self):
        import shutil
        for name in runtime.MODULES:
            shutil.copyfile(PROJECT / name, self.source / name)
        for name in runtime.ASSET_FILES:
            shutil.copyfile(PROJECT / 'premium_assets' / name, self.source / 'premium_assets' / name)
        runtime.install_runtime(self.source)
        shutil.rmtree(self.source)
        # Import only installed files. No subprocess, service, network or source path.
        with patch.dict(sys.modules), patch.object(sys, 'path', [str(self.target), *sys.path]):
            for name in ('manage', 'progress', 'premium_site'):
                sys.modules.pop(name, None)
            installed_spec = importlib.util.spec_from_file_location('installed_selfsteal', self.target / 'selfsteal.py')
            installed = importlib.util.module_from_spec(installed_spec)
            installed_spec.loader.exec_module(installed)
            premium = installed._premium()
            self.assertEqual(set(premium.ASSET_FILES), set(runtime.ASSET_FILES))
            self.assertEqual(Path(installed.m.__file__).parent, self.target)
            self.assertEqual(Path(premium.__file__).parent, self.target)
            manifest = premium.new_manifest('north')
            expected = premium.expected_files(manifest)
            output = premium.generate(manifest, self.root / 'generated')
            premium.copy_generated(output, self.root / 'verified', manifest)
            self.assertEqual((output / 'index.html').read_bytes(), expected['index.html'])

    def test_managed_runtime_can_be_updated_and_reinstalled_from_itself(self):
        runtime.install_runtime(self.source)
        (self.source / 'selfsteal.py').write_bytes(b'updated')
        runtime.install_runtime(self.source)
        self.assertEqual((self.target / 'selfsteal.py').read_bytes(), b'updated')
        runtime.install_runtime(self.target)
        self.assertEqual((self.target / 'selfsteal.py').read_bytes(), b'updated')
        runtime.check_conflict(self.source)

    def test_foreign_wrapper_refused_before_any_source_read(self):
        self.wrapper.write_text('#!/bin/sh\nforeign\n')
        original = Path.read_bytes
        def read(path):
            if path.is_relative_to(self.source):
                raise AssertionError('source read forbidden')
            return original(path)
        with patch.object(Path, 'read_bytes', new=read), self.assertRaises(runtime.m.Failure):
            runtime.install_runtime(self.source)
        self.assertFalse(self.target.exists())
        self.assertEqual(self.wrapper.read_text(), '#!/bin/sh\nforeign\n')

    def test_unknown_runtime_refused_without_changes(self):
        self.target.mkdir(parents=True)
        (self.target / 'foreign').write_text('keep')
        with self.assertRaises(runtime.m.Failure):
            runtime.install_runtime(self.source)
        self.assertEqual((self.target / 'foreign').read_text(), 'keep')
        self.assertFalse(self.wrapper.exists())

    def test_wrapper_replace_failure_restores_previous_runtime_and_wrapper(self):
        runtime.install_runtime(self.source)
        old_wrapper = self.wrapper.read_bytes()
        previous = (self.target / 'selfsteal.py').read_bytes()
        (self.source / 'selfsteal.py').write_bytes(b'new')
        with patch.object(runtime.os, 'replace', side_effect=OSError('replace failed')):
            with self.assertRaises(OSError):
                runtime.install_runtime(self.source)
        self.assertEqual(self.wrapper.read_bytes(), old_wrapper)
        self.assertEqual((self.target / 'selfsteal.py').read_bytes(), previous)

    def test_first_install_failure_leaves_no_command_or_runtime(self):
        with patch.object(runtime.os, 'replace', side_effect=OSError('replace failed')):
            with self.assertRaises(OSError):
                runtime.install_runtime(self.source)
        self.assertFalse(self.wrapper.exists())
        self.assertFalse(self.target.exists())

    def test_missing_source_file_does_not_touch_existing_runtime(self):
        runtime.install_runtime(self.source)
        previous = (self.target / 'manage.py').read_bytes()
        (self.source / 'progress.py').unlink()
        with self.assertRaises(OSError):
            runtime.install_runtime(self.source)
        self.assertEqual((self.target / 'manage.py').read_bytes(), previous)

    def test_symlink_is_rejected_before_read(self):
        try:
            self.wrapper.symlink_to(self.source / 'manage.py')
        except OSError as exc:
            self.skipTest('symlink fixture unavailable: ' + str(exc))
        with patch.object(Path, 'read_bytes', side_effect=AssertionError('must not read')):
            with self.assertRaises(runtime.m.Failure):
                runtime.check_conflict(self.source)

    @unittest.skipUnless(os.name == 'posix', 'POSIX permissions unavailable on Windows')
    def test_installed_permissions(self):
        runtime.install_runtime(self.source)
        self.assertEqual(stat.S_IMODE(self.wrapper.stat().st_mode), 0o755)
        for path in [self.target, *self.target.rglob('*')]:
            self.assertEqual(stat.S_IMODE(path.stat().st_mode), 0o755 if path.is_dir() else 0o644)

    def test_root_guard_refuses_before_preflight(self):
        self.root_guard.side_effect = runtime.m.Failure('root required')
        with self.assertRaises(runtime.m.Failure):
            runtime.install_runtime(self.source)
        self.secure.assert_not_called()


if __name__ == '__main__':
    unittest.main()
