#!/usr/bin/env python3
"""Offline editorial studio: eight composed, reproducible static publications."""
import argparse
import html
import json
from pathlib import Path
import random
import sys
import xml.etree.ElementTree as ET

import themed_site
from design_catalog import validate_manifest

CONTENT = themed_site.CONTENT
site_tool = themed_site.site_tool
SiteError = site_tool.SiteError


def esc(value):
    return html.escape(value, quote=True)


# Directions own their typography, spatial system, navigation and page hierarchy.
# These are not theme palettes: every subject can inhabit every direction.
PALETTES = {
    'editorial': ('#f3f0e7', '#24241e', '#853c29', '#e4dfd1', '#b2aa96'),
    'botanical': ('#f4f2e6', '#243d30', '#365c3e', '#e3e8d4', '#a3af94'),
    'nocturne': ('#131e26', '#f4f1e9', '#edc88d', '#23343e', '#70828a'),
    'gallery': ('#faf9f5', '#282a2a', '#79503d', '#eeeae3', '#b5ada3'),
    'reference': ('#f6f7f3', '#23352f', '#315c50', '#e5ece4', '#a3b5aa'),
    'almanac': ('#f4e9d8', '#402c23', '#87402c', '#e7d6bc', '#b8a080'),
    'notebook': ('#fbf7ed', '#313b45', '#385b72', '#e8e9df', '#a7b4b7'),
    'poster': ('#f4edcf', '#202a3c', '#793628', '#e2be71', '#ad976b'),
}

BASE_CSS = '''
* { box-sizing: border-box; }
html { color-scheme: light; scroll-padding-top: 1rem; }
body { margin: 0; background: var(--paper); color: var(--ink); font-family: Georgia, 'Times New Roman', serif; line-height: 1.7; }
a { color: var(--accent); text-underline-offset: .23em; }
a:hover { text-decoration-thickness: 2px; }
a:focus-visible, summary:focus-visible { outline: 3px solid var(--accent); outline-offset: 5px; }
img { display: block; width: 100%; max-width: 100%; height: auto; }
figure { margin: 0; min-width: 0; }
figcaption { padding-top: .65rem; font: .76rem/1.5 Arial, sans-serif; }
h1, h2, h3 { line-height: 1.08; font-weight: 400; margin: 0 0 1.1rem; letter-spacing: -.035em; }
h1 { font-size: clamp(2.8rem, 5.6vw, 6rem); }
h2 { font-size: clamp(1.8rem, 3vw, 3rem); }
h3 { font-size: 1.55rem; }
p { margin: 0 0 1.2rem; }
h1, h2, h3, p, a, li { overflow-wrap: anywhere; }
main, section, article, aside, div { min-width: 0; }
nav { display: flex; flex-wrap: wrap; gap: .65rem 1.5rem; font: .85rem/1.7 Arial, sans-serif; }
nav a { padding: .3rem 0; text-decoration: none; }
nav a[aria-current="page"] { border-bottom: 2px solid currentColor; }
.brand { color: var(--ink); font-size: 1.3rem; text-decoration: none; line-height: 1.2; }
.kicker, .meta, .index-no, .section-label { font: .72rem/1.6 Arial, sans-serif; letter-spacing: .11em; text-transform: uppercase; }
.kicker, .meta { color: var(--accent); }
.lede { font-size: 1.16rem; max-width: 42rem; }
.action { display: inline-block; font: .85rem/1.7 Arial, sans-serif; padding: .6rem 0; }
.skip { position: absolute; left: -10000px; }
.skip:focus { left: 1rem; top: 1rem; z-index: 10; background: var(--paper); padding: 1rem; }
.publication-footer { border-top: 1px solid var(--line); margin-top: 4rem; padding: 2rem 0; display: flex; flex-wrap: wrap; gap: 1rem 3rem; justify-content: space-between; font: .8rem/1.7 Arial, sans-serif; }
.publication-footer p { max-width: 28rem; }
.section-heading { border-top: 1px solid var(--line); padding: 1.5rem 0; display: flex; flex-wrap: wrap; align-items: baseline; justify-content: space-between; gap: 1rem; }
.section-heading h2 { margin: 0; }
.hero { margin-bottom: 4.5rem; }
.hero-copy { min-width: 0; }
.hero-art { overflow: hidden; }
.art-mosaic { display: grid; grid-template-columns: 1.2fr .8fr; gap: .8rem; align-items: start; }
.art-mosaic figure:first-child { grid-row: span 2; }
.art-mosaic figure:first-child img { aspect-ratio: 3 / 4; object-fit: cover; }
.art-mosaic figure:not(:first-child) img { aspect-ratio: 4 / 3; object-fit: cover; }
.type-specimen { border-top: 1px solid currentColor; border-bottom: 1px solid currentColor; padding: .6rem 0; font-size: clamp(2rem, 5vw, 5rem); line-height: 1.1; letter-spacing: -.05em; }
.type-specimen span { display: block; }
.entry { min-width: 0; }
.entry h3 a, .entry h2 a { color: var(--ink); text-decoration: none; }
.entry h3 a:hover, .entry h2 a:hover { text-decoration: underline; }
.entry-image { display: block; margin-bottom: 1rem; overflow: hidden; }
.entry-image img { aspect-ratio: 4 / 3; object-fit: cover; }
.entry-copy p { font-size: .96rem; }
.entry-copy .meta { font-size: .7rem; margin-bottom: .6rem; }
.list-cards { display: grid; grid-template-columns: repeat(3, minmax(0, 1fr)); gap: 2.2rem 1.5rem; }
.list-rows { list-style: none; margin: 0; padding: 0; }
.list-rows > li { border-top: 1px solid var(--line); padding: 1.4rem 0; }
.row-entry { display: grid; grid-template-columns: 2.3rem minmax(0, 1fr) 9rem; gap: 1.4rem; align-items: start; }
.row-entry .entry-image { grid-column: 3; grid-row: 1; margin: 0; }
.row-entry .entry-copy { grid-column: 2; grid-row: 1; }
.list-featured { display: grid; grid-template-columns: minmax(0, 1.2fr) minmax(0, 1fr); gap: 2.5rem; }
.featured-lead h3 { font-size: clamp(2rem, 3vw, 3.2rem); }
.featured-rest { list-style: none; padding: 0; margin: 0; }
.featured-rest > li { border-top: 1px solid var(--line); padding: 1rem 0; }
.small-entry { display: grid; grid-template-columns: 5rem minmax(0, 1fr); gap: 1rem; }
.small-entry h3 { font-size: 1.3rem; }
.small-entry .index-no { display: none; }
.small-entry .entry-copy > p:not(.meta), .small-entry .action { display: none; }
.caution { border-left: 3px solid var(--accent); background: var(--wash); padding: 1.5rem 2rem; margin: 3rem 0 0; }
.caution h2 { font-size: 1.4rem; }
.caution p { font-size: .94rem; margin: 0; }
.page-title { max-width: 48rem; margin-bottom: 3rem; }
.about-copy { max-width: 43rem; margin: auto; }
.about-copy h2 { font-size: 1.8rem; margin-top: 2rem; }
.breadcrumb { font: .8rem/1.7 Arial, sans-serif; margin-bottom: 2rem; }
.article-heading .lede { max-width: 42rem; }
.article-cover { margin: 2rem 0; }
.article-cover img { aspect-ratio: 16 / 9; object-fit: cover; }
.article-content h2 { font-size: 1.55rem; margin-top: 2.3rem; }
.article-content p { font-size: 1.08rem; line-height: 1.85; }
.reading-column { max-width: 43rem; margin: auto; }
.reading-split { display: grid; grid-template-columns: minmax(12rem, .7fr) minmax(0, 1.8fr); gap: 3.5rem; align-items: start; }
.reading-split .reading-guide { position: sticky; top: 2rem; }
.reading-guide { background: var(--wash); border-top: 3px solid var(--accent); padding: 1.3rem; font: .88rem/1.7 Arial, sans-serif; }
.reading-guide h2 { font: 1rem/1.4 Arial, sans-serif; letter-spacing: 0; }
.reading-guide ol { padding-left: 1.2rem; }
.reading-guide li { margin-bottom: .65rem; }
.reading-guide p { font-size: .86rem; }
.related { border-top: 1px solid var(--line); margin-top: 3rem; padding-top: 1.5rem; }
.related h2 { font-size: 1.5rem; }
.related li { margin-bottom: .7rem; }
@media (max-width: 900px) {
  .list-cards { grid-template-columns: repeat(2, minmax(0, 1fr)); }
  .reading-split { gap: 2rem; grid-template-columns: 12rem minmax(0, 1fr); }
}
'''

DIRECTION_CSS = {
    'editorial': '''
.newspaper { max-width: 1320px; margin: auto; padding: 0 4%; }
.news-utility { display: flex; justify-content: space-between; gap: 1rem; border-bottom: 1px solid var(--ink); padding: .7rem 0; }
.news-header { border-bottom: 4px double var(--ink); padding: 1.5rem 0; text-align: center; }
.news-header .brand { font-size: clamp(1.8rem, 4vw, 3.4rem); font-weight: 700; }
.news-header nav { justify-content: center; margin-top: 1.2rem; }
.news-main { padding-top: 2.5rem; }
.news-lead { display: grid; grid-template-columns: 1.2fr 1fr; gap: 2.5rem; align-items: start; }
.news-lead h1 { font-size: clamp(3.3rem, 6vw, 6.5rem); }
.news-deck { border-top: 1px solid var(--ink); padding-top: 1rem; }
.news-lead.hero-type { grid-template-columns: 1.5fr 1fr; }
.editorial .list-cards .entry { border-right: 1px solid var(--line); padding-right: 1.2rem; }
.editorial .entry .index-no { border-top: 2px solid var(--ink); display: block; margin-bottom: .8rem; padding-top: .3rem; }
.news-article > .article-heading { border-bottom: 4px double var(--ink); padding-bottom: 1rem; margin-bottom: 2rem; }
''',
    'botanical': '''
.atlas { max-width: 1250px; padding: 0 4.5%; margin: auto; }
.atlas-header { padding: 2rem 0; display: grid; grid-template-columns: 1fr auto; align-items: center; gap: 2rem; border-bottom: 1px solid var(--line); }
.atlas-seal { border: 1px solid var(--accent); width: 3.6rem; height: 3.6rem; border-radius: 50%; display: grid; place-items: center; font-size: 2rem; }
.atlas-identity { display: flex; align-items: center; gap: 1rem; }
.atlas-main { padding-top: 3.5rem; }
.atlas-hero { display: grid; grid-template-columns: 3.5rem minmax(0, 1fr) minmax(0, 1.1fr); gap: 2rem; align-items: center; }
.atlas-rail { align-self: stretch; border-right: 1px solid var(--line); writing-mode: vertical-rl; padding-right: 1rem; }
.atlas-hero .hero-art { border-radius: 48% 48% 0 0; padding: .7rem; border: 1px solid var(--line); }
.atlas-hero.hero-type { grid-template-columns: 3.5rem 1.2fr 1fr; }
.botanical .entry { padding: .8rem; border: 1px solid var(--line); background: #faf9f0; }
.botanical .entry .index-no { display: block; color: var(--accent); margin: .4rem 0; }
.botanical .row-entry { border: 0; background: transparent; }
.botanical .list-rows > li { padding: .5rem 0; }
.atlas-article { border-top: 1px solid var(--line); padding-top: 1.5rem; }
.atlas-article > .article-heading { max-width: 48rem; margin-bottom: 2rem; }
''',
    'nocturne': '''
html:has(.nocturne) { color-scheme: dark; }
.night-shell { max-width: 1440px; margin: auto; }
.night-header { display: flex; justify-content: space-between; align-items: center; gap: 2rem; padding: 2rem 5%; }
.night-header .brand { font-family: Arial, sans-serif; font-size: 1rem; letter-spacing: .03em; max-width: 24rem; }
.night-main { padding: 0 5%; }
.night-stage { margin: 0 -5.56% 4rem; background: #1c2c35; }
.night-stage .hero-art img { aspect-ratio: 2.25 / 1; object-fit: cover; }
.night-stage > .hero-copy { padding: 2.7rem 5% 3rem; display: grid; grid-template-columns: minmax(0, 1.5fr) minmax(0, 1fr); gap: 2rem; align-items: end; }
.night-stage figcaption { padding: .7rem 5%; color: #e1d7c6; }
.night-stage .art-mosaic { padding: 1.5rem 5% 0; grid-template-columns: 1.3fr 1fr 1fr; }
.night-stage .art-mosaic figure:first-child { grid-row: auto; }
.night-stage .art-mosaic img, .night-stage .art-mosaic figure:first-child img { aspect-ratio: 4 / 5; }
.night-stage.hero-type { padding-top: 2.5rem; }
.night-stage .type-specimen { margin: 0 5%; color: #edc88d; }
.nocturne h1, .nocturne h2, .nocturne h3 { font-family: Arial, sans-serif; font-weight: 400; letter-spacing: -.045em; }
.nocturne .entry-image { border: 1px solid #70828a; }
.nocturne .entry .index-no { color: #edc88d; }
.nocturne .publication-footer { margin-left: 5%; margin-right: 5%; }
.night-article > .article-cover { margin: 0 -5.56% 3rem; }
.night-article > .article-heading { max-width: 58rem; padding: 2rem 0; }
''',
    'gallery': '''
.gallery-shell { max-width: 1380px; padding: 0 6%; margin: auto; }
.gallery-header { display: grid; grid-template-columns: 1fr 1fr; gap: 3rem; padding: 3rem 0 5rem; }
.gallery-header nav { justify-content: flex-end; align-content: start; }
.gallery-header .brand { max-width: 15rem; font-family: Arial, sans-serif; font-size: 1rem; }
.gallery-exhibit { display: grid; grid-template-columns: minmax(0, .8fr) minmax(0, 1.2fr); gap: 6%; align-items: end; padding-bottom: 4rem; }
.gallery-exhibit > .hero-copy { padding-bottom: 4rem; }
.gallery-exhibit .hero-art { padding: 1.1rem; background: #fff; border: 1px solid var(--line); }
.gallery-exhibit .art-mosaic { grid-template-columns: 1fr 1fr; gap: 1.8rem; }
.gallery-exhibit .art-mosaic figure:nth-child(2) { padding-top: 3rem; }
.gallery-exhibit.hero-type { grid-template-columns: 1fr; max-width: 56rem; margin-left: 12%; }
.gallery-exhibit .type-specimen { margin-left: 24%; }
.gallery .list-cards { grid-template-columns: 1fr 1fr; gap: 5rem 8%; }
.gallery .list-cards .entry:nth-child(even) { margin-top: 5rem; }
.gallery .entry-image { padding: .75rem; background: white; border: 1px solid var(--line); }
.gallery .entry .index-no { display: block; margin: .8rem 0; }
.gallery-article > .article-heading { max-width: 46rem; margin-left: 12%; margin-bottom: 4rem; }
.gallery-article > .article-cover { max-width: 54rem; margin-left: auto; }
''',
    'reference': '''
.reference-shell { display: grid; grid-template-columns: 17rem minmax(0, 1fr); min-height: 100vh; }
.directory-sidebar { padding: 2.5rem 1.8rem; border-right: 1px solid var(--line); background: var(--wash); }
.directory-sidebar > .sidebar-inner { position: sticky; top: 2rem; }
.directory-sidebar .brand { display: block; font-size: 1.7rem; margin-bottom: 1rem; }
.directory-sidebar nav { flex-direction: column; gap: .4rem; padding: 1rem 0; border-top: 1px solid var(--line); }
.directory-index { padding-left: 1.2rem; font: .8rem/1.6 Arial, sans-serif; }
.directory-index li { margin-bottom: 1rem; }
.directory-content { padding: 2.7rem 5% 0; max-width: 1200px; }
.reference h1, .reference h2, .reference h3 { font-family: 'Trebuchet MS', Arial, sans-serif; letter-spacing: -.035em; }
.directory-hero { border: 1px solid var(--line); padding: 2rem; }
.directory-hero .hero-copy { max-width: 44rem; }
.directory-hero .hero-art { margin-top: 2rem; max-width: 38rem; }
.directory-hero .hero-art img { aspect-ratio: 2 / 1; object-fit: cover; }
.directory-hero .art-mosaic { margin-top: 2rem; }
.directory-hero .type-specimen { margin-top: 2rem; }
.reference .list-cards { grid-template-columns: repeat(2, minmax(0, 1fr)); }
.reference .entry { border-bottom: 1px solid var(--line); padding-bottom: 1rem; }
.reference .entry .index-no { background: var(--wash); display: inline-block; padding: .15rem .6rem; margin-bottom: .7rem; }
.reference .reading-split { grid-template-columns: minmax(10rem, .7fr) minmax(0, 1.5fr); gap: 2rem; }
.reference-article > .article-heading { border-bottom: 1px solid var(--line); padding-bottom: 1rem; }
''',
    'almanac': '''
.almanac-shell { max-width: 1320px; margin: auto; padding: 0 4%; }
.almanac-header { display: flex; align-items: baseline; justify-content: space-between; gap: 2rem; padding: 2rem 0; border-bottom: 1px solid var(--line); }
.almanac-header .brand { font-style: italic; font-size: 1.7rem; }
.almanac-main { padding-top: 2.5rem; }
.almanac-spread { display: grid; grid-template-columns: 1fr 1fr; background: var(--wash); }
.almanac-spread > .hero-copy { padding: clamp(1.5rem, 4vw, 4rem); align-self: center; }
.almanac-spread > .spread-plate { padding: 1.5rem; border-left: 1px solid var(--line); }
.almanac-spread .hero-art { border-radius: 48% 48% 0 0; overflow: hidden; }
.almanac-spread .hero-art img { aspect-ratio: 4 / 5; object-fit: cover; }
.almanac-spread .type-specimen { font-style: italic; padding: 3rem 0; }
.almanac .entry .index-no { float: left; margin-right: .8rem; font-style: italic; font-size: 1rem; }
.almanac .list-cards { grid-template-columns: repeat(2, minmax(0, 1fr)); gap: 3rem; }
.almanac .entry-copy { border-top: 1px solid var(--line); padding-top: .8rem; }
.almanac .row-entry .entry-copy { border: 0; padding: 0; }
.almanac-article > .article-heading { max-width: 46rem; margin: 2rem auto; text-align: center; }
.almanac-article > .article-heading .lede { margin-left: auto; margin-right: auto; }
.almanac-article > .article-cover { max-width: 54rem; margin: 2rem auto 3rem; }
''',
    'notebook': '''
.notebook-shell { max-width: 960px; padding: 0 5%; margin: auto; border-left: 1px solid var(--line); }
.notebook-header { padding: 2.5rem 0 1.5rem; border-bottom: 1px solid var(--line); }
.notebook-header .brand { font-style: italic; font-size: 1.5rem; }
.notebook-header nav { margin-top: 1.2rem; }
.notebook-main { padding-top: 3rem; }
.notebook-entry { max-width: 43rem; margin-left: auto; margin-right: auto; }
.notebook-entry .hero-copy { border-left: 2px solid var(--accent); padding-left: 1.5rem; }
.notebook-entry .hero-art, .notebook-entry .art-mosaic, .notebook-entry .type-specimen { margin-top: 2rem; }
.notebook-entry h1 { font-size: clamp(2.8rem, 5vw, 4.5rem); }
.notebook .list-cards { grid-template-columns: repeat(2, minmax(0, 1fr)); }
.notebook .entry .index-no { display: block; margin-bottom: .7rem; font-family: 'Courier New', monospace; color: var(--accent); }
.notebook .entry-image img { aspect-ratio: 16 / 10; }
.notebook .row-entry { grid-template-columns: 2rem minmax(0, 1fr) 7rem; }
.notebook .reading-split { grid-template-columns: 12rem minmax(0, 1fr); gap: 2rem; }
.notebook-article > .article-heading { max-width: 43rem; margin: 0 auto 2rem; padding-left: 1.5rem; border-left: 2px solid var(--accent); }
.notebook-article > .article-cover { max-width: 43rem; margin-left: auto; margin-right: auto; }
''',
    'poster': '''
.poster-shell { max-width: 1480px; padding: 0 4%; margin: auto; }
.poster-header { border-bottom: 3px solid var(--ink); display: flex; justify-content: space-between; gap: 2rem; align-items: center; padding: 1.5rem 0; }
.poster-header .brand { font: 700 1rem/1.2 Arial, sans-serif; text-transform: uppercase; max-width: 19rem; }
.poster-main { padding-top: 2rem; }
.poster h1, .poster h2, .poster h3 { font-family: Arial, sans-serif; font-weight: 800; letter-spacing: -.065em; }
.poster-bill { position: relative; border-bottom: 3px solid var(--ink); padding-bottom: 3rem; }
.poster-bill h1 { font-size: clamp(4rem, 10.5vw, 10rem); line-height: .94; text-transform: uppercase; max-width: 66rem; }
.poster-bill .hero-copy { position: relative; z-index: 1; }
.poster-bill .poster-bottom { display: grid; grid-template-columns: minmax(0, 1fr) minmax(0, 1fr); gap: 3rem; align-items: center; margin-top: 2rem; }
.poster-bill .hero-art { border-radius: 0 45% 0 0; border: 3px solid var(--ink); }
.poster-bill .art-mosaic { grid-template-columns: 1fr 1fr 1fr; gap: .5rem; }
.poster-bill .art-mosaic figure:first-child { grid-row: auto; }
.poster-bill .art-mosaic figure img { aspect-ratio: 3 / 4; }
.poster-bill::before { content: ''; position: absolute; width: 32%; aspect-ratio: 1; border-radius: 50%; right: 0; top: 0; background: var(--wash); }
.poster-bill .type-specimen { font-family: Arial, sans-serif; font-weight: 900; border-width: 3px; }
.poster .entry { border: 2px solid var(--ink); padding: 1rem; }
.poster .entry .index-no { display: block; font-size: 1.5rem; font-weight: 700; margin-bottom: .5rem; }
.poster .entry h3 { font-size: 1.75rem; }
.poster .row-entry { border: 0; padding: 0; }
.poster .small-entry { padding: .7rem; }
.poster-article > .article-heading { border-bottom: 3px solid var(--ink); padding-bottom: 2rem; }
.poster-article > .article-heading h1 { font-size: clamp(3.2rem, 6vw, 6.5rem); }
''',
}

MOBILE_CSS = '''
@media (max-width: 700px) {
  h1 { font-size: clamp(2.7rem, 11vw, 4rem); }
  .hero { margin-bottom: 3rem; }
  .news-lead, .news-lead.hero-type, .atlas-hero, .atlas-hero.hero-type,
  .gallery-exhibit, .almanac-spread, .poster-bill .poster-bottom,
  .night-stage > .hero-copy, .reading-split, .reference .reading-split,
  .notebook .reading-split, .list-featured { grid-template-columns: minmax(0, 1fr); gap: 1.5rem; }
  .atlas-rail { writing-mode: horizontal-tb; border-right: 0; border-bottom: 1px solid var(--line); padding: 0 0 .6rem; }
  .atlas-header, .gallery-header { grid-template-columns: minmax(0, 1fr); gap: 1.5rem; padding: 1.5rem 0; }
  .night-header, .almanac-header, .poster-header { flex-direction: column; align-items: flex-start; gap: 1rem; padding-top: 1.3rem; }
  .news-utility { flex-wrap: wrap; }
  .news-header .brand { font-size: 2rem; }
  .news-main, .atlas-main, .notebook-main { padding-top: 2rem; }
  .gallery-header nav { justify-content: flex-start; }
  .gallery-exhibit > .hero-copy { padding-bottom: 0; }
  .gallery-exhibit.hero-type, .gallery-article > .article-heading { margin-left: 0; }
  .gallery-exhibit .type-specimen { margin-left: 0; }
  .gallery-exhibit { padding-top: 2rem; padding-bottom: 0; }
  .list-cards, .gallery .list-cards, .reference .list-cards,
  .almanac .list-cards, .notebook .list-cards { grid-template-columns: minmax(0, 1fr); gap: 2rem; }
  .gallery .list-cards .entry:nth-child(even) { margin-top: 0; }
  .editorial .list-cards .entry { border-right: 0; padding-right: 0; }
  .row-entry, .notebook .row-entry { grid-template-columns: 1.5rem minmax(0, 1fr) 4.5rem; gap: .7rem; }
  .row-entry h3, .poster .row-entry h3 { font-size: 1.25rem; }
  .row-entry .entry-copy p:not(.meta) { font-size: .9rem; }
  .reference-shell { display: block; }
  .directory-sidebar { border-right: 0; border-bottom: 1px solid var(--line); padding: 1.5rem 5%; }
  .directory-sidebar > .sidebar-inner { position: static; }
  .directory-sidebar nav { flex-direction: row; }
  .directory-index { columns: 2; column-gap: 1.5rem; }
  .directory-index li { break-inside: avoid; }
  .directory-hero { padding: 1.3rem; }
  .night-stage .hero-art img { aspect-ratio: 4 / 3; }
  .night-stage .art-mosaic { grid-template-columns: 1fr 1fr; }
  .night-stage .art-mosaic figure:first-child { grid-column: 1 / -1; }
  .night-stage .art-mosaic figure:first-child img { aspect-ratio: 16 / 9; }
  .almanac-spread > .spread-plate { border-left: 0; border-top: 1px solid var(--line); }
  .almanac-spread .hero-art img { aspect-ratio: 4 / 3; }
  .poster-bill h1 { font-size: clamp(3.2rem, 14vw, 5rem); }
  .poster-bill .art-mosaic { gap: .5rem; }
  .poster-bill .art-mosaic figcaption { font-size: .65rem; }
  .reading-split .reading-guide { position: static; }
  .article-content p { font-size: 1.03rem; }
  .article-heading h1 { font-size: clamp(2.5rem, 10vw, 4rem); }
  .caution { padding: 1.2rem; }
  .publication-footer { margin-top: 3rem; }
}
'''


def illustration(theme, rng, palette, number):
    """Original local plates; randomness changes visible geometry, not metadata."""
    paper, ink, accent, wash, line = palette
    # Artwork has its own light/dark pigments, independent of text contrast.
    pigments = {'plants': ('#193f35', '#507353', '#afbf88', '#e4cf9d'),
                'coffee': ('#493128', '#986247', '#d7ac76', '#ecdbc0'),
                'photo': ('#233e50', '#537e86', '#cba47d', '#e7d5b2')}
    deep, middle, bright, light = pigments[theme]
    shapes = [f'<rect width="960" height="720" fill="{light}"/>',
              '<defs><linearGradient id="sky" x2="0.8" y2="1">'
              f'<stop stop-color="{light}"/><stop offset="1" stop-color="{middle}"/>'
              '</linearGradient><radialGradient id="glow">'
              f'<stop stop-color="{light}"/><stop offset="1" stop-color="{bright}"/>'
              '</radialGradient></defs>',
              '<rect x="32" y="32" width="896" height="656" fill="url(#sky)"/>']
    sun_x, sun_y = rng.randint(570, 790), rng.randint(115, 240)
    shapes.append(f'<circle cx="{sun_x}" cy="{sun_y}" r="{rng.randint(80, 150)}" fill="url(#glow)"/>')
    if theme == 'plants':
        shapes.append(f'<path d="M65 610Q480 520 895 610V688H65Z" fill="{middle}" opacity=".3"/>')
        for stem in range(3 + number % 3):
            x = 220 + stem * 125 + rng.randint(-30, 30)
            top = rng.randint(110, 250)
            bend = rng.randint(-65, 65)
            shapes.append(f'<path d="M{x} 600Q{x + bend} 350 {x + bend} {top}" fill="none" stroke="{deep}" stroke-width="5"/>')
            for leaf in range(4):
                y = top + 60 + leaf * 75
                side = -1 if (leaf + stem) % 2 else 1
                reach = side * rng.randint(65, 110)
                tip_x, tip_y = x + bend + reach, y - rng.randint(30, 75)
                color = middle if (leaf + stem) % 2 else deep
                shapes.append(f'<path d="M{x + bend} {y}Q{tip_x} {y + 25} {tip_x} {tip_y}Q{x + bend} {tip_y - 10} {x + bend} {y}Z" fill="{color}"/>')
                shapes.append(f'<path d="M{x + bend} {y}L{tip_x} {tip_y}" stroke="{bright}" stroke-width="1.6" fill="none"/>')
        shapes.append(f'<path d="M300 560H670L625 675H345Z" fill="{deep}"/><path d="M320 580H650M335 603H642M343 626H632" stroke="{bright}" stroke-width="2" opacity=".65"/>')
        shapes.append(f'<path d="M85 90V230M85 90H200M875 490V630H760" fill="none" stroke="{deep}" stroke-width="2"/>')
    elif theme == 'coffee':
        shapes.append(f'<path d="M32 440L928 310V688H32Z" fill="{bright}"/><ellipse cx="500" cy="585" rx="280" ry="57" fill="{deep}" opacity=".2"/>')
        cx = rng.randint(390, 510)
        if number % 2:
            shapes.append(f'<path d="M{cx - 140} 185H{cx + 140}L{cx + 45} 410H{cx - 45}Z" fill="{light}" stroke="{deep}" stroke-width="5"/>')
            for n in range(-3, 4):
                shapes.append(f'<path d="M{cx + n * 35} 200L{cx + n * 9} 394" stroke="{middle}" stroke-width="3"/>')
            shapes.append(f'<path d="M{cx - 120} 430H{cx + 120}L{cx + 100} 592Q{cx} 630 {cx - 100} 592Z" fill="{middle}"/><path d="M{cx} 412V455" stroke="{deep}" stroke-width="5"/>')
        else:
            shapes.append(f'<ellipse cx="{cx}" cy="565" rx="205" ry="48" fill="{light}"/><path d="M{cx + 140} 325Q{cx + 270} 310 {cx + 225} 430Q{cx + 200} 465 {cx + 135} 450" fill="none" stroke="{deep}" stroke-width="25"/>')
            shapes.append(f'<path d="M{cx - 160} 300H{cx + 155}L{cx + 125} 525Q{cx} 590 {cx - 130} 525Z" fill="{deep}"/><ellipse cx="{cx}" cy="300" rx="158" ry="43" fill="{light}"/><ellipse cx="{cx}" cy="303" rx="140" ry="31" fill="{middle}"/>')
            for n in range(3):
                x = cx - 70 + n * 70 + rng.randint(-10, 10)
                shapes.append(f'<path d="M{x} 235C{x - 45} 190 {x + 35} 160 {x} 105" fill="none" stroke="{light}" stroke-width="5"/>')
        for _ in range(12):
            x, y, angle = rng.randint(100, 850), rng.randint(590, 650), rng.randint(-75, 75)
            shapes.append(f'<g transform="rotate({angle} {x} {y})"><ellipse cx="{x}" cy="{y}" rx="13" ry="21" fill="{deep}"/><path d="M{x} {y - 17}Q{x - 7} {y} {x} {y + 17}" fill="none" stroke="{bright}" stroke-width="2"/></g>')
    else:
        horizon = rng.randint(330, 430)
        shapes.append(f'<path d="M32 {horizon}L270 {horizon - 140}L520 {horizon + 30}L725 {horizon - 90}L928 {horizon + 5}V688H32Z" fill="{middle}"/>')
        shapes.append(f'<path d="M32 565L470 {horizon + 40}L928 520V688H32Z" fill="{deep}"/>')
        if number % 2:
            shapes.append(f'<path d="M155 100H310V688H155Z" fill="{deep}"/><path d="M310 100L610 32V688H310Z" fill="{bright}"/>')
            for y in range(170, 610, 90):
                shapes.append(f'<path d="M345 {y}L555 {y - 40}V{y + 8}L345 {y + 48}Z" fill="{deep}" opacity=".8"/>')
            shapes.append(f'<path d="M610 688L925 445V688Z" fill="{light}" opacity=".65"/>')
        else:
            shapes.append(f'<path d="M80 80H880V640H80Z M110 110V610H850V110Z" fill="{deep}" fill-rule="evenodd"/>')
            shapes.append(f'<path d="M470 95V630M95 370H865" stroke="{deep}" stroke-width="18"/>')
            shapes.append(f'<path d="M95 630L430 420L700 630Z" fill="{light}" opacity=".65"/>')
        for _ in range(5):
            y = rng.randint(horizon + 60, 660)
            shapes.append(f'<path d="M{rng.randint(80, 300)} {y}H{rng.randint(600, 880)}" stroke="{bright}" stroke-width="2" opacity=".5"/>')
    # Visible print-like stippling, not a fingerprint or an invisible identifier.
    for _ in range(95):
        x, y, radius = rng.randint(45, 915), rng.randint(45, 675), rng.choice((1, 1.5, 2))
        shapes.append(f'<circle cx="{x}" cy="{y}" r="{radius}" fill="{deep}" opacity=".12"/>')
    shapes.append(f'<rect x="32" y="32" width="896" height="656" fill="none" stroke="{deep}" stroke-width="1"/>')
    return ('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 960 720">'
            f'<title>{esc(CONTENT[theme]["caption"])}</title><desc>Авторская векторная иллюстрация к теме; не фотография.</desc>'
            + ''.join(shapes) + '</svg>')


class Renderer:
    def __init__(self, theme, title, composition):
        self.theme, self.title = theme, title
        self.content = CONTENT[theme]
        self.articles = self.content['articles']
        self.composition = composition
        self.direction = composition['direction']

    def nav(self, current):
        links = []
        for name, label in (('index.html', 'Главная'), ('notes.html', 'Заметки'), ('about.html', 'О сайте')):
            active = ' aria-current="page"' if name == current else ''
            links.append(f'<a href="/{name}"{active}>{label}</a>')
        return '<nav aria-label="Основная навигация">' + ''.join(links) + '</nav>'

    def page(self, title, body, current=None, description=None):
        brand = f'<a class="brand" href="/index.html">{esc(self.title)}</a>'
        label = f'<p class="kicker">{esc(self.content["label"])}</p>'
        nav = self.nav(current)
        footer = (f'<footer class="publication-footer"><div><p>{esc(self.title)}</p>'
                  '<p>Практические материалы для неспешного чтения. Все иллюстрации — векторные, не фотографии.</p></div>'
                  '<a href="/about.html">О материалах и подходе →</a></footer>')
        main = '<main id="main">' + body + '</main>'
        if self.direction == 'editorial':
            shell = ('<div class="newspaper"><div class="news-utility"><span class="section-label">Практика повседневного</span>'
                     f'<span class="section-label">{esc(self.content["label"])}</span></div>'
                     f'<header class="news-header">{brand}{nav}</header><div class="news-main">{main}</div>{footer}</div>')
        elif self.direction == 'botanical':
            shell = (f'<div class="atlas"><header class="atlas-header"><div class="atlas-identity">'
                     f'<span class="atlas-seal" aria-hidden="true">✳</span><div>{brand}{label}</div></div>{nav}</header>'
                     f'<div class="atlas-main">{main}</div>{footer}</div>')
        elif self.direction == 'nocturne':
            shell = (f'<div class="night-shell"><header class="night-header">{brand}{nav}</header>'
                     f'<div class="night-main">{main}</div>{footer}</div>')
        elif self.direction == 'gallery':
            shell = (f'<div class="gallery-shell"><header class="gallery-header"><div>{brand}{label}</div>{nav}</header>'
                     f'{main}{footer}</div>')
        elif self.direction == 'reference':
            directory = ''.join(f'<li><a href="/articles/{a[0]}.html">{esc(a[1])}</a></li>' for a in self.articles)
            shell = (f'<div class="reference-shell"><aside class="directory-sidebar"><div class="sidebar-inner">'
                     f'<header>{label}{brand}{nav}</header><p class="section-label">Указатель материалов</p>'
                     f'<ol class="directory-index">{directory}</ol></div></aside>'
                     f'<div class="directory-content">{main}{footer}</div></div>')
        elif self.direction == 'almanac':
            shell = (f'<div class="almanac-shell"><header class="almanac-header"><div>{label}{brand}</div>{nav}</header>'
                     f'<div class="almanac-main">{main}</div>{footer}</div>')
        elif self.direction == 'notebook':
            shell = (f'<div class="notebook-shell"><header class="notebook-header">{brand}{nav}</header>'
                     f'<div class="notebook-main">{main}</div>{footer}</div>')
        else:
            shell = (f'<div class="poster-shell"><header class="poster-header">{brand}{nav}</header>'
                     f'<div class="poster-main">{main}</div>{footer}</div>')
        return ('<!doctype html>\n<html lang="ru"><head><meta charset="utf-8">'
                '<meta name="viewport" content="width=device-width, initial-scale=1">'
                f'<title>{esc(title)} — {esc(self.title)}</title>'
                f'<meta name="description" content="{esc(description or self.content["intro"])}">'
                '<link rel="stylesheet" href="/style.css"><link rel="icon" href="/favicon.svg" type="image/svg+xml">'
                f'</head><body class="{self.direction}"><a class="skip" href="#main">К содержанию</a>'
                + shell + '</body></html>\n')

    def art(self):
        axis = self.composition['hero']
        if axis == 'type':
            words = {'plants': ('Свет.', 'Листья.', 'Наблюдение.'),
                     'coffee': ('Зерно.', 'Вода.', 'Время.'),
                     'photo': ('Свет.', 'Линии.', 'Внимание.')}[self.theme]
            return '<div class="type-specimen">' + ''.join(f'<span>{word}</span>' for word in words) + '</div>'
        if axis == 'mosaic':
            return '<div class="art-mosaic">' + ''.join(
                f'<figure><img src="/illustrations/plate-{i}.svg" alt="" width="960" height="720">'
                f'<figcaption>Этюд {i + 1:02d} · {esc(self.content["label"])}</figcaption></figure>' for i in range(3)) + '</div>'
        return ('<figure class="hero-art"><img src="/illustration.svg" alt="" width="960" height="720">'
                f'<figcaption>{esc(self.content["caption"])}</figcaption></figure>')

    def hero(self):
        axis = 'hero-' + self.composition['hero']
        heading = f'<p class="kicker">{esc(self.content["label"])}</p><h1>{esc(self.title)}</h1>'
        deck = f'<p class="lede">{esc(self.content["intro"])}</p><a class="action" href="/notes.html">Выбрать заметку →</a>'
        art = self.art()
        # Each direction constructs a distinct lead, not a palette-swapped shell.
        if self.direction == 'editorial':
            return (f'<section class="hero news-lead {axis}" aria-label="Главный материал"><div class="hero-copy">'
                    f'{heading}<div class="news-deck">{deck}</div></div><div class="news-plate">{art}'
                    '<p class="section-label">Наблюдать · пробовать · сравнивать</p></div></section>')
        if self.direction == 'botanical':
            return (f'<section class="hero atlas-hero {axis}"><div class="atlas-rail section-label">Атлас повседневной практики / 01</div>'
                    f'<div class="hero-copy">{heading}{deck}</div><div class="atlas-plate">{art}</div></section>')
        if self.direction == 'nocturne':
            return (f'<section class="hero night-stage {axis}">{art}<div class="hero-copy"><div>{heading}</div>'
                    f'<div>{deck}</div></div></section>')
        if self.direction == 'gallery':
            return (f'<section class="hero gallery-exhibit {axis}"><div class="hero-copy"><p class="section-label">Коллекция наблюдений</p>'
                    f'{heading}{deck}</div><div class="exhibit-wall">{art}</div></section>')
        if self.direction == 'reference':
            return (f'<section class="hero directory-hero {axis}"><p class="section-label">Справочник / начало</p>'
                    f'<div class="hero-copy">{heading}{deck}</div>{art}</section>')
        if self.direction == 'almanac':
            return (f'<section class="hero almanac-spread {axis}"><div class="hero-copy"><p class="section-label">Маленький альманах</p>'
                    f'{heading}{deck}</div><div class="spread-plate">{art}</div></section>')
        if self.direction == 'notebook':
            return (f'<section class="hero notebook-entry {axis}"><div class="hero-copy"><p class="section-label">Запись 01 / Вместо предисловия</p>'
                    f'{heading}{deck}</div>{art}</section>')
        return (f'<section class="hero poster-bill {axis}"><div class="hero-copy">{heading}</div>'
                f'<div class="poster-bottom"><div>{deck}<p class="section-label">Меньше спешки. Больше внимания.</p></div>{art}</div></section>')

    def entry(self, article, number, mode='card'):
        slug, heading, category, summary, _ = article
        href = f'/articles/{slug}.html'
        image = (f'<a class="entry-image" href="{href}" aria-label="{esc(heading)}">'
                 f'<img src="/illustrations/{slug}.svg" alt="" width="960" height="720" loading="lazy"></a>')
        copy = (f'<div class="entry-copy"><p class="meta">{esc(category)} · Практическая заметка</p>'
                f'<h3><a href="{href}">{esc(heading)}</a></h3><p>{esc(summary)}</p>'
                f'<a class="action" href="{href}">Читать →</a></div>')
        num = f'<span class="index-no">{number:02d}</span>'
        if mode in ('row', 'small'):
            body = num + image + copy
        elif self.direction == 'editorial':
            body = num + copy + image
        elif self.direction == 'botanical':
            body = '<figure>' + image + f'<figcaption>Лист {number:02d}</figcaption></figure>' + copy
        elif self.direction == 'nocturne':
            body = image + '<div class="night-caption">' + num + copy + '</div>'
        elif self.direction == 'gallery':
            body = '<div class="gallery-frame">' + image + '</div>' + num + copy
        elif self.direction == 'reference':
            body = '<header>' + num + '</header>' + copy + image
        elif self.direction == 'almanac':
            body = image + '<div class="almanac-caption">' + num + copy + '</div>'
        elif self.direction == 'notebook':
            body = '<header>' + num + '</header>' + image + copy
        else:
            body = '<div class="poster-caption">' + num + copy + '</div>' + image
        return f'<article class="entry {mode}-entry">{body}</article>'

    def listing(self):
        axis = self.composition['listing']
        if axis == 'rows':
            return '<ol class="list-rows">' + ''.join(f'<li>{self.entry(a, i + 1, "row")}</li>' for i, a in enumerate(self.articles)) + '</ol>'
        if axis == 'featured':
            return ('<div class="list-featured"><div class="featured-lead">' + self.entry(self.articles[0], 1, 'lead')
                    + '</div><ol class="featured-rest" start="2">' + ''.join(
                        f'<li>{self.entry(a, i + 2, "small")}</li>' for i, a in enumerate(self.articles[1:])) + '</ol></div>')
        return '<div class="list-cards">' + ''.join(self.entry(a, i + 1) for i, a in enumerate(self.articles)) + '</div>'

    def caution(self):
        return '<aside class="caution"><h2>Важно учитывать</h2><p>' + esc(self.content['caution']) + '</p></aside>'

    def article(self, item):
        slug, heading, category, summary, paragraphs = item
        section_names = ('С чего начать', 'На что обратить внимание', 'Проверить на практике')
        heading_html = (f'<header class="article-heading"><p class="kicker">{esc(category)}</p>'
                        f'<h1>{esc(heading)}</h1><p class="lede">{esc(summary)}</p></header>')
        cover = (f'<figure class="article-cover"><img src="/illustrations/{slug}.svg" alt="" width="960" height="720">'
                 f'<figcaption>{esc(self.content["caption"])} · Векторный этюд</figcaption></figure>')
        body = '<div class="article-content">' + ''.join(
            f'<section id="part-{i + 1}"><h2>{section_names[i]}</h2><p>{esc(text)}</p></section>'
            for i, text in enumerate(paragraphs)) + '</div>'
        related = '<aside class="related"><h2>Продолжить чтение</h2><ul>' + ''.join(
            f'<li><a href="/articles/{a[0]}.html">{esc(a[1])}</a></li>' for a in self.articles if a[0] != slug) + '</ul></aside>'
        if self.composition['article'] == 'split':
            toc = ''.join(f'<li><a href="/articles/{slug}.html#part-{i + 1}">{name}</a></li>' for i, name in enumerate(section_names))
            guide = (f'<aside class="reading-guide"><h2>В этом материале</h2><p>{esc(summary)}</p>'
                     f'<ol>{toc}</ol><a href="/notes.html">Все заметки →</a></aside>')
            reading = '<div class="reading-split">' + guide + '<div>' + body + related + '</div></div>'
        else:
            reading = '<div class="reading-column">' + body + related + '</div>'
        # Direction-specific article choreography: cover first, framed title,
        # centred spread or directory heading. Reading axis stays independent.
        direction_class = {'editorial': 'news', 'botanical': 'atlas', 'nocturne': 'night',
                           'gallery': 'gallery', 'reference': 'reference', 'almanac': 'almanac',
                           'notebook': 'notebook', 'poster': 'poster'}[self.direction]
        breadcrumb = '<p class="breadcrumb"><a href="/notes.html">Все заметки</a> / ' + esc(category) + '</p>'
        if self.direction == 'nocturne':
            lead = cover + heading_html
        elif self.direction == 'reference':
            lead = heading_html + '<details><summary>Иллюстрация к материалу</summary>' + cover + '</details>'
        elif self.direction == 'botanical':
            lead = '<p class="section-label">Атлас / практический лист</p>' + heading_html + cover
        elif self.direction == 'gallery':
            lead = heading_html + '<div class="exhibit-wall">' + cover + '</div>'
        elif self.direction == 'notebook':
            lead = '<p class="section-label">На полях тетради</p>' + heading_html + cover
        else:
            lead = heading_html + cover
        return self.page(heading, breadcrumb + f'<article class="{direction_class}-article">' + lead + reading + '</article>', description=summary)

    def pages(self, rng):
        paper, ink, accent, wash, line = PALETTES[self.direction]
        css = (f':root {{ --paper: {paper}; --ink: {ink}; --accent: {accent}; --wash: {wash}; --line: {line}; }}\n'
               + BASE_CSS + DIRECTION_CSS[self.direction] + MOBILE_CSS)
        home = (self.hero() + '<section aria-labelledby="reading-title"><div class="section-heading">'
                '<h2 id="reading-title">С чего начать</h2><span class="section-label">Пять материалов / один вопрос за раз</span></div>'
                + self.listing() + '</section>' + self.caution())
        notes = ('<header class="page-title"><p class="kicker">Указатель практики</p><h1>Заметки</h1>'
                 '<p class="lede">Выберите вопрос, который интересует вас сейчас. Каждый материал можно читать отдельно: '
                 'наблюдайте, пробуйте и сравнивайте результат.</p></header>' + self.listing() + self.caution())
        about = ('<article class="about-copy"><p class="kicker">О проекте</p><h1>О сайте</h1>'
                 f'<p class="lede">{esc(self.content["about"])}</p><h2>Внимание вместо спешки</h2>'
                 '<p>Начните с одного вопроса и меняйте по одному условию. Общие ориентиры помогают организовать наблюдение, '
                 'но не гарантируют одинакового результата в разных условиях.</p><h2>О материалах</h2>'
                 '<p>Здесь нет вымышленных авторов, личных историй, отзывов или дат публикации. Это общие справочные тексты, '
                 'а не индивидуальные консультации и не рекомендации конкретных товаров. Иллюстрации — векторные этюды, не фотографии.</p>'
                 '<h2>Спокойное чтение</h2><p>Все страницы и изображения находятся на этом сайте. Нет форм, '
                 'аналитики, скриптов и внешних загрузок. После сохранения файлов серверу не нужен доступ к сети.</p>'
                 '<a class="action" href="/notes.html">К материалам →</a>' + self.caution() + '</article>')
        pages = {'index.html': self.page('Главная', home, 'index.html'),
                 'notes.html': self.page('Заметки', notes, 'notes.html'),
                 'about.html': self.page('О сайте', about, 'about.html'), 'style.css': css,
                 'favicon.svg': ('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64">'
                                 f'<title>{esc(self.title)}</title><rect width="64" height="64" rx="8" fill="{accent}"/>'
                                 f'<text x="32" y="45" text-anchor="middle" font-family="Georgia,serif" font-size="40" fill="{paper}">'
                                 f'{esc(self.title[0].upper())}</text></svg>')}
        palette = PALETTES[self.direction]
        pages['illustration.svg'] = illustration(self.theme, rng, palette, 0)
        for i in range(3):
            pages[f'illustrations/plate-{i}.svg'] = illustration(self.theme, rng, palette, i + 1)
        for i, item in enumerate(self.articles):
            pages[f'articles/{item[0]}.html'] = self.article(item)
            pages[f'illustrations/{item[0]}.svg'] = illustration(self.theme, rng, palette, i + 4)
        return pages


def generate(theme, output, title=None, *, manifest):
    """Publish a new validated public tree; private registry state is never copied.

    The caller owns reservation and private manifest storage. Equal manifests,
    subjects and titles produce byte-identical public files. This finite design
    vocabulary does not claim that every possible request is visually unique.
    Serve output as the document root (links are root-absolute).
    """
    manifest = validate_manifest(manifest)
    if not isinstance(theme, str) or theme not in CONTENT:
        raise SiteError('Неизвестная тема: выберите plants, coffee или photo.')
    if title is not None:
        if (not isinstance(title, str) or not title.strip() or len(title) > 160
                or any(ord(c) < 32 or ord(c) == 127 for c in title)):
            raise SiteError('Название должно содержать от 1 до 160 символов без управляющих знаков.')
        title = title.strip()
    rng = random.Random(int(manifest['seed'], 16))
    title = title if title is not None else rng.choice(CONTENT[theme]['names'])
    renderer = Renderer(theme, title, manifest['composition'])
    pages = renderer.pages(rng)

    def build(staging):
        public = staging / 'public'
        public.mkdir()
        (public / 'articles').mkdir()
        (public / 'illustrations').mkdir()
        for name, text in pages.items():
            (public / name).write_bytes(text.encode('utf-8'))

    site_tool.publish(output, build)


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--theme', choices=tuple(CONTENT), required=True)
    parser.add_argument('--output', required=True, help='Новый каталог в существующем родительском каталоге')
    parser.add_argument('--title', help='Название, до 160 символов')
    parser.add_argument('--manifest', required=True, help='Приватный JSON-манифест зарезервированной композиции')
    args = parser.parse_args(argv)
    try:
        with Path(args.manifest).open('rb') as stream:
            data = stream.read(65537)
        if len(data) > 65536:
            raise ValueError('oversized manifest')
        manifest = json.loads(data.decode('utf-8-sig'))
        generate(args.theme, args.output, args.title, manifest=manifest)
    except SiteError as error:
        print('Ошибка: ' + str(error), file=sys.stderr)
        return 1
    except (OSError, ValueError, TypeError, KeyError, RecursionError, ET.ParseError):
        # Never print input, credentials, identifiers or the private file path.
        print('Ошибка: некорректный манифест или недоступная операция с файлами.', file=sys.stderr)
        return 1
    print('Готово: статический сайт создан и проверен.')
    return 0


if __name__ == '__main__':
    sys.exit(main())
