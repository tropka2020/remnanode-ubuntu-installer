"""Private offline selection for new templates, independent of the legacy registry."""
import json
import os
from pathlib import Path

import manage as m

DIRECTORY = Path('/var/lib/remnanode-design')
MANIFEST = DIRECTORY / 'premium-manifest.json'


def prepare(template):
    from premium_site import new_manifest, validate_manifest
    m.secure_path(DIRECTORY, directory=True)
    if not DIRECTORY.exists():
        DIRECTORY.mkdir(mode=0o700)
        os.chmod(DIRECTORY, 0o700)
    if DIRECTORY.stat().st_mode & 0o077:
        raise m.Failure('Private design directory requires mode700.')
    m.secure_path(MANIFEST, directory=False)
    if MANIFEST.exists():
        if MANIFEST.stat().st_mode & 0o077 or MANIFEST.stat().st_size > 16384:
            raise m.Failure('Private manifest has unsafe permissions or size.')
        try:
            value = validate_manifest(json.loads(MANIFEST.read_text(encoding='utf-8')))
        except (ValueError, TypeError, UnicodeError) as exc:
            raise m.Failure('Повреждён premium manifest; автоматический сброс запрещён.') from exc
        if value['template'] != template:
            raise m.Failure('Сохранён другой шаблон. Для смены после установки используйте selfsteal template.')
    else:
        value = new_manifest(template)
        m.write_json(MANIFEST, value)
    print('АВТОНОМНО: сохранён шаблон', value['template'], '(без межсерверной гарантии уникальности)')
    return MANIFEST
