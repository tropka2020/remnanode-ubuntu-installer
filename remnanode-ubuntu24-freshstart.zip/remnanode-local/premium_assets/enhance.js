/* Trusted optional enhancement. Navigation and article text are ordinary HTML. */
(() => {
  'use strict';
  const media = window.matchMedia('(prefers-reduced-motion: reduce)');
  const progress = document.querySelector('.reading-track span');
  let queued = false;
  function update() {
    queued = false;
    if (!progress) return;
    const length = Math.max(1, document.documentElement.scrollHeight - innerHeight);
    progress.style.transform = `scaleX(${Math.max(0, Math.min(1, scrollY / length))})`;
  }
  addEventListener('scroll', () => {
    if (!queued) { queued = true; requestAnimationFrame(update); }
  }, { passive: true });
  addEventListener('resize', update);
  update();
  // Animate arrival only: never hide readable content while waiting for JS.
  if (!media.matches && 'IntersectionObserver' in window) {
    const observer = new IntersectionObserver(entries => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.classList.add('arrived');
          observer.unobserve(entry.target);
        }
      });
    }, { threshold: 0.08 });
    document.querySelectorAll('.reveal, .av-chapter').forEach(node => observer.observe(node));
    media.addEventListener('change', event => {
      if (event.matches) observer.disconnect();
    });
  }
  // Native details remains usable with JS disabled, including keyboard activation.
  document.querySelectorAll('.menu-links a').forEach(link => link.addEventListener('click', () => {
    const details = link.closest('details');
    if (details) details.open = false;
  }));
})();
