"""Versioned structural design vocabulary shared by registry and renderer."""
import itertools
import json
import re
import uuid

VERSION = 'studio-v1'
DIRECTIONS = ('editorial', 'botanical', 'nocturne', 'gallery', 'reference', 'almanac', 'notebook', 'poster')
HEROES = ('feature', 'mosaic', 'type')
LISTINGS = ('cards', 'rows', 'featured')
ARTICLES = ('column', 'split')


def validate_composition(value):
    if not isinstance(value, dict) or set(value) != {'version', 'direction', 'hero', 'listing', 'article'}:
        raise ValueError('Invalid composition schema')
    if (value['version'] != VERSION or value['direction'] not in DIRECTIONS or
            value['hero'] not in HEROES or value['listing'] not in LISTINGS or value['article'] not in ARTICLES):
        raise ValueError('Unsupported composition')
    return dict(value)


def composition_key(value):
    return json.dumps(validate_composition(value), sort_keys=True, separators=(',', ':'))


def all_compositions():
    return [{'version': VERSION, 'direction': direction, 'hero': hero, 'listing': listing, 'article': article}
            for direction, hero, listing, article in itertools.product(DIRECTIONS, HEROES, LISTINGS, ARTICLES)]


def validate_manifest(value):
    keys = {'schema', 'version', 'request_id', 'reservation_id', 'seed', 'composition'}
    if not isinstance(value, dict) or set(value) != keys or type(value['schema']) is not int or value['schema'] != 1:
        raise ValueError('Invalid design manifest schema')
    if value['version'] != VERSION:
        raise ValueError('Unsupported design manifest version')
    for key in ('request_id', 'reservation_id'):
        if not isinstance(value[key], str) or str(uuid.UUID(value[key])) != value[key]:
            raise ValueError('Invalid design identifier')
    if not isinstance(value['seed'], str) or not re.fullmatch(r'[0-9a-f]{64}', value['seed']):
        raise ValueError('Invalid design seed')
    result = dict(value)
    result['composition'] = validate_composition(value['composition'])
    return result
