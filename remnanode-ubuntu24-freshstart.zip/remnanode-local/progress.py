"""Opt-in wizard progress; never include command arguments or captured output."""
from contextlib import contextmanager
from contextvars import ContextVar
import sys
import threading
import time


_reporting = ContextVar('progress_reporting', default=None)
_label = ContextVar('progress_label', default='Внешняя команда')
_pending = ContextVar('progress_pending', default=False)


class _Reporter:
    def __init__(self, stream, interval):
        self.stream = stream
        self.interval = interval
        self.steps = {}

    def checklist(self, label=None, state=None):
        if not self.steps:
            return
        if label is not None:
            if label not in self.steps:
                return
            self.steps[label] = state
        marks = {'pending': ' ', 'running': '→', 'done': '✓', 'failed': '×'}
        self.emit('\nХод установки:')
        for name, status in self.steps.items():
            self.emit(f'[{marks[status]}] {name}')

    def emit(self, message):
        if self.stream is None:
            return
        try:
            print(message, file=self.stream, flush=True)
        except (OSError, UnicodeError, ValueError):
            # A closed pipe or a terminal without Unicode must not break rollback.
            pass


@contextmanager
def reporting(*, enabled=False, stream=None, interval=10):
    """Enable progress only in this context, without changing the environment."""
    if interval <= 0:
        raise ValueError('Progress interval must be positive')
    reporter = _Reporter(sys.stderr if stream is None else stream, interval) if enabled else None
    token = _reporting.set(reporter)
    try:
        yield
    finally:
        _reporting.reset(token)


def checklist(labels):
    reporter = _reporting.get()
    if reporter is not None:
        reporter.steps = dict.fromkeys(labels, 'pending')
        reporter.checklist()


@contextmanager
def stage(label):
    """Report a static, non-sensitive stage label and its monotonic duration."""
    reporter = _reporting.get()
    if reporter is None:
        yield
        return
    token = _label.set(label)
    started = time.monotonic()
    reporter.checklist(label, 'running')
    reporter.emit(f'[НАЧАЛО] {label}')
    try:
        yield
    except BaseException:
        reporter.checklist(label, 'failed')
        reporter.emit(f'[ОШИБКА] {label} ({time.monotonic() - started:.1f} с)')
        raise
    else:
        reporter.checklist(label, 'done')
        reporter.emit(f'[ГОТОВО] {label} ({time.monotonic() - started:.1f} с)')
    finally:
        _label.reset(token)


@contextmanager
def command():
    """Heartbeat only while subprocess.run is pending, never during prompts."""
    reporter = _reporting.get()
    if reporter is None or _pending.get():
        yield
        return
    label = _label.get()
    started = time.monotonic()
    stopped = threading.Event()

    def heartbeat():
        while not stopped.wait(reporter.interval):
            reporter.emit(f'[ОЖИДАНИЕ] {label} ({time.monotonic() - started:.1f} с)')

    worker = threading.Thread(target=heartbeat, name='installer-progress', daemon=True)
    token = _pending.set(True)
    try:
        worker.start()
        yield
    finally:
        stopped.set()
        _pending.reset(token)
        # start() itself can be interrupted after launching the worker.
        # Do not strand the CLI if an unusual output stream blocks in write().
        if worker.ident is not None:
            worker.join(timeout=1)
