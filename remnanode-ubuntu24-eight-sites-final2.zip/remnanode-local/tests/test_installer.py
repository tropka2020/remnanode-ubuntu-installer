"""Windows-portable installer contracts; never run Docker, APT, UFW or network.

Run: python -B -m unittest discover -s tests -p test_installer.py -v
Only temporary test paths may be written. Linux permissions/services are mocked,
not claimed to have been integration-tested.
"""
from contextlib import ExitStack
import base64
import importlib.util
import io
import json
import os
from pathlib import Path
import socket
import subprocess
import sys
import tempfile
from types import SimpleNamespace
import unittest
from unittest.mock import Mock, call, patch


PROJECT = Path(__file__).resolve().parents[1]


def load_module(name, filename):
    spec = importlib.util.spec_from_file_location(name, PROJECT / filename)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


# Do not share patched manage globals with the other test suites, or import the
# real bootstrap (which must never install anything in this suite).
m = load_module("installer_test_manage", "manage.py")
with patch.dict(sys.modules, {"manage": m}):
    installer = load_module("installer_under_test", "installer.py")

PRIVATE = base64.urlsafe_b64encode(bytes(range(32))).decode().rstrip("=")
PUBLIC = base64.urlsafe_b64encode(bytes(range(32, 64))).decode().rstrip("=")
NODE_IMAGE = "remnawave/node:latest"
NODE_DIGEST = "remnawave/node@sha256:" + "a" * 64
CADDY_IMAGE = "caddy@sha256:" + "b" * 64
PAGE = "<!doctype html><title>Тестовый сайт</title>\n"


class IsolatedCase(unittest.TestCase):
    def setUp(self):
        self.stack = ExitStack()
        self.addCleanup(self.stack.close)
        self.root = Path(self.stack.enter_context(
            tempfile.TemporaryDirectory(prefix="test-installer-")))
        self.stdout = self.stack.enter_context(patch("sys.stdout", new_callable=io.StringIO))
        self.stderr = self.stack.enter_context(patch("sys.stderr", new_callable=io.StringIO))
        for target, name in ((subprocess, "run"), (subprocess, "Popen"),
                             (os, "system"), (socket, "socket"),
                             (socket, "getaddrinfo"), (socket, "create_connection")):
            self.stack.enter_context(patch.object(
                target, name, side_effect=AssertionError("External command/network forbidden")))
        self.node = self.root / "remnanode"
        self.web = self.root / "caddy"
        self.log = self.root / "logs"
        self.patch(m, "NODE", new=self.node)
        self.patch(m, "WEB", new=self.web)
        self.secure = self.patch(m, "secure_path", side_effect=self.safe_path)
        # Belt-and-suspenders barrier for direct Path writes bypassing secure_path.
        original_open, original_mkdir, original_rename = Path.open, Path.mkdir, Path.rename

        def safe_open(path, mode="r", *args, **kwargs):
            if any(flag in mode for flag in "wax+"):
                self.assert_test_path(path)
            return original_open(path, mode, *args, **kwargs)

        def safe_mkdir(path, *args, **kwargs):
            self.assert_test_path(path)
            return original_mkdir(path, *args, **kwargs)

        def safe_rename(path, destination):
            self.assert_test_path(path)
            self.assert_test_path(destination)
            return original_rename(path, destination)

        self.patch(Path, "open", new=safe_open)
        self.patch(Path, "mkdir", new=safe_mkdir)
        self.patch(Path, "rename", new=safe_rename)
        self.run = self.patch(m, "run", side_effect=AssertionError("Unexpected command"))
        self.compose = self.patch(m, "compose")
        self.free = self.patch(m, "assert_free")
        self.inspect = self.patch(m, "inspect", return_value=None)
        self.https = self.patch(m, "wait_https")
        self.wait = self.patch(m, "wait_container")
        self.stopped = self.patch(m, "confirm_stopped")
        self.backup = self.patch(m, "backup_dir", side_effect=self.make_backup)
        self.site = self.patch(m, "site_tool", side_effect=self.site_action)
        self.guard = Mock(spec=["apply", "commit", "commit_automatic", "rollback"])
        self.bootstrap = Mock(spec=["ensure_packages", "ensure_docker", "install_logrotate",
                                    "prepare_firewall", "discover_ssh_ports"])
        self.bootstrap.prepare_firewall.return_value = self.guard
        self.bootstrap.discover_ssh_ports.return_value = [22, 2200]
        self.disk_plan = {'status': 'unchanged', 'fs_bytes': 20 * 1024 ** 3}
        self.disk = SimpleNamespace(inspect_plan=Mock(return_value=self.disk_plan),
                                    describe=Mock(return_value='disk plan details'),
                                    apply=Mock(return_value={'status': 'unchanged'}))
        self.stack.enter_context(patch.dict(sys.modules, {'disk_expand': self.disk}))

    def patch(self, target, name, **kwargs):
        return self.stack.enter_context(patch.object(target, name, **kwargs))

    def assert_test_path(self, path):
        path = Path(path).absolute()
        if not path.is_relative_to(self.root):
            raise AssertionError("Non-test write forbidden: " + str(path))
        return path

    def safe_path(self, path, **kwargs):
        if str(path) == "/var/log/remnanode":
            return self.log
        return self.assert_test_path(path)

    def make_backup(self, label):
        folder = self.root / "backups" / (label + "-" + str(self.backup.call_count))
        folder.mkdir(parents=True)
        return folder

    def site_action(self, *args):
        if args[0] == "copy":
            output = self.assert_test_path(args[args.index("--output") + 1])
            output.mkdir(parents=True)
            (output / "index.html").write_text(PAGE, encoding="utf-8")
        elif args[0] != "validate":
            raise AssertionError("Unexpected site command: " + str(args))

    def read_json(self, path):
        return json.loads(path.read_text(encoding="utf-8"))


class KeypairTests(IsolatedCase):
    def test_accepts_both_xray_formats(self):
        for text in (f"Private key: {PRIVATE}\nPublic key: {PUBLIC}\n",
                     f"PrivateKey: {PRIVATE}\nPassword: {PUBLIC}\nHash32: unused\n",
                     f"  Private key :  {PRIVATE}  \r\n Public key: {PUBLIC}\r\n"):
            with self.subTest(text=text):
                self.assertEqual(installer.parse_keypair(text), (PRIVATE, PUBLIC))
        self.assertEqual(self.stdout.getvalue(), "")
        self.assertEqual(self.stderr.getvalue(), "")

    def test_accepts_current_xray_password_publickey_label(self):
        text = f"PrivateKey: {PRIVATE}\nPassword (PublicKey): {PUBLIC}\nHash32: unused\n"
        self.assertEqual(installer.parse_keypair(text), (PRIVATE, PUBLIC))
        self.assertEqual(self.stdout.getvalue(), "")
        self.assertEqual(self.stderr.getvalue(), "")

    def test_invalid_keypairs_fail_without_disclosing_any_secret(self):
        marker = "TOP_SECRET_DO_NOT_PRINT"
        invalid = ["", marker, f"PrivateKey: {PRIVATE}", f"Public key: {PUBLIC}",
                   f"PrivateKey: {marker}\nPassword: {PUBLIC}",
                   f"PrivateKey: {PRIVATE}\nPassword: {marker}"]
        for bad in ("A" * 42, "A" * 44, "A" * 42 + "=", "A" * 42 + "/",
                    "A" * 42 + "+", "A" * 42 + "!", "A" * 42 + "é",
                    PRIVATE[:20] + " " + PRIVATE[21:]):
            invalid.extend((f"Private key: {bad}\nPublic key: {PUBLIC}",
                            f"PrivateKey: {PRIVATE}\nPassword: {bad}"))
        for text in invalid:
            with self.subTest(text=text):
                with self.assertRaises(m.Failure) as caught:
                    installer.parse_keypair(text)
                diagnostics = str(caught.exception) + self.stdout.getvalue() + self.stderr.getvalue()
                for secret in (PRIVATE, PUBLIC, marker):
                    self.assertNotIn(secret, diagnostics)


class ProfileAndConfigTests(IsolatedCase):
    def test_build_profile_panel_clients_and_reality_backend_contract(self):
        profile = installer.build_profile("node.example.com", PRIVATE, "0123456789abcdef")
        self.assertEqual(len(profile["inbounds"]), 1)
        inbound = profile["inbounds"][0]
        self.assertEqual((inbound["port"], inbound["listen"], inbound["protocol"]),
                         (443, "0.0.0.0", "vless"))
        self.assertEqual(inbound["settings"], {"clients": [], "decryption": "none"})
        stream = inbound["streamSettings"]
        self.assertEqual((stream["network"], stream["security"]), ("raw", "reality"))
        reality = stream["realitySettings"]
        self.assertEqual(reality["target"], "127.0.0.1:9443")
        self.assertEqual(reality["xver"], 0)
        self.assertEqual(reality["serverNames"], ["node.example.com"])
        self.assertEqual(reality["privateKey"], PRIVATE)
        self.assertEqual(reality["shortIds"], ["0123456789abcdef"])
        self.assertIs(reality["show"], False)
        self.assertEqual(profile["log"]["access"], "/var/log/remnanode/access.log")
        self.assertEqual(profile["log"]["error"], "/var/log/remnanode/error.log")

    def test_build_profile_optional_inbound_tag_preserves_legacy_default(self):
        default = installer.build_profile("node.example.com", PRIVATE, "0123456789abcdef")
        self.assertEqual(default["inbounds"][0]["tag"], "VLESS_REALITY")
        tag = "VLESS_REALITY_0123456789abcdef"
        custom = installer.build_profile("node.example.com", PRIVATE, "0123456789abcdef",
                                         inbound_tag=tag)
        self.assertEqual(custom["inbounds"][0]["tag"], tag)
        default["inbounds"][0]["tag"] = tag
        self.assertEqual(custom, default)

    def test_build_profile_does_not_share_mutable_clients(self):
        first = installer.build_profile("a.example", PRIVATE, "00")
        first["inbounds"][0]["settings"]["clients"].append({"id": "test"})
        second = installer.build_profile("b.example", PRIVATE, "11")
        self.assertEqual(second["inbounds"][0]["settings"]["clients"], [])

    def test_prepare_node_writes_official_yaml_contract_and_escapes_compose_dollars(self):
        self.node.mkdir()
        secret = "abc$HOME${TOKEN}$$end'\\\""
        installer.prepare_node(secret, NODE_IMAGE)
        text = (self.node / "docker-compose.yml").read_text(encoding="utf-8")
        self.assertIn('image: "remnawave/node:latest"', text)
        self.assertIn("restart: always", text)
        self.assertIn("      - NET_ADMIN", text)
        self.assertIn("soft: 1048576", text)
        self.assertIn('      - "NODE_PORT=2222"', text)
        self.assertIn('      - "SECRET_KEY=abc$$HOME$${TOKEN}$$$$end\'\\\\\\\""', text)
        self.assertIn("      - /var/log/remnanode:/var/log/remnanode", text)
        self.assertNotIn("logging:", text)
        self.assertTrue(self.log.is_dir())
        self.secure.assert_any_call("/var/log/remnanode", directory=True, allow_system_parent=True)
        self.compose.assert_called_once_with(self.node, "config", "--quiet")
        self.assertNotIn(secret, self.stdout.getvalue() + self.stderr.getvalue())

    def test_premium_copy_error_uses_safe_failure_boundary(self):
        error = RuntimeError('PRIVATE_SITE_ERROR')
        with patch.dict(sys.modules, {'premium_site': SimpleNamespace(
                copy_generated=Mock(side_effect=error), SiteError=RuntimeError)}):
            with self.assertRaises(m.Failure) as caught:
                installer.prepare_backend('source', CADDY_IMAGE, 'node.example.com',
                                          premium_manifest={'test': True})
        self.assertIs(caught.exception.__cause__, error)
        self.assertNotIn('PRIVATE_SITE_ERROR', str(caught.exception))
        self.compose.assert_not_called()

    def test_backend_uses_only_loopback_tls_9443_and_public_http80_acme(self):
        config = installer.backend_config("node.example.com")
        self.assertIn("https_port 9443", config)
        self.assertIn("auto_https disable_redirects", config)
        self.assertIn("admin off", config)
        http, tls = config.split("http://node.example.com {", 1)[1].split(
            "https://node.example.com {", 1)
        self.assertIn("redir https://node.example.com{uri} permanent", http)
        self.assertNotIn("bind 127.0.0.1", http)  # HTTP-01 needs public port 80.
        self.assertIn("bind 127.0.0.1", tls)
        self.assertIn("disable_tlsalpn_challenge", tls)
        self.assertIn("issuer acme", tls)
        self.assertIn("file_server", tls)
        for forbidden in ("0.0.0.0", "[::]", "proxy_protocol", "https_port 443", "http_port 9443"):
            self.assertNotIn(forbidden, config)
        self.assertNotIn("DOMAIN", config)

    def test_prepare_backend_pins_image_mounts_and_validates_before_start(self):
        self.web.mkdir()
        installer.prepare_backend(str(self.root / "source"), CADDY_IMAGE, "node.example.com")
        compose = self.read_json(self.web / "docker-compose.yml")
        service = compose["services"]["caddy"]
        self.assertEqual(service["image"], CADDY_IMAGE)
        self.assertEqual(service["network_mode"], "host")
        self.assertEqual(service["volumes"], ["./html:/var/www/html:ro",
                         "./Caddyfile:/etc/caddy/Caddyfile:ro", "./logs:/var/log/caddy", "caddy_data:/data", "caddy_config:/config"])
        self.assertEqual(compose["volumes"], {"caddy_data": {}, "caddy_config": {}})
        self.assertEqual(self.compose.call_args_list, [
            call(self.web, "config", "--quiet"),
            call(self.web, "run", "--rm", "--no-deps", "caddy", "caddy", "validate",
                 "--config", "/etc/caddy/Caddyfile", "--adapter", "caddyfile")])
        self.assertEqual((self.web / "Caddyfile").read_text(encoding="utf-8"),
                         installer.backend_config("node.example.com"))


class ResolveImageTests(IsolatedCase):
    def test_selects_matching_repository_immutable_digest_not_first_entry(self):
        self.run.side_effect = [None, json.dumps([{"RepoDigests": [
            "other/node@sha256:" + "c" * 64, NODE_DIGEST]}])]
        self.assertEqual(installer.resolve_image("remnawave/node:latest"), NODE_DIGEST)
        self.assertEqual(self.run.call_args_list, [
            call(["docker", "pull", "remnawave/node:latest"], timeout=600),
            call(["docker", "image", "inspect", "remnawave/node:latest"], capture=True)])

    def test_registry_port_is_not_mistaken_for_image_tag(self):
        expected = "registry.example:5000/team/node@sha256:" + "d" * 64
        self.run.side_effect = [None, json.dumps([{"RepoDigests": [expected]}])]
        self.assertEqual(installer.resolve_image("registry.example:5000/team/node:v1"), expected)

    def test_missing_unknown_unpinned_or_invalid_digests_are_rejected(self):
        for payload in ("not json", "null", "[]", "{}", "[null]", "[{}]",
                        json.dumps([{"RepoDigests": None}]), json.dumps([{"RepoDigests": []}]),
                        json.dumps([{"RepoDigests": [CADDY_IMAGE]}]),
                        json.dumps([{"RepoDigests": ["remnawave/node:latest"]}]),
                        json.dumps([{"RepoDigests": ["remnawave/node@sha256:" + "f" * 63]}]),
                        json.dumps([{"RepoDigests": ["remnawave/node@sha256:" + "A" * 64]}])):
            with self.subTest(payload=payload):
                self.run.side_effect = [None, payload]
                with self.assertRaises(m.Failure):
                    installer.resolve_image("remnawave/node:latest")

    def test_malformed_digest_members_raise_controlled_failure(self):
        # Docker inspection is untrusted structured input, not necessarily a
        # correctly typed list of strings. Never leak an AttributeError out of
        # the installer's controlled error path.
        for digest in (None, 42, {}, []):
            with self.subTest(digest=digest):
                self.run.side_effect = [None, json.dumps([{"RepoDigests": [digest]}])]
                with self.assertRaises(m.Failure):
                    installer.resolve_image("remnawave/node:latest")

    def test_repo_digests_requires_nonempty_list_not_other_json_containers(self):
        for digests in (None, [], "", NODE_DIGEST, 42, True, {}, {NODE_DIGEST: "value"}):
            with self.subTest(digests=digests):
                self.run.side_effect = [None, json.dumps([{"RepoDigests": digests}])]
                with self.assertRaises(m.Failure):
                    installer.resolve_image("remnawave/node:latest")

    def test_valid_digest_cannot_hide_malformed_member_before_or_after_it(self):
        for malformed in (None, 42, True, {}, []):
            for digests in ([malformed, NODE_DIGEST], [NODE_DIGEST, malformed]):
                with self.subTest(digests=digests):
                    self.run.side_effect = [None, json.dumps([{"RepoDigests": digests}])]
                    with self.assertRaises(m.Failure):
                        installer.resolve_image("remnawave/node:latest")

    def test_inspect_failure_propagates_without_returning_a_mutable_tag(self):
        failure = m.Failure("inspect failed")
        self.run.side_effect = [None, failure]
        with self.assertRaises(m.Failure) as caught:
            installer.resolve_image("remnawave/node:latest")
        self.assertIs(caught.exception, failure)
        self.assertEqual(self.run.call_args_list, [
            call(["docker", "pull", "remnawave/node:latest"], timeout=600),
            call(["docker", "image", "inspect", "remnawave/node:latest"], capture=True)])

    def test_pull_failure_propagates_without_inspect(self):
        failure = m.Failure("pull failed")
        self.run.side_effect = failure
        with self.assertRaises(m.Failure) as caught:
            installer.resolve_image("remnawave/node:latest")
        self.assertIs(caught.exception, failure)
        self.assertEqual(self.run.call_count, 1)


class CollectAndMainTests(IsolatedCase):
    def inputs(self, confirmation="cancel", theme="1"):
        self.patch(installer, "dns_addresses", return_value=["192.0.2.10"])
        self.patch(installer.getpass, "getpass", return_value="SECRET_NOT_LOGGED")
        self.patch(__import__("builtins"), "input", side_effect=[
            "Node.Example.com", "192.0.2.1", theme, confirmation])

    def test_collect_cancel_has_no_install_or_system_side_effects(self):
        self.inputs()
        self.assertIsNone(installer.collect_settings([22, 2200]))
        self.bootstrap.assert_not_called()
        self.assertEqual(self.bootstrap.mock_calls, [])
        for mock in (self.run, self.compose, self.backup, self.secure, self.site):
            mock.assert_not_called()
        self.assertEqual(list(self.root.iterdir()), [])
        self.assertNotIn("SECRET_NOT_LOGGED", self.stdout.getvalue())

    def test_collect_confirm_returns_settings_but_does_not_install(self):
        self.inputs(confirmation="УСТАНОВИТЬ")
        settings = installer.collect_settings([22, 2200])
        self.assertEqual((settings.domain, settings.panel_ip, settings.theme, settings.title),
                         ("node.example.com", "192.0.2.1", "north", ""))
        self.assertEqual(settings.ssh_ports, [22, 2200])
        self.assertEqual(settings.secret, "SECRET_NOT_LOGGED")
        self.run.assert_not_called()
        self.backup.assert_not_called()
        self.assertNotIn(settings.secret, self.stdout.getvalue())

    def test_collect_accepts_each_new_premium_theme_number(self):
        templates = ('north', 'still', 'ritual', 'index', 'form', 'afterlight', 'common', 'orbit')
        with patch.dict(sys.modules, {'premium_site': SimpleNamespace(TEMPLATES=templates)}):
            for number, expected in zip(('4', '5', '6', '7', '8'), templates[3:]):
                with self.subTest(number=number):
                    dns = self.patch(installer, 'dns_addresses', return_value=['192.0.2.10'])
                    secret = self.patch(installer.getpass, 'getpass', return_value='SECRET_NOT_LOGGED')
                    prompt = self.stack.enter_context(patch(
                        'builtins.input', side_effect=['Node.Example.com', '192.0.2.1',
                                                        number, 'УСТАНОВИТЬ']))
                    settings = installer.collect_settings([22, 2200])
                    self.assertEqual((settings.domain, settings.panel_ip, settings.theme, settings.title),
                                     ('node.example.com', '192.0.2.1', expected, ''))
                    self.assertEqual(settings.secret, 'SECRET_NOT_LOGGED')
                    dns.assert_called_once_with('node.example.com')
                    secret.assert_called_once_with('SECRET_KEY из окна создания ноды (ввод скрыт): ')
                    self.assertEqual(prompt.call_count, 4)
                    self.run.assert_not_called()
                    self.backup.assert_not_called()

    def test_collect_disk_summary_and_snapshot_warning_precede_single_confirmation(self):
        self.inputs(confirmation='УСТАНОВИТЬ')
        plan = {'status': 'expand-partition'}
        prompt = __import__('builtins').input
        original_answers = prompt.side_effect

        def answer(label):
            if 'УСТАНОВИТЬ' in label:
                summary = self.stdout.getvalue()
                self.assertIn('disk plan details', summary)
                self.assertIn('snapshot', summary)
                self.assertIn('не откатывается', summary)
                self.disk.apply.assert_not_called()
            return next(original_answers)

        prompt.side_effect = answer
        self.assertIsNotNone(installer.collect_settings([22], disk_plan=plan))
        self.disk.describe.assert_called_once_with(plan)
        self.assertEqual(prompt.call_count, 4)
        self.disk.inspect_plan.assert_not_called()
        self.disk.apply.assert_not_called()

    def test_explicit_recovery_flag_reaches_confirmed_install_only(self):
        settings = SimpleNamespace()
        self.patch(installer, 'preflight')
        self.patch(installer, 'collect_settings', return_value=settings)
        install = self.patch(installer, 'install')
        self.patch(m, 'lock')
        self.patch(installer.os, 'umask')
        self.patch(installer.signal, 'signal')
        with patch.dict(sys.modules, {'bootstrap': self.bootstrap}):
            installer.main(['--recover-fail2ban'])
        self.assertIs(settings.recover_fail2ban, True)
        install.assert_called_once_with(settings, self.bootstrap)

    def test_main_cancel_expansion_plan_never_applies_or_installs_packages(self):
        self.inputs()
        self.disk.inspect_plan.return_value = {'status': 'expand-partition'}
        self.patch(installer, 'preflight')
        lock = self.patch(m, 'lock')
        self.patch(installer.os, 'umask')
        self.patch(installer.signal, 'signal')
        with patch.dict(sys.modules, {'bootstrap': self.bootstrap}):
            installer.main()
        self.disk.inspect_plan.assert_called_once_with()
        self.disk.apply.assert_not_called()
        self.bootstrap.ensure_packages.assert_not_called()
        self.bootstrap.ensure_docker.assert_not_called()
        lock.assert_not_called()
        self.assertNotIn('[✓] Диск', self.stderr.getvalue())
        self.assertEqual(list(self.root.iterdir()), [])

    def test_main_disk_failure_blocks_questions_lock_and_packages(self):
        failure = m.Failure('root disk unsupported')
        self.disk.inspect_plan.side_effect = failure
        self.patch(installer, 'preflight')
        collect = self.patch(installer, 'collect_settings')
        install = self.patch(installer, 'install')
        lock = self.patch(m, 'lock')
        self.patch(installer.os, 'umask')
        self.patch(installer.signal, 'signal')
        with patch.dict(sys.modules, {'bootstrap': self.bootstrap}):
            with self.assertRaises(m.Failure) as caught:
                installer.main()
        self.assertIs(caught.exception, failure)
        collect.assert_not_called()
        install.assert_not_called()
        lock.assert_not_called()
        self.assertEqual(self.bootstrap.mock_calls, [])
        self.disk.apply.assert_not_called()
        self.assertEqual(list(self.root.iterdir()), [])

    def test_invalid_secret_reprompt_never_logs_input(self):
        self.inputs(confirmation="УСТАНОВИТЬ")
        installer.getpass.getpass.side_effect = ["BAD SECRET", "", "valid$secret"]
        settings = installer.collect_settings([22])
        self.assertEqual(settings.secret, "valid$secret")
        self.assertEqual(installer.getpass.getpass.call_count, 3)
        for secret in ("BAD SECRET", "valid$secret"):
            self.assertNotIn(secret, self.stdout.getvalue())

    def test_valid_secret_rejects_empty_whitespace_controls_and_byte_overflow(self):
        for invalid in ("", "has space", "a\tb", "a\nb", "a\x00b", "a\x7fb",
                        "a\u00a0b", "a" * 16385, "é" * 8193):
            with self.subTest(invalid=repr(invalid)), self.assertRaises(ValueError):
                installer.valid_secret(invalid)
        for valid in ("a" * 16384, "é" * 8192, "a$HOME${X}'\\\""):
            self.assertEqual(installer.valid_secret(valid), valid)

    def test_main_cancel_does_not_lock_or_dispatch_install(self):
        self.inputs()
        preflight = self.patch(installer, "preflight")
        install = self.patch(installer, "install")
        lock = self.patch(m, "lock")
        self.patch(installer.os, "umask")
        self.patch(installer.signal, "signal")
        with patch.dict(sys.modules, {"bootstrap": self.bootstrap}):
            installer.main()
        preflight.assert_called_once_with()
        self.bootstrap.discover_ssh_ports.assert_called_once_with()
        for name in ("ensure_packages", "ensure_docker", "install_logrotate", "prepare_firewall"):
            getattr(self.bootstrap, name).assert_not_called()
        lock.assert_not_called()
        install.assert_not_called()
        self.run.assert_not_called()
        self.assertEqual(list(self.root.iterdir()), [])
        self.assertIn('Ход установки:', self.stderr.getvalue())
        self.disk.inspect_plan.assert_called_once_with()
        self.disk.apply.assert_not_called()
        self.assertNotIn('[✓] Диск', self.stderr.getvalue())
        for label in ('Проверка сервера', 'Диск', 'Настройки', 'Дизайн', 'APT/Docker', 'Образы',
                      'Сайт/Caddy', 'Нода', 'Logrotate', 'UFW/SSH', 'Fail2ban', 'BBR',
                      'Selfsteal', 'Итог'):
            self.assertIn('[ ] ' + label, self.stderr.getvalue())
        self.assertIn('[✓] Проверка сервера', self.stderr.getvalue())
        self.assertIn('[✓] Настройки', self.stderr.getvalue())
        self.assertIn('[НАЧАЛО] Настройки', self.stderr.getvalue())
        self.assertIn('[ГОТОВО] Настройки', self.stderr.getvalue())
        self.assertNotIn('[ОЖИДАНИЕ]', self.stderr.getvalue())
        self.assertIsNone(installer.progress._reporting.get())

    def test_main_rechecks_preflight_inside_lock_after_confirmation(self):
        events = Mock()
        settings = SimpleNamespace(domain="node.example.com")
        for target, name, kwargs in (
                (installer, "preflight", {}), (installer, "collect_settings", {"return_value": settings}),
                (installer, "install", {}), (m, "lock", {})):
            events.attach_mock(self.patch(target, name, **kwargs), name)
        self.patch(installer.os, "umask")
        self.patch(installer.signal, "signal")
        with patch.dict(sys.modules, {"bootstrap": self.bootstrap}):
            installer.main()
        self.disk.inspect_plan.assert_called_once_with()
        self.assertIs(settings.disk_plan, self.disk_plan)
        self.assertEqual(events.mock_calls, [
            call.preflight(), call.collect_settings([22, 2200], disk_plan=self.disk_plan), call.lock(),
            call.lock().__enter__(), call.preflight(), call.install(settings, self.bootstrap),
            call.lock().__exit__(None, None, None)])


class SSHConfirmationTests(IsolatedCase):
    def setUp(self):
        super().setUp()
        # Windows has no SIGALRM; simulate only the signal API and deadline.
        self.patch(installer.signal, "SIGALRM", new=14, create=True)
        self.previous = object()
        self.signal = self.patch(installer.signal, "signal", return_value=self.previous)
        self.alarm = self.patch(installer.signal, "alarm", create=True)

    def test_explicit_ssh_confirmation_cancels_alarm_and_restores_handler(self):
        self.patch(__import__("builtins"), "input", return_value="SSH РАБОТАЕТ")
        installer.confirm_ssh()
        self.assertEqual(self.alarm.call_args_list, [call(180), call(0)])
        self.assertEqual(self.signal.call_count, 2)
        self.assertEqual(self.signal.call_args, call(14, self.previous))

    def test_cancel_or_eof_never_confirms_and_always_clears_alarm(self):
        for answer in ("", "yes", "SSH", EOFError()):
            with self.subTest(answer=answer):
                self.signal.reset_mock()
                self.alarm.reset_mock()
                with patch("builtins.input") as prompt:
                    if isinstance(answer, BaseException):
                        prompt.side_effect = answer
                        expected = EOFError
                    else:
                        prompt.return_value = answer
                        expected = m.Failure
                    with self.assertRaises(expected):
                        installer.confirm_ssh()
                self.assertEqual(self.alarm.call_args_list, [call(180), call(0)])
                self.assertEqual(self.signal.call_args, call(14, self.previous))

    def test_expired_deadline_fails_without_accepting_confirmation(self):
        def expire(prompt):
            callback = self.signal.call_args_list[0].args[1]
            callback(14, None)
            self.fail("Expired SSH confirmation must not return")
        self.patch(__import__("builtins"), "input", side_effect=expire)
        with self.assertRaises(m.Failure):
            installer.confirm_ssh()
        self.assertEqual(self.alarm.call_args_list, [call(180), call(0)])
        self.assertEqual(self.signal.call_args, call(14, self.previous))


class PreflightTests(IsolatedCase):
    def setUp(self):
        super().setUp()
        self.bundle = self.root / "bundle"
        self.bundle.mkdir()
        for name in ("installer.py", "bootstrap.py", "manage.py", "progress.py", "site.py", "themed_site.py",
                     "studio_site.py", "design_catalog.py", "design_state.py", "registry_client.py",
                     "selfsteal.py", "host_features.py", "disk_expand.py", "command_runtime.py", "premium_site.py",
                     "premium_state.py", "install-remnanode.sh"):
            (self.bundle / name).write_text("test fixture", encoding="utf-8")
        self.patch(m, "BASE", new=self.bundle)
        self.stack.enter_context(patch.dict(sys.modules, {
            'host_features': SimpleNamespace(preflight_capacity=Mock()),
            'command_runtime': SimpleNamespace(check_conflict=Mock())}))
        self.patch(installer.sys, "platform", new="linux")
        self.patch(installer.os, "geteuid", return_value=0, create=True)
        self.patch(installer, "read_os", return_value={"ID": "ubuntu", "VERSION_ID": "24.04"})
        self.run.side_effect = None
        original_exists, original_is_dir = Path.exists, Path.is_dir
        self.nginx_exists = False

        def exists(path):
            if path == Path("/opt/nginx-selfsteal"):
                return self.nginx_exists
            return original_exists(path)

        def is_dir(path):
            if path == Path("/run/systemd/system"):
                return True
            return original_is_dir(path)

        self.patch(Path, "exists", new=exists)
        self.patch(Path, "is_dir", new=is_dir)
        self.patch(Path, "is_symlink", return_value=False)

    def test_fresh_directories_and_required_ports_are_checked_without_writes(self):
        installer.preflight()
        self.assertEqual(self.free.call_args_list, [call(80), call(443), call(2222), call(9443)])
        self.run.assert_called_once_with(["systemctl", "is-system-running"], check=False)
        self.assertFalse(self.node.exists())
        self.assertFalse(self.web.exists())
        self.assertEqual(self.bootstrap.mock_calls, [])

    def test_existing_node_or_backend_directory_is_refused_untouched(self):
        for folder in (self.node, self.web):
            with self.subTest(folder=folder):
                folder.mkdir()
                marker = folder / "keep"
                marker.write_text("original", encoding="utf-8")
                with self.assertRaises(m.Failure):
                    installer.preflight()
                self.assertEqual(marker.read_text(encoding="utf-8"), "original")
                self.free.assert_not_called()
                self.run.assert_not_called()
                marker.unlink()
                folder.rmdir()

    def test_missing_progress_module_is_refused_before_port_checks(self):
        (self.bundle / 'progress.py').unlink()
        with self.assertRaisesRegex(m.Failure, 'progress.py'):
            installer.preflight()
        self.free.assert_not_called()
        self.run.assert_not_called()

    def test_missing_disk_module_is_refused_before_port_checks(self):
        (self.bundle / 'disk_expand.py').unlink()
        with self.assertRaisesRegex(m.Failure, 'disk_expand.py'):
            installer.preflight()
        self.free.assert_not_called()
        self.run.assert_not_called()
        self.disk.inspect_plan.assert_not_called()
        self.disk.apply.assert_not_called()

    def test_legacy_nginx_is_refused_before_port_checks(self):
        self.nginx_exists = True
        with self.assertRaises(m.Failure):
            installer.preflight()
        self.free.assert_not_called()
        self.run.assert_not_called()


class InstallTests(IsolatedCase):
    def setUp(self):
        super().setUp()
        self.settings = SimpleNamespace(domain="node.example.com", panel_ip="192.0.2.1",
                                        secret="INSTALL_SECRET$VALUE", source=None, theme="plants",
                                        title="Тестовый сайт", ssh_ports=[22, 2200],
                                        disk_plan=self.disk_plan)
        self.manifest = self.root / "private" / "site-manifest.json"
        self.manifest.parent.mkdir(mode=0o700)
        self.manifest_data = {
            "schema": 1, "version": "studio-v1",
            "request_id": "00000000-0000-4000-8000-000000000001",
            "reservation_id": "00000000-0000-4000-8000-000000000002",
            "seed": "c" * 64,
            "composition": {"version": "studio-v1", "direction": "editorial",
                            "hero": "feature", "listing": "cards", "article": "column"}}
        m.write_json(self.manifest, self.manifest_data)
        self.design = Mock(return_value=self.manifest)
        self.stack.enter_context(patch.dict(sys.modules, {
            "design_state": SimpleNamespace(prepare_design=self.design)}))
        self.confirm = self.patch(installer, "confirm_ssh")
        self.input = self.stack.enter_context(
            patch("builtins.input", side_effect=AssertionError("SSH confirmation input forbidden")))
        self.runtime = self.patch(installer, "install_selfsteal_command")
        self.short_id = "0123456789abcdef"
        self.patch(installer.secrets, "token_hex", return_value=self.short_id)
        self.run.side_effect = self.command
        original_temporary_directory = tempfile.TemporaryDirectory

        def temporary_directory(*args, **kwargs):
            # The production /opt staging directory is always redirected.
            self.assertEqual(kwargs.get("dir"), "/opt")
            kwargs["dir"] = self.root
            return original_temporary_directory(*args, **kwargs)

        self.patch(installer, "tempfile", new=SimpleNamespace(TemporaryDirectory=temporary_directory))
        self.events = Mock()
        for name, child in (("design", self.design), ("disk_apply", self.disk.apply),
                            ("bootstrap", self.bootstrap), ("guard", self.guard),
                            ("commit_automatic", self.guard.commit_automatic), ("compose", self.compose),
                            ("https", self.https), ("stopped", self.stopped),
                            ("site", self.site), ("backup", self.backup)):
            self.events.attach_mock(child, name)

    def command(self, args, **kwargs):
        args = [str(arg) for arg in args]
        if len(args) > 1 and args[1] == str(m.BASE / "studio_site.py"):
            self.assertEqual(args[0], sys.executable)
            return None
        if args[:2] == ["docker", "pull"]:
            return None
        if args[:3] == ["docker", "image", "inspect"]:
            image = {installer.NODE_IMAGE: NODE_DIGEST, installer.CADDY_IMAGE: CADDY_IMAGE}[args[3]]
            return json.dumps([{"RepoDigests": [image]}])
        if args[:2] == ["docker", "run"]:
            self.assertEqual(args[args.index("--network") + 1], "none")
            self.assertIn(NODE_DIGEST, args)
            if args[-1] == "x25519":
                return f"PrivateKey: {PRIVATE}\nPassword: {PUBLIC}\n"
            if args[-1] == "version":
                return "Xray test-version\n"
            if args[-4:] == ["run", "-test", "-config", "/config.json"]:
                return None
        raise AssertionError("Unexpected external command: " + str(args))

    def install(self):
        installer.install(self.settings, self.bootstrap)

    def assert_no_guard_or_start(self):
        self.bootstrap.prepare_firewall.assert_not_called()
        self.guard.apply.assert_not_called()
        self.guard.commit_automatic.assert_not_called()
        self.guard.rollback.assert_not_called()
        self.confirm.assert_not_called()
        self.assertFalse(any(c.args[1] in ("up", "down") for c in self.compose.call_args_list))

    def assert_archived(self):
        self.assertFalse(self.node.exists())
        self.assertFalse(self.web.exists())
        self.assertEqual(len(list((self.root / "backups").glob("failed-node-wizard-*/remnanode"))), 1)
        self.assertEqual(len(list((self.root / "backups").glob("failed-web-wizard-*/caddy"))), 1)

    def test_progress_stages_cover_installation_without_secret_output(self):
        with installer.progress.reporting(enabled=True):
            self.install()
        text = self.stderr.getvalue()
        stages = ('Дизайн', 'Диск', 'APT/Docker', 'Образы', 'Сайт/Caddy',
                  'Генерация и проверка ключей Xray', 'Нода', 'Logrotate', 'UFW/SSH',
                  'Запуск Caddy', 'Ожидание сертификата и HTTPS', 'Selfsteal', 'Итог')
        for label in stages:
            self.assertIn('[НАЧАЛО] ' + label, text)
            self.assertIn('[ГОТОВО] ' + label, text)
        for secret in ('INSTALL_SECRET$VALUE', PRIVATE, PUBLIC, self.manifest_data['seed']):
            self.assertNotIn(secret, text + self.stdout.getvalue())
        self.guard.commit_automatic.assert_called_once_with()
        self.confirm.assert_not_called()
        self.input.assert_not_called()
        self.guard.rollback.assert_not_called()

    def test_premium_features_start_only_after_automatic_firewall_commit(self):
        self.settings.theme = 'north'
        features = SimpleNamespace(
            ensure_fail2ban=Mock(return_value=SimpleNamespace(status='ready')),
            configure_bbr=Mock(return_value=SimpleNamespace(status='ready')),
            inspect_performance=Mock(return_value={}))
        self.guard.commit_automatic.side_effect = m.Failure('automatic firewall proof failed')
        prepared = Mock(return_value=self.manifest)
        generated = Mock()
        backend = installer.prepare_backend
        with patch.dict(sys.modules, {
                'premium_state': SimpleNamespace(prepare=prepared),
                'premium_site': SimpleNamespace(TEMPLATES=('north', 'still', 'ritual', 'index', 'form', 'afterlight', 'common', 'orbit'),
                                                validate_manifest=lambda value: value, generate=generated,
                                                SiteError=RuntimeError),
                'host_features': features}), \
                patch.object(installer, 'prepare_backend', side_effect=lambda source, image, domain, premium_manifest=None: backend(source, image, domain)):
            with self.assertRaisesRegex(m.Failure, 'automatic firewall proof failed'):
                self.install()
        features.ensure_fail2ban.assert_not_called()
        features.configure_bbr.assert_not_called()
        self.guard.rollback.assert_called_once_with()
        self.assert_archived()

    def test_premium_features_update_matching_checklist_labels(self):
        self.settings.theme = 'north'
        prepared = Mock(return_value=self.manifest)
        generated = Mock()
        features = SimpleNamespace(
            ensure_fail2ban=Mock(return_value=SimpleNamespace(status='ready')),
            configure_bbr=Mock(return_value=SimpleNamespace(status='ready')),
            inspect_performance=Mock(return_value={}))
        backend = installer.prepare_backend
        self.events.attach_mock(features.ensure_fail2ban, 'fail2ban')
        self.events.attach_mock(features.configure_bbr, 'bbr')

        def prepare_backend(source, image, domain, premium_manifest=None):
            return backend(source, image, domain)

        labels = ['Диск', 'Дизайн', 'APT/Docker', 'Образы', 'Сайт/Caddy', 'Нода', 'Logrotate',
                  'UFW/SSH', 'Fail2ban', 'BBR', 'Selfsteal', 'Итог']
        with patch.dict(sys.modules, {
                'premium_state': SimpleNamespace(prepare=prepared),
                'premium_site': SimpleNamespace(TEMPLATES=('north', 'still', 'ritual', 'index', 'form', 'afterlight', 'common', 'orbit'),
                                                validate_manifest=lambda value: value, generate=generated,
                                                SiteError=RuntimeError),
                'host_features': features}), \
                patch.object(installer, 'prepare_backend', side_effect=prepare_backend), \
                installer.progress.reporting(enabled=True):
            installer.progress.checklist(labels)
            self.install()
        for label in labels:
            self.assertIn('[✓] ' + label, self.stderr.getvalue())
        prepared.assert_called_once_with('north')
        features.ensure_fail2ban.assert_called_once_with([22, 2200])
        features.configure_bbr.assert_called_once_with()
        calls = self.events.mock_calls
        self.assertLess(calls.index(call.commit_automatic()),
                        calls.index(call.fail2ban([22, 2200])))
        self.assertLess(calls.index(call.fail2ban([22, 2200])), calls.index(call.bbr()))
        self.design.assert_not_called()
        self.guard.rollback.assert_not_called()

    def test_premium_features_rollback_in_reverse_before_firewall(self):
        self.settings.theme = 'north'
        features = SimpleNamespace(ensure_fail2ban=Mock(), configure_bbr=Mock(),
                                   inspect_performance=Mock(return_value={}))
        for name in ('ensure_fail2ban', 'configure_bbr'):
            getattr(features, name).return_value.status = 'ready'
        self.events.attach_mock(features.ensure_fail2ban.return_value.rollback, 'rollback_fail2ban')
        self.events.attach_mock(features.configure_bbr.return_value.rollback, 'rollback_bbr')
        failure = m.Failure('HTTPS failed')
        self.https.side_effect = failure
        backend = installer.prepare_backend
        with patch.dict(sys.modules, {
                'premium_state': SimpleNamespace(prepare=Mock(return_value=self.manifest)),
                'premium_site': SimpleNamespace(TEMPLATES=('north', 'still', 'ritual', 'index', 'form', 'afterlight', 'common', 'orbit'),
                                                validate_manifest=lambda value: value,
                                                generate=Mock(), SiteError=RuntimeError),
                'host_features': features}), \
                patch.object(installer, 'prepare_backend',
                             side_effect=lambda source, image, domain, **kwargs: backend(source, image, domain)):
            with self.assertRaises(m.Failure) as caught:
                self.install()
        self.assertIs(caught.exception, failure)
        calls = self.events.mock_calls
        self.assertLess(calls.index(call.stopped('remnanode-web')), calls.index(call.rollback_bbr()))
        self.assertLess(calls.index(call.rollback_bbr()), calls.index(call.rollback_fail2ban()))
        self.assertLess(calls.index(call.rollback_fail2ban()), calls.index(call.guard.rollback()))
        self.assert_archived()

    def test_premium_generation_error_uses_safe_failure_boundary(self):
        self.settings.theme = 'north'
        error = RuntimeError('PRIVATE_SITE_ERROR')
        with patch.dict(sys.modules, {
                'premium_state': SimpleNamespace(prepare=Mock(return_value=self.manifest)),
                'premium_site': SimpleNamespace(TEMPLATES=('north', 'still', 'ritual', 'index', 'form', 'afterlight', 'common', 'orbit'),
                                                validate_manifest=lambda value: value,
                                                generate=Mock(side_effect=error), SiteError=RuntimeError)}):
            with self.assertRaises(m.Failure) as caught:
                self.install()
        self.assertIs(caught.exception.__cause__, error)
        self.assertNotIn('PRIVATE_SITE_ERROR', str(caught.exception))
        self.assert_no_guard_or_start()

    def assert_new_premium_theme_install(self, theme):
        self.settings.theme = theme
        templates = ('north', 'still', 'ritual', 'index', 'form', 'afterlight', 'common', 'orbit')
        prepared = Mock(return_value=self.manifest)
        generated = Mock()
        copied = Mock()
        features = SimpleNamespace(
            ensure_fail2ban=Mock(return_value=SimpleNamespace(status='ready')),
            configure_bbr=Mock(return_value=SimpleNamespace(status='ready')),
            inspect_performance=Mock(return_value={}))

        def generate(manifest, output):
            generated(manifest, output)
            output = Path(output)
            output.mkdir(parents=True)
            (output / 'index.html').write_text(PAGE, encoding='utf-8')

        def copy_generated(source, output, manifest):
            copied(source, output, manifest)
            output = Path(output)
            output.mkdir(parents=True)
            (output / 'index.html').write_text(PAGE, encoding='utf-8')

        with patch.dict(sys.modules, {
                'premium_state': SimpleNamespace(prepare=prepared),
                'premium_site': SimpleNamespace(
                    TEMPLATES=templates, validate_manifest=lambda value: value,
                    generate=generate, copy_generated=copy_generated, SiteError=RuntimeError),
                'host_features': features}):
            self.install()

        prepared.assert_called_once_with(theme)
        generated.assert_called_once()
        copied.assert_called_once()
        features.ensure_fail2ban.assert_called_once_with([22, 2200])
        features.configure_bbr.assert_called_once_with()
        self.design.assert_not_called()
        self.site.assert_not_called()
        self.assertFalse(any(len(entry.args[0]) > 1 and
                             str(entry.args[0][1]) == str(m.BASE / 'studio_site.py')
                             for entry in self.run.call_args_list))

    def test_premium_theme_index_uses_premium_install_path(self):
        self.assert_new_premium_theme_install('index')

    def test_premium_theme_form_uses_premium_install_path(self):
        self.assert_new_premium_theme_install('form')

    def test_premium_theme_afterlight_uses_premium_install_path(self):
        self.assert_new_premium_theme_install('afterlight')

    def test_premium_theme_common_uses_premium_install_path(self):
        self.assert_new_premium_theme_install('common')

    def test_premium_theme_orbit_uses_premium_install_path(self):
        self.assert_new_premium_theme_install('orbit')

    def test_progress_ssh_error_keeps_rollback_scope(self):
        failure = m.Failure('SSH local verification failed')
        self.guard.commit_automatic.side_effect = failure
        with self.assertRaises(m.Failure) as caught:
            with installer.progress.reporting(enabled=True):
                self.install()
        self.assertIs(caught.exception, failure)
        self.assertIn('[ОШИБКА] UFW/SSH', self.stderr.getvalue())
        self.assertIn('[НАЧАЛО] Откат после ошибки', self.stderr.getvalue())
        self.assertIn('[ГОТОВО] Откат после ошибки', self.stderr.getvalue())
        self.guard.rollback.assert_called_once_with()
        self.guard.commit_automatic.assert_called_once_with()
        self.assert_archived()
        self.assertFalse(any(c.args[1] == 'up' for c in self.compose.call_args_list))
        self.assertIsNone(installer.progress._reporting.get())

    def test_progress_failed_rollback_reports_error_and_keeps_mounts(self):
        self.guard.commit_automatic.side_effect = m.Failure('SSH local verification failed')
        failure = m.Failure('rollback failed')
        self.guard.rollback.side_effect = failure
        with self.assertRaises(m.Failure) as caught:
            with installer.progress.reporting(enabled=True):
                self.install()
        self.assertIs(caught.exception, failure)
        self.assertIn('[ОШИБКА] Откат после ошибки', self.stderr.getvalue())
        self.assertNotIn('[ГОТОВО] Откат после ошибки', self.stderr.getvalue())
        self.assertTrue(self.node.exists())
        self.assertTrue(self.web.exists())
        self.guard.commit_automatic.assert_called_once_with()

    def test_success_frontend_still_requires_panel_inbound(self):
        self.install()
        managed = self.read_json(self.node / "managed.json")
        self.assertIs(managed["inbound_applied"], False)
        self.assertEqual(managed["image"], NODE_IMAGE)
        compose_text = (self.node / "docker-compose.yml").read_text(encoding="utf-8")
        self.assertIn('image: "remnawave/node:latest"', compose_text)
        self.assertNotIn(NODE_DIGEST, compose_text)
        self.assertIn("restart: always", compose_text)
        state = self.read_json(next((self.root / "backups").glob("setup-*/install-state.json")))
        self.assertEqual(state["node_image"], NODE_IMAGE)
        self.assertEqual(state["node_image_digest"], NODE_DIGEST)
        web = self.read_json(self.web / "managed.json")
        self.assertEqual((web["https_port"], web["purpose"], web["image"]),
                         (9443, "local-backend", CADDY_IMAGE))
        self.https.assert_called_once_with("node.example.com", 9443, PAGE, timeout=180)
        self.wait.assert_called_once_with("remnanode", 2222)
        self.guard.rollback.assert_not_called()
        self.assertEqual(self.settings.secret, "")
        profile = self.read_json(self.node / "config-profile.json")
        host = self.read_json(self.node / "host-settings.json")
        self.assertEqual(profile["inbounds"][0]["settings"]["clients"], [])
        self.assertEqual((host["port"], host["publicKey"], host["shortId"]),
                         (443, PUBLIC, self.short_id))
        self.assertNotIn(PRIVATE, json.dumps(host))
        instructions = (self.node / "PANEL-SETUP.txt").read_text(encoding="utf-8")
        self.assertIn("443", instructions)
        self.assertNotIn(PRIVATE, instructions)
        output = self.stdout.getvalue() + self.stderr.getvalue()
        self.assertNotIn("INSTALL_SECRET$VALUE", output)
        self.assertNotIn(PRIVATE, output)
        state = self.read_json(next((self.root / "backups").glob("setup-*/install-state.json")))
        self.assertEqual(state["status"], "ready-for-panel")
        self.assertEqual(list(self.root.glob("remnanode-site-*")), [])

    def test_design_reserved_before_packages_and_private_manifest_backup_not_public(self):
        self.install()
        self.design.assert_called_once_with(self.settings)
        calls = self.events.mock_calls
        self.assertLess(calls.index(call.design(self.settings)),
                        calls.index(call.bootstrap.ensure_packages()))
        backup = next((self.root / "backups").glob("setup-*/site-manifest.json"))
        self.assertEqual(self.read_json(backup), self.manifest_data)
        self.assertEqual(backup.read_bytes(), self.manifest.read_bytes())
        self.assertFalse((self.web / "html/site-manifest.json").exists())
        self.assertEqual([path.name for path in (self.web / "html").iterdir()], ["index.html"])
        commands = [entry.args[0] for entry in self.run.call_args_list]
        generated = [args for args in commands if len(args) > 1 and
                     str(args[1]) == str(m.BASE / "studio_site.py")]
        self.assertEqual(len(generated), 1)
        args = generated[0]
        self.assertEqual(args[:4], [sys.executable, m.BASE / "studio_site.py", "--theme", "plants"])
        self.assertEqual(args[args.index("--manifest") + 1], self.manifest)
        self.assertEqual(args[args.index("--title") + 1], self.settings.title)
        self.assertTrue(Path(args[args.index("--output") + 1]).is_relative_to(self.root))
        self.assertNotIn(self.manifest, [item for entry in self.site.call_args_list for item in entry.args])

    def test_disk_applies_once_after_design_before_packages_and_result_is_private(self):
        self.settings.disk_plan = {'status': 'expand-partition'}
        result = {'status': 'expanded', 'fs_bytes': 30 * 1024 ** 3}
        self.disk.apply.return_value = result
        self.install()
        self.disk.apply.assert_called_once_with(self.settings.disk_plan)
        self.disk.inspect_plan.assert_not_called()
        calls = self.events.mock_calls
        self.assertLess(calls.index(call.design(self.settings)),
                        calls.index(call.disk_apply(self.settings.disk_plan)))
        self.assertLess(calls.index(call.disk_apply(self.settings.disk_plan)),
                        calls.index(call.bootstrap.ensure_packages()))
        saved = next((self.root / 'backups').glob('setup-*/disk-result.json'))
        self.assertEqual(self.read_json(saved), result)
        self.assertFalse((self.web / 'html/disk-result.json').exists())

    def test_disk_apply_failure_blocks_packages_and_reports_no_disk_success(self):
        self.disk.apply.side_effect = m.Failure('disk expansion failed')
        with self.assertRaisesRegex(m.Failure, 'disk expansion failed'):
            with installer.progress.reporting(enabled=True):
                self.install()
        self.assertEqual(self.bootstrap.mock_calls, [])
        self.run.assert_not_called()
        self.backup.assert_not_called()
        self.assert_no_guard_or_start()
        self.assertIn('[ОШИБКА] Диск', self.stderr.getvalue())
        self.assertNotIn('[ГОТОВО] Диск', self.stderr.getvalue())

    def test_main_expansion_runs_once_inside_lock_after_repeated_preflight(self):
        self.settings.disk_plan = {'status': 'expand-partition'}
        self.disk.inspect_plan.return_value = self.settings.disk_plan
        events = []
        self.patch(installer, 'preflight', side_effect=lambda: events.append('preflight'))
        self.patch(installer, 'collect_settings', side_effect=lambda *args, **kwargs:
                   (events.append('confirmed') or self.settings))
        self.patch(installer.os, 'umask')
        self.patch(installer.signal, 'signal')
        locked = False

        class Lock:
            def __enter__(inner):
                nonlocal locked
                locked = True
                events.append('locked')

            def __exit__(inner, *args):
                nonlocal locked
                locked = False
                events.append('unlocked')

        self.patch(m, 'lock', return_value=Lock())

        def apply(plan):
            self.assertTrue(locked)
            self.assertEqual(events, ['preflight', 'confirmed', 'locked', 'preflight'])
            self.design.assert_called_once_with(self.settings)
            self.bootstrap.ensure_packages.assert_not_called()
            events.append('expanded')
            return {'status': 'expanded'}

        self.disk.apply.side_effect = apply
        with patch.dict(sys.modules, {'bootstrap': self.bootstrap}):
            installer.main()
        self.disk.inspect_plan.assert_called_once_with()
        self.disk.apply.assert_called_once_with(self.settings.disk_plan)
        self.assertEqual(events[-2:], ['expanded', 'unlocked'])

    def test_later_rollback_does_not_repeat_or_reverse_disk_expansion(self):
        self.settings.disk_plan = {'status': 'expand-filesystem'}
        self.disk.apply.return_value = {'status': 'expanded'}
        self.https.side_effect = m.Failure('HTTPS failed')
        with self.assertRaisesRegex(m.Failure, 'HTTPS failed'):
            self.install()
        self.disk.apply.assert_called_once_with(self.settings.disk_plan)
        self.disk.inspect_plan.assert_not_called()
        self.guard.rollback.assert_called_once_with()
        self.assert_archived()
        self.assertFalse(any('shrink' in str(c) for c in self.run.call_args_list))

    def test_legacy_library_install_without_plan_does_not_inspect_host_disk(self):
        del self.settings.disk_plan
        self.install()
        self.disk.inspect_plan.assert_not_called()
        self.disk.apply.assert_not_called()

    def test_empty_title_is_omitted_from_studio_command(self):
        self.settings.title = ""
        self.install()
        generated = next(entry.args[0] for entry in self.run.call_args_list
                         if len(entry.args[0]) > 1 and
                         str(entry.args[0][1]) == str(m.BASE / "studio_site.py"))
        self.assertNotIn("--title", generated)
        self.assertIn("--manifest", generated)

    def test_own_source_none_manifest_skips_generator_and_manifest_backup(self):
        self.settings.source = str(self.root / "own-site")
        self.design.return_value = None
        self.install()
        self.design.assert_called_once_with(self.settings)
        self.assertFalse(any(len(entry.args[0]) > 1 and
                             str(entry.args[0][1]) == str(m.BASE / "studio_site.py")
                             for entry in self.run.call_args_list))
        self.site.assert_any_call("validate", "--source", self.settings.source)
        self.site.assert_any_call("copy", "--source", self.settings.source,
                                  "--output", self.web / "html")
        self.assertEqual(list((self.root / "backups").glob("setup-*/site-manifest.json")), [])
        self.assertFalse((self.web / "html/site-manifest.json").exists())
        self.bootstrap.ensure_packages.assert_called_once_with()
        self.guard.commit_automatic.assert_called_once_with()

    def test_reservation_failure_stops_before_bootstrap_docker_or_firewall(self):
        failure = m.Failure("registry reservation failed")
        self.design.side_effect = failure
        with self.assertRaises(m.Failure) as caught:
            self.install()
        self.assertIs(caught.exception, failure)
        self.disk.apply.assert_not_called()
        self.assertEqual(self.bootstrap.mock_calls, [])
        for mock in (self.run, self.inspect, self.free, self.backup, self.site, self.compose):
            mock.assert_not_called()
        self.assert_no_guard_or_start()
        self.assertFalse(self.node.exists())
        self.assertFalse(self.web.exists())
        self.assertEqual(list(self.root.glob("remnanode-site-*")), [])

    def test_generated_profile_and_host_tags_match_and_vary_with_short_id(self):
        short_ids = ("0123456789abcdef", "fedcba9876543210")
        tags = []
        with patch.object(installer.secrets, "token_hex", side_effect=short_ids) as token_hex:
            for short_id in short_ids:
                with self.subTest(short_id=short_id):
                    directory = self.root / ("profile-" + short_id)
                    directory.mkdir()
                    self.assertEqual(installer.generate_profile(
                        NODE_DIGEST, directory, self.settings.domain), (PUBLIC, short_id))
                    profile = self.read_json(directory / "config-profile.json")
                    host = self.read_json(directory / "host-settings.json")
                    self.assertEqual(len(profile["inbounds"]), 1)
                    inbound = profile["inbounds"][0]
                    expected_tag = "VLESS_REALITY_" + short_id
                    self.assertEqual(inbound["tag"], expected_tag)
                    self.assertEqual(host["inboundTag"], inbound["tag"])
                    self.assertEqual(host["shortId"], short_id)
                    self.assertEqual(inbound["streamSettings"]["realitySettings"]["shortIds"],
                                     [short_id])
                    tags.append(inbound["tag"])
            self.assertEqual(token_hex.call_args_list, [call(8), call(8)])
        self.assertEqual(len(set(tags)), len(short_ids))
        self.assertNotIn("VLESS_REALITY", tags)

    def test_instructions_reference_same_generated_tag_as_profile_and_host(self):
        self.install()
        profile = self.read_json(self.node / "config-profile.json")
        host = self.read_json(self.node / "host-settings.json")
        expected_tag = "VLESS_REALITY_" + self.short_id
        self.assertEqual(profile["inbounds"][0]["tag"], expected_tag)
        self.assertEqual(host["inboundTag"], expected_tag)
        instructions = (self.node / "PANEL-SETUP.txt").read_text(encoding="utf-8")
        self.assertIn("включите inbound " + expected_tag + " ", instructions)
        self.assertNotIn("включите inbound VLESS_REALITY ", instructions)

    def test_guard_order_validation_then_apply_automatic_commit_then_start(self):
        self.install()
        calls = self.events.mock_calls
        checkpoints = [call.compose(self.web, "config", "--quiet"),
                       call.compose(self.node, "config", "--quiet"),
                       call.bootstrap.install_logrotate(),
                       call.bootstrap.prepare_firewall("192.0.2.1", [22, 2200]),
                       call.guard.apply(), call.commit_automatic(),
                       call.compose(self.web, "up", "-d", "--no-build", "--pull", "never"),
                       call.https("node.example.com", 9443, PAGE, timeout=180),
                       call.compose(self.node, "up", "-d", "--no-build", "--pull", "never")]
        indices = [calls.index(item) for item in checkpoints]
        self.assertEqual(indices, sorted(indices))
        self.bootstrap.ensure_packages.assert_called_once_with()
        self.bootstrap.ensure_docker.assert_called_once_with()
        self.assertEqual(self.inspect.call_args_list, [call("remnanode"), call("remnanode-web"),
                                                     call("caddy-selfsteal")])
        self.assertEqual(self.free.call_args_list, [call(80), call(443), call(2222), call(9443)])

    def test_generated_profile_validation_is_networkless_and_mounts_logs(self):
        self.install()
        commands = [entry.args[0] for entry in self.run.call_args_list]
        validation = next(args for args in commands if "-test" in args)
        self.assertIn("--network", validation)
        self.assertEqual(validation[validation.index("--network") + 1], "none")
        mounts = [str(validation[i + 1]) for i, arg in enumerate(validation) if arg == "--mount"]
        self.assertEqual(len(mounts), 2)
        self.assertTrue(any("dst=/config.json,readonly" in item for item in mounts))
        self.assertTrue(any("dst=/var/log/remnanode" in item for item in mounts))

    def test_firewall_is_only_prepared_after_both_fresh_configs_exist(self):
        def prepare(panel_ip, ssh_ports):
            self.assertEqual((panel_ip, ssh_ports), ("192.0.2.1", [22, 2200]))
            for folder in (self.node, self.web):
                self.assertTrue((folder / "docker-compose.yml").is_file())
            self.assertTrue((self.web / "html/index.html").is_file())
            self.guard.apply.assert_not_called()
            self.guard.commit_automatic.assert_not_called()
            self.confirm.assert_not_called()
            return self.guard
        self.bootstrap.prepare_firewall.side_effect = prepare
        self.install()
        self.bootstrap.prepare_firewall.assert_called_once_with("192.0.2.1", [22, 2200])

    def test_generated_source_failure_does_not_prepare_firewall_or_services(self):
        original_command = self.command
        def fail_generator(args, **kwargs):
            if len(args) > 1 and str(args[1]) == str(m.BASE / "studio_site.py"):
                raise m.Failure("site generator failed")
            return original_command(args, **kwargs)
        self.run.side_effect = fail_generator
        with self.assertRaisesRegex(m.Failure, "site generator failed"):
            self.install()
        self.assert_no_guard_or_start()
        self.assertFalse(self.node.exists())
        self.assertFalse(self.web.exists())
        self.assertEqual(list(self.root.glob("remnanode-site-*")), [])

    def test_firewall_commit_failure_rolls_back_without_starting(self):
        self.guard.commit_automatic.side_effect = m.Failure("firewall commit failed")
        with self.assertRaisesRegex(m.Failure, "firewall commit failed"):
            self.install()
        self.guard.rollback.assert_called_once_with()
        self.guard.commit_automatic.assert_called_once_with()
        self.assert_archived()
        self.stopped.assert_not_called()
        self.assertFalse(any(c.args[1] in ("up", "down") for c in self.compose.call_args_list))

    def test_existing_container_refused_before_pull_backups_or_firewall(self):
        self.inspect.return_value = {"State": {"Status": "running"}}
        with self.assertRaises(m.Failure):
            self.install()
        self.run.assert_not_called()
        self.backup.assert_not_called()
        self.assert_no_guard_or_start()
        self.assertFalse(self.node.exists())
        self.assertFalse(self.web.exists())

    def test_source_validation_failure_never_changes_firewall_or_creates_services(self):
        self.site.side_effect = m.Failure("invalid source")
        with self.assertRaisesRegex(m.Failure, "invalid source"):
            self.install()
        self.assert_no_guard_or_start()
        self.assertFalse(self.node.exists())
        self.assertFalse(self.web.exists())
        self.assertEqual(list(self.root.glob("remnanode-site-*")), [])

    def test_source_copy_failure_archives_partial_backend_before_guard(self):
        def fail_copy(*args):
            if args[0] == "copy":
                raise m.Failure("copy failed")
        self.site.side_effect = fail_copy
        with self.assertRaisesRegex(m.Failure, "copy failed"):
            self.install()
        self.assert_no_guard_or_start()
        self.assertFalse(self.web.exists())
        self.assertFalse(self.node.exists())
        self.assertEqual(len(list((self.root / "backups").glob("failed-web-wizard-*/caddy"))), 1)

    def test_compose_validation_failure_does_not_apply_firewall_or_start(self):
        self.compose.side_effect = m.Failure("compose config failed")
        with self.assertRaisesRegex(m.Failure, "compose config failed"):
            self.install()
        self.assert_no_guard_or_start()
        self.assertFalse(self.web.exists())
        self.assertFalse(self.node.exists())

    def test_firewall_apply_failure_rolls_back_and_archives(self):
        self.guard.apply.side_effect = m.Failure("apply failed")
        with self.assertRaisesRegex(m.Failure, "apply failed"):
            self.install()
        self.guard.rollback.assert_called_once_with()
        self.guard.commit_automatic.assert_not_called()
        self.confirm.assert_not_called()
        self.assert_archived()
        self.stopped.assert_not_called()

    def test_ssh_cancel_rolls_back_before_commit_without_start(self):
        self.guard.commit_automatic.side_effect = m.Failure("SSH local verification failed")
        with self.assertRaisesRegex(m.Failure, "SSH local verification failed"):
            self.install()
        self.guard.apply.assert_called_once_with()
        self.guard.commit_automatic.assert_called_once_with()
        self.guard.rollback.assert_called_once_with()
        self.assert_archived()
        self.assertFalse(any(c.args[1] in ("up", "down") for c in self.compose.call_args_list))

    def test_https_failure_stops_both_before_rollback_and_archive(self):
        self.https.side_effect = m.Failure("HTTPS failed")
        with self.assertRaisesRegex(m.Failure, "HTTPS failed"):
            self.install()
        self.guard.rollback.assert_called_once_with()
        self.assert_archived()
        self.wait.assert_not_called()
        calls = self.events.mock_calls
        checkpoints = [call.compose(self.node, "down"), call.stopped("remnanode"),
                       call.compose(self.web, "down"), call.stopped("remnanode-web"),
                       call.guard.rollback()]
        indices = [calls.index(item) for item in checkpoints]
        self.assertEqual(indices, sorted(indices))
        rollback = calls.index(call.guard.rollback())
        self.assertLess(rollback, calls.index(call.backup("failed-node-wizard")))

    def test_compose_start_failure_rolls_back_after_confirmed_shutdown(self):
        def fail_start(directory, *args):
            if args[0] == "up":
                raise m.Failure("compose up failed")
        self.compose.side_effect = fail_start
        with self.assertRaisesRegex(m.Failure, "compose up failed"):
            self.install()
        self.guard.rollback.assert_called_once_with()
        self.stopped.assert_has_calls([call("remnanode"), call("remnanode-web")])
        self.assert_archived()

    def test_node_health_failure_rolls_back_both_services(self):
        self.wait.side_effect = m.Failure("node health failed")
        with self.assertRaisesRegex(m.Failure, "node health failed"):
            self.install()
        self.guard.rollback.assert_called_once_with()
        self.compose.assert_any_call(self.node, "down")
        self.compose.assert_any_call(self.web, "down")
        self.assert_archived()

    def test_interrupt_during_https_also_rolls_back(self):
        interrupted = KeyboardInterrupt()
        self.https.side_effect = interrupted
        with self.assertRaises(KeyboardInterrupt) as caught:
            self.install()
        self.assertIs(caught.exception, interrupted)
        self.guard.rollback.assert_called_once_with()
        self.assert_archived()

    def assert_retained_after_unknown_shutdown(self):
        self.guard.rollback.assert_not_called()
        self.assertTrue((self.node / "docker-compose.yml").is_file())
        self.assertTrue((self.web / "docker-compose.yml").is_file())
        self.assertEqual((self.web / "html/index.html").read_text(encoding="utf-8"), PAGE)
        self.assertFalse((self.node / "managed.json").exists())
        self.assertFalse(list((self.root / "backups").glob("failed-*")))
        self.guard.commit_automatic.assert_called_once_with()

    def test_down_failure_keeps_restrictive_firewall_and_live_mounts(self):
        self.https.side_effect = m.Failure("HTTPS failed")
        def fail_down(directory, *args):
            if args[0] == "down":
                raise m.Failure("down failed")
        self.compose.side_effect = fail_down
        with self.assertRaisesRegex(m.Failure, "down failed"):
            self.install()
        self.assert_retained_after_unknown_shutdown()

    def test_unconfirmed_shutdown_keeps_firewall_and_files(self):
        self.https.side_effect = m.Failure("HTTPS failed")
        self.stopped.side_effect = m.Failure("container status unknown")
        with self.assertRaisesRegex(m.Failure, "container status unknown"):
            self.install()
        self.assert_retained_after_unknown_shutdown()

    def test_backend_unknown_shutdown_keeps_both_mounts_even_if_node_stopped(self):
        self.https.side_effect = m.Failure("HTTPS failed")
        self.stopped.side_effect = [None, m.Failure("backend still running")]
        with self.assertRaisesRegex(m.Failure, "backend still running"):
            self.install()
        self.assert_retained_after_unknown_shutdown()
        self.stopped.assert_has_calls([call("remnanode"), call("remnanode-web")])


if __name__ == "__main__":
    unittest.main()
