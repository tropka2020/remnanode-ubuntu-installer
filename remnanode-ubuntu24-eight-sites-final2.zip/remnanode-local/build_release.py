#!/usr/bin/env python3
"""Build an allowlisted release without private state, keys or old archives."""
import argparse
import hashlib
from pathlib import Path
import zipfile

MODULES = ('install-remnanode.sh', 'download-install.sh', 'installer.py', 'bootstrap.py', 'host_features.py', 'disk_expand.py', 'check_failed_install.py', 'prepare_fresh_install.py',
           'manage.py', 'progress.py', 'selfsteal.py', 'command_runtime.py',
           'site.py', 'themed_site.py', 'studio_site.py', 'premium_site.py', 'premium_expanded.py', 'premium_state.py',
           'design_catalog.py', 'design_state.py', 'design_registry.py', 'registry_client.py')
DOCS = ('README.md', 'QUICKSTART-V2.md', 'QUICKSTART.md', 'DESIGN-REGISTRY.md', 'TEST-REPORT.md')
FIXTURES = ('tests/fixtures/premium-original-output-sha256.json',)


def build(output):
    from premium_site import ASSET_FILES
    root = Path(__file__).resolve().parent
    output = Path(output).absolute()
    if output.exists():
        raise SystemExit('Archive exists; choose a new output name instead of overwriting.')
    names = list(MODULES + DOCS + FIXTURES) + ['build_release.py']
    names += ['premium_assets/' + name for name in ASSET_FILES]
    names += [p.relative_to(root).as_posix() for p in sorted((root / 'tests').glob('test_*.py'))]
    for name in names:
        path = root / name
        if path.is_symlink() or not path.is_file() or path.stat().st_nlink != 1:
            raise SystemExit('Missing or unsafe release file: ' + name)
    checksum = ''.join(hashlib.sha256((root / name).read_bytes()).hexdigest() + '  ' + name + '\n' for name in names)
    (root / 'SHA256SUMS').write_text(checksum, encoding='utf-8', newline='\n')
    with zipfile.ZipFile(output, 'x', compression=zipfile.ZIP_DEFLATED) as archive:
        for name in names + ['SHA256SUMS']:
            archive.write(root / name, 'remnanode-local/' + name)
    with zipfile.ZipFile(output) as archive:
        if archive.testzip() is not None:
            raise SystemExit('ZIP integrity verification failed.')
    print('Archive:', output.name)
    print('Files:', len(names) + 1)
    print('Bytes:', output.stat().st_size)
    print('SHA256:', hashlib.sha256(output.read_bytes()).hexdigest())


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('output', nargs='?', default='remnanode-ubuntu24-eight-sites.zip')
    build(parser.parse_args().output)
